import logger from "../src/modules/logger";


logger.error({
  'error_message': 'hello',
  'stack': '123123',
  'url': 'sfsdf'
})