process.env.NODE_ENV = 'development'

// // console.info()

// // import hk from "../src/modules/stockinfo/hk";

// // hk.stockinfo('116.00001').then(v=>{
// //   console.info(v)
// // })

// // hk.getProfile('00001').then(v=>{
// //   console.info(v)
// // })

// // hk.hgtList().then(v=>{
// //   console.info(v)
// // })

// // hk.gubaFierceUser('hk00700', 4).then(v=>{
// //   console.info(v)
// // })

// // import cheerio from "cheerio";

// // const $ = cheerio.load('<ul><li><span class="red"><a href="http://acttg.eastmoney.com/pub/web_jcb_hqsy_hqbj_01_01_01_1" >DK点自动提示涨跌信号！</a></span></li></ul>')

// //     $('span').each((i, elem)=>{
// //       console.info($('a', elem).attr('href'))
// //       console.info($(elem).attr('class'))
// //       console.info($('a', elem).text())
      
      
      
  
// //     })

// import a from "../src/modules/stockinfo/a";

// // // a.getBulletin('1032').then(v=>{
// // //   console.info(v)
// // // })

// // a.getGuBaActiveUserList('300059', 20).then(v=>{
// //   console.info(v)
// // })

// // import moment from "moment";

// // console.info(moment('2019/8/26 14:29:55', 'YYYY/M/D hh:mm:ss').format('MM-DD'))

// // a.getVote('sz300059').then(v=>{
// //   console.info(v)
// // })

// // a.getLtgd('300059').then(v => {
// //   console.info(v)
// // })

// // import zs from "../src/modules/stockinfo/zs";

// // // zs.getRzrq().then(v=>{
// // //   console.info(v)
  
// // // })

// // import logger from "../src/modules/logger";
// // // logger.info('1111')

// // let aaa = new Error('sdfsdf')

// // console.info(aaa instanceof Error)

// // console.info(aaa.stack)
// // console.info(aaa.name)

// import api_cache from "../src/modules/api_cache";
// const config = require('../config/index.js')

// ;(async function () {
//   let back = await api_cache({
//         url: `${config.getEnvParam('sczmapi')}getMarketOverview?ut=7eea3edcaed734bea9cbfc24409ed989&dpt=wz.sczm`,
//         check_callback: function(data:any) {
//           return data.data.overview != undefined
//         },
//         error_replace: {
//           data: {
//             overview: [
//               {
//                 nt: "深市",
//                 td: '',
//                 v: '',
//                 tv: '',
//                 ts: '',
//                 ns: '',
//                 cn: '',
//                 ttm: ''
//               },
//               {
//                 nt: "中小板",
//                 td: '',
//                 v: '',
//                 tv: '',
//                 ts: '',
//                 ns: '',
//                 cn: '',
//                 ttm: ''
//               },
//               {
//                 nt: "创业板",
//                 td: '',
//                 v: '',
//                 tv: '',
//                 ts: '',
//                 ns: '',
//                 cn: '',
//                 ttm: ''
//               },
//               {
//                 nt: "沪市",
//                 td: '',
//                 v: '',
//                 tv: '',
//                 ts: '',
//                 ns: '',
//                 cn: '',
//                 ttm: ''
//               }
//             ]
//           }
//         }
//       })  

//       console.info(back)
      
// })()
import fund from "../src/modules/stockinfo/fund"

fund.getFundNews('创业板EF').then(v=>{
  console.info(v)
  
})