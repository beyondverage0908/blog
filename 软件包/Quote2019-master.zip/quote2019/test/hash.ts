import encryption from "../src/modules/encryption"

// // console.info(encryption.sha1('http://emres.dfcfw.com/public/footer-1000-html.html'))

// var objecthash = require('object-hash')


// let aa = objecthash({method:'get'})

// // console.info(aa)



// console.info(encryption.sha1('http://emres.dfcfw.com/public/footer-1000-html.html' + aa))

// console.info(encryption.base64('aaaa'))

// console.info(encryption.decodeBase64('YWFhYQ=='))


console.info(encryption.sha1('/hk/02001.html'))
