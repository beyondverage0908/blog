import forex from "../src/modules/stockinfo/forex";

forex.getFinanceCalendar().then(v=>{
  console.info(v)
  
})



// import moment from "moment";

// var aa = '2019/11/9 9:30:00'

// console.info(moment(aa, "YYYY/M/D H:m:s").format('YYYY-MM-DD HH:mm'))
