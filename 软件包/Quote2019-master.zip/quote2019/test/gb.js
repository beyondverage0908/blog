// var axios =  require("axios");

// axios.request({
//   method: 'GET',
//   url: 'http://newsdata.eastmoney.com/rollnewslist_2_1.html',
//   responseType: 'stream'
// }).then(v=>{
//   console.info(v.data)
  
// })


const fs = require('fs')
const cheerio = require('cheerio')
const axios = require('axios')
const iconv = require('iconv-lite')

async function getHtml() {
  const url = `http://newsdata.eastmoney.com/rollnewslist_2_1.html`
  const res = await axios({
    url,
responseType: 'arraybuffer',
  responseEncoding: 'binary'
  })

  //c

  const str = iconv.decode(Buffer.from(res.data), 'gb2312')
  
  console.info(str)

  // return new Promise(resolve => {
  //   const chunks = []
  //   res.data.on('data', chunk => {
  //     chunks.push(chunk)
  //   })
  //   res.data.on('end', () => {
  //     const buffer = Buffer.concat(chunks)
  //     const str = iconv.decode(buffer, 'gb2312')
  //     resolve(str)
  //   })
  // })

  // return new Promise(resolve => {
  //   const chunks = []
  //   res.data.on('data', chunk => {
  //     chunks.push(chunk)
  //   })
  //   res.data.on('end', () => {
  //     const buffer = Buffer.concat(chunks)
  //     const str = iconv.decode(buffer, 'gb2312')
  //     resolve(str)
  //   })
  // })


}

// let str = ''

;(async function(){
  const html = await getHtml()
  console.info(html)
})()