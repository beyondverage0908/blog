import hk from "../src/modules/stockinfo/hk";

hk.announcement('20305').then(v=>{
  console.info(v)
  
})