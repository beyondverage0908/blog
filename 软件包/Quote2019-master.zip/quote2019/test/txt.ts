import txt from "../src/modules/txt";


console.info(txt.format('hello {0} good {1}', 'world', 'gogo'))
