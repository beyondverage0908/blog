/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./jssrc/zs.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./jssrc/zs.ts":
/*!*********************!*\
  !*** ./jssrc/zs.ts ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * 指数页面JS
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var quote_phf = __webpack_require__(/*! ../src/modules/old_zs/quote_phf */ "./src/modules/old_zs/quote_phf.js");
var HistoryViews = __webpack_require__(/*! ../src/modules/old_zs/hisacc */ "./src/modules/old_zs/hisacc.js");
var gotowap_1 = __importDefault(__webpack_require__(/*! ../src/modules/gotowap */ "./src/modules/gotowap/index.ts"));
gotowap_1["default"](kLine.stockCode, newmarket);
var oMarquee = document.getElementById("zhrool");
var iLineHeight = 28;
var iLineCount = 1;
var iScrollAmount = 1;
setTimeout(function () {
    quote_phf.getIndexQuote(20);
    var arg = { def: "", set: "", lns: 0 };
    var HV = new HistoryViews("historyest", arg);
}, 500);
/**
 * Modified by zxw on 19-6-6.
 */
window['chart'] = function (opt) {
    var max = Math.abs(opt.data[0].f62) > Math.abs(opt.data[opt.many - 1].f62) ? Math.abs(opt.data[0].f62) : Math.abs(opt.data[opt.many - 1].f62);
    var _w = 15;
    var W = 26; //减少了两根柱体后+1
    var MM = 80;
    var htm = '';
    for (var i in opt.data) {
        var arrow = opt.data[i].f62 > 0 ? 'up' : 'down';
        var title = (opt.data[i].f62 > 0 ? '主力净流入' : '主力净流出') + '(' + opt.data[i].f14 + '):' + (opt.data[i].f62 / Math.pow(10, 8)).toFixed(2) + "亿元";
        var height = (opt.data[0].f62 == '-' ? 0 : (parseFloat((Math.abs(opt.data[i].f62) / max).toString()) * MM)) + 'px';
        var left = ((1000 - (opt.many - 1) * W - _w) / 2) + parseInt(i) * W + "px";
        var value = opt.data[i].f62 == '-' ? '-' : (Math.abs(opt.data[i].f62) / Math.pow(10, 8)).toFixed(2);
        var bkname = opt.data[i].f14;
        var bkcode = opt.data[i].f12.slice(3);
        htm += '<div class="' + arrow + '" title="' + title + '" style="height:' + height + '; left: ' + left + '"><span>' + value + '</span><div class="i"><a target="_blank" href="http://data.eastmoney.com/bkzj/' + bkcode + '.html">' + bkname + '</a></div></div>';
    }
    htm += opt.appendHTML;
    $("#hqzschart .chart").html(htm);
};
__webpack_require__(/*! ../src/modules/old_zs/quote_min */ "./src/modules/old_zs/quote_min.js");
__webpack_require__(/*! ../src/modules/old_zs/fucs_min */ "./src/modules/old_zs/fucs_min.js");
__webpack_require__(/*! ../src/modules/old_zs/data_min */ "./src/modules/old_zs/data_min.js");
__webpack_require__(/*! ../src/modules/old_zs/emchart_min */ "./src/modules/old_zs/emchart_min.js");


/***/ }),

/***/ "./src/modules/cookie/index.ts":
/*!*************************************!*\
  !*** ./src/modules/cookie/index.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * 浏览器操作cookie
 */
exports.__esModule = true;
exports["default"] = {
    /**
     * 获取cookie
     * @param name cookie名称
     */
    get: function (name) {
        var xarr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
        if (xarr != null)
            return decodeURIComponent(xarr[2]);
        return null;
    },
    /**
     * 设置cookie
     * @param key cookie名称
     * @param value cookie的值
     * @param expiredays 过期时间（天）
     * @param domain cookie的domain
     */
    set: function (key, value, expiredays, domain) {
        var cookiestr = key + "=" + escape(value);
        if (expiredays != undefined) {
            var exdate = new Date();
            exdate.setDate(exdate.getDate() + expiredays);
            cookiestr += ";expires=" + exdate.toUTCString();
        }
        if (domain != undefined) {
            cookiestr += ";domain=" + domain;
        }
        cookiestr += ';path=/';
        document.cookie = cookiestr;
    },
    /**
     * 删除cookie
     * @param key cookie名称
     * @param domain cookie的domain
     */
    del: function (key, domain) {
        var exdate = new Date((new Date).getTime() - 1);
        if (domain) {
            document.cookie = key + '=;path=/;expires=' + exdate.toUTCString() + ';domain=' + domain;
        }
        else {
            document.cookie = key + '=;path=/;expires=' + exdate.toUTCString();
        }
    }
};


/***/ }),

/***/ "./src/modules/gotowap/index.ts":
/*!**************************************!*\
  !*** ./src/modules/gotowap/index.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * 跳转wap网站
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var cookie_1 = __importDefault(__webpack_require__(/*! ../cookie */ "./src/modules/cookie/index.ts"));
function isMobile() {
    var ua = navigator.userAgent;
    var res = false;
    var ipad = ua.match(/(iPad).*OS\s([\d_]+)/), isIphone = !ipad && ua.match(/(iPhone\sOS)\s([\d_]+)/), isAndroid = ua.match(/(Android)\s+([\d.]+)/) && ua.match(/(Mobile)\s+/), isMobile = isIphone || isAndroid;
    if (isMobile) {
        res = true;
    }
    else {
        res = false;
    }
    return res;
}
/**
 * 跳转wap
 * @param code 代码
 * @param market 市场
 */
function gotowap(code, market) {
    var isJump = cookie_1["default"].get("has_jump_to_web");
    console.info(isJump);
    if (isJump && isJump == "1") {
        return false;
    }
    if (isMobile()) {
        self.location.href = "https://wap.eastmoney.com/quota/hq/stock?id=" + code + "&mk=" + market;
    }
}
exports["default"] = gotowap;


/***/ }),

/***/ "./src/modules/old_zs/data_min.js":
/*!****************************************!*\
  !*** ./src/modules/old_zs/data_min.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Created by zbc on 14-5-6.
 * modified by zxw on 19-6-1
 */

var $x = function (id) { return "string" == typeof id ? document.getElementById(id) : id; };
//时间随机数
function formatm() {
    var now = new Date();
    return now.getTime();
}
var token = "44c9d251add88e27b65ed86506f6e5da";
var PicR = "http://webquotepic.eastmoney.com/GetPic.aspx?nid={0}.{1}&imageType={2}&token=" + token;

window.allUri = {
    //imageURL: "http://pifm3.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx?ID=3000592&UnitWidth=-6&imageType=KXL&EF=&Formula=RSI&AT=&&type=m5&token=44c9d251add88e27b65ed86506f6e5da"
    imageURL:"http://webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da&nid=0.300059&type=W&unitWidth=-6&ef=&formula=RSI&imageType=KXL&_=1558433993320"
};
window.imageOpition = {
    ID: kLine.stockCode + kLine.stockMarket,
    type: "",
    Formula: "RSI",
    EF: "",
    UnitWidth: -6,
    AT: ""
};

(function () {
    function myselect(ap, func) {
        FUC.addEvent(FUC.$(ap), "mouseenter", function (e) {
            this.getElementsByTagName("dl")[0].style.display = "block";
        }, false)

        FUC.addEvent(FUC.$(ap), "mouseleave", function (e) {
            this.getElementsByTagName("dl")[0].style.display = "none";
        }, false)

        var b = FUC.$(ap).getElementsByTagName("dl")[0]
        var a = b.children;

        for (var i = 0; i < a.length; i++) {
            a[i].onclick = function () {
                var is = i
                FUC.$(ap).getElementsByTagName("span")[0].innerHTML = this.innerHTML;
                FUC.$(ap).getElementsByTagName("span")[0].setAttribute("value", this.getAttribute("value"));
                b.style.display = 'none';
                func && func(this.getAttribute("value"))
            }
        }
    }

    //myselect("select_flsdb", function (a) {
    //    if (a != "") {
    //        var rPort = document.getElementsByName("pkdb");
    //        rPort[0].checked = true
    //    }
    //})
    /*myselect("select2", function (a) {
        var hyid = $x("pylist").getAttribute("value");
        window.phIsFirst = true;
        phrank(a, hyid);
    })
    myselect("select3", function (a) {

    })*/

    LiPic.changeDiv({
        id: "tab_hyzdfb",
        dom: ["cnt_hyzfb", "cnt_hydfb"],
        selectedClass: "cur"
    });

    LiPic.changeDiv({
        id: "tab_gnzdfb",
        dom: ["cnt_gnzfb", "cnt_gndfb"],
        selectedClass: "cur"
    });

    LiPic.changeDiv({
        id: "tab_zjlfb",
        dom: ["cnt_zjl", "cnt_fb"],
        selectedClass: "cur"
    });

    LiPic.changeDiv2({
        id: "tab_fxmb",
        selectedClass: "cur",
        dom: ["cnt_dpfx", "cnt_mb"],
        domt: ["tit_dpfx", "tit_mb"]
    });

    //LiPic.changeDiv({
    //    id: "tab_wyzgzgp",
    //    dom: ["cnt_day3", "cnt_day5", "cnt_day10", "cnt_day20"],
    //    selectedClass: "cur"
    //});
    LiPic.changeDiv({
        id: "tab_dkdc",
        dom: ["dcoxa", "dcoxb", "dcoxc"],
        selectedClass: "cur"
    });

    new LIB.actTab({
        pnode: "tab_picr",
        callBacks: function (a) {
            imgChangeNode1(a);
        }
    });

    new LIB.actTab({
        pnode: "tab_pick",
        callBacks: getImageValue
    });

    function imgChangeNode1(a) {
        var t = parseInt(a.getAttribute("index"));
        if (t == 0) {
            $x("picr").src = PicR.replace("{0}", _this._Market).replace("{1}", _this._Code).replace("{2}", "r") + "&rt=" + formatm();
        } else {
            var md = "M" + t;
            $x("picr").src = "http://webquotepic.eastmoney.com/GetPic.aspx?imagetype=t&type=" + md + "&nid=" + _this._Market+ '.' + _this._Code  + "&token=" + window.token + "&rt=" + formatm();
        }
    }
    function changeImage() {
        allUri.imageURL = FUC.changeURL(allUri.imageURL, imageOpition);
        var PicUrl = allUri.imageURL + "&" + Math.random();
        FUC.$("pick").setAttribute("src", PicUrl);
    }
    function InitFQImg() {
        var num = GetCookie("emhq_picfq");
        var itemName = "不复权";
        var itemNum = num == "" ? "0" : num;
        switch (num) {
            case "0": {
                window.imageOpition.FA = "";
                window.imageOpition.BA = "";
                break;
            }
            case "1": {
                window.imageOpition.FA = true;
                window.imageOpition.BA = "";
                itemName = "前复权";
                break;
            }
            case "2": {
                window.imageOpition.FA = "";
                window.imageOpition.BA = true;
                itemName = "后复权";
                break;
            }
        }
        changeImage();
    }
    function getImageValue(arr) {
        imageOpition.type = arr.getAttribute("value");
        changeImage();
        return;
    }
    new LiPic.change({
        dom1: FUC.$("zkeyb"), dom2: FUC.$("zkeyc"), callbacks: function (arg) {
            imageOpition.Formula = arg.getAttribute("value");
            changeImage();
        }
    });
    new LiPic.change({
        dom1: FUC.$("zkeyc"), dom2: FUC.$("zkeyb"), callbacks: function (arg) {
            imageOpition.Formula = arg.getAttribute("value");
            changeImage();
        }
    });
    new LiPic.change({
        dom1: FUC.$("zkeya"), callbacks: function (arg) {
            imageOpition.EF = arg.getAttribute("value");
            changeImage();
        }
    });

    //拉长 缩短线
    FUC.addEvent(FUC.$("picklc"), "click", function (e) {
        var width = imageOpition.UnitWidth;
        if (width <= -8) return;
        imageOpition.UnitWidth = width - 1;
        changeImage();
    }, false);
    FUC.addEvent(FUC.$("picksd"), "click", function (e) {
        var width = imageOpition.UnitWidth;
        if (width >= 0) return;
        imageOpition.UnitWidth = width + 1;
        changeImage();
    }, false);

    FUC.addEvent(FUC.$("js_show"), "click", function (e) {
        showjs();
    }, false);

    FUC.addEvent(FUC.$("image_show"), "click", function (e) {
        showimg();
    }, false);

    InitFQImg();

    var not_h5 = !+"\v1";
    if (not_h5) {
        $("#js_show").hide();
        $(".img_show").click();
    }
    else {
        $("#js_show").click(function () {
            showjs();
        });
        var ct = GetCookie("em_hq_fls");
        if (!ct) {
            $("#js_show").click();
        } else if ((ct === "old")){
            $("#img_show").click();
            $("#js_box").addClass("hidefixed");
        } else {
            $("#js_show").click();
        }

    }
    
})();

/***/ }),

/***/ "./src/modules/old_zs/emchart_min.js":
/*!*******************************************!*\
  !*** ./src/modules/old_zs/emchart_min.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

$(document).ready(function () {
    var not_h5 = !+"\v1";
    if (not_h5) {
        $(".js_show").hide();
        $(".picrbox a").show()
        $(".tox a").show()
        return;
    }

    $.ajax({
        url: "//hqres.eastmoney.com/emcharts/v3/lts/emcharts.min.js",
        method: "GET",
        cache: true,
        scriptCharset: 'UTF-8',
        dataType: "script"
    }).success(function () {
        loadTimeSharingChart();
        loadCandleChart();
    });

    /**
     * 分时图
     */
    function loadTimeSharingChart() {
        $("#emchart-0").append($('<div class="loading"></div>'));
        var timer,
            chart = new emcharts3.time({
                container: "#emchart-0",
                width: 578,
                height: 276,
                type: "r",
                iscr: false,
                gridwh: {
                    height: 25,
                    width: 50
                },
                padding: {
                    top: 0,
                    bottom: 5
                },
                color: {
                    line: "#326fb2",
                    fill: ["rgba(101,202,254, 0.2)", "rgba(101,202,254, 0.1)"]
                },
                onClick: function () {
                    window.open(window.location + "#fullScreenChart", "_blank")
                    //window.open("//quote.eastmoney.com/chart/h5.html?id=" + (window.Def._Code + window.Def._Market) + "&type=" + chart.option.type);
                },
                onComplete: function () {
                    //$("#emchart-0").remove('.loading');
                },
                onError: function (err) {
                    console.error(err)
                }
            });
        function init() {
            events();
            if (window.bjTime && Def.PanQian(new Date(window.bjTime))) {
                $(".changeFenshiTab span[type=panqian]").click();
            }
            else $(".changeFenshiTab span[type=oneday]").click();
            load()
            timer = setInterval(function () {
                load();
            }, 20 * 1000);
        }

        function load(type, iscr) {
            if (typeof type === "string" && type) chart.option.type = type;
            if (typeof iscr === "boolean" && iscr) chart.option.iscr = iscr;
            // 加载分时
            $.ajax({
                url: "http://push2his.eastmoney.com/api/qt/stock/trends2/get",
                dataType: "jsonp",
                scriptCharset: 'utf-8',
                data: {
                    secid: ((window.Def._Market == 1 ? 1 : 0) + '.' + window.Def._Code),
                    ut: 'fa5fd1943c7b386f172d6893dbfba10b',
                    fields1: 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11',
                    fields2: 'f51,f53,f56,f58',
                    iscr: 0,
                    ndays: chart.option.type == 'r' ? 1 : chart.option.type.slice(1, 2)
                },
                jsonp: "cb",
                success: function (res1) {
                    //console.log("分时图数据fenshitu>>",res1)
                    var obj = {
                        name: window.Def._Name || res1.data.name,
                        code: window.Def._Code || res1.data.code,
                        info: {
                            "c": "",
                            "h": "",
                            "l": "",
                            "o": "",
                            "a": "",
                            "v": "",
                            "yc": res1.data ? res1.data.preClose : $("#gt7").text(), //昨收
                            "time": "",
                            "ticks": "34200|54000|0|34200|41400|46800|54000",
                            "total": res1.data ? res1.data.trendsTotal : 0, //多少数据
                            "pricedigit": "0.00",
                            "jys": "2",
                            "Settlement": "-"
                        },
                        data: []
                    }
                    var dataList = res1.data ? res1.data.trends : []
                    for (var i = 0; i < dataList.length; i++) {
                        var arr = dataList[i].split(",")
                        var str = arr[0] + ',' + arr[1] + ',' + (arr[2]) + ',' + arr[3] + ',' + 0
                        obj.data.push(str)
                    }
                    var option = {
                        container: "#emchart-0",
                        width: 578,
                        height: 276,
                        type: chart.option.type,
                        iscr: false
                    }
                    var timechart = new emcharts3.time(option);
                    timechart.start(false)
                    timechart.setData({
                        time: obj
                    });
                    timechart.redraw();
                    timechart.stop();
                },
                error: function (e) {
                    console.error(e);
                }
            });
            //$.ajax({
            //    url: "//pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js?rtntype=5&token=4f1862fc3b5e77c150a2b985b12db0fd",
            //    dataType: "jsonp",
            //    scriptCharset: 'utf-8',
            //    data: {
            //        id: (window.Def._Code + window.Def._Market),
            //        type: chart.option.type,
            //        iscr: chart.option.iscr
            //    },
            //    jsonp: "cb",
            //    success: function (json) {
            //        console.log(json)
            //        if (!json || json.stats === false) return false;
            //        chart.setData({
            //            time: json
            //        });
            //        chart.redraw();
            //    },
            //    error: function (e) {
            //        console.error(e);
            //    }
            //});

        }

        function events() {
            $(".changeFenshiTab span").click(function (e) {
                var params = chart.option;
                params.iscr = false;
                $(".changeFenshiTab span").removeClass("cur");
                $(this).addClass("cur");
                switch ($(this).attr("type")) {
                    case "panqian":
                        params.iscr = true;
                        params.type = "r";
                        break;
                    case "oneday":
                        params.type = "r";
                        break;
                    case "twoday":
                        params.type = "t2";
                        break;
                    case "threeday":
                        params.type = "t3";
                        break;
                    case "fourday":
                        params.type = "t4";
                        break;
                    case "fiveday":
                        params.type = "t5";
                        break;
                }
                load();
                return false;
            });
        }

        init();
    }

    /**
     * K图
     */
    function loadCandleChart() {
        $("#emchartk").html($('<div class="loading"></div>'));
        var timer,
            kchart = new emcharts3.k2({
                container: "#emchartk",
                width: 585,
                height: 390,
                padding: {
                    top: 0,
                    bottom: 0
                },
                scale: {
                    pillar: 60,
                    min: 10
                },
                popWin: { type: "move" },
                maxin: {
                    //show: true,
                    lineWidth: 30,     // 线长
                    skewx: 0,            // x偏移   
                    skewy: 0            // y偏移
                },
                onComplete: function () {
                    $("#emchartk").remove('.loading');
                },
                onClick: function () {
                    var val = $("#changektab span.cur").attr("value"), type = 'k';
                    switch (val) {
                        case "D":
                            type = "k";
                            break;
                        case "W":
                            type = "wk";
                            break;
                        case "M":
                            type = "mk";
                            break;
                        case "M5":
                            type = "m5k";
                            break;
                        case "M15":
                            type = "m15k";
                            break;
                        case "M30":
                            type = "m30k";
                            break;
                        case "M60":
                            type = "m60k";
                            break;
                        default: break;
                    }
                    window.open(window.location + "#fullScreenChart", "_blank")
                    //window.open("//quote.eastmoney.com/chart/h5.html?id=" + (window.Def._Code + window.Def._Market) + "&type=" + type);
                },
                onError: function (e) {
                    console.error(e)
                }
            }),
            params = {
                id: window.Def._Code + window.Def._Market,
                type: "k",
                authorityType: ""
            };
        function init() {

            events();
            // 复权判断
            var fq = GetCookie("emhq_picfq");
            if (fq === "1") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=before]").html());
                params.authorityType = "fa";
            }
            else if (fq === "2") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=before]").html());
                params.authorityType = "ba";
            }

            load();
        }

        function load() {
            $("#js_box").removeClass("hidefixed");
            $("#js_box").removeClass("hidefixed");
            clearTimeout(timer);
            var _load = function () {
                var params1 = {
                    secid: ((window.Def._Market == 1 ? 1 : 0) + '.' + window.Def._Code),
                    ut: 'fa5fd1943c7b386f172d6893dbfba10b',
                    fields1: 'f1,f2,f3,f4,f5',
                    fields2: 'f51,f52,f53,f54,f55,f56,f57,f58',
                    klt: params.type == 'k' ? 101 : params.type == 'wk' ? 102 : params.type == 'mk' ? 103 : params.type == 'm5k' ? 5 : params.type == 'm15k' ? 15 : params.type == 'm30k' ? 30 : 60,
                    fqt: 0,
                    beg: "19900101",
                    end: "20220101"
                }
                $.ajax({
                    url: "http://push2his.eastmoney.com/api/qt/stock/kline/get",
                    dataType: "jsonp",
                    scriptCharset: 'utf-8',
                    data: params1,
                    jsonp: "cb",
                    success: function (resk) {
                        //console.log("kkkk>>", resk)
                        var obj = {
                            "name": resk.data.name,
                            "code": resk.data.code,
                            "info": {
                                "c": "",
                                "h": "",
                                "l": "",
                                "o": "",
                                "a": "",
                                "v": "",
                                "yc": $("#gt7").text(),
                                "time": "",
                                "ticks": "34200|54000|0|34200|41400|46800|54000",
                                "total": resk.data.dktotal,
                                "pricedigit": "0.00",
                                "jys": "2",
                                "Settlement": "-"
                            },
                            data: []
                        }
                        for (var i = 0; i < resk.data.klines.length; i++) {
                            var item = resk.data.klines[i] + '%'
                            obj.data.push(item)
                        }
                        kchart.setData({
                            k: obj
                        });
                        kchart.draw();
                    },
                    error: function (e) {
                        console.error(e);
                    },
                    complate: function () {
                        timer = setTimeout(load, 60 * 1000);
                    }
                });
            };
            _load();
        }

        function events() {
            $("#beforeBackRight dl dd").click(function () {
                $("#beforeBackRight span").html($(this).html());
                var v = $(this).attr("value");
                $("#beforeBackRight").attr("value", v);
                params.authorityType = v === "before" ? "fa" : v === "back" ? "ba" : "";
                load();
                var at = v === "before" ? "1" : v === "back" ? "2" : "0";
                if ($("#js_box").is(":visible")) {
                    $("#select4 dd[value=" + at + "]").click();
                    WriteCookie("emhq_picfq", at, 8760);
                }
            });

            $("#changektab span").click(function () {
                $("#changektab span").removeClass("cur");
                $(this).addClass("cur");
                switch ($(this).attr("value")) {
                    case "D":
                        params.type = "k";
                        break;
                    case "W":
                        params.type = "wk";
                        break;
                    case "M":
                        params.type = "mk";
                        break;
                    case "M5":
                        params.type = "m5k";
                        break;
                    case "M15":
                        params.type = "m15k";
                        break;
                    case "M30":
                        params.type = "m30k";
                        break;
                    case "M60":
                        params.type = "m60k";
                        break;
                }
                load();
            });

            $("#scale-plus").click(function () {
                kchart.shorten(-1, 0.1);
            });

            $("#scale-minus").click(function () {
                kchart.elongate(-1, 0.1);
            });

            $("#beforeBackRight").mouseenter(function () {
                this.getElementsByTagName("dl")[0].style.display = "block";
            });

            $("#beforeBackRight").mouseleave(function () {
                this.getElementsByTagName("dl")[0].style.display = "none";
            });
        }
        init();
    }
});



/***/ }),

/***/ "./src/modules/old_zs/fucs_min.js":
/*!****************************************!*\
  !*** ./src/modules/old_zs/fucs_min.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/*
 * Created by zbc on 14-5-6
 * modified by zxw on 19-6-1
 */

(function () {
    var Browser = window.Browser = { ie: /msie/.test(window.navigator.userAgent.toLowerCase()), moz: /gecko/.test(window.navigator.userAgent.toLowerCase()), opera: /opera/.test(window.navigator.userAgent.toLowerCase()), safari: /safari/.test(window.navigator.userAgent.toLowerCase()) };

    var FUC = window.FUC = {
        add: function (a, fuc) {
            FUC[a] = fuc;
        },
        $: function (a) {
            return document.getElementById(a);
        },
        xcopy: function (a, b) {
            for (var i in a) {
                b[i] !== undefined && (b[i] = a[i])
            }
            return b;
        },
        addClass: function (a, t) {
            if (t.className.indexOf(a) < 0) {
                t.className = t.className + " " + a;
            }
        },
        removeClass: function (a, t) {
            if (t.className.indexOf(a) > -1) {
                a = new RegExp("\s{0,}" + a);
                t.className = t.className.replace(a, "");
            }
        },
        botherAddClass: function (a, t) {

        },
        ajax: function (opt) {
            var opts = {
                url: "",
                method: "post",
                success: function () {

                },
                error: function () {

                }
            }
            var http = new XMLHttpRequest() || new ActiveXObject("Microsoft.XMLHTTP");
            http.onreadystatechange = function () {
                if (this.readyState === 4 && this.status === 200) {
                    opts.success();
                    return;
                }
            }

        },
        dataJsLoader: function (uri, cb, charset) {
            var _script = document.createElement("script");
            _script.type = "text/javascript";
            _script.charset = charset || "utf-8";
            _script._fun = typeof cb != "undefined" ? cb : new Function();
            _script[document.all ? "onreadystatechange" : "onload"] = function () {
                if (document.all && this.readyState != "loaded" && this.readyState != "complete") {
                    return;
                }
                this._fun(this);
                this._fun = null;
                this[document.all ? "onreadystatechange" : "onload"] = null;
                var _t = this;
                _t.parentNode.removeChild(_t);
            };
            _script.src = uri;
            document.getElementsByTagName("head").item(0).appendChild(_script);


        },
        addEvent: function (el, type, handler, capture) {
            if (!el) return;
            function withinElement(handler) {
                return function (e) {
                    var parent = e.relatedTarget;
                    while (parent && parent != this) {
                        try {
                            parent = parent.parentNode;
                        }
                        catch (e) {
                            break;
                        }
                    }
                    if (parent != this)
                        handler.call(this, e);
                };
            };

            if (typeof el.addEventListener != 'undefined') {
                if (type === 'mouseenter') {
                    el.addEventListener('mouseover', withinElement(handler), capture);
                } else if (type === 'mouseleave') {
                    el.addEventListener('mouseout', withinElement(handler), capture);
                } else {
                    el.addEventListener(type, handler, capture);
                }
            } else if (typeof el.attachEvent != 'undefined') {
                el['on' + type] = function () {
                    handler.call(this);
                };
            }
        },
        vcodeC: function (code) {
            var one = code.substr(0, 1);
            var three = code.substr(0, 3);
            if (one == "5" || one == "6" || one == "9") {
                //上证股票
                return "1";
            }
            else {
                if (three == "009" || three == "126" || three == "110" || three == "201" || three == "202" || three == "203" || three == "204") {
                    //上证股票
                    return "1";
                }
                else {
                    //深圳股票
                    return "2";
                }
            }
        },
        getCookie: function (name) {
            var bikky = document.cookie;
            name += "=";
            var i = 0;
            while (i < bikky.length) {
                var offset = i + name.length;
                if (bikky.substring(i, offset) == name) {
                    var endstr = bikky.indexOf(";", offset);
                    if (endstr == -1) endstr = bikky.length;
                    return unescape(bikky.substring(offset, endstr));
                }
                i = bikky.indexOf(" ", i) + 1;
                if (i == 0) break;
            }
            return null;
        },
        setCookie: function (c_name, value, expiredays) {
            var exdate = new Date();
            exdate.setDate(exdate.getDate() + expiredays);
            document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : "; expires=" + exdate.toGMTString());
        },
        insertText: function (obj, text) {
            if (document.selection) {
                obj.focus();
                var sel = document.selection.createRange();
                sel.text = text;
            }
            else {
                var prefix, main, suffix;
                prefix = obj.value.substring(0, obj.selectionStart);
                main = obj.value.substring(obj.selectionStart, obj.selectionEnd);
                suffix = obj.value.substring(obj.selectionEnd);
                if (main == "") {
                    obj.value = prefix + text + suffix;
                }
                else {
                    obj.value = prefix + text + suffix;
                }
            }
        },
        insertAfter: function (newElement, targetElement) {
            var parent = targetElement.parentNode;
            if (parent.lastChild == targetElement) {
                parent.appendChild(newElement);
            }
            else {
                parent.insertBefore(newElement, targetElement.nextSibling);
            }
        },
        createElement: function (option) {
            var obj = document.createElement(option.dom);
            obj.id ? obj.id = option.id : "";
            obj.className ? obj.className = option.className : "";
            obj.innerHTML = option.html;
            return obj;
        },
        changeURL: function (url, urlDom) {
            var marketId = urlDom.ID.slice(6, 7) == 2 ? 0 : urlDom.ID.slice(6, 7)
            var url1 = 'http://webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da&nid=' + marketId + '.' + urlDom.ID.slice(0, 6) + '&unitWidth=' + urlDom.UnitWidth + '&ef=' + urlDom.EF + '&formula=' + urlDom.Formula + '&type=' + urlDom.type + '&imageType=KXL&'
            return url1;
        }
    }


    var LIB = window.LIB = {
        tab: function (opts) {
            var _opts = {
                pnode: "",
                selectedClass: "cur",
                contentID: "",
                callBacks: []
            }
            _opts = FUC.xcopy(opts, _opts);

            _opts.pnode = FUC.$(_opts.pnode);
            var cn = FUC.$(_opts.contentID);
            var arr = _opts.pnode.children;
            var carr = cn.children;
            for (var i = 0; i < arr.length; i++) {
                arr[i].setAttribute("index", i);
                arr[i].onmouseover = function (event) {
                    var t = this.getAttribute("index");
                    for (var j = 0; j < carr.length; j++) {
                        carr[j].style.display = 'none';
                    }
                    for (j = 0; j < arr.length; j++) {
                        FUC.removeClass(_opts.selectedClass, arr[j])
                    }
                    FUC.addClass(_opts.selectedClass, this);
                    carr[t].style.display = 'block';
                    _opts.callBacks[t] && _opts.callBacks[t]();
                }
            }
        },
        actTab: function (opts) {
            var _opts = {
                pnode: "",
                selectedClass: "cur",
                callBacks: "",
                eventKind: "click"
            }
            _opts = FUC.xcopy(opts, _opts);
            _opts.pnode = FUC.$(_opts.pnode);
            var arr = _opts.pnode.children;

            var handler = function () {
                var t = this.getAttribute("index");
                for (j = 0; j < arr.length; j++) {
                    FUC.removeClass(_opts.selectedClass, arr[j])
                }
                FUC.addClass(_opts.selectedClass, this);
                if (_opts.callBacks) {
                    _opts.callBacks(this);
                }
            }

            for (var i = 0; i < arr.length; i++) {
                arr[i].setAttribute("index", i);
                if (window.attachEvent) {
                    arr[i]["on" + _opts.eventKind] = function () {
                        handler.call(this);
                    }
                } else {
                    arr[i].addEventListener(_opts.eventKind, handler, false);
                }
            }
        }
    };

    var LiPic = window.LiPic = {
        change: function (opts) {
            var _opts = {
                dom1: "",
                dom2: "",
                type: "",
                selectedClass: "at",
                callbacks: ""
            }
            _opts = FUC.xcopy(opts, _opts);
            var li = _opts.dom1.children;
            for (var i = 0; i < li.length; i++) {
                li[i].onclick = function (i) {
                    return function () {
                        for (j = 0; j < li.length; j++) {
                            FUC.removeClass(_opts.selectedClass, li[j])
                        }
                        FUC.addClass(_opts.selectedClass, this);
                        if (_opts.dom2) {
                            var li2 = _opts.dom2.children;
                            for (j = 0; j < li2.length; j++) {
                                FUC.removeClass(_opts.selectedClass, li2[j])
                            }
                            FUC.addClass(_opts.selectedClass, li2[i]);
                            _opts.callbacks(this);
                            return;
                        }
                        _opts.callbacks(this);
                    }
                }(i)
            }
        },
        changeDiv: function (opts) {
            var _opts = {
                id: "",
                dom: [],
                selectedClass: "",
                callBacks: ""
            }
            _opts = FUC.xcopy(opts, _opts);
            var li = document.getElementById(_opts.id).children;
            for (var i = 0; i < li.length; i++) {
                li[i].onmouseover = function () {
                    for (j = 0; j < li.length; j++) {
                        FUC.removeClass(_opts.selectedClass, li[j])
                    }
                    FUC.addClass(_opts.selectedClass, this);
                    for (k = 0; k < _opts.dom.length; k++) {
                        var value = document.getElementById(_opts.dom[k]).getAttribute("value");
                        if (this.getAttribute("value") == value) {
                            document.getElementById(_opts.dom[k]).style.display = "block";
                        } else {
                            document.getElementById(_opts.dom[k]).style.display = "none";
                        }
                    }
                    if (_opts.callBacks) {
                        _opts.callBacks(this);
                    }
                }
            }
        },
        changeDiv2: function (opts) {
            var _opts = {
                id: "",
                dom: [],
                domt: [],
                selectedClass: "",
                callBacks: ""
            }
            _opts = FUC.xcopy(opts, _opts);
            var li = document.getElementById(_opts.id).children;
            for (var i = 0; i < li.length; i++) {
                li[i].onmouseover = function () {
                    for (j = 0; j < li.length; j++) {
                        FUC.removeClass(_opts.selectedClass, li[j])
                    }
                    FUC.addClass(_opts.selectedClass, this);
                    for (k = 0; k < _opts.dom.length; k++) {
                        var value = document.getElementById(_opts.dom[k]).getAttribute("value");
                        if (this.getAttribute("value") == value) {
                            document.getElementById(_opts.dom[k]).style.display = "block";
                            document.getElementById(_opts.domt[k]).style.display = "block";
                        } else {
                            document.getElementById(_opts.dom[k]).style.display = "none";
                            document.getElementById(_opts.domt[k]).style.display = "none";
                        }
                    }
                    if (_opts.callBacks) {
                        _opts.callBacks(this);
                    }
                }
            }
        }
    };

    var numParser = window.numParser = {
        def: function (a) {
            if (a.indexOf("-") >= 0) {
                return a;
            }
            a = parseFloat(a)
            if (a > 100000000) {
                return (a / 100000000).toFixed(2) + "亿";
            } else {
                return a > 10000 ? ((a / 10000).toFixed(2) + "万") : a;
            }
        },
        tos: function (a) {
            a = parseFloat(a) / 100
            return numParser.def(a) + "手"
        }
    }

    function formatm() {
        var now = new Date();
        return now.getDate() + "" + now.getHours() + "" + now.getMinutes() + "";
    }

})()

/***/ }),

/***/ "./src/modules/old_zs/hisacc.js":
/*!**************************************!*\
  !*** ./src/modules/old_zs/hisacc.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function HistoryViews(obj, arg) {
    this.WriteCookie = function (name, value, hours) {
        var expire = "";
        if (hours != null) {
            expire = new Date((new Date()).getTime() + hours * 3600000);
            expire = ";expires=" + expire.toGMTString() + ";path=/;domain=.eastmoney.com";
        }
        document.cookie = name + "=" + escape(value) + expire;
    };

    this.GetCookie = function (name) {
        var dc = document.cookie;
        var prefix = name + "=";
        var begin = dc.indexOf("; " + prefix);
        if (begin == -1) {
            begin = dc.indexOf(prefix);
            if (begin != 0) { return null };
        }
        else {
            begin += 2;
        }
        var end = document.cookie.indexOf(";", begin);
        if (end == -1) {
            end = dc.length;
        }
        return unescape(dc.substring(begin + prefix.length, end));
    };
    this.setvi = 1;
    if (arg.def == "") {
        arg.def = ["a-sh-600000-浦发银行", "a-sz-300017-网宿科技", "a-sh-600020-中原高速", "a-sh-600005-武钢股份", "a-sh-600004-白云机场", "a-sz-162605-景顺鼎益", "a-sz-159901-深100ETF", "a-sh-600015-华夏银行", "a-sz-002364-中恒电气", "a-sh-600128-弘业股份", "a-sz-002357-富临运业", "a-sz-002363-隆基机械", "a-sh-601106-中国一重", "a-sz-002013-中航精机", "a-sz-000550-江铃汽车"];
    }
    if (arg.def == "0") {
        this.setvi = 0;
    }
    this.mb = { "a": "http://quote.eastmoney.com/[#MARKET#][#CODE#].html", "b": "http://guba.eastmoney.com/topic,[#CODE#].html", "c": "http://fund.eastmoney.com/[#CODE#].html", "d": "http://quote.eastmoney.com/hk/[#CODE#].html", "e": "http://quote.eastmoney.com/gzqh/[#CODE#].html", "f": "http://quote.eastmoney.com/zs[#CODE#].html", "g": "http://quote.eastmoney.com/qihuo/[#CODE#].html", "h": "http://quote.eastmoney.com/hk/[#CODE#].html", "i": "http://quote.eastmoney.com/hk/zs[#CODE#].html", "j": "http://quote.eastmoney.com/us/[#CODE#].html", "k": "http://quote.eastmoney.com/forex/[#CODE#].html", "l": "http://quote.eastmoney.com/[#MARKET#][#CODE#].html", "m": "http://quote.eastmoney.com/gb/zs[#CODE#].html", "n": "http://quote.eastmoney.com/globalfuture/[#CODE#].html", "o": "http://quote.eastmoney.com/qiquan/[#CODE#]_[#MARKET#].html", "p": "http://quote.eastmoney.com/3ban/[#MARKET#][#CODE#].html" };
    if (this.GetCookie("em_hq_fls") == "new") {
        this.mb.a = "http://quote.eastmoney.com/flash/[#MARKET#][#CODE#].html";
    }
    //[类型(a:行情,b:股吧,c:基金,d:港股,e:股指期货,f:大盘指数,g:期货,h:港股,i:港股指数,j:美股,k:外汇,l:债券,m:全球指数,n:国际期货,o:期权,p:3板),市场(没有为0),代码,名称]
    this.len = arg.lns;
    if (arg.lns == 0 || arg.lns > arg.def.length || arg.lns == "" || arg.lns == "undefined") {
        this.len = arg.def.length;
    }
    this.addlen = 0;
    this.ret = [];
    this.init = function () {
        if (arg.set == "") {
            this.ReadInfo();
        }
        else {
            this.SetInfo();
        }
    };
    this.ReadInfo = function () {
        var Str = "<ul>";
        var showlist = new Array();
        var _ckv = this.GetCookie("HAList");
        var ckv;
        if (_ckv != "" && _ckv != null) {
            var ckv = _ckv.split(',');
            if (ckv.length < this.len) {
                this.addlen = this.len - ckv.length;
            }
        }
        else {
            ckv = arg.def;
        }
        for (var i = 0; i < ckv.length; i++) {
            if (i >= this.len) { break; }
            var _tmcn = ckv[i]; showlist.push(ckv[i]);
            var tmcn = _tmcn.split('-');
            if (tmcn.length == 4) {
                var tp = tmcn[0]; var mk = tmcn[1]; var cd = tmcn[2]; var nm = tmcn[3]; var lk = "";
                var _lk = eval("this.mb." + tp);
                var lk = _lk.replace("[#MARKET#]", mk).replace("[#CODE#]", cd);
                Str += "<li><a href=\"" + lk + "\" target=\"_blank\">" + nm + "</a></li>";
                this.ret.push(mk + "-" + cd + "-" + nm);
            }
        }
        if (this.addlen > 0) {
            var ed = 0;
            for (var i = 0; i < arg.def.length; i++) {
                if (showlist.toString().indexOf(arg.def[i]) == -1) {
                    var tmcn = arg.def[i].split('-');
                    if (tmcn.length == 4) {
                        var tp = tmcn[0]; var mk = tmcn[1]; var cd = tmcn[2]; var nm = tmcn[3]; var lk = "";
                        var _lk = eval("this.mb." + tp);
                        var lk = _lk.replace("[#MARKET#]", mk).replace("[#CODE#]", cd);
                        Str += "<li><a href=\"" + lk + "\" target=\"_blank\">" + nm + "</a></li>";
                        this.ret.push(mk + "-" + cd + "-" + nm);
                        ed++;
                    }
                }
                if (ed >= this.addlen) { break; }
            }
        }
        Str += "</ul>";
        if (this.setvi == 1) {
            document.getElementById(obj).innerHTML = Str;
        }
    };

    this.SetInfo = function () {
        var _ckv = this.GetCookie("HAList");
        var ckv = new Array();
        if (_ckv != "" && _ckv != null) {
            ckv = _ckv.split(',');
        }
        ckv.unshift(arg.set);
        for (var i = 1; i < ckv.length; i++) {
            var pattern = new RegExp("([^-]+)-([^-]+)-([^-]+)-([^-]+)", "ig");
            var _s = ckv[i].replace(pattern, "$1-$2-$3-***");
            var _o = arg.set.replace(pattern, "$1-$2-$3-***");
            if (_s == _o) {
                ckv.splice(i, 1);
                break;
            }
            if (i >= this.len) {
                ckv.splice(i, 1);
            }
        }
        this.WriteCookie("HAList", ckv, 99999);
        this.ReadInfo();
    };
    this.init();
}

module.exports = HistoryViews

/***/ }),

/***/ "./src/modules/old_zs/quote_min.js":
/*!*****************************************!*\
  !*** ./src/modules/old_zs/quote_min.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var HistoryViews = __webpack_require__(/*! ./hisacc */ "./src/modules/old_zs/hisacc.js");

var gdomain = "http://hqdigi2.eastmoney.com/EM_Quote2010NumericApplication/";
var token = "44c9d251add88e27b65ed86506f6e5da";
var PicR = "http://webquotepic.eastmoney.com/GetPic.aspx?nid={0}.{1}&imageType={2}&token=" + token;
var PicK = "http://hqpick.eastmoney.com/k/";
var PicN = "http://pifm3.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx?id={0}{1}&imageType={2}&token=" + token;
//var PicN = "http://webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da&nid=0.399006&unitWidth=-6&ef=&formula=RSI&type=&imageType=KXL&&0.04516759924739544"
var $x = function (id) { return "string" == typeof id ? document.getElementById(id) : id; };
var baseUrl = 'http://push2.eastmoney.com'
var ut = 'bd1d9ddb04089700cf9c27f6f7426281'
function inArray(el, array) { for (var i = 0, n = array.length; i < n; i++) { if (array[i] === el) { return true; } } return false; }
function unique(array) { var i = 0, n = array.length, ret = []; for (; i < n; i++) { if (!inArray(array[i], ret)) { ret.push(array[i]); } } return ret; }
function ForDight(Dight, How) { rDight = parseFloat(Dight).toFixed(How); if (rDight == "NaN") { rDight = "--"; } return rDight; }
//显示完整时间
function GetFullWeekTime(time) {
    var dt = new Date(Date.parse(time.replace(/-/g, "/")));
    var day = dt.getDay();
    var arr_week = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");
    var week = arr_week[day];
    return time.replace(" ", " " + week + " ");
}

//单位格式化
function NumbericFormat(string) {
    var context = Number(string);
    //var fushu = false;
    if (!isNaN(context)) {
        var item = parseInt(string);
        if ((item > 0 && item < 1e4) || (item < 0 && item > -1e4)) {
            return item;
        } else if ((item > 0 && item < 1e6) || (item < 0 && item > -1e6)) {
            item = item / 10000;
            return item.toFixed(2) + "万";
        } else if ((item > 0 && item < 1e7) || (item < 0 && item > -1e7)) {
            item = item / 10000;
            return item.toFixed(1) + "万";
        } else if ((item > 0 && item < 1e8) || (item < 0 && item > -1e8)) {
            item = item / 10000;
            return item.toFixed(0) + "万";
        } else if ((item > 0 && item < 1e10) || (item < 0 && item > -1e10)) {
            item = item / 1e8;
            return item.toFixed(2) + "亿";
        } else if ((item > 0 && item < 1e11) || (item < 0 && item > -1e11)) {
            item = item / 1e8;
            return item.toFixed(1) + "亿";
        } else if ((item > 0 && item < 1e12) || (item < 0 && item > -1e12)) {
            item = item / 1e8;
            return item.toFixed(0) + "亿";
        } else if ((item > 0 && item < 1e14) || (item < 0 && item > -1e14)) {
            item = item / 1e12;
            return item.toFixed(2) + "万亿";
        } else if ((item > 0 && item < 1e15) || (item < 0 && item > -1e15)) {
            item = item / 1e12;
            return item.toFixed(1) + "万亿";
        } else if ((item > 0 && item < 1e16) || (item < 0 && item > -1e16)) {
            item = item / 1e12;
            return item.toFixed(0) + "万亿";
        } else {
            return item;
        }
    }
    return context.toString();
}

//时间格式化处理
function dateFtt(fmt, date) { //author: meizz   
    var o = {
        "M+": date.getMonth() + 1,                 //月份   
        "d+": date.getDate(),                    //日   
        "h+": date.getHours(),                   //小时   
        "m+": date.getMinutes(),                 //分   
        "s+": date.getSeconds(),                 //秒   
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度   
        "S": date.getMilliseconds()             //毫秒   
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

//刷新本页
function prefresh() {
    window.location.reload();
}

//涨跌标记
function udt(vs) {
    if (vs > 0) {
        return "↑";
    } else if (vs < 0) {
        return "↓";
    } else { return ""; }
}

//涨跌颜色
function udcls(vsa, vsb) {
    vsa = vsa.replace("%", "");
    if (arguments.length == 1) {
        if (vsa > 0) { return "red"; } else if (vsa < 0) { return "green"; } else { return ""; }
    } else {
        vsb = vsb.replace("%", "");
        if (vsa - vsb > 0) {
            return "red";
        } else if (vsa - vsb < 0) {
            return "green";
        } else {
            return "";
        }
    }
}

//涨跌颜色
function udc(vsa, vsb) {
    vsa = vsa.replace("%", "");
    if (vsb == "" || vsb == null || vsb == "undefined") {
        if (vsa > 0) {
            return "#f00";
        } else if (vsa < 0) {
            return "#090";
        } else {
            return "";
        }
    } else {
        vsb = vsb.replace("%", "");
        if (vsa - vsb > 0) {
            return "#f00";
        } else if (vsa - vsb < 0) {
            return "#090";
        } else {
            return "";
        }
    }
}

//涨跌颜色
function udcolor(vsa, vsb) {
    vsa = vsa.replace("%", "");
    if (vsb == "" || vsb == null || vsb == "undefined") {
        if (vsa > 0) {
            return "color:#f00";
        } else if (vsa < 0) {
            return "color:#090";
        } else {
            return "";
        }
    } else {
        vsb = vsb.replace("%", "");
        if (vsa - vsb > 0) {
            return "color:#f00";
        } else if (vsa - vsb < 0) {
            return "color:#090";
        } else {
            return "";
        }
    }
}

//数字涨跌
function rendercolor(a,b) {
    if (a > b) {
        return 'red'
    } else if (a < b) {
        return 'green'
    } else {
        return ''
    }
}

//涨跌平判断
function zdp(Pnum) {
    if (Pnum > 0) {
        return 1;
    } else if (Pnum < 0) {
        return -1;
    } else {
        return 0;
    }
}

//增减标记
function fvc(vs) {
    if (vs == 0 || vs == "") {
        return "";
    } else {
        if (vs > 0) {
            return "+" + vs;
        } else {
            return vs;
        }
    }
}

//数字格式化
function ForDight(Dight, How) {
    rDight = parseFloat(Dight).toFixed(How);
    if (rDight == "NaN") {
        rDight = "--";
    }
    return rDight;
}

//数字格式化
function ForWc(Di) {
    var chu = 1;
    var res = Di;
    if (Di > 0 && Di.length >= 6) {
        chu = 6;
    } if (Di < 0 && Di.length >= 7) {
        chu = 6;
    } if (chu == 6) {
        res = ForDight((Di / 10000), 2) + "万";
    }
    return res;
}

//获取市场
function getmarket(cd) {
    var j = cd.substring(0, 3);
    var i = j.substring(0, 1);
    if (i == "5" || i == "6" || i == "9") {
        return "1";
    } else {
        if (j == "009" || j == "126" || j == "110") {
            return "1";
        } else {
            return "2";
        }
    }
}

//写cookies
function WriteCookie(name, value, hours) {
    var expire = "";
    if (hours != null) {
        expire = new Date((new Date()).getTime() + hours * 3600000);
        expire = "; expires=" + expire.toGMTString() + ";path=/;domain=.eastmoney.com";
    }
    document.cookie = name + "=" + escape(value) + expire;
}

//取cookies
function GetCookie(name) {
    var dc = document.cookie;
    var prefix = name + "=";
    var begin = dc.indexOf("; " + prefix);
    if (begin == -1) {
        begin = dc.indexOf(prefix);
        if (begin != 0) {
            return null;
        };
    } else {
        begin += 2;
    }
    var end = document.cookie.indexOf(";", begin);
    if (end == -1) {
        end = dc.length;
    }
    return unescape(dc.substring(begin + prefix.length, end));
}

window.GetCookie = GetCookie


//增加登录逻辑
function myCookie(name) {
	var xarr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
	if (xarr != null)
		return decodeURIComponent(xarr[2]);
	return null;
	
}
function myuserGet() {
    if (myCookie('ut') && myCookie('ct') && myCookie('uidal')) {
        
        //获取加v信息
        var jiav = {vtype:null, state: null, name: ''};
        if (myCookie('vtpst') && myCookie('vtpst') != '|') {
            var jiavarr = GetCookie('vtpst').split('|');
            if( jiavarr.length > 1 ){
                //console.info(typeof jiavarr[0]);
                if (jiavarr[1] == "0" || jiavarr[1] == "3") {
                    switch (jiavarr[0]) {
                        case "301":
                            jiav.vtype = 1;
                            jiav.name = '理财师';
                            break;
                        case "302":
                            jiav.vtype = 2;
                            jiav.name = '非理财师';
                            break;
                        case "303":
                            jiav.vtype = 3;
                            jiav.name = '企业';
                            break;
                        default:
                            break;
                    }
                }

                switch (jiavarr[1]) {
                    case "0":
                        jiav.state = 0; //审核通过
                        break;                        
                    case "1":
                        jiav.state = 11; //审核未通过
                        break;
                    case "2":
                        jiav.state = 12; //审核中
                        break;
                    case "3":
                        jiav.state = 13; //加v用户修改审核
                        break;
                    case "8":
                        jiav.state = 18; //加v用户修改审核
                        break;
                    case "9":
                        jiav.state = 19; //加v用户修改审核
                        break;
                    default:
                        break;
                }
                
                //console.info(jiav);

            }
        }
        
        return {
          id: myCookie('uidal').substring(0,16),
          nick: myCookie('uidal').substring(16),
          jiav: jiav
        };
    }
    return null; 
}

var islogin = myuserGet() ? true: false
// console.log(islogin);




function Getcks(key) {
    var result = document.cookie.match(new RegExp(key + "=([^;]*)"));
    return result != null ? unescape(decodeURI(result[1])) : null;
}

//拉长缩短K线
function picklc() {
    KBd.Change('-');
}

//拉长缩短K线
function picksd() {
    KBd.Change('+');
}

/** 
 * js截取字符串，中英文都能用 
 * @param {string} str: 需要截取的字符串 
 * @param {number} len: 需要截取的长度
 * @param {string} ellipsis: 溢出文字
 * @returns {string} 截取后的字符串
 */
function cutstr(str, len, ellipsis) {
    if (typeof ellipsis != "string") ellipsis = "...";
    var str_length = 0;
    var str_len = 0;
    str_cut = new String();
    for (var i = 0; i < str.length; i++) {
        a = str.charAt(i);
        str_length++;
        if (escape(a).length > 4) {
            //中文字符的长度经编码之后大于4  
            str_length++;
        }
        //str_cut = str_cut.concat(a);
        if (str_length <= len) {
            str_len++;
        }
    }
    //如果给定字符串小于指定长度，则返回源字符串；  
    if (str_length <= len) {
        return str.toString();
    } else {
        return str.substr(0, str_len).concat(ellipsis);
    }
}

var Browser = { ie: /msie/.test(window.navigator.userAgent.toLowerCase()), moz: /gecko/.test(window.navigator.userAgent.toLowerCase()), opera: /opera/.test(window.navigator.userAgent.toLowerCase()), safari: /safari/.test(window.navigator.userAgent.toLowerCase()) };
var Min = new Object(); Min.Loader = {
    load: function (sUrl, sBianMa, fCallback) {
        var _script = document.createElement('script'); _script.setAttribute('charset', sBianMa); _script.setAttribute('type', 'text/javascript'); _script.setAttribute('src', sUrl);
        document.getElementsByTagName('head')[0].appendChild(_script);
        if (Browser.ie) {
            _script.onreadystatechange = function () { if (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') { _script.parentNode.removeChild(_script); fCallback(); } };
        } else if (Browser.moz || Browser.opera) {
            _script.onload = function () { _script.parentNode.removeChild(_script); fCallback(); };
        } else { _script.parentNode.removeChild(_script); fCallback(); }
    }
};

(function () {
    function QaDefault(Code, Market, Market_10, Name, styleid, zjlCode, zdpCode) {
        //代码，市场_12，市场_10，名称，排行对应ID,资金流代码，涨跌平代码,
        _this = this; _this._Code = Code; _this._Market = Market == 2 ? 0 : Market; _this._Market_10 = Market_10; _this._Name = Name; _this.styleid = styleid; _this._zjlCode = zjlCode; _this._zdpCode = zdpCode;
        _this.$ = function (id) { return "string" == typeof id ? document.getElementById(id) : id; };
        _this.sansuoNum = 0; _this.cbian = true; _this.sansuo; _this.tempStatus = {}; _this.ColorStatus = {};
        _this.hongdise = function () {
            var span = [_this.$("price9"), _this.$("km1"), _this.$("km2")];
            for (i = 0; i < 3; i++) {
                _this.ColorStatus[i] = (_this.ColorStatus[i]) ? false : true;
                if (_this.cbian) {
                    if (!_this.ColorStatus[i]) {
                        _this.tempStatus[i] = span[i].style.color; span[i].style.color = "#000000";
                    } else {
                        span[i].style.color = _this.tempStatus[i];
                    }
                }
            }
            _this.sansuoNum++;
            if (_this.sansuoNum > 6) {
                clearInterval(_this.sansuo);
                _this.sansuoNum = 0; _this.tempStatus = {}; _this.ColorStatus = {}; _this.cbian = false;
                _this.$("price9").style.color = ""; _this.$("km1").style.color = ""; _this.$("km2").style.color = "";
                
            }
        };
    };
    QaDefault.prototype = {
        init: function () {
            window.quoteIsFirst = true; window.quoteRefresh = 12000;//行情
            window.zxgIsFirst = true; window.zxgRefresh = 30000; window.zxgDisNum = 6; window.favorsetInterval = 0;//自选股
            window.GetBkphNUM = 1; window.GetBkzj = 1; window.GetLzBk = 1; window.GetKX = 1; window.GetKXMaxID; window.GetRankNUM = 1; window.GetZjlxNUM = 1; window.GetZdpNUM = 1; window.GetGzqhNUM = 1;

            window.GetTimeZoneInfo = false;
            _this.bindPageEvent();
            _this.Gethis();//最近访问
            _this.fullScreenFun();
            //createSWF(_this._Code, _this._Market, _this._Name, 578, 276, 565, 415, "1", "0", "1");
                
        

            //第一次执行我的自选
            // setTimeout(function () { 
            //     console.log('我的自选')
            //     _this.GetFavorList(_this._Code); 

            // }, 100);

            //我的自选自刷
            _this.GetControlMyzixuan();


            setTimeout(function () {
                loadBkph("_BKHY", "-1");
                loadBkph("_BKHY", "1");
                loadBkph("_BKGN", "-1");
                loadBkph("_BKGN", "1");
                loadBkzj("_BKHY");
                loadBkzj("_BKGN");
                LoadLzbk();
                LoadZyzs();
                Loadgzqh();
                loadRank(_this.styleid);
                loadKuaiXun();
                loadhyzjlx(); //行业资金流向图
                yjbgList(); //研究报告
            }, 200);
            setInterval(function () {
                LoadLzbk();
                LoadZyzs();
                Loadgzqh();
                loadRank(_this.styleid);
            }, 10000);
            setInterval(function () {
                loadBkph("_BKHY", "-1");
                loadBkph("_BKHY", "1");
                loadBkph("_BKGN", "-1");
                loadBkph("_BKGN", "1");
            }, 15000);

            //百度隐藏广告
            if (_this.getQueryStringByName("from") == "BaiduAladdin") {
                $("#tbggiframe").hide();
                $("#ifhqheadad").hide();

                $.ajax({
                    url: "http://emres.dfcfw.com/public/js/aldtg.js",
                    method: "GET",
                    scriptCharset: 'UTF-8',
                    dataType: "script"
                });

            } else {
                $.ajax({
                    url: "http://emres.dfcfw.com/public/js/left.js",
                    method: "GET",
                    scriptCharset: 'UTF-8',
                    dataType: "script"
                });

                $.ajax({
                    url: "http://emres.dfcfw.com/public/js/em_news_fixed_right.js",
                    method: "GET",
                    scriptCharset: 'UTF-8',
                    dataType: "script"
                });
            }
        },
        getQueryStringByName: function (name) {
            var result = location.search.match(new RegExp("[\?\&]" + name + "=([^\&]+)", "i"));
            if (result == null || result.length < 1) {
                return "";
            }
            return result[1];
        },
        bindPageEvent: function () {//页面事件绑定
            _this.DisQuote();
            setInterval(function () { _this.DisQuote(); }, window.quoteRefresh);
            _this.GetTimeZone(); setInterval(function () { _this.GetTimeZone(); _this.UpZjlx() }, 30000);//时间戳 资金流向
            setInterval(function () { _this.UpPic(true); }, 180000);//更新R图和K线
            _this.$("RefPR").onclick = function () { prefresh(); }
            _this.$("refgbauls").onclick = function () {
                var dl = _this.$("gbauls").getElementsByTagName("dl");
                var sedl = GetRandomNum(0, dl.length - 1);
                for (var i = 0; i < dl.length; i++) {
                    if (i == sedl) {
                        if (dl[i].hasChildNodes()) {
                            var dd = dl[i].childNodes;
                            for (var j = 0; j < dd.length; j++) {
                                if (dd[j].hasChildNodes()) {
                                    var ddimg = dd[j].childNodes[0].getElementsByTagName('img')[0];
                                    if (ddimg && !ddimg.getAttribute('src'))
                                        ddimg.setAttribute('src', ddimg.getAttribute('data-value'));
                                }
                            }
                        }
                        dl[i].style.display = "";
                    } else {
                        dl[i].style.display = "none";
                    }
                }
            };
            _this.$("kx_fontsize").onclick = function () {
                //if ($x("flash_box").style.display == "block") {
                //    _this.$("kx_list").className = _this.$("kx_list").className == "kx_list kx_listfls" ? "kx_list kx_fz14 kx_listfls" : "kx_list kx_listfls";
                //} else {
                //    _this.$("kx_list").className = _this.$("kx_list").className == "kx_list" ? "kx_list kx_fz14" : "kx_list";
                //}

                _this.$("kx_list").className = _this.$("kx_list").className == "kx_list" ? "kx_list kx_fz14" : "kx_list";
                _this.$("kx_fontsize").innerHTML = _this.$("kx_list").className.indexOf("kx_fz14") > 0 ? "小字-" : "大字+";
            };
            _this.$("kx_refresh").onclick = function () { loadKuaiXun(); };
            _this.$("kx_auto").onclick = function () {
                if (_this.$("kx_auto").className == "kx_auto kx_autoing") {
                    _this.$("kx_auto").className = "kx_auto"; clearInterval(window.kxst);
                }
                else {
                    _this.$("kx_auto").className = "kx_auto kx_autoing"; loadKuaiXun();
                }
            };
            _this.$('lookVote0').onclick = function () { window.open('http://vote.eastmoney.com/vote_look1.asp?action=look'); };
            _this.$('lookVote1').onclick = function () { window.open('http://vote.eastmoney.com/vote_look1.asp?action=look'); };
            _this.$('lookVote2').onclick = function () { window.open('http://vote.eastmoney.com/vote_look2.asp?action=look'); };
            _this.$("hq_cr_close").onclick = function () { _this.$("hq_cr_tips").style.display = "none"; WriteCookie("emhq_cr", "1", 12); };
            _this.$("hq_cr_b").onmouseover = function () { _this.$("hq_cr_tips").style.display = "block"; };
            _this.$("hq_cr_b").onmouseout = function () { _this.$("hq_cr_tips").style.display = "none"; };
            // _this.$('zjlx_bars').onclick = function () {
            //     var s1 = _this.$("zjlx_bar").value; var s = escape(s1);
            //     if (s1 == "输代码、名称或拼音" || s1 == "" || isNaN(parseInt(s1)) || s1.length != 6) { alert("请输入所查询股票的代码！"); return false; } else { var url = "http://data.eastmoney.com/rzrq/detail/" + s1 + ".html"; window.open(url); }
            // };
            // var zz = new StockSuggest("zjlx_bar", {
            //     text: "输代码、名称或拼音",
            //     type: "ABSTOCK",
            //     autoSubmit: false,
            //     width: 190,
            //     header: ["选项", "代码", "名称", "类型"],
            //     body: [-1, 1, 4, -2],
            //     callback: function (ag) {
            //         var url = "http://data.eastmoney.com/rzrq/detail/" + ag.code + ".html";
            //         window.open(url);
            //     }
            // });
            var newsuggest = new suggest2017({ //新建实例
                width: 300,
                placeholder: '输代码、名称或拼音',
                showblank:false,
                offset:{
                    left:-140,
                    top:0
                },
                stockcount: 10,
                showstocklink: false,
                modules: ['stock'],
                filter: {
                    securitytype: '1,2,3,4'
                },
                onConfirmStock : function(result){ //事件
                    window.open('http://data.eastmoney.com/rzrq/detail/' + result.stock.Code + '.html')
                    return false;
                },
                onSubmit : function(result){ //事件
                    if (result.key == '') {
                        return false
                    }
                    window.open('http://data.eastmoney.com/rzrq/detail/' + result.stock.Code + '.html')
                    return false;
                },                
                inputid: 'zjlx_bar' //参数部分
            })

        },
        Bian: function (dt) {//是否在开盘期间
            var res = false;
            var hs = dt.getHours();
            var ms = dt.getMinutes();
            if (hs >= 9 && hs <= 11) {
                res = true;
                if ((hs == 11) && ms >= 30)
                    res = false;
            }
            if (hs >= 13 && hs < 15) { res = true; }
            return res;
        },
        PanQian: function (dt) {//是否在盘前期间
            var res = false;
            var hs = dt.getHours();
            var ms = dt.getMinutes();
            if (hs == 9) { if ((ms >= 14) && ms < 29) { res = true; } }
            return res;
        },
        GetTimeZone: function () {//系统时间
            Min.Loader.load("http://quote.eastmoney.com/timezone.js?" + formatm(), 'utf-8', function () {
                var dt = new Date(window["bjTime"] * 1000);
                window.GetTimeZoneInfo = _this.Bian(dt);
                var Notify = window["Notify"];
                //_this.setPicrTab(dt);
                if (Notify != "undefined" && Notify != "" && !window.Notifyed && _this.IsNotify) {
                    if (Notify == 0) { clearInterval(window.NotifyS); } else { _this.NotifyPage(Notify * 60000); }
                }
            });
        },
        NotifyPage: function (num) {//通知页面刷新
            window.Notifyed = true; window.NotifyS = setInterval("prefresh()", num);
        },
        //控制我的自选自刷问题：
        GetControlMyzixuan: function () {
            jQuery.ajax({
                url: baseUrl + "/api/qt/stock/get?secid=" + _this._Market + "." + _this._Code + '&ut=' + ut +'&fields=f118&invt=2',
                dataType: 'jsonp',
                jsonp: 'cb',
                scriptCharset: "utf-8",
                success: function (res) {
                    // console.log('外加方法：')
                    // console.log(res);

                    //增加判断 国内登录我的自选刷新
                    if(res) {
                        _this.GetFavorList(_this._Code, res.lt, islogin); 
                    }


                }
            })

        },
        GetFavorList: function (thisCode, lt, islogin) {
            // console.log('执行 GetFavorList');
            var iscks = false;
            if (GetCookie("pi")) {
                var gcks = Getcks("pi");
                if (gcks.split(';').length >= 3) {
                    var name = gcks.split(';')[2];
                    if (/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) { iscks = true; }
                    else {
                        Min.Loader.load("https://myfavor1.eastmoney.com/mystock?f=gsaandcheck&sc=" + _this._Code + "|0" + _this._Market + "|01&c=13&var=asl&rt=" + formatm(), "utf-8", function () {
                            var allstocklist = "";
                            if (asl.result == "1") {
                                var sl = asl.data.list.split(',');
                                for (var i = 0; i < sl.length; i++) {
                                    var item = sl[i].split('|');
                                    if (i == sl.length - 1) {
                                        allstocklist += item[0];
                                    } else {
                                        allstocklist += item[0] + ",";
                                    }
                                }
                            }
                            _this.FavorPad(allstocklist, thisCode, lt, islogin);
                        });
                    }
                }
                else {
                    iscks = true;
                }
            } else {
                iscks = true;
            }
            if (iscks) {
                var emhq_stock = GetCookie("emhq_stock");
                if (emhq_stock) {
                    _this.FavorPad(emhq_stock, thisCode);
                } else {
                    _this.FavorPad("", thisCode);
                }
            }
        },
        FavorPad: function (initlist, thisCode, lt, islogin) {
            var arr = new Array();
            initlist += ",000001,000002,000004,000005,000006,000008,000009,000010,000011,000012,000014,000016,000017,000018";
            var list = unique(initlist.split(","));
            for (var k = 0; k < list.length; k++) {
                if (list[k] != "") {
                    var code = list[k];
                    var market = getmarket(code)==1?1:0;
                    if (thisCode != code) {
                        arr.push(market + '.' +code);
                    }
                }
            }
            _this.FavorDis(arr);
            window.zxgIsFirst = true;

            //判断若是国内登录 刷新我的自选列表
            if(lt !== 2 && islogin) {
                 window.favorsetInterval = setInterval(function () {
                    //   console.log('刷新我的自选列表')
                      _this.FavorDis(arr); 
                }, window.zxgRefresh);
            }
            
        },
        //自选股
        FavorDis: function (arr) {
            if (window.GetTimeZoneInfo || window.zxgIsFirst) {
                var res = arr.slice(0, window.zxgDisNum);
                var codestr = res.join(",")
                var url = baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2'
                $.ajax({
                    url: url,
                    dataType: 'jsonp',
                    jsonp: 'cb',
                    Type: 'get',
                    success: function (json) {
                        var list = json.data.diff
                        var htm = ''
                        for (var i = 0; i < list.length; i++) {
                            var color = rendercolor(list[i].f3, 0)
                            var zxj = list[i].f2 == '-' ? list[i].f2 : (list[i].f2 / Math.pow(10, list[i].f1)).toFixed(list[i].f1)
                            var zdf = list[i].f3 == '-' ? '-' : ((list[i].f3 / 100).toFixed(2)+'%')
                            htm += '<tr><td class="nm"><span class="' + color + '"><a href="http://quote.eastmoney.com/' + list[i].f12 + '.html" target="_blank">' + list[i].f14 + '</a></span></td><td class="' + color + '">' + zxj+'</td><td class="'+color+'">'+zdf+'</td></tr>'
                        }

                        $("#favorlist").html(htm)
                    }
                })
                window.zxgIsFirst = false;
            }
        },
        Gethis: function () {
            var arg = { def: "", set: "f-0-" + _this._Code + "-" + _this._Name }; var HV = new HistoryViews("historyest", arg);
        },
        Setudclass: function (zd) {
            var hqcr = _this.$("arrowud").getAttribute("xid");
            if (zd > 0) {
                _this.$("arrowud").className = hqcr == "1" ? "cr red" : "red";
                _this.$("arrow-find").className = "xp2 up-arrow";
            } else if (zd < 0) {
                _this.$("arrowud").className = hqcr == "1" ? "cr green" : "green";
                _this.$("arrow-find").className = "xp2 down-arrow";
            } else {
                _this.$("arrowud").className = hqcr == "1" ? "cr" : "";
                _this.$("arrow-find").className = "";
            }
        },
        DisQuote: function () {
            if (window.GetTimeZoneInfo || window.quoteIsFirst) {

                jQuery.ajax({
                    url: baseUrl + "/api/qt/stock/get?secid=" + _this._Market + "." + _this._Code + '&ut=' + ut +'&fields=f118,f107,f57,f58,f59,f152,f43,f169,f170,f46,f60,f44,f45,f168,f50,f47,f48,f49,f46,f169,f161,f117,f85,f47,f48,f163,f171,f113,f114,f115,f86,f117,f85,f119,f120,f121,f122&invt=2',
                    dataType: 'jsonp',
                    jsonp: 'cb',
                    scriptCharset: "utf-8",
                    success: function (res) {
                        // console.log("基本数据>>", res)
                        var data = res.data
                        getHqStat(data.f118)

                        var zxj = data.f43 == '-' ? data.f43 : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var zd = (data.f169 == "-" ? "-" : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))
                        var zdf = data.f43 == '-' ? '-' : (data.f170 / 100).toFixed(2)
                        var time = dateFtt("yyyy-MM-dd hh:mm:ss", new Date(data.f86 * 1000))
                        var jkj = data.f46 == '-' ? data.f46 : (data.f46 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var zgj = data.f44 == '-' ? data.f44 : (data.f44 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var zdj = data.f45 == '-' ? data.f45 : (data.f45 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var zsj = data.f60 == '-' ? data.f60 : (data.f60 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var kpj = data.f46 == '-' ? data.f46 : (data.f46 / Math.pow(10, data.f59)).toFixed(data.f59)

                        document.title = (data.f58 + " " + zxj + " " + zd + "(" + zdf + "%) _ 股票行情 _ 东方财富网");
                        $("#price9").text(zxj).addClass(rendercolor(data.f43, data.f60)) //最新价
                        $("#arrow-find").addClass(data.f43 > data.f60 ? 'up-arrow' :'down-arrow')
                        $("#km1").text(zd).addClass(rendercolor(data.f43, data.f60));//涨跌
                        $("#km2").text(zdf + "%").addClass(rendercolor(data.f43, data.f60));//涨幅
                        $("#hqday").text("（" + GetFullWeekTime(time) + "）");//时间
                        $("#gt1").text(jkj).addClass(rendercolor(data.f46, data.f60)) //今开
                        $("#gt2").text(zgj).addClass(rendercolor(data.f44, data.f60)) //最高
                        $("#gt3").text(zdf + '%').addClass(rendercolor(data.f43, data.f60)) //涨幅
                        $("#gt4").text((data.f168 / 100).toFixed(2) + '%') //换手
                        $("#gt5").text(data.f47 == 0 ? '-' : (NumbericFormat(data.f47) + '手'));//成交量
                        $("#gt7").text(zsj) //昨收
                        $("#gt8").text(zdj).addClass(rendercolor(data.f45, data.f60)) //最低
                        $("#gt9").text(zd).addClass(rendercolor(data.f43, data.f60)) //涨跌
                        $("#gt10").text((data.f171 / 100).toFixed(2) + '%') //振幅
                        $("#gt11").text(data.f48 == '-' ? '-' : (NumbericFormat(data.f48) + "元"))//成交額

                        $("#rgt1").text(zxj).addClass(rendercolor(data.f43, data.f60)) //最新价
                        $("#rgt2").text(kpj).addClass(rendercolor(data.f46, data.f60)) //最新价
                        $("#rgt3").text(zgj).addClass(rendercolor(data.f44, data.f60)) //最高
                        $("#rgt4").text(zdj).addClass(rendercolor(data.f45, data.f60)) //最低
                        $("#rgt5").text(zdf + "%").addClass(rendercolor(data.f43, data.f60));//涨幅
                        $("#rgt6").text(zd).addClass(rendercolor(data.f43, data.f60)) //涨跌
                        $("#rgt7").text(data.f47 == 0?'-': (NumbericFormat(data.f47) +'手'));//成交量
                        $("#rgt8").text(data.f48 == '-' ? '-' : (NumbericFormat(data.f48)))//成交額
                        $("#rgt9").text((data.f168 / 100).toFixed(2) + '%') //换手
                        $("#rgt10").text(data.f117 == '-' ? '-' : (NumbericFormat(data.f117)))//流通市值
                        $("#rgt11").text(data.f161 == '-' ? '-' : fmtdig(data.f161, "手"))//内盘
                        $("#rgt12").text(data.f49 == '-' ? '-' : fmtdig(data.f49, "手"))//外盘
                        $("#rgt13").text((data.f171 / 100).toFixed(2) + '%') //振幅

                        $("#rgt17").text((data.f119 == '-' ? '-' : (data.f119 / 100).toFixed(2)) + "%").addClass(rendercolor(data.f119, 0));//5涨幅
                        $("#rgt18").text((data.f120 == '-' ? '-' : (data.f120 / 100).toFixed(2)) + "%").addClass(rendercolor(data.f120, 0));//20涨幅
                        $("#rgt19").text((data.f121 == '-' ? '-' : (data.f121 / 100).toFixed(2)) + "%").addClass(rendercolor(data.f121, 0));//30涨幅
                        $("#rgt20").text((data.f122 == '-' ? '-' : (data.f122 / 100).toFixed(2)) + "%").addClass(rendercolor(data.f122, 0));//今年涨幅
                        $("#rgt14").text(data.f113 + '家').addClass('red')
                        $("#rgt15").text(data.f114 + '家').addClass('green')
                        $("#rgt16").text(data.f115 + '家') 

                        _this.GetFbFj()


                        var fullcode = _this._Market + "." + _this._Code
                        if (fullcode == '0.399006' || fullcode == '0.399005') { // 创业板指 中小板指
                            _this.showzs(fullcode)
                        } else {
                            if (data.f107 == 1) {
                                _this.showzs('1.000001') //显示上证成指
                            } else {
                                _this.showzs('0.399001')//显示深证指数
                            }
                        }

                        if (data.f107 == 1) {
                            _this.showzsb('0.399001')//显示深证指数
                        } else {
                            _this.showzsb('1.000001') //显示上证成指
                        }


                    }
                });
                _this.sansuo = setInterval(_this.hongdise, 300);
                window.quoteIsFirst = false;
            }
        }, 

        
        //获取单个指数涨跌
        showzsb: function (zscode) {
            var url = baseUrl + "/api/qt/stock/get?secid=" + zscode + '&ut=' + ut + '&fields=f57,f58,f59,f107,f43,f169,f170,f135,f136,f137,f193,f138,f139,f140,f194,f141,f142,f143,f195,f144,f145,f146,f196,f147,f148,f149,f197&invt=2'
            $.ajax({
                url: url,
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get',
                success: function (json) {
                    var data = json.data
                    var zxj = data.f43 == '-' ? data.f43 : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59)
                    var zd = (data.f169 == "-" ? "-" : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))
                    var zdf = data.f43 == '-' ? '-' :( (data.f170 / 100).toFixed(2) + '%')
                    var str1 = "<a href=\"http://quote.eastmoney.com/zs" + data.f57 + ".html\" target=\"_blank\">" + data.f58 + "A股行情</a>"
                    var str2 = zxj + "&nbsp;&nbsp;" + zd + "&nbsp;&nbsp;" + zdf;
                    $("#rstocka").html(str1);
                    $("#rstockb").html(str2).addClass(rendercolor(data.f170, 0));
                }
            })

        },

        //获取资金流
        showzs: function (zscode) {
            var url = baseUrl + "/api/qt/stock/get?secid=" + zscode + '&ut=' + ut + '&fields=f57,f58,f59,f107,f43,f169,f170,f135,f136,f137,f193,f138,f139,f140,f194,f141,f142,f143,f195,f144,f145,f146,f196,f147,f148,f149,f197&invt=2'
            $.ajax({
                url: url,
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get',
                success: function (json) {
                    var data = json.data
                    //资金流
                    $("#hz_a").text(data.f135 == '-' ? '-' : (NumbericFormat(data.f135) + '元'))
                    $("#hz_b").text(data.f136 == '-' ? '-' : (NumbericFormat(data.f136) + '元'))
                    $("#hz_c").text(data.f137 == '-' ? '-' : (NumbericFormat(Math.abs(data.f137)) + '元')).addClass(rendercolor(data.f137, 0))
                    $("#hz_c_t").text(data.f137 < 0 ? "主力净流出" : "主力净流入");
                    $("#hz_d").text(data.f138 == '-' ? '-' : (NumbericFormat(data.f138)))
                    $("#hz_e").text(data.f139 == '-' ? '-' : (NumbericFormat(data.f139)))
                    $("#hz_f").text(data.f141 == '-' ? '-' : (NumbericFormat(data.f141)))
                    $("#hz_g").text(data.f142 == '-' ? '-' : (NumbericFormat(data.f142)))
                    $("#hz_h").text(data.f144 == '-' ? '-' : (NumbericFormat(data.f144)))
                    $("#hz_i").text(data.f145 == '-' ? '-' : (NumbericFormat(data.f145)))
                    $("#hz_j").text(data.f147 == '-' ? '-' : (NumbericFormat(data.f147)))
                    $("#hz_k").text(data.f148 == '-' ? '-' : (NumbericFormat(data.f148)))
                    var _l = [[data.f138 == '-' ? 0 : data.f138, data.f139 == '-' ? 0 : -data.f139], [data.f141 == '-' ? 0 : data.f141, data.f142 == '-' ? 0 : -data.f142], [data.f144 == '-' ? '0' : data.f144, data.f145 == '-' ? '0' : -data.f145], [data.f147 == '-' ? 0 : data.f147, data.f148 == '-' ? 0 : -data.f148]]
                    if (_l[0][0] != '-') {
                        ZjlxCek(_l)
                    }   

                    //var zxj = data.f43 == '-' ? data.f43 : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59)
                    //var zd = (data.f169 == "-" ? "-" : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))
                    //var zdf = data.f43 == '-' ? '-' :( (data.f170 / 100).toFixed(2) + '%')
                    //var str1 = "<a href=\"http://quote.eastmoney.com/zs" + data.f57 + ".html\" target=\"_blank\">" + data.f58 + "A股行情</a>"
                    //var str2 = zxj + "&nbsp;&nbsp;" + zd + "&nbsp;&nbsp;" + zdf;
                    //$("#rstocka").html(str1);
                    //$("#rstockb").html(str2).addClass(rendercolor(data.f170, 0));

                    //var fullcode = _this._Market + "." + _this._Code
                    //if (fullcode == '0.399006' || fullcode == '0.399005') {

                    //} else {
                       
                    //}
                }
            })
        },

        GetFbFj: function () {
            var _url = baseUrl + "/api/qt/stock/details/get?secid=" + _this._Market + "." + _this._Code + "&ut=" + ut + "&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55&pos=-13&invt=2"
            $.ajax({
                url: _url,
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get',
                success: function (json) {
                    var data = json.data
                    if (!data.details.length || !data.prePrice) return;
                    var list = [];
                    var details = data.details
                    for (var i = 0; i < details.length; i++) {
                        if (i > 0) {
                            var itemslast = details[i - 1].split(",")
                            var items = details[i].split(",");
                            var dir = (items[1] > itemslast[1] ? "↑" : items[1] == itemslast[1] ? " " : "↓")
                            var listitem = {
                                time: items[0],
                                close: items[1],
                                closeCss: rendercolor(items[1], data.prePrice),
                                volumn: items[2],
                                dir: dir,
                                volumnCss: items[4] == 0 ? lastcolor : (items[4] == 2 ? 'red' : 'green'),
                                arrowcolor: items[1] > itemslast[1] ? "red" : items[1] == itemslast[1] ? " " : "green"
                            }
                            list.push(listitem);
                            var lastcolor = listitem.volumnCss
                        }
                    }
                    list = list.reverse()
                    var htm = ''
                    for (var i = 0; i < list.length; i++) {
                        htm += '<tr><td class="nm">' + list[i].time + '</td><td class="' + list[i].closeCss + '">' + list[i].close + '</td><td class="' + list[i].volumnCss + '">' + list[i].volumn + list[i].dir +'</td></tr>' 
                    }
                    $("#fblist").html(htm)
                }
            });
        },
        UpZjlx: function () {
            RefZjlx(_this._zjlCode)
        },
        UpPic: function (refk, pq) {//更新图 (refk是否需要更新K图，是否为盘前图)
            var pqtit = _this.$("tab_picr").getElementsByTagName("span");
            for (var i = 0; i < pqtit.length; i++) {
                pqtit[i].className = "";
            }
            //if (pq) {
            //    pqtit[0].className = "cur";
            //    _this.$("picr").src = PicR.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "r") + "&rt=" + formatm();
            //} else {
            pqtit[0].className = "cur";
            _this.$("picr").src = PicR.replace("{0}", _this._Market).replace("{1}", _this._Code).replace("{2}", "r") + "&rt=" + formatm();
            //}
            if (refk) {
                if (_this.Lstng == "0") {
                    _this.$("pick").src = "http://hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif?1";
                } else {
                    var src = $("#pick").attr("src").split("&&")[0] + '&&' + new Date().getTime()
                    _this.$("pick").src = src
                    //_this.$("pick").src = PicN.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "KXL") + "&rt=" + formatm();
                }
            }
        },
        hqcr: function (hq_cr_type, _hq_cr_time, hq_cr_cnt) {
            var hq_cr_time = _hq_cr_time.length > 5 ? _hq_cr_time.substring(16, 11) : "-";
            if (hq_cr_type == "8" || hq_cr_type == "9" || hq_cr_type == "10" || hq_cr_type == "11") {
                _this.$("hq_cr").style.display = "block";
                //_this.$("hq_cr_time").innerHTML = hq_cr_time == "-" ? "暂停交易" : "暂停交易至" + hq_cr_time;
                if (hq_cr_type == "8" || hq_cr_type == "10") { _this.$("hq_cr_time").innerHTML = "暂停交易15分钟"; } else { _this.$("hq_cr_time").innerHTML = "暂停交易至15:00"; }
                _this.$("arrowud").setAttribute("xid", "1"); _this.$("arrowud").className = _this.$("arrowud").className.indexOf("cr") == -1 ? "cr " + _this.$("arrowud").className : _this.$("arrowud").className;
                switch (hq_cr_type) {
                    case "8": _this.$("hq_cr_type").innerHTML = "5%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgr"; break;
                    case "9": _this.$("hq_cr_type").innerHTML = "7%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgr"; break;
                    case "10": _this.$("hq_cr_type").innerHTML = "-5%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgg"; break;
                    case "11": _this.$("hq_cr_type").innerHTML = "-7%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgg"; break;
                }
                var _rdContent = "";
                switch (hq_cr_cnt.toLowerCase()) {
                    case "aa1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "aa2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "aa3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，于9：30起暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "aa4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，于9：30起暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ab1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ab2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ab3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ab4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ad1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ad2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ad3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ad4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ba1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ba2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ba3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ba4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "bb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "bb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易至14：57。熔断期间您可以继续申报，也可以撤销申报。熔断结束后进入3分钟的尾盘集合竞价。";
                        break;
                    case "bc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易至14：57。熔断期间您可以继续申报，也可以撤销申报。熔断结束后进入3分钟的尾盘集合竞价。";
                        break;
                    case "bc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "be1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "be2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "be3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "be4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ca1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "ca2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "ca3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "ca4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间（熔断发生在11:15-11:18之间，下午开盘直接进入3分钟集合竞价），期间接受指令申报和撤销。";
                        break;
                    case "cb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间（熔断发生在11:15-11:18之间，下午开盘直接进入3分钟集合竞价），期间接受指令申报和撤销。";
                        break;
                    case "cb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定相关合约收市前15分钟内触发5%阈值，暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定相关合约收市前15分钟内触发5%阈值，暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "taa1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "taa2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "taa3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "taa4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tab1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tab2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tab3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tab4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tba1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tba2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tba3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tba4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tbb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tbb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tca1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tca2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tca3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tca4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tcb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tcb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tcb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tcb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tcc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tcc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tcc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tcc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                }
                var cookies_cr = GetCookie("emhq_cr");
                _this.$("hq_cr_cnt").innerHTML = _rdContent;
                if (_rdContent == "") { _this.$("hq_cr_tips").style.display = "none"; _this.$("hq_cr_b").style.display = "none"; }
                if ((cookies_cr == "" || cookies_cr == null) && _rdContent != "") { _this.$("hq_cr_tips").style.display = "block"; _this.$("hq_cr_b").style.display = "block"; }
            } else {
                _this.$("hq_cr").style.display = "none"; _this.$("hq_cr_type").className = "hq_cr_a"; _this.$("arrowud").setAttribute("xid", "0"); _this.$("arrowud").className = _this.$("arrowud").className.replace("cr", "");
            }
        },
        //全屏的方法
        fullScreenFun: function () {
            // ie9以下隐藏全屏按钮
            if (document.all && !document.addEventListener) {
                $(".fullScreenBtn").hide();
                window.location.hash = "";
            }
            var id = _this._Market_10 + "." + _this._Code
            var url = "//quote.eastmoney.com/basic/full.html?mcid=" + id + "&type=r";
            var $context = $('<div class="fs-wrapper"><div class= "mark-box"></div><div class="full-box"><span class="full-close">×</span><iframe src = "' + url + '" style="height:98%;width:99%"></iframe></div ></div>');
            $(".fullScreenBtn").click(function () {
                $("body").append($context)
                $(".full-close").click(function () {
                    $($context).remove()
                    window.location.hash = "";
                })
            });
            if (location.href.indexOf("#fullScreenChart") > 0) {
                $(".fullScreenBtn").trigger("click");
            }
        }
    };
    window.QaDefault = QaDefault;
})();


//行业板块涨跌幅  zxw
function loadBkph(type, sortType) {
    var url = baseUrl + '/api/qt/clist/get?pi=0&pz=5&po=' + (sortType == -1 ? 1 : 0) + "&ut=" + ut + '&fs=m:90+t:' + (type == '_BKHY' ? 2 : 3) + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152,' + (sortType == '-1' ? 'f128':'f207')+'&invt=2'
    $.ajax({
        type: "GET",
        url: url,
        data: null,
        dataType: 'jsonp',
        jsonp: 'cb',
        success: function (res) {
            //console.log("行业涨跌幅", res.data.diff)
            var item = res.data.diff
            var html = "";
            for (var i in item) {
                var color = item[i].f3 > 0 ? "red" : "green";
                var market = sortType == '-1' ? (item[i].f141 == 1 ? "sh" : "sz"):(item[i].f209 == 1 ? "sh" : "sz");
                var name = sortType == '-1' ? item[i].f128 : item[i].f207
                var code = sortType == '-1' ? item[i].f140 : item[i].f208
                html += '<tr><td><a href="http://quote.eastmoney.com/center/list.html#28002' + item[i].f12.slice(3) + '.html" target="_blank">' + item[i].f14 + '</a></td>' +
                    '<td class="' + color + '">' + (item[i].f3=='-'?'-':(item[i].f3 / 100).toFixed(2) + '%') + '</td>' +
                    '<td><a href="http://quote.eastmoney.com/' + market + code + '.html" target="_blank">' + name + '</a></td></tr>';
            }
            if (type == "_BKHY") {
                if (sortType == "-1") {
                    $("#cnt_hyzfb_list").html(html);
                } else {
                    $("#cnt_hydfb_list").html(html);
                }
            } else {
                if (sortType == "-1") {
                    $("#cnt_gnzfb_list").html(html);
                } else {
                    $("#cnt_gndfb_list").html(html);
                }
            }
        }
    })
}

function loadBkzj(type) {
    var url = baseUrl + '/api/qt/clist/get?pi=0&pz=5&po=1&ut=' + ut + '&fs=m:90+t:' + (type == '_BKHY' ? 2 : 3) + '&fid=f62&fields=f1,f2,f3,f12,f13,f14,f62,f152,f128,f204&invt=2'
    $.ajax({
        type: "GET",
        url: url,
        data: null,
        dataType: 'jsonp',
        jsonp: 'cb',
        success: function (res) {
            //console.log(url)
            //console.log("行业资金", res.data.diff)
            var item = res.data.diff
            var html = "";
            for (var i in item) {
                var color = item[i].f62 > 0 ? "red" : "green";
                html += '<tr><td><a href="http://quote.eastmoney.com/center/list.html#28002' + item[i].f12.slice(3) + '.html" target="_blank">' + item[i].f14 + '</a></td>' +
                    '<td class="' + color + '">' + (item[i].f62 == '-' ? '-' : NumbericFormat(item[i].f62))  + '</td>' +
                    '<td><a href="http://quote.eastmoney.com/' + item[i].f205 + '.html" target="_blank">' + item[i].f204 + '</a></td></tr>';
            }
            if (type == "_BKHY") {
                $("#hyzjlpy").html(html);
            } else {
                $("#gnzjlpy").html(html);
            }
        }
    })
}

function _loadBkzj() {
    if (window.GetTimeZoneInfo == true || window.GetBkzj == 1) {
        jQuery.ajax({
            url: "http://quote.eastmoney.com/hq2data/bk/data/indexbkzj.js",
            dataType: "jsonp",
            scriptCharset: "gb2312",
            contentType: 'application/x-javascript',
            jsonpCallback: "callbackbkzj",
            success: function (json) {
                var htmlhy = [];
                for (var i = 0; i < json.hy.length; i++) {
                    var item = json.hy[i].split(",");
                    var marketcode = item[4].substring(6) == "1" ? "sh" + item[4].substring(0, 6) : "sz" + item[4].substring(0, 6);
                    var link = "<a href=\"http://quote.eastmoney.com/" + marketcode + ".html\" target=\"_blank\" title='" + item[5] + "'>" + cutstr(item[5], 8) + "</a>";
                    var bkcode = item[1].replace("BK0", "");
                    htmlhy.push('<tr><td><a href="http://quote.eastmoney.com/center/list.html#28002' + bkcode + '_0_2" target="_blank" title="' + item[2] + '">' + cutstr(item[2], 8) + '</a></td><td style="' + udcolor(item[3]) + '">' + fmtdig(item[3] * 10000, "-") + '</td><td>' + link + '</td></tr>');
                }
                removeAllChild("hyzjlpy"); $("#hyzjlpy").append(htmlhy.join(''));

                var htmlgn = [];
                for (var i = 0; i < json.gn.length; i++) {
                    var item = json.gn[i].split(",");
                    var marketcode = item[4].substring(6) == "1" ? "sh" + item[4].substring(0, 6) : "sz" + item[4].substring(0, 6);
                    var link = "<a href=\"http://quote.eastmoney.com/" + marketcode + ".html\" target=\"_blank\" title='" + item[5] + "'>" + cutstr(item[5], 8) + "</a>";
                    var bkcode = item[1].replace("BK0", "");
                    htmlgn.push('<tr><td><a href="http://quote.eastmoney.com/center/list.html#28003' + bkcode + '_0_2" target="_blank" title="' + item[2] + '">' + cutstr(item[2], 8) + '</a></td><td style="' + udcolor(item[3]) + '">' + fmtdig(item[3] * 10000, "-") + '</td><td>' + link + '</td></tr>');
                }
                removeAllChild("gnzjlpy"); $("#gnzjlpy").append(htmlgn.join(''));
            }
        });
        window.GetBkzj = 0;
    }
}

function LoadLzbk() {
    if (window.GetTimeZoneInfo == true || window.GetLzBk == 1) {

        var url = baseUrl + '/api/qt/clist/get?pi=0&pz=1&po=1&ut=' + ut + '&fs=m:90+t:2&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152,f128,f104,f105,f106&invt=2'
        $.ajax({
            url: url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data.diff['0']
                var str = "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">" +
                    "<tr><td width=\"248\" align=\"center\"><a href=\"http://quote.eastmoney.com/center/list.html#28002" + data.f12.replace("BK0", "") + "_0_2\" target=\"_blank\">" +
                    "<img src=\"http://webquotepic.eastmoney.com/GetPic.aspx?id=" + data.f12 + "1&imageType=rs&token=44c9d251add88e27b65ed86506f6e5da\" border=\"0\" /></a></td><td>" +
                    "<br><p>上涨家数:<span style=\"color:#f00\">" + data.f104 + "</span></p><p>下跌家数:<span style=\"color:#090\">" + data.f105 + "</span></p><p><b>领涨股票：</b></p><p><a href=\"http://quote.eastmoney.com/" + data.f140 + ".html\" target=\"_blank\">" + data.f128 + "</a></p><p>涨幅:<span style=\"color:" + rendercolor(data.f3, 0) + "\">" + (data.f3 == '-' ? '-' : (data.f3 / 100).toFixed(2) +'%') + "</span></p></td></tr></table>";
                $("#lzbkinfo").html(str)
            }
        })
        window.GetLzBk = 0;
    }
}

// 重要指数 zxw
function LoadZyzs() {
    var url = baseUrl + '/api/qt/ulist.np/get?secids=1.000001,0.399001,0.399005,0.399006,100.hsi&ut=' + ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2'
    $.ajax({
        url: url,
        dataType: 'jsonp',
        jsonp: 'cb',
        Type: 'get',
        success: function (json) {
            var list = json.data.diff
            var htm = ''
            for (var i = 0; i < list.length; i++) {
                var color = rendercolor(list[i].f3, 0)
                var zxj = list[i].f2 == '-' ? list[i].f2 : (list[i].f2 / Math.pow(10, list[i].f1)).toFixed(list[i].f1)
                var zdf = list[i].f3 == '-' ? '-' : ((list[i].f3 / 100).toFixed(2) + '%')
                htm += '<tr><td class="nm"><span class="' + color + '"><a href="' + (list[i].f12 == 'HSI' ? 'http://quote.eastmoney.com/hk/zs110000' : ('http://quote.eastmoney.com/zs'+list[i].f12)) + '.html" target="_blank">' + list[i].f14 + '</a></span></td><td class="' + color + '">' + zxj + '</td><td class="' + color + '">' + zdf + '</td></tr>'
            }

            $("#zyzslist").html(htm)
        }
    })
}

function Loadgzqh() {
    if (window.GetTimeZoneInfo == true || window.GetGzqhNUM == 1) {
        var codeList = ['8.040120', '8.040121', '8.060120', '8.060121', '8.070120', '8.070121',]
        var codestr = codeList.join(',')
        var url = baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2'
        $.ajax({
            url: url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var list = json.data.diff
                var htm = ''
                for (var i = 0; i < list.length; i++) {
                    var gzname = list[i].f14.replace("连续", "");
                    var gzcode = gzname.replace("当月", "DYLX").replace("下月", "XYLX");
                    if (gzname.indexOf('IF') < 0) { gzcode = gzcode.replace("LX", ""); }
                    var color = rendercolor(list[i].f3, 0)
                    var zxj = list[i].f2 == '-' ? list[i].f2 : (list[i].f2 / Math.pow(10, list[i].f1)).toFixed(list[i].f1)
                    var zdf = list[i].f3 == '-' ? '-' : ((list[i].f3 / 100).toFixed(2) + '%')
                    htm += '<tr><td class="nm"><a href="http://quote.eastmoney.com/gzqh/' + gzcode + '.html" target="_blank">' + gzname + '</a></td><td class="' + color + '">' + zxj + '</td><td class="' + color + '">' + zdf + '</td></tr>'
                }
                $("#gzqhlist").html(htm)
            }
        })
        window.GetGzqhNUM = 0;
    }
}

function loadRank() {
    if (window.GetTimeZoneInfo == true || window.GetRankNUM == 1) {
        var fs = _this._Market == 1 ? 'm:1+t:2+f:!18' :'m:0+t:6+f:!18,m:0+t:13+f:!18,m:0+t:80+f:!18'
        var url = baseUrl + '/api/qt/clist/get?ut=' + ut + '&pi=0&pz=15&po=1&fs='+ fs  +'&fid=f3&fields=f1,f2,f3,f12,f13,f14&invt=2'
        //console.log(url)
        $.ajax({
            url: url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                //console.log('涨幅排行>>',json.data.diff)
                var list = json.data.diff
                var htm = ''
                for (var i in list) {
                    var color = rendercolor(list[i].f3, 0)
                    var zxj = list[i].f2 == '-' ? list[i].f2 : (list[i].f2 / Math.pow(10, list[i].f1)).toFixed(list[i].f1)
                    var zdf = list[i].f3 == '-' ? '-' : ((list[i].f3 / 100).toFixed(2) + '%')
                    htm += '<tr><td class="nm"><a href="http://quote.eastmoney.com/' + list[i].f12 + '.html" target="_blank">' + list[i].f14 + '</a></td><td class="' + color + '">' + zxj + '</td><td class="' + color + '">' + zdf + '</td></tr>'
                }
                $("#pylist").html(htm)
            }
        })
        window.GetRankNUM = 0;
    }
}

//行业资金流向图
function loadhyzjlx() {
    var url = baseUrl + '/api/qt/clist/get?pi=0&pz=38&po=1&ut=' + ut + '&fs=m:90+t:2&fid=f62&fields=f1,f2,f3,f12,f13,f14,f62,f152,f128,f204&invt=2'
    $.ajax({
        type: "GET",
        url: url,
        data: null,
        dataType: 'jsonp',
        jsonp: 'cb',
        success: function (res) {
            chart({ data: res.data.diff, appendHTML: "<span class='danwei'>单位：亿元</span><div class='shuoming'><i class='sup'>&nbsp;</i>主力净流入 <i class='sdown'>&nbsp;</i>主力净流出</div>", many: 38 })
        }
    })
}


//研究报告
function yjbgList() {
    // console.log('研究报告');

     //行业研报
    var date = new Date();
    date = new Date(date.setFullYear(date.getFullYear()-2)) ;
    var fields = 'orgCode,orgSName,sRatingName,encodeUrl,title,publishDate';
    var  _url = "http://reportapi.eastmoney.com/report/list?beginTime="+ formateDate(date,"yyyy-MM-dd")+"&endTime="+ formateDate(new Date(),"yyyy-MM-dd")+"&pageNo=1&pageSize=4&qType=1&industryCode=*&fields="+ fields;
    var that = this;
    var html = '<tr><td align="center">机构</td><td align="center">评级</td><td class="text-indent10">研报</td></tr>';
    getNewReportUrl(_url,function(data){
        for(var i = 0;i<data.length;i++){
            var item = data[i];
            html += '<tr style="line-height:25px;"><td align="center"><a target="_blank" href="http://data.eastmoney.com/report/orgpublish.jshtml?orgcode='+item.orgCode+'" class="lightBlue" title="'+item.orgSName+'">'+ txtPoint(item.orgSName) +'</a></td>'+
                        '<td align="center"><span>'+ txtPoint(item.sRatingName) +'</span></td>'+
                        '<td class="text-indent10"><span class="dt">'+ formateDate(item.publishDate,"MM-dd")+'</span><a target="_blank" href="http://data.eastmoney.com/report/zw_industry.jshtml?encodeUrl=' + item.encodeUrl +'" title="'+item.title+' ">'+cutstr(item.title,22)+'</a></td></tr>'
    }
    $("#hyybTable tbody").html(html)

        },function(){
            html += "<tr><td colspan=\"3\"><span class=\"nodatalist\">暂无数据</span></td></tr>";
            $("#hyybTable tbody").html(html)
        })

}

//截取字数长度 大于四字则截取
function txtPoint(value) {
    var len = value.length,
        charCode = -1,
        realLength = 0
        strChar=[];
    
    if (len > 4) {
        value = value.substr(0,4) + '..';
    }

    return value
}

//
function formateDate(date, fmt) {
            fmt = fmt || "yyyy-MM-dd HH:mm:ss"
            if (typeof date === "string")
                date = new Date(date.replace(/-/g, '/').replace('T', ' ').split('+')[0]);
            var o = {
                "M+": date.getMonth() + 1, //月份         
                "d+": date.getDate(), //日         
                "h+": date.getHours() % 12 == 0 ? 12 : date.getHours() % 12, //小时         
                "H+": date.getHours(), //小时         
                "m+": date.getMinutes(), //分         
                "s+": date.getSeconds(), //秒         
                "q+": Math.floor((date.getMonth() + 3) / 3), //季度         
                "S": date.getMilliseconds() //毫秒         
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[date.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
}


//获取新版研报接口
function getNewReportUrl(url,sucess,fail){
    $.ajax({
        url:url,
        dataType: "jsonp",
        scriptCharset: "utf-8",
        jsonp:"cb",
        jsonpCallback:'callback' + Math.floor(Math.random() * 10000000 + 1)
    }).done(function(json){
        try{
            if(json && json.data && json.data.length){
                sucess &&sucess(json.data)
            }else{
                fail && fail()
            }
        }catch(error){
           console && console.log(error)
            fail && fail()
        }
    }).fail(function(error){
        console && console.log(error)
        fail && fail()
    })
}


function loadKuaiXun() {
    clearInterval(window.kxst); countRDown(60);
    var sjs = Math.random().toString().replace('.', '');
    var padRight = window.GetKX == 1 ? "" : "&id=" + window.GetKXMaxID;
    jQuery.ajax({
        url: "http://newsapi.eastmoney.com/kuaixun/v2/api/list?column=zhiboall&limit=50" + padRight,
        dataType: "jsonp",
        scriptCharset: "utf-8",
        jsonpCallback: "callback" + sjs,
        success: function (json) {
            if (json.rc = 1) {
                var info = json.news;
                var html = "";
                for (var i = 0; i < info.length; i++) {
                    var TopZbStr = "";
                    if (i == 0) { TopZbStr = '<span class="dt">' + gethhmm(info[i].showtime) + '</span><span class="t">' + info[i].title + '</span>'; }
                    if (info[i].newstype == 1) {//news.
                        html += '<li><span class="kx_itime">' + gethhmm(info[i].showtime) + '</span><span class="kx_itime_end">|</span><span class="bd_i_txt' + kxgetstyle(info[i].titlestyle) + '"><a href="' + info[i].url_unique + '" target="_blank">';
                        if (info[i].digest != "") { html += info[i].digest.replace(/\n+/g, "<br />"); } else { html += info[i].title; }
                        html += '&nbsp;[点击查看全文]</a></span></li>';
                        if (i == 0) { TopZbStr = '<span class="dt">' + gethhmm(info[i].showtime) + '</span><span class="t"><a href="' + info[i].url_unique + '" target="_blank">' + info[i].title + '</a></span>'; }
                    }
                    else if (info[i].newstype == 2) {//zhaiyao.
                        html += '<li><span class="kx_itime">' + gethhmm(info[i].showtime) + '</span><span class="kx_itime_end">|</span><span class="bd_i_txt' + kxgetstyle(info[i].titlestyle) + '">' + info[i].digest + '</span></li>';
                    }
                    else {
                        html += '<li><span class="kx_itime">' + gethhmm(info[i].showtime) + '</span><span class="kx_itime_end">|</span><span class="bd_i_txt' + kxgetstyle(info[i].titlestyle) + '"><a href="' + info[i].url_unique + '" target="_blank">' + info[i].title + '&nbsp;>[点击查看全文]</a></span></li>';
                        TopZbStr = '<span class="dt">' + gethhmm(info[i].showtime) + '</span><span class="t"><a href="' + info[i].url_unique + '" target="_blank">' + info[i].title + '</a></span>';
                    }
                    if (i == 0) { $x("ScrollMIIRBox").innerHTML = TopZbStr; window.GetKXMaxID = json.MaxID; }
                }
                var tipstr = info.length == 0 ? "暂无新闻更新" : "刚刚为您更新了" + info.length + "条新闻";
                if (html != "") {
                    if (window.GetKX == 1) { $x("kx_lists").innerHTML = html; } else {
                        $("#kx_lists").prepend(html);
                        $x("tipstr").innerHTML = tipstr;
                        setTimeout(function () { $x("tipstr").innerHTML = "直播中..."; }, 3000)
                    }
                } else {
                    $x("tipstr").innerHTML = "暂无新闻更新";
                    setTimeout(function () { $x("tipstr").innerHTML = "直播中..."; }, 3000)
                }
                window.GetKX = 0;
            }
        }
    });
}

// 全球直播和财富号 轮询
function caifuhao() {
    var timeCount = 0;
    var cfhIndex = 0;

    var list = window.cfhArtilce || [];

    if (list.length > 0) {

        var html = $(".gszb .lox").clone().html();
        // var html1 = $(".gszb .lox").html();
        // var html2 = $(".gszb .rox").html();
        // var newhtml = html1 + html1.replace("lox", "cfh") + html2;

        var html = '<div class="cfh" style="display: none;">' +
            '<div class="tit"><a href="http://caifuhao.eastmoney.com/" target="_blank">财富号</a></div>' +
            '<div class="cnt"><ul><li id="ScrollMIIRBox2"><span class="dt">21:06</span><span class="t"><a href="" target="_blank"></a></span></li></ul></div>' +
            '</div>';

        var clone = $(html);

        $(".gszb .rox").before(clone);

        // 每分钟切换一次
        setInterval(function () {
            if (timeCount % 2 == 0) {
                $(".gszb .lox").hide();
                $(".gszb .cfh").show();
            } else {
                $(".gszb .lox").show();
                $(".gszb .cfh").hide();
            }

            timeCount++;
        }, 60 * 1000);


        setInterval(function () {
            var item = list[cfhIndex];
            var sp1 = $("<span class='dt'></span>").text((item.Showtime || "").substr(10, 6));
            var sp2 = $("<span class='t'><a target='_blank'></a></span>");
            sp2.find("a").attr("href", "http://caifuhao.eastmoney.com/news/" + item.ArtCode).text(item.Title);

            clone.find(".cnt li").html("").append(sp1).append(sp2);
            cfhIndex++;

            cfhIndex = cfhIndex % list.length;
        }, 10 * 1000);
    }

}



function kxgetstyle(titlestyle) {
    //0-默认 1-加粗 2-跳红 3-跳红加粗.
    var res = "";
    switch (titlestyle) {
        case "1": res = " bold"; break;
        case "2": res = " red"; break;
        case "3": res = " redbold"; break;
    }
    return res;
}

function countRDown(secs) {
    $x("kx_auto_sec").innerHTML = secs;
    if (--secs >= 0) { window.kxst = setTimeout("countRDown(" + secs + ")", 1000); }
    else { loadKuaiXun(); }
}

window.countRDown = countRDown

//更新资金流数据
function RefZjlx(zjlcode) {
    //if (window.GetTimeZoneInfo == true || window.GetZjlxNUM == 1) {
    //    var rcode = _this._Market == "1" ? "3990012" : "0000011";
    //    jQuery.ajax({
    //        url: "http://nufm3.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=P.(x),(x)|" + zjlcode + "," + _this._Code + _this._Market + "|" + rcode + "&sty=IFDPFI|IFDPFITA&token=" + token,
    //        dataType: "jsonp",
    //        scriptCharset: "utf-8",
    //        jsonp: 'cb',
    //        success: function (json) {
    //            if (json.length == 3) {
    //                var item = json[0].split(',');
    //                var ritem = json[2].split(',');
    //                var jitem = json[1].split(',');
    //                //$x("hz_a").innerHTML = fmtdigm(item[3] * 10000, 0, "亿元");
    //                //$x("hz_b").innerHTML = fmtdigm(item[4].replace('-', '') * 10000, 0, "亿元");
    //                //$x("hz_c").innerHTML = fmtdigm(ForDight(parseFloat(item[3]) + parseFloat(item[4]), 2) * 10000, 0, "亿元").replace('-', ''); $x("hz_c").className = udcls(ForDight(parseFloat(item[3]) + parseFloat(item[4]), 2));
    //                //$x("hz_c_t").innerHTML = $x("hz_c").className == "green" ? "主力净流出" : "主力净流入";
    //                //$x("hz_d").innerHTML = fmtdigm(Math.abs(item[6]), 0, "-"); $x("hz_e").innerHTML = fmtdigm(Math.abs(item[7]), 0, "-");
    //                //$x("hz_f").innerHTML = fmtdigm(Math.abs(item[8]), 0, "-"); $x("hz_g").innerHTML = fmtdigm(Math.abs(item[9]), 0, "-");
    //                //$x("hz_h").innerHTML = fmtdigm(Math.abs(item[10]), 0, "-"); $x("hz_i").innerHTML = fmtdigm(Math.abs(item[11]), 0, "-");
    //                //$x("hz_j").innerHTML = fmtdigm(Math.abs(item[12]), 0, "-"); $x("hz_k").innerHTML = fmtdigm(Math.abs(item[13]), 0, "-");
    //                //var _l = [[item[6], item[7]], [item[8], item[9]], [item[10], item[11]], [item[12], item[13]]]; ZjlxCek(_l);
    //                ////
                   
    //                //$x("rstocka").innerHTML = "<a href=\"http://quote.eastmoney.com/zs" + ritem[1] + ".html\" target=\"_blank\">" + ritem[2] + "A股行情</a>";
    //                //$x("rstockb").innerHTML = ritem[3] + "&nbsp;&nbsp;" + ritem[4] + "&nbsp;&nbsp;" + ritem[5]; $x("rstockb").className = udcls(ritem[4]);
    //                //
    //            }
    //        }
    //    });
    //    window.GetZjlxNUM = 0;
    //}


    //function percentRender(data) {
    //    if (typeof data === 'number') return data + '%';
    //    if (!isNaN(data) && data.indexOf('%') !== data.length - 1) {
    //        return data + '%';
    //    }
    //    return data;
    //}
}


function getHqStat(stat) {
    var str = "";
    switch (stat) {
        case 1: str = '<b class="red on" title="' + stat + '"></b>集合竞价'; $x("hqstat").className = "hqstat red"; break;
        case 4: str = '<b class="red on" title="' + stat + '"></b>集合竞价'; $x("hqstat").className = "hqstat red"; break;
        case 2: str = '<b class="red on" title="' + stat + '"></b>交易中'; $x("hqstat").className = "hqstat red"; break;
        case 3: str = '<b class="off" title="' + stat + '"></b>午间休市'; break;
        case 5: str = '<b class="off" title="' + stat + '"></b>已收盘'; break;
    }
    $x("hqstat").innerHTML = str;
}

//资金流向数据更新
function ZjlxCek(ls) {
    var _in = 0; var _out = 0; var items = [];
    for (var i = 0; i <= 3; i++) {
        var _l = parseFloat(ls[i][0]) + parseFloat(ls[i][1]);
        $x("hz_" + i + "l").innerHTML = ""; $x("hz_" + i + "r").innerHTML = "";
        if (_l >= 0) {
            _in += Math.abs(parseFloat(_l));
            $x("hz_" + i + "l").innerHTML = "<div class=\"box\" id=\"hz_" + i + "h\"></div><span class=\"red\">" + fmtdigm(_l, 1, "-") + "</span>";
            $x("hz_" + i + "l").style.borderBottom = "1px solid #ccc";
        }
        if (_l < 0) {
            _out += Math.abs(parseFloat(_l));
            $x("hz_" + i + "r").innerHTML = "<div class=\"box\" id=\"hz_" + i + "h\"></div><span class=\"green\">" + fmtdigm(_l, 1, "-") + "</span>";
            $x("hz_" + i + "r").style.borderTop = "1px solid #ccc";
        }
        items[i] = Math.abs(_l);
    }
    var total = _out + _in;
    for (var i = 0; i <= 3; i++) {
        if (items[i] != 0) {
            $x("hz_" + i + "h").style.height = items[i] / total * 36 + "px";
        }
    }
}

function showMore(tp, obj) { var over = $x("xh" + tp + obj).style.display = "block"; }
function hideall(tp, obj) { var over = $x("xh" + tp + obj).style.display = "none"; }

function fmtdig(Data, _Unit) {//数值,阀值，小数位，单位后尾随字符(为-表示不需要)
    var isfs = false;
    if (parseFloat(Data) < 0) { isfs = true; }
    var res = Data; var Unit = "万"; var Fix = 0; var Mat = 10000;
    if (Data != "" && Data != "--" && Data != "-") {
        var _temp = parseFloat(Math.abs(Data));
        if (_temp > 100000000000)//大于千亿
        {
            Mat = 1000000000000; Unit = "万亿"; Fix = 2;
        }
        else if (_temp > 100000000000)//等于千亿
        {
            Mat = 100000000; Unit = "亿"; Fix = 0;
        }
        else if (_temp > 100000000)//大于等于亿
        {
            Mat = 100000000; Unit = "亿"; Fix = 2;
        }
        else if (_temp == 0)//等于0
        {
            Mat = 1; Unit = ""; Fix = 0; _Unit = "-"
        }
        res = ForDight((_temp / Mat), Fix);
    }
    return (isfs ? "-" : "") + res + Unit + (_Unit == "-" ? "" : _Unit);
}

function fmtdigw(Data, Fix, padRight) {//数值 单位固定亿
    var isfs = false;
    if (parseFloat(Data) < 0) { isfs = true; }
    var res = Data; var Mat = 10000;
    if (Data != "" && Data != "--" && Data != "-") {
        var _temp = parseFloat(Math.abs(Data));
        res = ForDight((_temp / Mat), Fix);
    }
    return (isfs ? "-" : "") + res + (padRight == "-" ? "" : padRight);
}

function fmtdigm(Data, Fix, padRight) {//数值 单位固定亿
    var isfs = false;
    if (parseFloat(Data) < 0) { isfs = true; }
    var res = Data; var Mat = 100000000;
    if (Data != "" && Data != "--" && Data != "-") {
        var _temp = parseFloat(Math.abs(Data));
        res = ForDight((_temp / Mat), Fix);
    }
    return (isfs ? "-" : "") + res + (padRight == "-" ? "" : padRight);
}

//时间随机数
function formatm() {
    var now = new Date();
    return now.getDate() + "" + now.getHours() + "" + now.getMinutes() + "";
}

function gethhmm(time) { return time.substr(11, 5); }

//随机数
function GetRandomNum(Min, Max) { var Range = Max - Min; var Rand = Math.random(); return (Min + Math.round(Rand * Range)); }

function showimg() {
    $x("js_box").style.display = "none";
    var c_cn = $x("kx_list").className;
    if (c_cn.indexOf("fz14") > 0) {
        $x("kx_list").className = "kx_list kx_fz14";
    } else {
        $x("kx_list").className = "kx_list";
    }
    $x("image_box").style.display = "block"; window.zxgIsFirst = true; window.quoteIsFirst = true; //Def.DisQuote();
    WriteCookie("em_hq_fls", "old", 99999);
}
window.showimg = showimg

function showjs() {
    $x("js_box").style.display = "block";
    var c_cn = $x("kx_list").className;
    if (c_cn.indexOf("fz14") > 0) {
        $x("kx_list").className = "kx_list kx_fz14 kx_listfls";
    } else {
        $x("kx_list").className = "kx_list kx_listfls";
    }
    $x("image_box").style.display = "none"; window.zxgIsFirst = true; window.quoteIsFirst = true; //Def.DisQuote();
    WriteCookie("em_hq_fls", "js", 99999);
}

window.showjs = showjs

function showfls() {
    $x("flash_box").style.display = "block";
    var c_cn = $x("kx_list").className;
    if (c_cn.indexOf("fz14") > 0) {
        $x("kx_list").className = "kx_list kx_fz14 kx_listfls";
    } else {
        $x("kx_list").className = "kx_list kx_listfls";
    }
    $x("image_box").style.display = "none"; window.zxgIsFirst = true; window.quoteIsFirst = true; Def.DisQuote();
    WriteCookie("em_hq_fls", "new", 99999);
    var picrtr = $x("actTab1").getElementsByTagName("span");
    var picrtk = $x("actTab2").getElementsByTagName("span");
    for (var i = 2; i < picrtr.length; i++) {
        if (picrtr[i].className == "cur") {
            setTimeout(function () { stockr.selectDay(i - 1); }, 200);
            break;
        }
    }
    for (var j = 0; j < picrtk.length; j++) {
        if (picrtk[j].className == "cur") {
            setTimeout(function () { stock.kMT = false; stock.FlashObj.selectButton(j + 1, 10); }, 2000);
            break;
        }
    }
}

window.hotpersonafp = function hotpersonafp(uid, oid, marketcode) {
    var iscks = false;
    if (GetCookie("pi")) {
        var gcks = Getcks("pi");
        if (gcks.split(';').length >= 3) {
            var name = gcks.split(';')[2];
            if (/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) { iscks = true; }
            else {
                var url = "http://iguba.eastmoney.com/action.aspx?callback=&action=oaddfollowperson&uid2=" + uid;
                Min.Loader.load(url + "&v=" + formatm(), "utf-8", function () {
                    oid.className = "allow"; oid.innerHTML = ""; oid.onclick = null;
                });
            }
        }
        else { iscks = true; }
    }
    else { iscks = true; }
    if (iscks) {
        location.href = "https://passport2.eastmoney.com/pub/login?backurl=" + location.href;
    }
}


function getdomain(min, max) {
    var min = 1; var max = 10;
    var res = "nufm3.dfcfw.com"; var m2 = "nufm2.dfcfw.com";
    var rom = GetRandomNum(min, max);
    if (rom != "1" && rom != "2" && rom != "3") { res = m2; }//80% ->nufm2
    //if (rom == "1") { res = m2; }//10% ->nufm2
    return res;
}

function removeAllChild(obj) {
    var div = $x(obj);
    while (div.hasChildNodes()) //当div下还存在子节点时 循环继续
    {
        div.removeChild(div.firstChild);
    }
}


window.onload = function () {
    setTimeout(function () {
        caifuhao();
    }, 500);
}


/***/ }),

/***/ "./src/modules/old_zs/quote_phf.js":
/*!*****************************************!*\
  !*** ./src/modules/old_zs/quote_phf.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function quote_phf() {
    this.Browser = {
        ie: /msie/.test(window.navigator.userAgent.toLowerCase()),
        ie11: /trident/.test(window.navigator.userAgent.toLowerCase()),
        moz: /gecko/.test(window.navigator.userAgent.toLowerCase()),
        opera: /opera/.test(window.navigator.userAgent.toLowerCase()),
        safari: /safari/.test(window.navigator.userAgent.toLowerCase())
    };
}
//收藏
quote_phf.prototype.addBookMark = function () {
    var title = document.title;
    var url = location.href;
    if (window.sidebar) { window.sidebar.addPanel(title, url, ""); }
    else if (document.all) {
        window.external.AddFavorite(url, title);
    } else if (window.opera && window.print) {
        return true;
    }
};
//收藏
quote_phf.prototype.addBookEM = function () {
    var title = "东方财富网——中国财经证券门户网站";
    var url = "http://www.eastmoney.com/";
    if (window.sidebar) { window.sidebar.addPanel(title, url, ""); }
    else if (document.all) {
        window.external.AddFavorite(url, title);
    } else if (window.opera && window.print) {
        return true;
    }
};
//查行情
quote_phf.prototype.toQuote = function () {
    _this = this;
    stockcode_current = _this.trim(this.$(("StockCode")).value);
    if (stockcode_current == "输代码、名称或简拼" || stockcode_current == "") { window.open('http://quote.eastmoney.com/'); return false; }
    var re = /[0-9]{6}/; var re2 = /[0-9]{1,}/; var re3 = /[^0-9]{1,}/;
    bool1 = stockcode_current.match(re); bool2 = stockcode_current.match(re2); bool3 = stockcode_current.match(re3);
    if (bool1 != null && stockcode_current.length == 6) {
        window.open('http://quote.eastmoney.com/search.html?stockcode=' + escape(stockcode_current)); return false;
    }
    else {
        if (bool2 != null && bool3 == null && stockcode_current.length < 3) { alert("股票代码至少输入3位！"); return false; }
        if (bool2 == null && bool3 != null && stockcode_current.length < 2) { alert("模糊查询时关键字至少2位！"); return false; }
        window.open('http://quote.eastmoney.com/search.html?stockcode=' + escape(stockcode_current)); return false;
    }
    return (false);
};
//进股吧
quote_phf.prototype.toGuBa = function () {
    stockcode_current = this.$(("StockCode")).value;
    if (stockcode_current == "输代码、名称或简拼" || stockcode_current == "") { window.open('http://guba.eastmoney.com/'); return false; }
    //var re=/[0-9]{6}/; 
    //bool1=stockcode_current.match(re);
    //if(bool1!=null){window.open('http://guba.eastmoney.com/topic,'+stockcode_current+'.html');}
    //else{window.open('http://quote.eastmoney.com/search.html?toba=1&stockcode='+escape(stockcode_current));}
    window.open('http://quote.eastmoney.com/search.html?toba=1&stockcode=' + escape(stockcode_current));
};
//查资讯
quote_phf.prototype.toNews = function () {
    stockcode_current = this.$(("StockCode")).value;
    if (stockcode_current == "输代码、名称或简拼") { window.open('http://so.eastmoney.com/'); } else { window.open('http://so.eastmoney.com/Search.htm?q=' + escape(stockcode_current) + '&t=2'); }
};
quote_phf.prototype.getIndexQuote = function (RefreshTime) {
    var _this = this;
    _this.init = function () {
        _this.bindCLK();
        _this.display();
        _this.gethgts();
        if (RefreshTime != "" && RefreshTime != "undefined" && RefreshTime != null) { setInterval(_this.display, 60*1000); setInterval(_this.gethgts, 50000); }

        _this.zxjjHref();
        _this.portfolio();
        _this.headlines();
    };
    _this.display = function () {
        var xvs = parseInt(_this.$("qqgscont").getAttribute("xvs"));       
        switch (xvs) {
            case 1:         
                var secids = "100.DJIA,100.NDX,100.N225,100.HSI";
                var obj = [
                    {
                        link: "gb/zsINDU.html",
                        name:"道琼斯"
                    },
                    {
                        link: "gb/zsCCMP.html",
                        name: "纳斯达克"
                    },
                    {
                        link: "gb/zsNKY.html",
                        name: "日经"
                    },
                    {
                        link: "gb/zs110000.html",
                        name: "恒生"
                    }                    
                ]
                _this.qqgsLoad(secids, obj);                
                break;
            case 2:
                var secids = "100.GDAXI,100.FCHI,100.FTSE,100.ATX";
                var obj = [
                    {
                        link: "gb/zsDAX.html",
                        name: "德DAX"
                    },
                    {
                        link: "gb/zsCAC.html",
                        name: "法CAC"
                    },
                    {
                        link: "gb/zsUKX.html",
                        name: "英FT"
                    },
                    {
                        link: "gb/zsATX.html",
                        name: "奥ATX"
                    }
                ]
                _this.qqgsLoad(secids, obj);            
                break;
            default:
                var secids = "1.000001,0.399001";
                var obj = [
                    {
                        link: "zs000001.html",
                        name: "上证"
                    },
                    {
                        link: "zs399001.html",
                        name: "深证"
                    }
                    
                ]
                _this.qqgsLoad(secids, obj);   


        }
    };
    //全球股市
    _this.qqgsLoad = function (secids, obj) {        
        //var mathNum = Math.floor(Math.random() * 100);//接口加随机数 
        var _url = "http://push2.eastmoney.com/api/qt/ulist.np/get?fid=f3&pi=0&pz=20&po=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&fields=f2,f3,f4,f6,f104,f105,f106&np=1&cb=qqgsData=&secids=" + secids;      
        _this.JsLoader(_url, 'utf-8', function () {
            var _qqgsData = eval("qqgsData");           
            if (_qqgsData && _qqgsData.data) {
                var items = _qqgsData.data.diff;             
                if (items.length > 0) {
                    var link = "//quote.eastmoney.com/";
                    if (obj.length > 2) {
                        var tem_a = items[0],
                            tem_b = items[1],
                            tem_c = items[2],
                            tem_d = items[3];

                        var obj_a = obj[0], obj_b = obj[1], obj_c = obj[2], obj_d = obj[3];

                        //道琼斯,纳斯达克,日经,恒生                                
                        var _temstrs = "<a href='" + link + obj_a.link + "'target=\"_blank\" class=\"blue\"><strong>" + obj_a.name + "</strong></a> <span style=\"" + _this.udcolor(tem_a.f3) + "\"><b>" + _this.toFixedFun(tem_a.f2) + "</b> " + _this.zdbjt(tem_a.f3) + "<b>" + _this.toFixedFun(tem_a.f4) + "</b> " + _this.zdbjt(tem_a.f3) + "<b>" + _this.addPercent(tem_a.f3) + "</b></span>";
                        _temstrs += "<a href='" + link + obj_b.link + "'target=\"_blank\" class=\"blue\"><strong>" + obj_b.name + "</strong></a> <span style=\"" + _this.udcolor(tem_b.f3) + "\"><b>" + _this.toFixedFun(tem_b.f2) + "</b> " + _this.zdbjt(tem_b.f3) + "<b>" + _this.toFixedFun(tem_b.f4) + "</b> " + _this.zdbjt(tem_b.f3) + "<b>" + _this.addPercent(tem_b.f3) + "</b></span>";
                        _temstrs += "<a href='" + link + obj_c.link + "'target=\"_blank\" class=\"blue\"><strong>" + obj_c.name + "</strong></a> <span style=\"" + _this.udcolor(tem_c.f3) + "\"><b>" + _this.toFixedFun(tem_c.f2) + "</b> " + _this.zdbjt(tem_c.f3) + "<b>" + _this.toFixedFun(tem_c.f4) + "</b> " + _this.zdbjt(tem_c.f3) + "<b>" + _this.addPercent(tem_c.f3) + "</b></span>";
                        _temstrs += "<a href='" + link + obj_d.link + "'target=\"_blank\" class=\"blue\"><strong>" + obj_d.name + "</strong></a> <span style=\"" + _this.udcolor(tem_d.f3) + "\"><b>" + _this.toFixedFun(tem_d.f2) + "</b> " + _this.zdbjt(tem_d.f3) + "<b>" + _this.toFixedFun(tem_d.f4) + "</b> " + _this.zdbjt(tem_d.f3) + "<b>" + _this.addPercent(tem_d.f3) + "</b></span>";

                    } else if (0 < obj.length < 4) {
                        var tem_a = items[0],
                            tem_b = items[1];

                        var obj_a = obj[0], obj_b = obj[1];

                        var _temstrs = "<a href='" + link + obj_a.link + "' target=\"_blank\" class=\"blue\"><strong>" + obj_a.name + "</strong></a>：<span style=\"" + _this.udcolor(tem_a.f3) + "\"><b>" + _this.toFixedFun(tem_a.f2) + "</b> " + _this.zdbjt(tem_a.f3) + "<b>" + _this.toFixedFun(tem_a.f4) + "</b> <b>" + _this.addPercent(tem_a.f3) + "  " + _this.ForDight(tem_a.f6 / 100000000, 2) + "</b></span>亿元(涨:<a href=\"http://quote.eastmoney.com/center/list.html#10_0_0_u?sortType=C&sortRule=-1\" target=\"_blank\" class=\"red\"><b>" + tem_a.f104 + "</b></a> 平:<b>" + tem_a.f106 + "</b> 跌:<a href=\"http://quote.eastmoney.com/center/list.html#10_0_0_d?sortType=C&sortRule=1\" target=\"_blank\" class=\"green\"><b>" + tem_a.f105 + "</b></a>)";
                        _temstrs += "<a href='" + link + obj_b.link + "' target=\"_blank\" class=\"blue\"><strong>" + obj_b.name + "</strong></a>：<span style=\"" + _this.udcolor(tem_b.f3) + "\"><b>" + _this.toFixedFun(tem_b.f2) + "</b> " + _this.zdbjt(tem_b.f3) + "<b>" + _this.toFixedFun(tem_b.f4) + "</b> <b>" + _this.addPercent(tem_b.f3) + "  " + _this.ForDight(tem_b.f6 / 100000000, 2) + "</b></span>亿元(涨:<a href=\"http://quote.eastmoney.com/center/list.html#20_0_0_u?sortType=C&sortRule=-1\" target=\"_blank\" class=\"red\"><b>" + tem_b.f104 + "</b></a> 平:<b>" + tem_b.f106 + "</b> 跌:<a href=\"http://quote.eastmoney.com/center/list.html#20_0_0_d?sortType=C&sortRule=1\" target=\"_blank\" class=\"green\"><b>" + tem_b.f105 + "</b></a>)";

                    }
                    _this.$("qqgscont").innerHTML = "<ul><li>" + _temstrs + "</li></ul>";

                }
            }
        })

    };   



    //头部自选基金强制换链接
    _this.zxjjHref = function () {
        var box = _this.getClassNames("qmbox", "div");
        box[0].getElementsByTagName('li')[28].children[0].setAttribute("href", 'http://favor.fund.eastmoney.com/');
    }
    _this.getClassNames = function (classStr, tagName) {
        if (document.getElementsByClassName) {
            return document.getElementsByClassName(classStr)
        } else {
            var nodes = document.getElementsByTagName(tagName), ret = [];
            for (i = 0; i < nodes.length; i++) {
                if (_this.hasClass(nodes[i], classStr)) {
                    ret.push(nodes[i])
                }
            }
            return ret;
        }
    }
    _this.hasClass = function (tagStr, classStr) {
        var arr = tagStr.className.split(/\s+/);  //这个正则表达式是因为class可以有多个,判断是否包含
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] == classStr) {
                return true;
            }
        }
        return false;
    }




    // 沪深港通接口
    _this.gethgts = function () {
        _this.JsLoader("http://push2.eastmoney.com/api/qt/kamt/get?fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54&ut=b2884a393a59ad64002292a3e90d46a5&cb=hsgtData=&rt=" + Math.random(), 'utf-8', function () {
            var _hsgtData = eval("hsgtData");
            if (_hsgtData != undefined) {
                var item = _hsgtData.data
                if (item) {

                    var hgtzj = item.hk2sh.dayNetAmtIn == 0 ? '-' : _this.vsfmt(item.hk2sh.dayNetAmtIn, 1, 1),
                        sgtzj = item.hk2sz.dayNetAmtIn == 0 ? '-' : _this.vsfmt(item.hk2sz.dayNetAmtIn, 1, 1),
                        ggthzj = item.sh2hk.dayNetAmtIn == 0 ? '-' : _this.vsfmt(item.sh2hk.dayNetAmtIn, 1, 1),
                        ggtszj = item.sz2hk.dayNetAmtIn == 0 ? '-' : _this.vsfmt(item.sz2hk.dayNetAmtIn, 1, 1);

                    _this.$("hgtzj").innerHTML = hgtzj; // 沪股通
                    _this.$("sgtzj").innerHTML = sgtzj; // 深股通
                    _this.$("ggthzj").innerHTML = ggthzj; // 港股通(沪)
                    _this.$("ggtszj").innerHTML = ggtszj; // 港股通(深)   

					if(item.hk2sh.status===4){
					_this.$("hgtzj").innerHTML = "- -";
					}
					
					if(item.hk2sz.status===4){
					_this.$("sgtzj").innerHTML = "- -";
					}
					
                    if(item.sh2hk.status === 4){
                        _this.$("ggthzj").innerHTML = "- -";
                    }

                    if(item.sz2hk.status === 4){
                        _this.$("ggtszj").innerHTML = "- -";
                    }

                    _this.$("hgtrun").innerHTML = _this.GetGangGuTongPNG(item.hk2sh.status);
                    _this.$("sgtrun").innerHTML = _this.GetGangGuTongPNG(item.hk2sz.status);
                    _this.$("ggthrun").innerHTML = _this.GetGangGuTongPNG(item.sh2hk.status);
                    _this.$("ggtsrun").innerHTML = _this.GetGangGuTongPNG(item.sz2hk.status);
                }

            }
        })

    }

    _this.bindCLK = function () {
        var obu = _this.$("btn_up"); var obd = _this.$("btn_down"); var oj = _this.$("qqgscont");
        obu.onclick = function () { var xvs = parseInt(oj.getAttribute("xvs")); xvs++; if (xvs >= 3) { xvs = 0; } oj.setAttribute("xvs", xvs); _this.display(); };
        obd.onclick = function () { var xvs = parseInt(oj.getAttribute("xvs")); xvs--; if (xvs < 0) { xvs = 2; } oj.setAttribute("xvs", xvs); _this.display(); };
    };
    //投资组合  还未测试
    _this.portfolio = function () {
        if (!_this.$("zhrool")) return false;
        _this.JsLoader('http://quote.eastmoney.com/api/static/portfolio.json?cb=var%20portfolioData=', 'utf-8', function () {
            var _portfolioData = eval("portfolioData");
            // console.log(_portfolioData)
            if (_portfolioData) {
                var data = _portfolioData.data;
                var rd, rw, rm, ry;
                rd = data.ReturnRateDaily;
                rw = data.ReturnRateWeekly;
                rm = data.ReturnRateMonthly;
                ry = data.ReturnRateYearly;
                if (!rd || !rw || !rm || !ry) return false;
                // var $dom = $('zhrool');
                var $Html = ' <li><a href="http://group.eastmoney.com/index.html" target="_blank">高手日收益达<span>' + rd + '</span></a></li>' +
                    '<li><a href="http://group.eastmoney.com/index.html" target="_blank">高手周收益达<span>' + rw + '</span></a></li>' +
                    '<li><a href="http://group.eastmoney.com/index.html" target="_blank">高手月收益达<span>' + rm + '</span></a></li>' +
                    '<li><a href="http://group.eastmoney.com/index.html" target="_blank">高手年收益达<span>' + ry + '</span></a></li>';

                _this.$("zhrool").innerHTML = $Html + $Html;

               // var oMarquee = document.getElementById("zhrool"); var iLineHeight = 28; var iLineCount = 1; var iScrollAmount = 1;
                //_this.scrollTopFun()
                setTimeout(_this.scrollTopFun,5000)
            }
        })
    };
   

    _this.scrollTopFun = function (num) {
        var oMarquee = document.getElementById("zhrool"); var iLineHeight = 28; var iLineCount = 4;
        var iScrollAmount = num ?  num : 1;

        _this.$("zhrool").onmouserover = function () {
            _this.scrollTopFun(0)
            console.log(iScrollAmount,"iScrollAmount")
        }.onmouserout = function () {
            _this.scrollTopFun(1)
            console.log(iScrollAmount, "iScrollAmount")
        }       
        oMarquee.scrollTop += iScrollAmount;
        if (oMarquee.scrollTop == iLineCount * iLineHeight)
            oMarquee.scrollTop = 0;
        if (oMarquee.scrollTop % iLineHeight == 0) {
            window.setTimeout(_this.scrollTopFun, 5000);
        } else {
            window.setTimeout(_this.scrollTopFun, 10);
        }       
    };
    //头条
    _this.headlines = function () {
        if (!_this.$('head_toutiao')) return false;
        _this.JsLoader("http://quote.eastmoney.com/api/static/bulletin/1071/?cb=var%20toutiao=", 'utf-8', function () {
            var _toutiao = eval("toutiao");
            if (_this.$('ieTt')) {
                _this.$('ieTt').innerHTML = _toutiao;
                var _Html = _this.$('ieTt').getElementsByTagName("li")[0].children[0].innerHTML;
                _this.$('head_toutiao').setAttribute("title", _Html);
                _this.$('head_toutiao').innerHTML = _Html
            }
        })
    }
    _this.init();
};



quote_phf.prototype.formatm = function () {
    var now = new Date();
    return now.getDate() + "" + now.getHours() + "" + now.getMinutes() + "";
};
//随机数
quote_phf.prototype.GetRandomNum = function (Min, Max) { var Range = Max - Min; var Rand = Math.random(); return (Min + Math.round(Rand * Range)); };
quote_phf.prototype.gmain = function () {
    var _this = this;
    var min = 1; var max = 10;
    var res = "nufm2.dfcfw.com"; var m3 = "nufm3.dfcfw.com";
    var rom = _this.GetRandomNum(min, max);
    if (rom == "1" && rom == "2" && rom == "3" && rom == "4" && rom == "5" && rom == "6") { res = m3; }
    return "nufm.dfcfw.com"; //res;
};
quote_phf.prototype.udcolor = function (vsa, vsb) {   
    vsa = String(vsa).replace("%", "");
    if (vsb == "" || vsb == null || vsb == "undefined") {
        if (vsa > 0) { return "color:#f00"; }
        else if (vsa < 0) { return "color:#090"; }
        else { return ""; }
    }
    else {
        vsb = vsb.replace("%", "");
        if (vsa - vsb > 0) { return "color:#f00"; }
        else if (vsa - vsb < 0) { return "color:#090"; }
        else { return ""; }
    }
};

quote_phf.prototype.udc = function (vs) {
    vs = Number((vs.toString()).replace("%", ""))
    if (vs > 0) {
        return " style=\"color:#f00\"";
    } else if (vs < 0) {
        return " style=\"color:#090\"";
    } else {
        return "";
    }
};
//添加百分号
quote_phf.prototype.addPercent = function (vs) {
    var num = parseFloat(vs),item;
    if (num == 0) {
        item = num.toFixed(2) + "%";
    } else if (num) {
        item = num.toFixed(2) + "%";
    } else {
        item = vs;
    }
    return item
}
//保留两位小数
quote_phf.prototype.toFixedFun = function (vs,tfx) {
    var num = parseFloat(vs), item = "-";
    var tofixed = tfx ? tfx : 2;
    if (num >= 0 || num <= 0 ) {
        item = num.toFixed(tofixed);
    } 
    return item;
}

quote_phf.prototype.vsfmt = function (_vs, iscl, lk) {
    var res = "";
    if (_vs != "" && _vs != "-") {
        var str = _vs * 10000;
        var unit = "";

        var abs = Math.abs(str);
        if (abs + "" == "NaN") {
            return "-";
        } else {
            if (abs > 0 && abs < 10000) {
                unit = "";
            } else if (abs >= 10000 && abs < 100000000) {
                str = str / 10000;
                unit = "万"
            } else if (abs >= 100000000 && abs < 1000000000000) {
                str = str / 100000000;
                unit = "亿"
            } else if (abs >= 1000000000000) {
                str = str / 1000000000000;
                unit = "万亿"
            }
        }
        str = str.toFixed(2);
        if (iscl == 1) {
            if (lk == 1) {
                res = "<b><a href=\"http://data.eastmoney.com/hsgt/index.html\" target=\"_blank\"" + this.udc(str) + ">" + str + "</a></b>" + unit;
            } else {
                res = "<b" + this.udc(str) + ">" + str + "</b>" + unit;
            }
        } else {
            if (lk == 1) {
                res = "<b><a href=\"http://data.eastmoney.com/hsgt/index.html\" target=\"_blank\">" + str + "</a></b>" + unit;
            } else {
                res = "<b>" + str + "</b>" + unit;
            }
        }
    }
    return res.replace("元", "");

};

quote_phf.prototype.GetGangGuTongPNG = function (number) {
    var typeStr = "-";
    var type = parseFloat(number);
    if (type == "NaN" || isNaN(type)) {
        typeStr = '-';
        return typeStr;
    }
    switch (type) {
        case 1:
            typeStr = ' <b></b >有额度';
            break;
        case 2:
            typeStr = '<b class="off"></b>无额度';
            break;
        case 3:
            typeStr = '<b class="off"></b>收盘';
            break;
        case 4:
            typeStr = '<b class="off"></b>休市';
            break;
    }

    return typeStr;



    //switch (type) {    
    //    case 8: typeStr = '<b class="off"></b>5%熔断'; break;
    //    case 9: typeStr = '<b class="off"></b>7%熔断'; break;
    //    case 10: typeStr = '<b class="off"></b>-5%熔断'; break;
    //    case 11: typeStr = '<b class="off"></b>-7%熔断'; break;
    //}
    //    额度可用->有额度
    //    午盘休息->午休
    //    早盘清空 ->清空
    //    额度用完 ->无额度
    //    今日停牌 ->停牌
    //    股市收盘 ->收盘
    //    今日休市 ->休市
    //    限制买入 ->限买
    //    限制卖出 ->限卖
    //    暂停

};

quote_phf.prototype.zdbjt = function (vs) {
    if (vs > 0) { return "↑"; }
    else if (vs < 0) { return "↓"; }
    else { return ""; }
};

quote_phf.prototype.ForDight = function (Dight, How) {//四舍五入
    rDight = parseFloat(Dight).toFixed(How);
    if (rDight == "NaN") { rDight = "--"; }
    return rDight;
};

quote_phf.prototype.$ = function (id) {
    return "string" == typeof id ? document.getElementById(id) : id;
};

quote_phf.prototype.JsLoader = function (sUrl, sBianMa, fCallback) {
    var _script = document.createElement('script');
    _script.setAttribute('charset', sBianMa);
    _script.setAttribute('type', 'text/javascript');
    _script.setAttribute('src', sUrl);
    document.getElementsByTagName('head')[0].appendChild(_script);
    if (typeof _script.onreadystatechange !== "undefined") {
        _script.onreadystatechange = function () {
            if (this.readyState == 'loaded' || this.readyState == 'complete') {
                _script.parentNode.removeChild(_script);
                fCallback();
            }
        };
    } else if (typeof _script.onload !== "undefined") {
        _script.onload = function () {
            _script.parentNode.removeChild(_script);
            fCallback();
        };
    }
    else {
        _script.parentNode.removeChild(_script);
        fCallback();
    }
};
quote_phf.prototype.trim = function (str) {
    return str.replace(/(^\s*)|(\s*$)/g, "");
};
var qphf = new quote_phf();

module.exports = qphf

/***/ })

/******/ });
//# sourceMappingURL=zs.js.map