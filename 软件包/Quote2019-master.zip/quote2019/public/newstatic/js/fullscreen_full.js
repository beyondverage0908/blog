/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./jssrc/fullscreen_full.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./jssrc/fullscreen_full.ts":
/*!**********************************!*\
  !*** ./jssrc/fullscreen_full.ts ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * 全屏页面-full
 */
var resize = __webpack_require__(/*! ../src/modules/old_fullscreen/common/resize */ "./src/modules/old_fullscreen/common/resize.js");
var hkscripts = __webpack_require__(/*! ../src/modules/old_fullscreen/hk */ "./src/modules/old_fullscreen/hk.js");
var aindex = __webpack_require__(/*! ../src/modules/old_fullscreen/aindex */ "./src/modules/old_fullscreen/aindex.js");
var bk = __webpack_require__(/*! ../src/modules/old_fullscreen/bk */ "./src/modules/old_fullscreen/bk.js");
var us = __webpack_require__(/*! ../src/modules/old_fullscreen/us */ "./src/modules/old_fullscreen/us.js");
resize(); //后期改过来
// 用于加载不同的js
;
(function () {
    var str = location.search.substr(1);
    var arr = str.split("&");
    var obj = {
        mcid: '',
        market: '',
        code: ''
    };
    for (var i = 0, len = arr.length; i < len; i++) {
        var ar = arr[i].split("=");
        obj[ar[0]] = ar[1];
    }
    if (obj.mcid) {
        var temp = obj.mcid.split(".");
        obj.market = temp[0];
        obj.code = temp[1];
    }
    var market = obj.market;
    var js = "";
    switch (market) {
        case "1":
        case "0":
            js = "aindex";
            aindex();
            break;
        case "90":
            js = "bk";
            bk();
            break;
        case "116":
            js = "hk";
            hkscripts();
            break;
        case "105":
        case "106":
        case "107":
            js = "us";
            us();
            break;
    }
    $("body").addClass('body_' + js);
    // if (location.href.indexOf("http://127") >= 0) {
    //     $.getScript("../dist/" + js + ".js");
    // } else if(location.href.indexOf("hqtest") > 0 || location.href.indexOf("quotationtest")>0 ) {
    //     $.getScript("http://hqtest.eastmoney.com/web/Content/js/static/dist/" + js + ".js")       
    // } else if(location.href.indexOf("quote") > 0 ) {
    // $.getScript("http://hqres.eastmoney.com/EMQuote_Basic/2018/js/dist/" + js + ".js")    //上线前确认下地址
    // }
    //$.getScript("../newstatic/js/fullscreen_full_hk.js") 
})();


/***/ }),

/***/ "./src/modules/old_fullscreen/aindex.js":
/*!**********************************************!*\
  !*** ./src/modules/old_fullscreen/aindex.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// require("../style/reset.less");
// require("../style/head.less");
// require("../style/right-aindex.less");

//require('eventsource-polyfill');
__webpack_require__(/*! ./ie_sse_polyfill */ "./src/modules/old_fullscreen/ie_sse_polyfill.js");

var main = __webpack_require__(/*! ./aindex/main.html */ "./src/modules/old_fullscreen/aindex/main.html");
var right = __webpack_require__(/*! ./aindex/right.html */ "./src/modules/old_fullscreen/aindex/right.html");


var uri = __webpack_require__(/*! ./common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var renderBlock = __webpack_require__(/*! ./common/renderBlock */ "./src/modules/old_fullscreen/common/renderBlock.js");

var config = __webpack_require__(/*! ./aindex/config */ "./src/modules/old_fullscreen/aindex/config.js");


var addEvent = __webpack_require__(/*! ./aindex/addEvent */ "./src/modules/old_fullscreen/aindex/addEvent.js");
var chartManager = __webpack_require__(/*! ./chart/index */ "./src/modules/old_fullscreen/chart/index.js");
var getdata = __webpack_require__(/*! ./aindex/getdata */ "./src/modules/old_fullscreen/aindex/getdata/index.js");

module.exports = function(){
    $(".main").html(main);
    $(".righ").html(right);




    renderBlock(config.head);
    var pars = uri.getParams();

    getdata(pars);



    var ctm = new chartManager(pars);

    addEvent(ctm, pars);



    // console.log('指数');

    //右侧
    var h = window.innerHeight;
    // console.log('h', h) 
    if (h <= 969) {
        //增加滚动条
        $(".jdzf").hide();

        var hei = (h - 520) + 'px';
        $(".fscj").css('height', hei);
        $(".fscj").css('overflow', 'auto');

    }

}

/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/addEvent.js":
/*!*******************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/addEvent.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function(ctm, pars){
    var that = this;

    this.ctm = ctm;
    this.pars = pars;


    $(".switchbar li,.switchbar .multi p").each(function(index, item){
        var t = $(item).attr("data-type");
        if (t == that.pars.type) {
            if (t.indexOf("t") == 0) {
                $(".day5 span").text($(item).text());
                $(".day5").addClass("active");
                $(".day5").attr("data-type", t);
            } else {
                $(item).addClass("active")
            }
        }
    });

    
    
    
    $(".switchbar").on("click", "li span", function(){

        var li = $(this).parent();

        var type = li.attr("data-type");

        $(".switchbar li").removeClass("active");
        li.addClass("active");

        // console.log(type);

        ctm.setType(type)
        
    });


    $(".switchbar").on("click", ".day5 .multi-day", function(){
        var t = $(this);
        if (t.hasClass("triangle-inline-down")) {
            t.removeClass("triangle-inline-down").addClass("triangle-inline-up");
            $(".multi").show();
        } else {
            t.removeClass("triangle-inline-up").addClass("triangle-inline-down");
            $(".multi").hide();
        }
    });
    

    $(".multi").on("click", "p", function(){
        var txt = $(this).text();
        var t = $(this).attr("data-type");
        $(".switchbar li").removeClass("active");
        $(".day5").attr("data-type", t);
        $(".day5").addClass("active");
        $(".day5 span").text(txt);
        $(".multi").hide();
        $(".multi-day").removeClass("triangle-inline-up").addClass("triangle-inline-down");

        // console.log(t);
        ctm.setType(t);
    });
    
};

/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/config.js":
/*!*****************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/config.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var fomrat = __webpack_require__(/*! ../common/format */ "./src/modules/old_fullscreen/common/format.js");
var geturl = __webpack_require__(/*! ../tools/url */ "./src/modules/old_fullscreen/tools/url.js");
module.exports = {

    
    //host: "http://61.152.230.32:38618/", //61.129.249.233:18665  61.152.230.32:38618
    host: geturl.get_url(),
    head: [
        [
            {
                name: "今开：",
                cls: "jk",
                color: "zs"
            },
            {
                name: "昨收：",
                cls: "zs",
                color: "zs"
            }
        ],
        [
            {
                name: "最高：",
                cls: "zg",
                color: "zs"
            },
            {
                name: "最低：",
                cls: "zd",
                color: "zs"
            }
        ],
        [
            {
                name: "涨跌幅：",
                cls: "zdf",
                sub: "%",
                color: 0
            },
            {
                name: "涨跌额：",
                cls: "zde",
                color: 0
            }
        ],
        [
            {
                name: "换手：",
                sub: "%",
                cls: "hs",
            },
            {
                name: "振幅：",
                sub: "%",
                cls: "zf",
            }
        ],
        [
            {
                name: "成交量：",
                cls: "cjl",
                cb: function(num){
                    return fomrat.num(num);
                }
            },
            {
                name: "成交额：",
                cls: "cje",
                cb: function(num){
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "内盘：",
                cls: "np",
                cb: function(num){
                    return fomrat.num(num);
                }
            },
            {
                name: "外盘：",
                cls: "wp",
                cb: function(num){
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "上涨家数：",
                cls: "szjs",
                sub: "家"
            },
            {
                name: "下跌家数：",
                cls: "xdjs",
                sub: "家"
            }
        ],
        [
            {
                name: "流值：",
                cls: "lz",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "平盘家数：",
                cls: "ppjs",
                sub: "家"
            }
        ]
    ]
    
    
};

/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/getdata/getBaseData.js":
/*!******************************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/getdata/getBaseData.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var merge = _.merge;

var renderHead = __webpack_require__(/*! ../../common/renderHead */ "./src/modules/old_fullscreen/common/renderHead.js");
var uri = __webpack_require__(/*! ../../common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var config = __webpack_require__(/*! ../config */ "./src/modules/old_fullscreen/aindex/config.js");

var renderJdzf = __webpack_require__(/*! ./renderJdzf */ "./src/modules/old_fullscreen/aindex/getdata/renderJdzf.js");
var renderZjl = __webpack_require__(/*! ./renderZjl */ "./src/modules/old_fullscreen/aindex/getdata/renderZjl.js");
var rendernewZjl = __webpack_require__(/*! ./rendernewZjl */ "./src/modules/old_fullscreen/aindex/getdata/rendernewZjl.js");

function data(par) {
    this.par = par;

    this.publicData = {};


    this.getData();
    this.getSSEData();


    //沪市 深市 资金流
    if(this.par.market == 1) {
        $(".zjl .ftitle").html('沪市资金流');
    } else {
        $(".zjl .ftitle").html('深市资金流');
    
    }
    this.getZJLData();
    this.getZJLSSEData();

}


data.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85, 106],       // 基础字段
        [119, 120, 121, 122],      // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                that.format(obj.data);
            }

        }
    });


}


data.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85, 106],       // 基础字段
        [119, 120, 121, 122],      // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = config.host + "api/qt/stock/sse?" + uri.parStringify(data);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }


}


data.prototype.format = function (d) {
    // console.log(d);
    var pdata = this.publicData;

    var oldo = this.o || {};       // 旧的对象
    // console.log(this.o,'测试')
    var o = {};

    var f = oldo.f || Math.pow(10, d.f59) || 1;
    var f59 = oldo.f59 || d.f59;
    if (f59 < 2) {
        f59 = 2;
    }
    o.f59 = f59;
    o.f = f;

    if (d.f85) {
        o.ltg = d.f85;  // 流通股
    }



    if (d.f58) {
        o.name = d.f58;
    }
    if (d.f57) {
        o.code = d.f57;
    }


    if (d.f43) {
        o.xj = (d.f43 / f).toFixed(f59) || "-";
    }
    if (d.f46) {
        o.jk = (d.f46 / f).toFixed(f59) || "-";
    }
    if (d.f60) {
        o.zs = (d.f60 / f).toFixed(f59);
    }
    if (d.f44) {
        o.zg = (d.f44 / f).toFixed(f59) || "-";
    }
    if (d.f45) {
        o.zd = (d.f45 / f).toFixed(f59) || "-";
    }
    if (d.f43) {
        var zs = (oldo.zs || d.f60 / f);
        o.zde = (d.f43 / f - zs).toFixed(f59);
        o.zdf = ((d.f43 / f - zs) / zs * 100).toFixed(f59);
    }
    if (d.f106) {
        o.f106 = d.f106;
    }
    if ((oldo.ltg || d.f85) && d.f47) {
        var ltg = oldo.ltg || d.f85;
        var f106 = oldo.f106 || d.f106;
        o.hs = ((d.f47 / ltg * f106) * 100).toFixed(f59);
    }
    if (d.f44 || d.f45) {
        var zg = d.f44 / f || oldo.zg;
        var zd = d.f45 / f || oldo.zd;
        var zs = oldo.zs || d.f60 / f;
        o.zf = ((zg - zd) / zs * 100).toFixed(f59);
    }
    if (d.f47) {
        o.cjl = d.f47;
    }
    if (d.f48) {
        o.cje = d.f48;
    }
    if (d.f49) {
        o.wp = d.f49;
        o.np = (oldo.cjl || d.f47) - d.f49;
    }
    if (d.f113) {
        o.szjs = d.f113;
    }
    if (d.f114) {
        o.xdjs = d.f114;
    }
    if (d.f115) {
        o.ppjs = d.f115;
    }
    if (d.f117) {
        o.lz = d.f117;
    }

    o.jdzf = {};
    if (d.f119) {
        o.jdzf.day5 = d.f119 / 100;
    }
    if (d.f120) {
        o.jdzf.day20 = d.f120 / 100;
    }
    if (d.f121) {
        o.jdzf.day60 = d.f121 / 100;
    }
    if (d.f122) {
        o.jdzf.dayyear = d.f122 / 100;
    }


    // 资金流
    o.zjl = {
        zl: [],
        cd: [],
        dd: [],
        zd: [],
        xd: []
    }

    // 5个
    if (d.f135 || d.f136 || d.f137) {
        o.zjl.zl = [d.f135, d.f136, d.f137];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.cd = [d.f138, d.f139, d.f140];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.dd = [d.f141, d.f142, d.f143];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.zd = [d.f144, d.f145, d.f146];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.xd = [d.f147, d.f148, d.f149];
    }

    // 净资金流
    try {
        o.zjl.jzjl = [
            d.f140 || oldo.zjl.cd[2],
            d.f143 || oldo.zjl.dd[2],
            d.f146 || oldo.zjl.zd[2],
            d.f149 || oldo.zjl.xd[2]
        ];
    } catch (error) {

    }


    this.o = merge(oldo, o);
    // console.log(this.o)


    this.render(o);

}


data.prototype.formatZJL = function (d) {
       // console.log(d);
       var pdata = this.publicData;

       var oldo = this.o_new || {};       // 旧的对象
       // console.log(this.o,'测试')
       var o_new = {};
   
       var f = oldo.f || Math.pow(10, d.f59) || 1;
       var f59 = oldo.f59 || d.f59;
       if (f59 < 2) {
           f59 = 2;
       }
       o_new.f59 = f59;
       o_new.f = f;
   
       if (d.f85) {
        o_new.ltg = d.f85;  // 流通股
       }
   
   
   
       if (d.f58) {
        o_new.name = d.f58;
       }
       if (d.f57) {
        o_new.code = d.f57;
       }
   
   
       if (d.f43) {
        o_new.xj = (d.f43 / f).toFixed(f59) || "-";
       }
       if (d.f46) {
        o_new.jk = (d.f46 / f).toFixed(f59) || "-";
       }
       if (d.f60) {
        o_new.zs = (d.f60 / f).toFixed(f59);
       }
       if (d.f44) {
        o_new.zg = (d.f44 / f).toFixed(f59) || "-";
       }
       if (d.f45) {
        o_new.zd = (d.f45 / f).toFixed(f59) || "-";
       }
       if (d.f43) {
           var zs = (oldo.zs || d.f60 / f);
           o_new.zde = (d.f43 / f - zs).toFixed(f59);
           o_new.zdf = ((d.f43 / f - zs) / zs * 100).toFixed(f59);
       }
       if (d.f106) {
        o_new.f106 = d.f106;
       }
       if ((oldo.ltg || d.f85) && d.f47) {
           var ltg = oldo.ltg || d.f85;
           var f106 = oldo.f106 || d.f106;
           o_new.hs = ((d.f47 / ltg * f106) * 100).toFixed(f59);
       }
       if (d.f44 || d.f45) {
           var zg = d.f44 / f || oldo.zg;
           var zd = d.f45 / f || oldo.zd;
           var zs = oldo.zs || d.f60 / f;
           o_new.zf = ((zg - zd) / zs * 100).toFixed(f59);
       }
       if (d.f47) {
        o_new.cjl = d.f47;
       }
       if (d.f48) {
        o_new.cje = d.f48;
       }
       if (d.f49) {
        o_new.wp = d.f49;
        o_new.np = (oldo.cjl || d.f47) - d.f49;
       }
       if (d.f113) {
        o_new.szjs = d.f113;
       }
       if (d.f114) {
        o_new.xdjs = d.f114;
       }
       if (d.f115) {
        o_new.ppjs = d.f115;
       }
       if (d.f117) {
        o_new.lz = d.f117;
       }
   
       o_new.jdzf = {};
       if (d.f119) {
        o_new.jdzf.day5 = d.f119 / 100;
       }
       if (d.f120) {
        o_new.jdzf.day20 = d.f120 / 100;
       }
       if (d.f121) {
        o_new.jdzf.day60 = d.f121 / 100;
       }
       if (d.f122) {
        o_new.jdzf.dayyear = d.f122 / 100;
       }
   
   
       // 资金流
       o_new.zjl = {
           zl: [],
           cd: [],
           dd: [],
           zd: [],
           xd: []
       }
   
       // 5个
       if (d.f135 || d.f136 || d.f137) {
        o_new.zjl.zl = [d.f135, d.f136, d.f137];
       }
       if (d.f138 || d.f139 || d.f140) {
        o_new.zjl.cd = [d.f138, d.f139, d.f140];
       }
       if (d.f138 || d.f139 || d.f140) {
        o_new.zjl.dd = [d.f141, d.f142, d.f143];
       }
       if (d.f138 || d.f139 || d.f140) {
        o_new.zjl.zd = [d.f144, d.f145, d.f146];
       }
       if (d.f138 || d.f139 || d.f140) {
        o_new.zjl.xd = [d.f147, d.f148, d.f149];
       }
   
       // 净资金流
       try {
        o_new.zjl.jzjl = [
               d.f140 || oldo.zjl.cd[2],
               d.f143 || oldo.zjl.dd[2],
               d.f146 || oldo.zjl.zd[2],
               d.f149 || oldo.zjl.xd[2]
           ];
       } catch (error) {
   
       }
   
   
       this.o_new = merge(oldo, o_new);
       // console.log(this.o)

       this.renderZJL(o_new);

}


//资金流
data.prototype.getZJLData = function () {
    var that = this;
    var par = this.par;

    // var zds = [
    //     [135, , 136, 137]    // 资金流
    // ]
    var zds = [
        [57, 58],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85, 106],       // 基础字段
        [119, 120, 121, 122],      // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var newsid = '';
    if(par.market == '1') {
        newsid = '1.000001';
    }else if(par.market == '0') {
        newsid = '0.399001'
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: newsid
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                that.formatZJL(obj.data);
            }

        }
    });

}


//资金流sse
data.prototype.getZJLSSEData = function () {
    var that = this;
    var par = this.par;

    // var zds = [
    //     [135, , 136, 137]     // 资金流
    // ]
    var zds = [
        [57, 58],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85, 106],       // 基础字段
        [119, 120, 121, 122],      // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }


    var newsid = '';
    if(par.market == '1') {
        newsid = '1.000001';
    }else if(par.market == '0') {
        newsid = '0.399001'
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: newsid
    }

    var fullurl = config.host + "api/qt/stock/sse?" + uri.parStringify(data);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        if (obj.rc == 0 && obj.data) {
            that.formatZJL(obj.data);
        }
    }


}


data.prototype.render = function (obj) {

    renderHead(config.head, obj);
    renderJdzf(obj);
    //renderZjl(obj);

}


//渲染资金流
data.prototype.renderZJL = function (obj) {

    rendernewZjl(obj);

}



module.exports = data;

/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/getdata/getFscj.js":
/*!**************************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/getdata/getFscj.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var renderFscj = __webpack_require__(/*! ./renderFscj */ "./src/modules/old_fullscreen/aindex/getdata/renderFscj.js");
var uri = __webpack_require__(/*! ../../common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var config = __webpack_require__(/*! ../config */ "./src/modules/old_fullscreen/aindex/config.js");



function fscj(par) {
    this.par = par;

    this.fscj = new renderFscj();

    //get
    this.getData();
    //sse
    //this.getSSEData();
}

fscj.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields1: "f1,f2,f3,f4",
        fields2: "f51,f52,f53,f54,f55",
        secid: par.market + "." + par.code,
        pos: '-16'
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/details/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb'
    })
    .then(function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                that.format(obj.data);
            }

        })
    .always(function(){
            // console.info(2222)
            that.getSSEData();
    })

}

fscj.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields1: "f1,f2,f3,f4",
        fields2: "f51,f52,f53,f54,f55",
        secid: par.market + "." + par.code,
        pos: '-16'
    }

    var fullurl = config.host + "api/qt/stock/details/sse?" + uri.parStringify(data);


    this.fscj.clear()
    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }

}


fscj.prototype.format = function(data){
    // console.log(data)

    this.fscj.setData(data)
}


module.exports = fscj;



/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/getdata/index.js":
/*!************************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/getdata/index.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getBaseData = __webpack_require__(/*! ./getBaseData */ "./src/modules/old_fullscreen/aindex/getdata/getBaseData.js");
var getFscj = __webpack_require__(/*! ./getFscj */ "./src/modules/old_fullscreen/aindex/getdata/getFscj.js");


module.exports = function(par){

    new getBaseData(par)
    new getFscj(par);
    
    
};

/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/getdata/renderFscj.js":
/*!*****************************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/getdata/renderFscj.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var fall = __webpack_require__(/*! ../../img/fall.png */ "./src/modules/old_fullscreen/img/fall.png");
var rise = __webpack_require__(/*! ../../img/rise.png */ "./src/modules/old_fullscreen/img/rise.png");


function fscj() {
    this.count = 16;
    this.flag = 0;
    
}


fscj.prototype.clear = function(){
    this.list = []
}

fscj.prototype.setData = function (data) {
    if (data.prePrice) {
        this.prePrice = data.prePrice;
    }

    var list = this.list || [];

    var details = data.details;
    this.list = list.concat(details);

    if (this.list.length > this.count) {
        this.list.splice(0, this.list.length - this.count)
    }
    this.render();
}




fscj.prototype.render = function () {

    var details = this.list;
    var prePrice = this.prePrice;
    $(".fscj table").html("")

    var tbody = $(".fscj table");


    for (var i = details.length - 1; i >= 0; i--) {
        var ar = details[i].split(",");

        var tr = $("<tr></tr>");
        var td1 = $("<td></td>").text(ar[0]);
        var td2 = $("<td></td>").text(ar[1]);
        if (ar[1] > prePrice) {
            td2.addClass("rise");
        } else if (ar[1] < prePrice) {
            td2.addClass("fall");
        }
        var td3 = $("<td></td>");

        if (ar[4] == 2) {
            td3.addClass("rise");
        } else if (ar[4] == 1){
            td3.addClass("fall");
        } else {
            td3.addClass("rise");
        }
        var span = $("<span></span>").text(ar[2]);
        var img = $("<img/>")
        if (ar[4] == 2) {
            img.attr("src", rise);
        } else if (ar[4] == 1){
            img.attr("src", fall);
        }else {
            img.attr("src", '');
        }
        span.append(img);
        td3.append(span);

        tr.append(td1, td2, td3);

        tbody.append(tr);
    }



}

module.exports = fscj;

/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/getdata/renderJdzf.js":
/*!*****************************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/getdata/renderJdzf.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var flicker = __webpack_require__(/*! ../../common/flicker */ "./src/modules/old_fullscreen/common/flicker.js");

// 阶段涨幅


module.exports = function(obj){

    var jdzf = $(".jdzf");

    var data = obj.jdzf;

    for (var k in data) {
        var val = data[k];
        var span = jdzf.find("." + k);
        span.text((val).toFixed(2) + "%");
        if (val > 0) {
            span.addClass("rise");
        } else if (val < 0) {
            span.addClass("fall");
        }
        flicker(span);
    }
    
    
};



/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/getdata/renderZjl.js":
/*!****************************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/getdata/renderZjl.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var format = __webpack_require__(/*! ../../common/format */ "./src/modules/old_fullscreen/common/format.js");
var flicker = __webpack_require__(/*! ../../common/flicker */ "./src/modules/old_fullscreen/common/flicker.js");

module.exports = function (obj) {


    var zjl = $(".righ .zjl");

    // 主力流向
    var zldata = obj.zjl.zl;
    // console.log(zldata)
    // [125743119616, 119175125760, 6567993856]

   
     //之前王资金流
    // if (zldata && zldata.length > 0) {
    //     var lx = zjl.find(".zjl-lx span");
    //     var rows = zjl.find(".zjl-lx .row");
    //     for (var i = 0; i < lx.size(); i++) {
    //         var lxi = lx.eq(i).text(format.num(zldata[i]));
    //         if (i == 0) {
    //             lxi.addClass("rise")
    //         }
    //         if (i == 1) {
    //             lxi.addClass("fall")
    //         }
    //         if (i == 2) {
    //             lx.eq(i).text(format.num(Math.abs(zldata[i])));
    //             if (zldata[2] > 0) {
    //                 rows.eq(i).find("label").text("主力净流入");
    //                 lxi.addClass("rise")
    //             } else if (zldata[2] < 0) {
    //                 rows.eq(i).find("label").text("主力净流出");
    //                 lxi.addClass("fall")
    //             }
    //         }
    //         flicker(lxi)
    //     }
    // }



    // 其他
    var table = zjl.find(".zjl-table tbody");
    var names = ["超大", "大单", "中单", "小单"];
    var otzjl = [obj.zjl.cd, obj.zjl.dd, obj.zjl.zd, obj.zjl.xd];
    // console.log('otzjl')
    // console.log(otzjl)
    for (var i = 0, len = otzjl.length; i < len; i++) {
        var row = otzjl[i];
        if (row && row.length > 0) {
            var tr = table.find("tr").eq(i);
            tr.find("td").eq(0).text(names[i]);
            for (var ii = 0; ii < 2; ii++) {
                if (row[ii] !== undefined && row[ii] + "" !== "NaN") {
                    var td = tr.find("td").eq(ii + 1);
                    var val = format.num(row[ii], 2);
                    td.text(val);
                    if (ii == 0) {
                        td.addClass("rise")
                    }
                    if (ii == 1) {
                        td.addClass("fall")
                    }
                    // flicker(td);     // 资金流全部发生变化，所有不要了
                }
            }
        }
    }


    // 净资金流图
    var names = ["净超大", "净大单", "净中单", "净小单"];
    var jzjl = obj.zjl.jzjl || [];

    var max = null;
    for (var i = 0; i < jzjl.length; i++) {
        max = max > jzjl[i] ? max : jzjl[i];
    }
    // console.log(max)

    var trs = $(".zjl-chart tr");
    for (var i = 0; i < jzjl.length; i++) {
        trs.eq(2).find("td").eq(i).text(names[i]);

        var val = jzjl[i] || 0;
        var td1 = trs.eq(0).find("td").eq(i);
        var td2 = trs.eq(1).find("td").eq(i);
        if (val > 0) {
            td1.find("span").height(Math.abs(val / max) * 30 + 1 + "px");
            td2.text((val / 100000000).toFixed(2));
        } else {
            td2.find("span").height(Math.abs(val / max) * 30 + 1 + "px");
            td1.text((val / 100000000).toFixed(2));
        }

    }

};

/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/getdata/rendernewZjl.js":
/*!*******************************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/getdata/rendernewZjl.js ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var format = __webpack_require__(/*! ../../common/format */ "./src/modules/old_fullscreen/common/format.js");
var flicker = __webpack_require__(/*! ../../common/flicker */ "./src/modules/old_fullscreen/common/flicker.js");

module.exports = function (obj) {

    var zjl = $(".righ .zjl");

    // 主力流向
    var zldata = obj.zjl.zl;
    // console.log(zldata)
    // [125743119616, 119175125760, 6567993856]

    // console.log(obj.zjl);

    if (zldata && zldata.length > 0) {
        var lx = zjl.find(".zjl-lx span");
        var rows = zjl.find(".zjl-lx .row");
        for (var i = 0; i < lx.size(); i++) {
            var lxi = lx.eq(i).text(format.num(zldata[i]));
            if (i == 0) {
                lxi.addClass("rise")
            }
            if (i == 1) {
                lxi.addClass("fall")
            }
            if (i == 2) {
                lx.eq(i).text(format.num(Math.abs(zldata[i])));
                if (zldata[2] > 0) {
                    rows.eq(i).find("label").text("主力净流入");
                    lxi.addClass("rise")
                } else if (zldata[2] < 0) {
                    rows.eq(i).find("label").text("主力净流出");
                    lxi.addClass("fall")
                }
            }
            flicker(lxi)
        }
    }


        // 其他
        var table = zjl.find(".zjl-table tbody");
        var names = ["超大", "大单", "中单", "小单"];
        var otzjl = [obj.zjl.cd, obj.zjl.dd, obj.zjl.zd, obj.zjl.xd];
        // console.log('otzjl')
        // console.log(otzjl)
        for (var i = 0, len = otzjl.length; i < len; i++) {
            var row = otzjl[i];
            if (row && row.length > 0) {
                var tr = table.find("tr").eq(i);
                tr.find("td").eq(0).text(names[i]);
                for (var ii = 0; ii < 2; ii++) {
                    if (row[ii] !== undefined && row[ii] + "" !== "NaN") {
                        var td = tr.find("td").eq(ii + 1);
                        var val = format.num(row[ii], 2);
                        td.text(val);
                        if (ii == 0) {
                            td.addClass("rise")
                        }
                        if (ii == 1) {
                            td.addClass("fall")
                        }
                        // flicker(td);     // 资金流全部发生变化，所有不要了
                    }
                }
            }
        }
    
    
        // 净资金流图
        var names = ["净超大", "净大单", "净中单", "净小单"];
        var jzjl = obj.zjl.jzjl || [];
    
        var max = null;
        for (var i = 0; i < jzjl.length; i++) {
            max = max > jzjl[i] ? max : jzjl[i];
        }
        // console.log(max)
    
        var trs = $(".zjl-chart tr");
        for (var i = 0; i < jzjl.length; i++) {
            trs.eq(2).find("td").eq(i).text(names[i]);
    
            var val = jzjl[i] || 0;
            var td1 = trs.eq(0).find("td").eq(i);
            var td2 = trs.eq(1).find("td").eq(i);
            if (val > 0) {
                td1.find("span").height(Math.abs(val / max) * 30 + 1 + "px");
                td2.text((val / 100000000).toFixed(2));
            } else {
                td2.find("span").height(Math.abs(val / max) * 30 + 1 + "px");
                td1.text((val / 100000000).toFixed(2));
            }
    
        }






};

/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/main.html":
/*!*****************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/main.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"switchbar\">\r\n    <ul>\r\n        <li class=\"\" data-type=\"r\">\r\n            <span>分时</span>\r\n        </li>\r\n        <li class=\"day5\" data-type=\"t5\">\r\n            <span>5日</span>\r\n            <label class=\"multi-day triangle-inline triangle-inline-down\"></label>\r\n            <div class=\"multi\">\r\n                <p data-type=\"t2\">2日</p>\r\n                <p data-type=\"t3\">3日</p>\r\n                <p data-type=\"t4\">4日</p>\r\n                <p data-type=\"t5\">5日</p>\r\n            </div>\r\n        </li>\r\n        <li data-type=\"k\">\r\n            <span>日K</span>\r\n        </li>\r\n        <li data-type=\"wk\">\r\n            <span>周K</span>\r\n        </li>\r\n        <li data-type=\"mk\">\r\n            <span>月K</span>\r\n        </li>\r\n        <li data-type=\"m5k\">\r\n            <span>5分钟</span>\r\n        </li>\r\n        <li data-type=\"m15k\">\r\n            <span>15分钟</span>\r\n        </li>\r\n        <li data-type=\"m30k\">\r\n            <span>30分钟</span>\r\n        </li>\r\n        <li data-type=\"m60k\">\r\n            <span>60分钟</span>\r\n        </li>\r\n    </ul>\r\n</div>\r\n<div class=\"chart\">\r\n    <div class=\"chart-box\"></div>\r\n</div>"

/***/ }),

/***/ "./src/modules/old_fullscreen/aindex/right.html":
/*!******************************************************!*\
  !*** ./src/modules/old_fullscreen/aindex/right.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- 阶段涨幅 -->\r\n<div class=\"jdzf\">\r\n    <p>阶段涨幅</p>\r\n    <table>\r\n        <tr>\r\n            <td>\r\n                <label>5日：</label>\r\n                <span class=\"day5\"></span>\r\n            </td>\r\n            <td>\r\n                <label>20日：</label>\r\n                <span class=\"day20\"></span>\r\n            </td>\r\n        </tr>\r\n        <tr>\r\n            <td>\r\n                <label>60日：</label>\r\n                <span class=\"day60\"></span>\r\n            </td>\r\n            <td>\r\n                <label>今年：</label>\r\n                <span class=\"dayyear\"></span>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</div>\r\n\r\n<!-- 资金流 -->\r\n<div class=\"zjl\">\r\n    <div class=\"zjl-lx\">\r\n        <p class=\"ftitle\">沪市资金流</p>\r\n        <div class=\"row\">\r\n            <label>主力流入</label>\r\n            <span></span>\r\n        </div>\r\n        <div class=\"row\">\r\n            <label>主力流出</label>\r\n            <span></span>\r\n        </div>\r\n        <div class=\"row\">\r\n            <label>主力净流出</label>\r\n            <span></span>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"zjl-table\">\r\n        <table>\r\n            <thead>\r\n                <tr>\r\n                    <td>（亿元）</td>\r\n                    <td>流入</td>\r\n                    <td>流出</td>\r\n                </tr>\r\n            </thead>\r\n            <tbody>\r\n                <tr>\r\n                    <td>超大</td>\r\n                    <td>-</td>\r\n                    <td>-</td>\r\n                </tr>\r\n                <tr>\r\n                    <td>大单</td>\r\n                    <td>-</td>\r\n                    <td>-</td>\r\n                </tr>\r\n                <tr>\r\n                    <td>中单</td>\r\n                    <td>-</td>\r\n                    <td>-</td>\r\n                </tr>\r\n                <tr>\r\n                    <td>小单</td>\r\n                    <td>-</td>\r\n                    <td>-</td>\r\n                </tr>\r\n            </tbody>\r\n        </table>\r\n    </div>\r\n\r\n    <div class=\"zjl-chart\">\r\n        <table>\r\n            <tr class=\"ctop\">\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n            </tr>\r\n            <tr class=\"cbot\">\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n            </tr>\r\n            <tr class=\"ctit\">\r\n                <td></td>\r\n                <td></td>\r\n                <td></td>\r\n                <td></td>\r\n            </tr>\r\n        </table>\r\n    </div>\r\n\r\n</div>\r\n\r\n<!-- 分时成交 -->\r\n<p class=\"ftitle2\">分时成交</p>\r\n<div class=\"fscj\">\r\n    <!-- <p class=\"ftitle\">分时成交</p> -->\r\n    <table>\r\n    </table>\r\n</div>"

/***/ }),

/***/ "./src/modules/old_fullscreen/bk.js":
/*!******************************************!*\
  !*** ./src/modules/old_fullscreen/bk.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// require("../style/reset.less");
// require("../style/head.less");
// require("../style/right-bk.less");

//require('eventsource-polyfill');
__webpack_require__(/*! ./ie_sse_polyfill */ "./src/modules/old_fullscreen/ie_sse_polyfill.js");


var main = __webpack_require__(/*! ./bk/main.html */ "./src/modules/old_fullscreen/bk/main.html");
var right = __webpack_require__(/*! ./bk/right.html */ "./src/modules/old_fullscreen/bk/right.html");

var uri = __webpack_require__(/*! ./common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var renderBlock = __webpack_require__(/*! ./common/renderBlock */ "./src/modules/old_fullscreen/common/renderBlock.js");

var config = __webpack_require__(/*! ./bk/config */ "./src/modules/old_fullscreen/bk/config.js");

var addEvent = __webpack_require__(/*! ./aindex/addEvent */ "./src/modules/old_fullscreen/aindex/addEvent.js");
var chartManager = __webpack_require__(/*! ./chart/index */ "./src/modules/old_fullscreen/chart/index.js");

var getdata = __webpack_require__(/*! ./bk/getdata */ "./src/modules/old_fullscreen/bk/getdata/index.js");

module.exports = function(){
    $(".main").html(main);
    $(".righ").html(right);


    renderBlock(config.head);
    var pars = uri.getParams();
    getdata(pars)


    var ctm = new chartManager(pars);

    addEvent(ctm, pars);



    // console.log('板块');
    //头部
    var w = window.innerWidth;
    // console.log('w,', w);
    if (w <= 1750) {
        var parent = document.getElementsByClassName("right")[0];
        var child = document.getElementsByClassName("block");

        parent.removeChild(child[8]);

    }

    //右侧
    var h = window.innerHeight;
    // console.log('h', h)
    if (h <= 1200) {
        //增加滚动条
        var hei = (h - 550) + 'px';
        $(".bkcfg").css('height', hei);
        $(".bkcfg").css('overflow', 'auto');

    }  
}



/***/ }),

/***/ "./src/modules/old_fullscreen/bk/config.js":
/*!*************************************************!*\
  !*** ./src/modules/old_fullscreen/bk/config.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var fomrat = __webpack_require__(/*! ../common/format */ "./src/modules/old_fullscreen/common/format.js");
var geturl = __webpack_require__(/*! ../tools/url */ "./src/modules/old_fullscreen/tools/url.js");
module.exports = {

    host: geturl.get_url(),
    head: [
        [
            {
                name: "今开：",
                cls: "jk",
                color: "zs",
                type: 1
            },
            {
                name: "昨收：",
                cls: "zs",
                color: "zs"
            }
        ],
        [
            {
                name: "最高：",
                cls: "zg",
                color: "zs"
            },
            {
                name: "最低：",
                cls: "zd",
                color: "zs"
            }
        ],
        [
            {
                name: "涨跌幅：",
                cls: "zdf",
                sub: "%",
                color: 0
            },
            {
                name: "涨跌额：",
                cls: "zde",
                color: 0
            }
        ],
        [
            {
                name: "成交量：",
                cls: "cjl",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "成交额：",
                cls: "cje",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "内盘：",
                cls: "np",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "外盘：",
                cls: "wp",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "换手：",
                sub: "%",
                cls: "hs",
            },
            {
                name: "振幅：",
                sub: "%",
                cls: "zf",
            }
        ],
        [
            {
                name: "上涨家数：",
                cls: "szjs",
                sub: "家"
            },
            {
                name: "下跌家数：",
                cls: "xdjs",
                sub: "家"
            }
        ],
        [
            {
                name: "量比：",
                cls: "lb"
            },
            {
                name: "平盘家数：",
                cls: "ppjs",
                sub: "家"
            }
        ],
        [
            {
                name: "流通市值：",
                cls: "lz",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "流通股本：",
                cls: "ltg",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ]
    ]


};

/***/ }),

/***/ "./src/modules/old_fullscreen/bk/getdata/getBaseData.js":
/*!**************************************************************!*\
  !*** ./src/modules/old_fullscreen/bk/getdata/getBaseData.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var merge = _.merge;

var renderHead = __webpack_require__(/*! ../../common/renderHead */ "./src/modules/old_fullscreen/common/renderHead.js");
var uri = __webpack_require__(/*! ../../common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var config = __webpack_require__(/*! ../config */ "./src/modules/old_fullscreen/bk/config.js");

// var renderJdzf = require("./renderJdzf");
var renderZjl = __webpack_require__(/*! ./renderZjl */ "./src/modules/old_fullscreen/bk/getdata/renderZjl.js");

function data(par) {
    this.par = par;

    this.publicData = {};

    
    this.getData();

    this.getSSEData();
}

data.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58, 106],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85, 50],       // 基础字段
        [119, 120, 121, 122],      // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                that.format(obj.data);
            }

        }
    });

}


data.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58, 106],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85, 50],       // 基础字段
        [119, 120, 121, 122],      // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = config.host + "api/qt/stock/sse?" + uri.parStringify(data);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }

}


data.prototype.format = function (d) {
    // console.log(d);
    var pdata = this.publicData;

    var oldo = this.o || {};       // 旧的对象
   
    var o = {};

    var f = oldo.f || Math.pow(10, d.f59) || 1;
    var f59 = oldo.f59 || d.f59;
    if (f59 < 2) {
        f59 = 2;
    }
    o.f59 = f59;
    o.f = f;

    if (d.f85) {
        o.ltg = d.f85;  // 流通股
    }



    if (d.f58) {
        o.name = d.f58;
    }
    if (d.f57) {
        o.code = d.f57;
    }


    if (d.f43) {
        o.xj = (d.f43 / f).toFixed(f59) || "-";
    }
    if (d.f46) {
        o.jk = (d.f46 / f).toFixed(f59) || "-";
    }
    if (d.f60) {
        o.zs = (d.f60 / f).toFixed(f59);
    }
    if (d.f44) {
        o.zg = (d.f44 / f).toFixed(f59) || "-";
    }
    if (d.f45) {
        o.zd = (d.f45 / f).toFixed(f59) || "-";
    }
    if (d.f43) {
        var zs = (oldo.zs || d.f60 / f);
        o.zde = (d.f43 / f - zs).toFixed(f59);
        o.zdf = ((d.f43 / f - zs) / zs * 100).toFixed(f59);
    }
    // if ((oldo.ltg || d.f85) && d.f47) {
    //     var ltg = oldo.ltg || d.f85;
    //     o.hs = ((d.f47 / ltg) * 100).toFixed(f59);
    // }
    if (d.f106) {
        o.f106 = d.f106;
    }
    if ((oldo.ltg || d.f85) && d.f47) {
        var ltg = oldo.ltg || d.f85;
        var f106 = oldo.f106 || d.f106;
        o.hs = ((d.f47 / ltg * f106) * 100).toFixed(f59);
    }
    if (d.f44 || d.f45) {
        var zg = d.f44 / f || oldo.zg;
        var zd = d.f45 / f || oldo.zd;
        var zs = oldo.zs || d.f60 / f;
        o.zf = ((zg - zd) / zs * 100).toFixed(f59);
    }
    if (d.f50) {
        o.lb = (d.f50 / 100).toFixed(f59);
    }
    if (d.f47) {
        o.cjl = d.f47;
    }
    if (d.f48) {
        o.cje = d.f48;
    }
    if (d.f49) {
        o.wp = d.f49;
        o.np = (oldo.cjl || d.f47) - d.f49;
    }
    if (d.f113) {
        o.szjs = d.f113;
    }
    if (d.f114) {
        o.xdjs = d.f114;
    }
    if (d.f115) {
        o.ppjs = d.f115;
    }
    if (d.f117) {
        o.lz = d.f117;
    }

    o.jdzf = {};
    if (d.f119) {
        o.jdzf.day5 = d.f119 / 100;
    }
    if (d.f120) {
        o.jdzf.day20 = d.f120 / 100;
    }
    if (d.f121) {
        o.jdzf.day60 = d.f121 / 100;
    }
    if (d.f122) {
        o.jdzf.dayyear = d.f122 / 100;
    }


    o.zjl = {
        // zl: [d.f135, d.f136, d.f137],
        // // ot: [
        // //     ["超大", d.f138, d.f139, d.f140],
        // //     ["大单", d.f141, d.f142, d.f143],
        // //     ["中单", d.f144, d.f145, d.f146],
        // //     ["小单", d.f147, d.f148, d.f149]
        // // ],
        // cd: [],
        // dd: [],
        // zd: [],
        // xd: []
    }

    // 其他 4个
    if (d.f135 || d.f136 || d.f137) {
        o.zjl.zl = [d.f135, d.f136, d.f137];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.cd = [d.f138, d.f139, d.f140];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.dd = [d.f141, d.f142, d.f143];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.zd = [d.f144, d.f145, d.f146];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.xd = [d.f147, d.f148, d.f149];
    }

    try {
        // 净资金流
        o.zjl.jzjl = [
            d.f140 || oldo.zjl.cd[2],
            d.f143 || oldo.zjl.dd[2],
            d.f146 || oldo.zjl.zd[2],
            d.f149 || oldo.zjl.xd[2]
        ];
    } catch (error) {

    }


    this.o = merge(oldo, o);
    // console.log(this.o)


    this.render(o);

}


data.prototype.render = function (obj) {

    renderHead(config.head, obj);
    // renderJdzf(obj);
    renderZjl(obj);


}

module.exports = data;

/***/ }),

/***/ "./src/modules/old_fullscreen/bk/getdata/getBkcfg.js":
/*!***********************************************************!*\
  !*** ./src/modules/old_fullscreen/bk/getdata/getBkcfg.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var uri = __webpack_require__(/*! ../../common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var config = __webpack_require__(/*! ../config */ "./src/modules/old_fullscreen/bk/config.js");

function cfg(par) {
    this.par = par;

    this.getData();
    this.getSSEData();
}


cfg.prototype.getData = function () {
    var that = this;

    var pars = {
        pn: 1,
        pz: 20,
        po: 1,
        fid: "f3",
        fields: "f1,f2,f3,f4,f12,f13,f14",
        fs: "b:" + this.par.code,
        ut: "fa5fd1943c7b386f172d6893dbfba10b"
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/clist/get?" + uri.parStringify(pars);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                that.render(obj);
            }

        }
    });

}



cfg.prototype.getSSEData = function () {
    var that = this;
    that.flag = 0;

    var pars = {
        pn: 1,
        pz: 20,
        po: 1,
        fid: "f3",
        fields: "f1,f2,f3,f4,f12,f13,f14",
        fs: "b:" + this.par.code,
        ut: "fa5fd1943c7b386f172d6893dbfba10b"
    }

    var fullurl = config.host + "api/qt/clist/sse?" + uri.parStringify(pars);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        // console.log(msg.data);
        var obj = JSON.parse(msg.data)
        // console.log(obj.data);
        that.render(obj);
    }

}



cfg.prototype.render = function (data) {
    var that =this;
    var bkcfg = $(".bkcfg tbody");
    var sdata = this.diff;

    // console.log(data.data);

    if (data.full == 1 && that.flag ==0) {
        that.flag =1;
        if (!data.data) {
            return false;
        }
        
        var diff = data.data.diff;
        var trs = [];
        for (var k in diff) {
            var item = diff[k];
            item._sortIndex = k;

            var f1 = item.f1;
            var pow = Math.pow(10, f1);
            var prise = (item.f2 / pow).toFixed(f1);
            var zdf = (item.f3 / pow).toFixed(f1);
            var zde = item.f4 / pow;

            var tr = $("<tr></tr>");
            var lianjie = '';
            if(item.f13 == 0) {
                lianjie = 'sz' + item.f12
            }else {
                lianjie = 'sh' + item.f12
            }
            var td1 = $('<a target="_blank" href="'+ 'http://quote.eastmoney.com/concept/'+ lianjie +'.html?from=bkqp#fschart-r' +'"></a>').text(item.f14);
            var td2 = $("<td></td>").text(prise);
            var td3 = $("<td></td>").text(zdf + "%");
            if (zde > 0) {
                td2.addClass("rise");
                td3.addClass("rise");
            } else if (zde < 0) {
                td2.addClass("fall");
                td3.addClass("fall");
            }
            tr.append(td1, td2, td3);
            tr.attr("data-sortindex", k);
            trs.push(tr);
                bkcfg.append(tr);
            
            
            
        }

        this.diff = diff;
        this.trs = trs;

       
    } else if(data.data){
        // var diff = this.diff;
        var trs = this.trs;

        var mv = data.data.mv;
        var diff = data.data.diff;

        // console.log(mv);
        
        // outhtml(trs);

        // 改变索引位置
        for (var k in mv) {
            trs[k].attr("data-sortindex", mv[k]);
        }
        // outhtml(trs);

        trs.sort(function(a, b){
            var ai = a.attr("data-sortindex");
            var bi = b.attr("data-sortindex");
            return ai - bi;
        });
        

        // 更新价格
        for (var k in diff) {
            var d = diff[k];
            var f1 = sdata[k / 1].f1;
            var pow = Math.pow(10, f1);
            var prise = (d.f2 / pow).toFixed(f1);
            var zdf = (d.f3 / pow).toFixed(f1);
            var zde = d.f4 / pow;

            var tr = trs[k / 1];
            var td2 = tr.find("td").eq(0);
            td2.text(prise);
            var td3 = tr.find("td").eq(1);
            td3.text(zdf + "%");

            if (zde > 0) {
                td2.removeClass().addClass("rise");
                td3.removeClass().addClass("rise");
            } else if (zde < 0) {
                td2.removeClass().addClass("fall");
                td3.removeClass().addClass("fall");
            }
        }
        // outhtml(trs);

        for(var i = 0, len = trs.length ; i < len ; i++){
            bkcfg.append(trs[i]);
        }

        // console.log("-----------------------");

    }


}



function outhtml(trs){
    console.log("==========");
    for (var i = 0; i < trs.length; i++) {
        console.log(trs[i].attr("data-sortindex") + "  " + trs[i].html());
    }
}



module.exports = cfg;

/***/ }),

/***/ "./src/modules/old_fullscreen/bk/getdata/index.js":
/*!********************************************************!*\
  !*** ./src/modules/old_fullscreen/bk/getdata/index.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getBaseData = __webpack_require__(/*! ./getBaseData */ "./src/modules/old_fullscreen/bk/getdata/getBaseData.js");
var getBkcfg = __webpack_require__(/*! ./getBkcfg */ "./src/modules/old_fullscreen/bk/getdata/getBkcfg.js");

module.exports = function(par){

    new getBaseData(par);
    new getBkcfg(par);

};

/***/ }),

/***/ "./src/modules/old_fullscreen/bk/getdata/renderZjl.js":
/*!************************************************************!*\
  !*** ./src/modules/old_fullscreen/bk/getdata/renderZjl.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var format = __webpack_require__(/*! ../../common/format */ "./src/modules/old_fullscreen/common/format.js");
var flicker = __webpack_require__(/*! ../../common/flicker */ "./src/modules/old_fullscreen/common/flicker.js");

module.exports = function (obj) {


    var zjl = $(".righ .zjl");

    // 主力流向
    var zldata = obj.zjl.zl;

    if (zldata && zldata.length > 0) {
        var lx = zjl.find(".zjl-lx span");
        var rows = zjl.find(".zjl-lx .row");
        for (var i = 0; i < lx.size(); i++) {
            var lxi = lx.eq(i).text(format.num(zldata[i]));
            if (i == 0) {
                lxi.addClass("rise")
            }
            if (i == 1) {
                lxi.addClass("fall")
            }
            if (i == 2) {
                lx.eq(i).text(format.num(Math.abs(zldata[i])));
                if (zldata[2] > 0) {
                    rows.eq(i).find("label").text("主力净流入");
                    lxi.addClass("rise")
                } else if (zldata[2] < 0) {
                    rows.eq(i).find("label").text("主力净流出");
                    lxi.addClass("fall")
                }
            }
            flicker(lxi)
        }
    }



    // 其他
    var table = zjl.find(".zjl-table tbody");
    var names = ["超大", "大单", "中单", "小单"];
    var otzjl = [obj.zjl.cd, obj.zjl.dd, obj.zjl.zd, obj.zjl.xd];
    for (var i = 0, len = otzjl.length; i < len; i++) {
        var row = otzjl[i];
        if (row && row.length > 0) {
            var tr = table.find("tr").eq(i);
            tr.find("td").eq(0).text(names[i]);
            for (var ii = 0; ii < 2; ii++) {
                if (row[ii] !== undefined && row[ii] + "" !== "NaN") {
                    var td = tr.find("td").eq(ii + 1);
                    var val = format.num(row[ii], 2);
                    td.text(val);
                    if (ii == 0) {
                        td.addClass("rise")
                    }
                    if (ii == 1) {
                        td.addClass("fall")
                    }
                    // flicker(td);     // 资金流全部发生变化，所有不要了
                }
            }
        }
    }


    // 净资金流图
    var names = ["净超大", "净大单", "净中单", "净小单"];
    var jzjl = obj.zjl.jzjl || [];

    var max = null;
    for (var i = 0; i < jzjl.length; i++) {
        max = max > jzjl[i] ? max : jzjl[i];
    }
    // console.log(max)

    var trs = $(".zjl-chart tr");
    for (var i = 0; i < jzjl.length; i++) {
        trs.eq(2).find("td").eq(i).text(names[i]);

        var val = jzjl[i];
        var td1 = trs.eq(0).find("td").eq(i);
        var td2 = trs.eq(1).find("td").eq(i);
        if (val > 0) {
            td1.find("span").height(Math.abs(val / max) * 30 + 1 + "px");
            td2.text((val / 100000000).toFixed(2));
        } else {
            td2.find("span").height(Math.abs(val / max) * 30 + 1 + "px");
            td1.text((val / 100000000).toFixed(2));
        }

    }

};

/***/ }),

/***/ "./src/modules/old_fullscreen/bk/main.html":
/*!*************************************************!*\
  !*** ./src/modules/old_fullscreen/bk/main.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"switchbar\">\r\n    <ul>\r\n        <li class=\"active\" data-type=\"r\">\r\n            <span>分时</span>\r\n        </li>\r\n        <li data-type=\"k\">\r\n            <span>日K</span>\r\n        </li>\r\n        <li data-type=\"wk\">\r\n            <span>周K</span>\r\n        </li>\r\n        <li data-type=\"mk\">\r\n            <span>月K</span>\r\n        </li>\r\n    </ul>\r\n</div>\r\n<div class=\"chart\">\r\n    <div class=\"chart-box\"></div>\r\n</div>"

/***/ }),

/***/ "./src/modules/old_fullscreen/bk/right.html":
/*!**************************************************!*\
  !*** ./src/modules/old_fullscreen/bk/right.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n<!-- 资金流 -->\r\n<div class=\"zjl\">\r\n    <div class=\"zjl-lx\">\r\n        <p class=\"ftitle\">板块资金流向</p>\r\n        <div class=\"row\">\r\n            <label>主力流入</label>\r\n            <span></span>\r\n        </div>\r\n        <div class=\"row\">\r\n            <label>主力流出</label>\r\n            <span></span>\r\n        </div>\r\n        <div class=\"row\">\r\n            <label>主力净流出</label>\r\n            <span></span>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"zjl-table\">\r\n        <table>\r\n            <thead>\r\n                <tr>\r\n                    <td>（亿元）</td>\r\n                    <td>流入</td>\r\n                    <td>流出</td>\r\n                </tr>\r\n            </thead>\r\n            <tbody>\r\n                <tr>\r\n                    <td>超大</td>\r\n                    <td>-</td>\r\n                    <td>-</td>\r\n                </tr>\r\n                <tr>\r\n                    <td>大单</td>\r\n                    <td>-</td>\r\n                    <td>-</td>\r\n                </tr>\r\n                <tr>\r\n                    <td>中单</td>\r\n                    <td>-</td>\r\n                    <td>-</td>\r\n                </tr>\r\n                <tr>\r\n                    <td>小单</td>\r\n                    <td>-</td>\r\n                    <td>-</td>\r\n                </tr>\r\n            </tbody>\r\n        </table>\r\n    </div>\r\n\r\n    <div class=\"zjl-chart\">\r\n        <table>\r\n            <tr class=\"ctop\">\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n            </tr>\r\n            <tr class=\"cbot\">\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n                <td><span></span></td>\r\n            </tr>\r\n            <tr class=\"ctit\">\r\n                <td></td>\r\n                <td></td>\r\n                <td></td>\r\n                <td></td>\r\n            </tr>\r\n        </table>\r\n    </div>\r\n\r\n</div>\r\n\r\n<!-- 板块成分涨跌幅 -->\r\n<p class=\"ftitle2\">板块成分股涨跌幅</p>\r\n<div class=\"ming\"><span>名称</span><span class=\"sec\">最新价</span><span class=\"tir\">涨跌幅</span></div>\r\n<div class=\"bkcfg\">\r\n    <!-- <p class=\"ftitle\">板块成分股涨跌幅</p> -->\r\n    \r\n    <table>\r\n        <!-- <thead>\r\n            <tr>\r\n                <td>名称</td>\r\n                <td>最新价</td>\r\n                <td>涨跌幅</td>\r\n            </tr>\r\n        </thead> -->\r\n        <tbody></tbody>\r\n    </table>\r\n</div>"

/***/ }),

/***/ "./src/modules/old_fullscreen/chart/index.js":
/*!***************************************************!*\
  !*** ./src/modules/old_fullscreen/chart/index.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var time = __webpack_require__(/*! ./time */ "./src/modules/old_fullscreen/chart/time.js");
var k = __webpack_require__(/*! ./k */ "./src/modules/old_fullscreen/chart/k.js");


function chartManager(par){
    this.par = par;
    this.type = this.par.type || "r";    // 默认是分时图

    this.k = null;
    this.time = null;

    this._init();
    
}


chartManager.prototype._init = function(){
    if (this.type.indexOf("k") > -1) {
        this.k = new k(this.par);
        this.time = null;
    } else {
        this.time = new time(this.par);
        this.k = null;
    }

    this.go();
}

chartManager.prototype.setType = function(type){
    if ((type || "").indexOf("k") > -1) {
        if (this.type.indexOf("k") == -1 && !this.k) {
            this.k = new k(this.par);
            this.time = null;
            // console.log("nnnnnnnnnnnnn kkkkkkkkkkk")
        }
    } else {
        if (!this.time) {
            this.time = new time(this.par);
            this.k = null;
            // console.log("nnnnnnnnnnnn ttttttttttt");
        }
    }

    this.type = type;

    // console.log(type);

    // console.log(this.time);
    // console.log(this.k)

    this.go();
}


chartManager.prototype.go = function() {
    if (this.k) {
        this.k.setPar({
            type: this.type
        })
        this.k.go();
    }
    if (this.time) {
        this.time.setPar({
            type: this.type
        })
        this.time.go();
    }
}


module.exports = chartManager;

/***/ }),

/***/ "./src/modules/old_fullscreen/chart/k.js":
/*!***********************************************!*\
  !*** ./src/modules/old_fullscreen/chart/k.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var merge = _.merge;

function chart(par) {
    this.par = par;

    this.option = {
        container: ".chart-box",
        width: par.width,
        height: par.height,  
        scale: {
            pillar: 50,
            min: 10
        },    
        onError: function (err) {
            console.log(err)
        }
    }

    this._init();
}


chart.prototype._init = function () {

    this.k = new emcharts3.k4(this.option);

}


chart.prototype._getData = function () {
    var par = this.par;

    var misd = {
        k: 101,
        wk: 102,
        mk: 103,
        m5k: 5,
        m15k: 15,
        m30k: 30,
        m60k: 60
    }

    this.k.setStock({
        secid: par.market + "." + par.code,
        klt: misd[par.type]
    });
    
}


chart.prototype.setPar = function (par) {
    this.par = merge(this.par , par) ;
    this.k.option.type = par.type;
}


chart.prototype.go = function (type) {

    this._getData();
}


module.exports = chart;




/***/ }),

/***/ "./src/modules/old_fullscreen/chart/time.js":
/*!**************************************************!*\
  !*** ./src/modules/old_fullscreen/chart/time.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var merge = _.merge;

var geturl = __webpack_require__(/*! ../tools/url */ "./src/modules/old_fullscreen/tools/url.js");

var uri = __webpack_require__(/*! ../common/uri */ "./src/modules/old_fullscreen/common/uri.js");

var user = __webpack_require__(/*! ../user */ "./src/modules/old_fullscreen/user/index.js");
var islogin = user.get() ? true: false;

function chart(par) {
    this.par = par || {};

    this.option = {
        container: ".chart-box",
        width: par.width,
        height: par.height,
        type: par.type, 
        iscr: par.iscr ? 1 : 0,
        show: {
            tradingArea: true,
            indicatorArea: true,
        },
        gridwh: {
            width: 50000
        },
        restline: {
            isshow: true,
            color: "#eee",
            solid: 3,       // 实线长度
            dashed: 0,      // 虚线长度
        },
        tip: {
            trading: true
        },
        onError: function (err) {
            console.log(err);
        }
    };

    //console.info()

    this.url = geturl.get_url();
    this.urlHis = geturl.get_Hisurl();
    
    this.data = {
        fields1: "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13",
        fields2: "f51,f52,f53,f54,f55,f56,f57,f58",
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        iscr: par.iscr ? "1" : "0",
        ndays: 1
    };

    //登录状态
    this.login = islogin;

    this._init();
}


chart.prototype._init = function () {

    this.time = new emcharts3.time(this.option);

}


chart.prototype._getData = function () {
    var that = this;
    var par = this.par;
    var time = this.time;
    var data = this.data;
    var url = this.urlHis;

    if (par.market && par.code) {
        data.secid = par.market + "." + par.code;
    }

    // console.log('par.market')
    // console.log(par.market)

    var arr = [];
    for (var k in data) {
        arr.push(k + "=" + data[k]);
    }

    // 请求分时数据
    $.ajax({
        type: "get",
        url: url + "api/qt/stock/trends2/get?" + arr.join("&"),
        dataType: "jsonp",
        jsonp: "cb",
        success: function (msg) {
            time.setData({
                time: msg,
            });
            time.redraw();


            var obj = msg;
            that.id = obj.lt;
            //增加 港股 图 的  推送逻辑
            //若是国内ip 登录了 就放出sse接口
            // console.log('图')
            // console.log(msg)

            // if(that.id !== 2 && that.login) {
                 //图的sse接口
                // that._getSSE();
               
            // }
        }
    });
}


chart.prototype._getSSE = function () {
    var that = this;

    var par = this.par;
    var time = this.time;
    var data = this.data;
    var url = this.url;

    var typs = {
        r: 1,
        t2: 2,
        t3: 3,
        t4: 4,
        t5: 5,
    }

    if (par.market && par.code) {
        data.secid = par.market + "." + par.code;
    }
    if (par.type) {
        data.ndays = typs[par.type];
    }

    var arr = [];
    for (var k in data) {
        arr.push(k + "=" + data[k]);
    }   

    if(data.ndays > 1 && data.ndays < 6){
        url = this.urlHis
    }

    var fullurl = url + "api/qt/stock/trends2/sse" + "?" + arr.join("&");

    // console.info(fullurl)

    this.sseType = par.type;
    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        // console.log(msg);
        var fdata = JSON.parse(msg.data)
        // console.log(fdata);

        if (fdata.rc == 0 && fdata.data) {

            var data = fdata.data;

            if (data.beticks) {
                that.fullData = fdata;
            } else {

                var source = that.fullData.data.trends;
                var last = source[source.length - 1].split(",");
                
                var trends = data.trends;
                var frist = trends[0].split(",");

                if (last[0] == frist[0]) {
                    source.pop();
                }
                for(var i = 0, len = trends.length ; i < len ; i++){
                    source.push(trends[i]);
                }
            }

            // console.log(that.fullData);
            time.setData({
                time: that.fullData,
            });
            time.redraw();
        }

    }

    this.sse = evtSource;
}


chart.prototype.setPar = function (par) {
    this.par = merge(this.par , par) ;
    this.time.option.type = par.type;
}


chart.prototype.go = function (type) {
    var that = this;

    if (this.sseType != this.type) {
        // console.log("结束");
        this.sse.close();
    }

    this._getData();

    //图的sse接口
    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: 'f107,f111,f177',
        secid: this.par.market + "." + this.par.code
    }
    //增加判断条件 若是为港股 增加 登录和非登录  图推送的逻辑
    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);
    

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            if(msg.data) {
                var data = msg.data;

                var mar = data.f107 == '116' || data.f107 == '128';
                var zqtype = data.f111 == '0' || data.f111 == '1' || data.f111 == '2' || data.f111 == '3' || data.f111 == '4' || data.f111 == '5' || data.f111 == '6';

                var hugantong = data.f177 & (128|256);
                //判断是否为港股
                if(mar && zqtype) {
                      
                    //并且是 国内  && 登录状态
                     if(that.id !== 2 && that.login) {
                        that._getSSE();
                     }

                     //或者是 国内 未登录 沪股通 的 港股
                     
                     if(that.id !== 2 && !that.login && hugantong) {
                         that._getSSE();
                     }


                } else {
                    // console.log('no')
                    that._getSSE();
                }
            }

        }
    })


    // this._getSSE();

}


module.exports = chart;




/***/ }),

/***/ "./src/modules/old_fullscreen/common/flicker.js":
/*!******************************************************!*\
  !*** ./src/modules/old_fullscreen/common/flicker.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function(dom){

    $(dom).css("background-color", "rgba(255,0,0,0.5)");
    $(dom).animate({
        "backgroundColor": "rgba(255,0,0,0)"
    }, 300);
    
};

/***/ }),

/***/ "./src/modules/old_fullscreen/common/format.js":
/*!*****************************************************!*\
  !*** ./src/modules/old_fullscreen/common/format.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {

    num: function (num, xs) {
        xs = xs === undefined ? 2 : xs;
        var abs = Math.abs(num);
        var fix = "";
        var res = "";

        if (abs + "" == "NaN") {
            return "-";
        } else {
            if (abs < 10000) {
                res = num;
            } else if (abs >= 10000 && abs < 100000000) {
                res = num / 10000;
                fix = "万"
            } else if (abs >= 100000000 && abs < 1000000000000) {
                res = num / 100000000;
                fix = "亿"
            } else if (abs >= 1000000000000) {
                res = num / 1000000000000;
                fix = "万亿"
            }
           // console.log(num , res)
            return res.toFixed(xs) + fix;
        }

    }


};

/***/ }),

/***/ "./src/modules/old_fullscreen/common/renderBlock.js":
/*!**********************************************************!*\
  !*** ./src/modules/old_fullscreen/common/renderBlock.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {


module.exports = function(heads){

    var selector = ".head .right";
    var box = $(selector);

    for(var i = 0, len = heads.length ; i < len ; i++){
        var block = heads[i];
        var blockBox = $("<div class='block'></div>")
        for(var ii = 0, len2 = block.length ; ii < len2 ; ii++){
            var line = block[ii];
            var row = $("<div class='row'></div>");
            var label = $("<label><label>").text(line.name);
            var span = $("<span>-<span>").attr("class", line.cls);
            row.append(label).append(span);
            blockBox.append(row);
        }
        box.append(blockBox);
    }
    
};

/***/ }),

/***/ "./src/modules/old_fullscreen/common/renderHead.js":
/*!*********************************************************!*\
  !*** ./src/modules/old_fullscreen/common/renderHead.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var flicker = __webpack_require__(/*! ./flicker */ "./src/modules/old_fullscreen/common/flicker.js");

module.exports = function (heads, data) {

    var head = heads;
    var obj = data;

    for (var i = 0; i < head.length; i++) {
        var ar = head[i];
        for (var ii = 0; ii < ar.length; ii++) {
            var blk = head[i][ii];
            var val = obj[blk.cls];
            var sub = blk.sub || "";
            var span = $(".head ." + blk.cls);

            // if (blk.cls == "hs") {
            //     console.log("hhhhhhhhhhh");
            // }

            if (val !== undefined) {
                if (blk.color !== undefined) {
                    var bj = "";
                    if (typeof blk.color === "string") {
                        bj = obj[blk.color];
                    } else {
                        bj = blk.color;
                    }
                    if (val > bj) {
                        span.addClass("rise")
                    } else if (val < bj) {
                        span.addClass("fall")
                    } else {
                        span.addClass("ping")
                    }
                }

                if (blk.cb) {
                    val = blk.cb(val);
                }
                var txt = val;
                if (val !== "-") {
                    txt += sub;
                }
                span.text(txt);
                if (blk.type != 1) {
                    flicker(span);
                }
            }
        }

    }


    $(".head .name").text(obj.name);
    $(".head .code").text(obj.code);
    var zde = $(".head .zde");
    var zdf = $(".head .zdf");
    var prise = $(".head .prise")
    prise.text(obj.xj);
    if (obj.zde > 0) {
        prise.addClass("triangle-up").addClass("rise");
    } else if (obj.zde < 0) {
        prise.addClass("triangle-down").addClass("fall");
    }

    if (obj.zde !== undefined) {
        if(obj.zde <= 0 ) {
            zde.text(obj.zde);
        }else if(obj.zde > 0) {
            zde.text('+' + obj.zde);
        }
        
        flicker(zde);
    }
    if (obj.zdf !== undefined) {
        if(obj.zdf <= 0) {
            zdf.text(obj.zdf + "%");
        }else if(obj.zdf > 0) {
            zdf.text('+' + obj.zdf + "%");
        }
        
        flicker(zdf);
    }

    if (obj.zde > 0) {
        zde.removeClass("fall").addClass("rise");
        zdf.removeClass("fall").addClass("rise");
    }
    if (obj.zde < 0) {
        zde.removeClass("rise").addClass("fall");
        zdf.removeClass("rise").addClass("fall");
    }




//判断right宽度,增加右侧left的自适应
var w = window.innerWidth;
// console.log('w,', w);
if(w <= 1550) {
    // console.log('小于1550')
    $(".fullbox .head .right .block").css("font-size", "12px");
    // $(".fullbox .head .left .name").css("font-size", "12px");
    $(".fullbox .head .right .block").css("margin-left", "10px");
    $(".fullbox .head .right .block").css("padding-right", "3px");
    // $(".fullbox .head .left .prise").css("font-size", "12px");
    
}else {
    $(".fullbox .head .right .block").css("font-size", "14px");
    $(".fullbox .head .right .block").css("margin-left", "40px");
    $(".fullbox .head .left .prise").css("font-size", "20px");
    $(".fullbox .head .right .block").css("padding-right", "5px");
}



    
    

};



/***/ }),

/***/ "./src/modules/old_fullscreen/common/resize.js":
/*!*****************************************************!*\
  !*** ./src/modules/old_fullscreen/common/resize.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function () {

    var time = 0;

    window.onresize = function () {
        // console.log("rrrrrrrrrr");
        var w = window.innerWidth;
        var t = Date.now();

        if (w > 1800 && t - time > 2000) {
            location.reload();
        }

    }



};

/***/ }),

/***/ "./src/modules/old_fullscreen/common/uri.js":
/*!**************************************************!*\
  !*** ./src/modules/old_fullscreen/common/uri.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {

    getParams: function () {
        var str = location.search.substr(1);
        var arr = str.split("&");

        var obj = {};
        for (var i = 0, len = arr.length; i < len; i++) {
            var ar = arr[i].split("=");
            obj[ar[0]] = ar[1];
        }

        if (obj.mcid) {
            var temp = obj.mcid.split(".");
            obj.market = temp[0];
            obj.code = temp[1];
        }

        var chartBox = $(".chart-box");

        obj.width = chartBox.width();
        obj.height = chartBox.height();

        return obj;
    },


    parStringify: function(obj){
        var arr = [];
        for (var k in obj) {
            arr.push(k + "=" + obj[k]);
        }
        return arr.join("&")
    }


};

/***/ }),

/***/ "./src/modules/old_fullscreen/cookie/index.js":
/*!****************************************************!*\
  !*** ./src/modules/old_fullscreen/cookie/index.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * cookie
 */

var cookie = {
	get: function (name) {
		var xarr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
		if (xarr != null)
			return decodeURIComponent(xarr[2]);
		return null;
	},
	set: function(key,value,expiredays,domain){
		var exdate = new Date();
		exdate.setDate(exdate.getDate() + expiredays);
		document.cookie = key + "=" + escape(value) + ";expires=" + exdate.toGMTString() + ";path=/;domain=" + domain;
	},
	del: function (key, domain) {
		var exdate = new Date((new Date).getTime() - 1);
		if (domain) {
			document.cookie = key + '=;path=/;expires=' + exdate.toGMTString() + ';domain=' + domain;
		}
		else{
			document.cookie = key + '=;path=/;expires=' + exdate.toGMTString();
		}
		
	}
};

module.exports = cookie;

/***/ }),

/***/ "./src/modules/old_fullscreen/hk.js":
/*!******************************************!*\
  !*** ./src/modules/old_fullscreen/hk.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// require("../style/reset.less");
// require("../style/head.less");
// require("../style/right-hk.less");
__webpack_require__(/*! ./ie_sse_polyfill */ "./src/modules/old_fullscreen/ie_sse_polyfill.js"); 

var main = __webpack_require__(/*! ./hk/main.html */ "./src/modules/old_fullscreen/hk/main.html");
var right = __webpack_require__(/*! ./hk/right.html */ "./src/modules/old_fullscreen/hk/right.html");

var uri = __webpack_require__(/*! ./common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var renderBlock = __webpack_require__(/*! ./common/renderBlock */ "./src/modules/old_fullscreen/common/renderBlock.js");

var config = __webpack_require__(/*! ./hk/config */ "./src/modules/old_fullscreen/hk/config.js");

var addEvent = __webpack_require__(/*! ./aindex/addEvent */ "./src/modules/old_fullscreen/aindex/addEvent.js");
var chartManager = __webpack_require__(/*! ./chart/index */ "./src/modules/old_fullscreen/chart/index.js");

var getdata = __webpack_require__(/*! ./hk/getdata */ "./src/modules/old_fullscreen/hk/getdata/index.js");

module.exports = function(){

  $(".main").html(main);
  $(".righ").html(right);


  renderBlock(config.head);
  var pars = uri.getParams();

  var ctm = new chartManager(pars);


  getdata(pars);
  addEvent(ctm, pars);


  // console.log('港股');
  //头部
  var w = window.innerWidth;
  // console.log('w,', w);
  if (w <= 1750) {
      var parent = document.getElementsByClassName("right")[0];
      var child = document.getElementsByClassName("block");

      parent.removeChild(child[8]);
      parent.removeChild(child[6]);
      parent.removeChild(child[2]);

  }

  //右侧
  var h = window.innerHeight;
  if (h <= 900) {
      var parent = document.getElementsByClassName("hqbj")[0];

      var child1 = document.getElementsByClassName("download")[0];
      //删广告
      // parent.removeChild(child1);



      //增加滚动条
      var hei = (h - 310) + 'px';
      $(".hqbj").css('height', hei);
      $(".hqbj").css('overflow', 'auto');

      //让滚动条处于中间位置
      var divhei = $(".hqbj").height();
      var vl = document.getElementsByClassName("hqbj")[0].scrollHeight;
      $(".hqbj").scrollTop((vl - divhei) * 0.5);


      //增加中间虚线
      // $(".hqbj table")[1].style.borderTop = '1px dashed gray';




  }  
}


/***/ }),

/***/ "./src/modules/old_fullscreen/hk/config.js":
/*!*************************************************!*\
  !*** ./src/modules/old_fullscreen/hk/config.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var fomrat = __webpack_require__(/*! ../common/format */ "./src/modules/old_fullscreen/common/format.js");
var geturl = __webpack_require__(/*! ../tools/url */ "./src/modules/old_fullscreen/tools/url.js");
module.exports = {

    host: geturl.get_url(),
    head: [
        [
            {
                name: "今开：",
                cls: "jk",
                color: "zs"
            },
            {
                name: "昨收：",
                cls: "zs",
                color: "zs"
            }
        ],
        [
            {
                name: "最高：",
                cls: "zg",
                color: "zs"
            },
            {
                name: "最低：",
                cls: "zd",
                color: "zs"
            }
        ],
        [
            {
                name: "52周最高：",
                cls: "zg52",
                color: "zs"
            },
            {
                name: "52周最低：",
                cls: "zd52",
                color: "zs"
            }
        ],
        [
            {
                name: "成交量：",
                cls: "cjl",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "成交额：",
                cls: "cje",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "内盘：",
                cls: "np",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "外盘：",
                cls: "wp",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "总市值：",
                cls: "zsz",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "总股本：",
                cls: "zgb",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "流通市值：",
                cls: "lz",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "流通股本：",
                cls: "ltg",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "市盈率：",               
                cls: "syl",
            },
            {
                name: "市净率：",             
                cls: "sjl",
            }
        ],
        [
            {
                name: "每股收益：",
                cls: "mgsy",
            },
            {
                name: "每股净资产：",
                cls: "mgjzc",
            }
        ],
        [
            {
                name: "换手率：",
                cls: "hs",
                sub: "%"
            },
            {
                name: "股息率：",
                cls: "gxl",
            }
        ],
        
    ]


};

/***/ }),

/***/ "./src/modules/old_fullscreen/hk/getdata/getBaseData.js":
/*!**************************************************************!*\
  !*** ./src/modules/old_fullscreen/hk/getdata/getBaseData.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var merge = _.merge;
var template = __webpack_require__(/*! ./template */ "./src/modules/old_fullscreen/hk/getdata/template.js");

var renderHead = __webpack_require__(/*! ../../common/renderHead */ "./src/modules/old_fullscreen/common/renderHead.js");
var uri = __webpack_require__(/*! ../../common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var config = __webpack_require__(/*! ../config */ "./src/modules/old_fullscreen/hk/config.js");

var renderMmp = __webpack_require__(/*! ./renderMmp */ "./src/modules/old_fullscreen/hk/getdata/renderMmp.js");
var renderXddp = __webpack_require__(/*! ./renderXddp */ "./src/modules/old_fullscreen/hk/getdata/renderXddp.js");

var user = __webpack_require__(/*! ../../user */ "./src/modules/old_fullscreen/user/index.js");
var islogin = user.get() ? true: false;
// islogin = true;

function data(par) {
    this.par = par;

    this.publicData = {};

    this.renderMmp = new renderMmp();

    this.id = '';  //默认为国内ip
    this.hugantong = ''
    this.login = islogin;


    if(!this.login ) {
        var span1 = '<span>点击立即领取L2十档行情</span>';
        $(".hqbj .download a").html(span1);
    }

    //行情报价
    this.getData();

}


data.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58, 106, 105, 62, 106, 108],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85], // 基础字段
        [51, 52, 116, 84, 92, 55, 126, 109], // 港股的一些字段
        [123, 124, 125], // 相对大盘涨跌幅
        [530], // 10档买卖盘
        [119, 120, 121, 122], // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 177] // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    //正式接口
    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);
    //测试
    //  var fullurl = "http://61.129.249.233:18665/" + "api/qt/stock/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
                var obj = msg;
                that.id = obj.lt;
                // console.log('海外ip')
                // console.log(that.id)
                // that.id=2
               
                if(obj.data) {
                    that.hugantong = obj.data.f177 & (128|256);
                    
                    // console.log('沪深港通 标识')
                    // console.log(that.hugantong)
                     //假
                    // that.hugantong = 0

                    //开始行情报价
                    that.format(obj.data);

                }
               



                //若是国外ip  修改行情报价中间的字
                if(that.id == 2) {
                    var span1 = '<span>应港交所要求，仅大陆（不含港、澳、台地区）登录用户，才能免费享受本公司港股Level-2活动</span>';
                    $(".hqbj .download a").html(span1);

                    $(".hqbj .download a").attr("href", "###");
                    $(".hqbj .download a").attr("disabled","disabled"); 
                    $(".hqbj .download a").attr("cursor","default"); 
                    $(".hqbj .download a").hover(function () {
                        $(".hqbj .download a").attr("cursor","default");
                    })
                    $(".hqbj .download a").click(function (event) {
                        event.preventDefault();   // 如果<a>定义了 target="_blank“ 需要这句来阻止打开新页面
                    });

                    $("#finance_queue").click(function (event) {
                        event.preventDefault();   // 如果<a>定义了 target="_blank“ 需要这句来阻止打开新页面
                    });


                    //若是海外ip  显示弹框
                    $("#chinese_alert").show();
                }

                 //若是国外ip  修改经纪队列图片
                if(that.id == 2) {

                    $("#finance_queue").html("<div><a target='_blank' style='color:red;font-size: 15px;font-weight: bold;text-decoration:default;position: absolute;top: 48%;left:0;padding: 0px 29px;' href='https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=http%3a%2f%2f183.136.160.79%3a8080%2fEM_HKL2%2f%3fcode%3d00700'>应港交所要求，仅大陆（不含港、澳、台地区）登录用户，才能免费享受本公司港股Level-2活动>></a></div>");
                    $("#finance_queue").css("background", "url(http://quotationtest.eastmoney.com/web/Content/images/quecn1.png)"); //http://hqres.eastmoney.com/EMHKl2/images/jjdl-mask.png
                    var height = $(".hqbjjjdl").height() - 59;
                    $("#finance_queue").css("height", height); 
                    $("#finance_queue").css("text-align", 'center');  
                    $("#finance_queue").css("background-size", "100% 100%");
                    $("#finance_queue").css("background-repeat", "no-repeat");
                    $("#finance_queue").click(function (e) {
                        // window.open("https://zqhd.eastmoney.com/Html/hkhd/pc/20171019/html/activity1.html?tz=web_act_161118ggl2_hdrk_01_01_20_0&cburl=http%3A%2F%2Fquote.eastmoney.com%2Fhk%2F00700.html");
                        // that.stopPropagation(e);
                    });
                }


                //增加点击事件
                that.renderClick();
                

                //经济队列  
                //国内 && 非登录 
                if (!that.login && that.id !== 2) {
                    $("#finance_queue").html("<div><a target='_blank' style='color:red;font-size: 15px;font-weight: bold;text-decoration:default;' href='https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=http%3a%2f%2f183.136.160.79%3a8080%2fEM_HKL2%2f%3fcode%3d00700'>点击立即领取经纪队列>></a></div>");
                    $("#finance_queue").css("background", "url(http://quotationtest.eastmoney.com/web/Content/images/quecn1.png)"); //http://hqres.eastmoney.com/EMHKl2/images/jjdl-mask.png
                    var height = $(".hqbjjjdl").height() - 59;
                    $("#finance_queue").css("height", height);
                    $("#finance_queue").css("line-height", height+'px');
                    $("#finance_queue").css("text-align", 'center');  
                    $("#finance_queue").css("background-size", "100% 100%");
                    $("#finance_queue").css("background-repeat", "no-repeat");
                    $("#finance_queue").click(function (e) {
                        window.open("https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=http%3a%2f%2f183.136.160.79%3a8080%2fEM_HKL2%2f%3fcode%3d00700");
                        that.stopPropagation(e);
                    });

                    $("#finance_queue div a").click(function (e) {
                        // console.log('000')
                        that.stopPropagation(e);
                    });


                    $(".hqbj .download a").attr("href", "https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=http%3a%2f%2f183.136.160.79%3a8080%2fEM_HKL2%2f%3fcode%3d00700");


                    // return;
                }

                //登录和非国外ip
                $("#finance_queue").css("padding-bottom", "10px");
                

                
                //若是国内ip 登录了 就放出sse接口
                if(that.id !== 2 && that.login) {

                     //国内 登录 的 才去请求经纪队列接口
                     that.getHqQueData();


                    //行情报价 sse
                    that.getSSEData();
                    //经纪队列 sse
                    that.getSSEhqqueData();

                }


                 //若是国内ip  未登录 并且是 沪股通的  就放出sse接口
                 if(that.id !== 2 && !that.login && that.hugantong) {
                    //行情报价 sse
                    that.getSSEData();
                    //经纪队列 sse
                    that.getSSEhqqueData();
                }
            

        }
    });

}


data.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58, 106, 105, 62, 106, 108],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85], // 基础字段
        [51, 52, 116, 84, 92, 55, 126, 109], // 港股的一些字段
        [123, 124, 125], // 相对大盘涨跌幅
        [530], // 10档买卖盘
        [119, 120, 121, 122], // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149] // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = config.host + "api/qt/stock/sse?" + uri.parStringify(data);
    //测试
    // var fullurl = "http://61.129.249.233:18665/" + "api/qt/stock/sse?" + uri.parStringify(data);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }

}


data.prototype.format = function (d) {
    // console.log(d)
    var that = this;

    var pdata = this.publicData;

    var oldo = this.o || {}; // 旧的对象

    var o = {};

    var f = oldo.f || Math.pow(10, d.f59) || 1;
    var f59 = oldo.f59 || d.f59;
    if (f59 < 2) {
        f59 = 2;
    }
    o.f59 = f59;
    o.f = f;

    if (d.f85) {
        o.ltg = d.f85; // 流通股
    }

    if (d.f58) {
        o.name = d.f58;
    }
    if (d.f57) {
        o.code = d.f57 + '.hk';
    }


    if (d.f43) {
        o.xj = (d.f43 / f).toFixed(f59) || "-";
    }
    if (d.f46) {
        o.jk = (d.f46 / f).toFixed(f59) || "-";
    }
    if (d.f60) {
        o.zs = (d.f60 / f).toFixed(f59);
    }
    if (d.f44) {
        o.zg = (d.f44 / f).toFixed(f59) || "-";
    }
    if (d.f45) {
        o.zd = (d.f45 / f).toFixed(f59) || "-";
    }
    if (d.f43) {
        var zs = (oldo.zs || d.f60 / f);
        o.zde = (d.f43 / f - zs).toFixed(f59);
        o.zdf = ((d.f43 / f - zs) / zs * 100).toFixed(f59);
    }
    // if ((oldo.ltg || d.f85) && d.f47) {
    //     var ltg = oldo.ltg || d.f85;
    //     o.hs = ((d.f47 / ltg) * 100).toFixed(f59);
    // }
    if (d.f106) {
        o.f106 = d.f106;
    }
    if ((oldo.ltg || d.f85) && d.f47) {
        var ltg = oldo.ltg || d.f85;
        var f106 = oldo.f106 || d.f106;
        o.hs = ((d.f47 / ltg * f106) * 100).toFixed(2);
    }
    if (d.f44 || d.f45) {
        var zg = d.f44 / f || oldo.zg;
        var zd = d.f45 / f || oldo.zd;
        var zs = oldo.zs || d.f60 / f;
        o.zf = ((zg - zd) / zs * 100).toFixed(f59);
    }
    if (d.f47) {
        o.cjl = d.f47;
    }
    if (d.f48) {
        o.cje = d.f48;
    }
    if (d.f49) {
        o.wp = d.f49;
        o.np = (oldo.cjl || d.f47) - d.f49;
    }
    if (d.f113) {
        o.szjs = d.f113;
    }
    if (d.f114) {
        o.xdjs = d.f114;
    }
    if (d.f115) {
        o.ppjs = d.f115;
    }
    if (d.f117) {
        o.lz = d.f117;
    }

    o.jdzf = {};
    if (d.f119) {
        o.jdzf.day5 = d.f119 / 100;
    }
    if (d.f120) {
        o.jdzf.day20 = d.f120 / 100;
    }
    if (d.f121) {
        o.jdzf.day60 = d.f121 / 100;
    }
    if (d.f122) {
        o.jdzf.dayyear = d.f122 / 100;
    }


    // 资金流
    o.zjl = {}

    // 其他 4个
    if (d.f135 || d.f136 || d.f137) {
        o.zjl.zl = [d.f135, d.f136, d.f137];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.cd = [d.f138, d.f139, d.f140];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.dd = [d.f141, d.f142, d.f143];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.zd = [d.f144, d.f145, d.f146];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.xd = [d.f147, d.f148, d.f149];
    }

    try {
        // 净资金流
        o.zjl.jzjl = [
            d.f140 || oldo.zjl.cd[2],
            d.f143 || oldo.zjl.dd[2],
            d.f146 || oldo.zjl.zd[2],
            d.f149 || oldo.zjl.xd[2]
        ];

    } catch (error) {

    }


    // 52 周
    if (d.f51) {
        o.zg52 = (d.f51 / f).toFixed(f59) || "-";
    }
    if (d.f52) {
        o.zd52 = (d.f52 / f).toFixed(f59) || "-";
    }

    if (d.f116) {
        o.zsz = d.f116;
    }
    if (d.f84) {
        o.zgb = d.f84;
    }
    if (d.f108) {
        o.mgsyttm = d.f108;
    }

    // 市盈率ttm
    if (d.f43 || d.f60 || d.f108) {
        var xj = d.f43 / f || oldo.xj;
        var zs = d.f60 / f || oldo.zs;

        var mgsyttm = d.f108 || oldo.mgsyttm;

        var chu = xj || zs;

        if (mgsyttm) {
            o.syl = (chu / mgsyttm).toFixed(f59);
        } else {
            o.syl = "-";
        }
    }


    if ((d.f43 || d.f60) && d.f92) {
        var xj = d.f43 / f || d.f60;
        var mgjzc = d.f92 || oldo.mgjzc;
        if (mgjzc) {
            o.sjl = (xj / mgjzc).toFixed(f59);
        } else {
            o.sjl = "-";
        }
    }

    if (d.f55) {
        o.mgsy = (d.f55).toFixed(f59)
    }
    if (d.f92) {
        o.mgjzc = (d.f92).toFixed(f59);
    }

    if (d.f126) {
        o.gxl = d.f126 + '%';
    }

    // 相对大盘涨跌幅
    if (d.f123 || d.f124 || d.f125) {
        o.xddp = {}
        o.xddp.month1 = d.f123 / 100 || oldo.xddp.month1;
        o.xddp.month3 = d.f124 / 100 || oldo.xddp.month3;
        o.xddp.week52 = d.f125 / 100 || oldo.xddp.week52;
    }


    // 买卖盘
    var mmp = {};
    var login = this.login; //用于区分登录状态，处理行情报价的显示条数

    // console.log('format  处理数据')
    // console.log(this.hugantong)
    //非海外的登录 和 非登录 情况
    if(this.id !== 2) {
        if(login) {
            mmp.buy = [
            [d.f21 / f, d.f22, d.f221],
            [d.f23 / f, d.f24, d.f222],
            [d.f25 / f, d.f26, d.f223],
            [d.f27 / f, d.f28, d.f224],
            [d.f29 / f, d.f30, d.f225],
            [d.f31 / f, d.f32, d.f226],
            [d.f33 / f, d.f34, d.f227],
            [d.f35 / f, d.f36, d.f228],
            [d.f37 / f, d.f38, d.f229],
            [d.f39 / f, d.f40, d.f230]
        ]
            mmp.sell = [
                [d.f19 / f, d.f20, d.f231],
                [d.f17 / f, d.f18, d.f232],
                [d.f15 / f, d.f16, d.f233],
                [d.f13 / f, d.f14, d.f234],
                [d.f11 / f, d.f12, d.f235],
                [d.f9 / f, d.f10, d.f236],
                [d.f7 / f, d.f8, d.f237],
                [d.f5 / f, d.f6, d.f238],
                [d.f3 / f, d.f4, d.f239],
                [d.f1 / f, d.f2, d.f240]
        ]
    
        }
        
        //国内未登录 and 沪股通
        if(!login && this.hugantong) {
            // console.log('22')
            mmp.buy = [
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                [d.f39 / f, d.f40, d.f230]
            ]
            mmp.sell = [
                [d.f19 / f, d.f20, d.f231],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-']
            ]


        }

        //国内未登录 and 不是沪股通
        if (!login && !this.hugantong){
            // console.log('333')
            mmp.buy = [
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-']
            ]
            mmp.sell = [
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-']
            ]

        }

    }

    //海外情况
    if(this.id == 2)  {
        mmp.buy = [
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-']
        ]
        mmp.sell = [
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-']
        ]


    }
    
    
    o.mmp = mmp;


    this.o = merge(oldo, o);

    this.render(o);

}


data.prototype.render = function (obj) {

    // console.log(obj);

    renderHead(config.head, obj);
    renderXddp(obj.xddp);

    var oldo = this.o || {};
    var zs = oldo.zs || obj.f60;

    //渲染行情报价
    this.renderMmp.setData(obj, zs);

    // console.log(obj.mmp)

    // renderZjl(obj);



}


data.prototype.renderClick = function () {

    $(".fiancequ").click(function () {
        $(".fiancequ").css("background", "#D3D3D3");
        $(".hangqp").css("background", "#fff");
        $("#finance_queue").show();
        $("#hangQA").hide();
    })

    $(".hangqp").click(function () {
        $(".hangqp").css("background", "#D3D3D3");
        $(".fiancequ").css("background", "#fff");
        $("#hangQA").show();
        $("#finance_queue").hide();
    })


    $("#chinese_alert .alert-remind b").click ( function() {
        $("#chinese_alert #bg").hide();
        $("#chinese_alert .alert-container").hide();

    })


    $("#chinese_alert .commit a").click ( function() {
        $("#chinese_alert #bg").hide();
        $("#chinese_alert .alert-container").hide();

    })
}


data.prototype.getHqQueData = function () {
    var that = this;
    var par = this.par;
    var secid = par.market + "." + par.code

    var fullurl = "http://push2.eastmoney.com/api/qt/stock/brkq/get?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + secid;

    //测试地址
    // var fullurl = "http://61.129.249.233:18665/api/qt/stock/brkq/get?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + secid;

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                var arr = obj.data.brkq;
                that.manerData(arr);
            }

        }
    });


}


data.prototype.getSSEhqqueData =  function () {

    var that = this;
    var par = this.par;
    var secid = par.market + "." + par.code

    var fullurl = "http://push2.eastmoney.com/api/qt/stock/brkq/sse?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + secid;

    // var fullurl = "http://61.129.249.233:18665/api/qt/stock/brkq/sse?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + secid;

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data);
        if (obj.rc == 0 && obj.data) {
            var arr = obj.data.brkq;

            that.manerData(arr);

        }
    }

}


//处理经济队列数据
data.prototype.manerData = function (arr) {
    // var that = this;

    var oldo = this.ol || {}; // 旧的对象

    var o = {};

    o.Blist = [];
    o.Slist = [];
    for (var i = 0; i < arr.length; i++) {
        var item = arr[i];
        if (item.substr(0, 1) == 'S') {
            o.Slist.push(item)
        } else if (item.substr(0, 1) == 'B') {
            o.Blist.push(item)
        }
    }

    // console.log(o.Blist)
    // console.log(o.Slist);


    this.ol = merge(oldo, o);

    var fullData = []
    for (var i = 0; i < this.ol.Blist.length; i++) {
        var temp = this.ol.Blist[i].split(',');

        for (var j = 0; j < temp.length; j++) {
            var tempj = temp[j].split('.');
            var shou = '';
            var name = '';
            shou = tempj[0];
            name = tempj[1];
            if (j == 0) {
                shou = tempj[0].split(':')[1];
            }
            var str = shou + '~' + name + '~' + 'B~' + (i + 1);
            fullData.push(str);

        }

    }


    for (var i = 0; i < this.ol.Slist.length; i++) {
        var temp = this.ol.Slist[i].split(',');

        for (var j = 0; j < temp.length; j++) {
            var tempj = temp[j].split('.');
            var shou = '';
            var name = '';
            shou = tempj[0];
            name = tempj[1];
            if (j == 0) {
                shou = tempj[0].split(':')[1];
            }
            var str = shou + '~' + name + '~' + 'S~' + (i + 1);
            fullData.push(str);

        }

    }
    
    var fullDatastr = fullData.join('|');

    // console.log(fullDatastr)

    //渲染经济队列
    this.renderFianceQe(fullDatastr);


}

//渲染经济队列
data.prototype.renderFianceQe = function (data) {
    var that = this;
    var lines = '';
    if(data) {
        lines = data.split('|');
    }
    

    var login = this.login;

    
    var blist = new Array(),
        slist = new Array();

    var currentIndexBuy = 0;
    var currentIndexSell = 0;

    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (!line) continue;
        var datum = line.split('~');

        if (datum.length > 1) {
            if (datum[2].toUpperCase() == "B") {
                if (currentIndexBuy != datum[3]) {
                    currentIndexBuy = datum[3];
                    blist.push({
                        idx: datum[3],
                        dir: datum[2],
                        seat: datum[0],
                        name: datum[1],
                        direction: "买" + currentIndexBuy
                    });
                } else {
                    blist.push({
                        idx: datum[3],
                        dir: datum[2],
                        seat: datum[0],
                        name: datum[1],
                        direction: ""
                    });
                }

            } else if (datum[2].toUpperCase() == "S") {
                if (currentIndexSell != datum[3]) {
                    currentIndexSell = datum[3];
                    slist.push({
                        idx: datum[3],
                        dir: datum[2],
                        seat: datum[0],
                        name: datum[1],
                        direction: "卖" + currentIndexSell
                    });
                } else {
                    slist.push({
                        idx: datum[3],
                        dir: datum[2],
                        seat: datum[0],
                        name: datum[1],
                        direction: ""
                    });
                }
            }
        }
    }
    var _bhtml = template("tmp_finance_queue", {
        list: blist
    });
    var _shtml = template("tmp_finance_queue", {
        list: slist
    });
    $("#finance_queue_buy tbody").html(_bhtml);
    $("#finance_queue_sell tbody").html(_shtml);
    var _herf = template("tmp_href", {
        logined: login
    });
    $("#finance_href").html(_herf);
}



data.prototype.stopPropagation = function (e) {
    e = e || window.event;
    if (e.stopPropagation) { //W3C阻止冒泡方法  
        e.stopPropagation();
    } else {
        e.cancelBubble = true; //IE阻止冒泡方法  
    }
}


module.exports = data;

/***/ }),

/***/ "./src/modules/old_fullscreen/hk/getdata/index.js":
/*!********************************************************!*\
  !*** ./src/modules/old_fullscreen/hk/getdata/index.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getBaseData = __webpack_require__(/*! ./getBaseData */ "./src/modules/old_fullscreen/hk/getdata/getBaseData.js");
// var getJjdl = require("./getJjdl");

module.exports = function(par){

    new getBaseData(par);
    // new getJjdl(par);

};

/***/ }),

/***/ "./src/modules/old_fullscreen/hk/getdata/renderMmp.js":
/*!************************************************************!*\
  !*** ./src/modules/old_fullscreen/hk/getdata/renderMmp.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var merge = _.merge;
var format = __webpack_require__(/*! ../../common/format */ "./src/modules/old_fullscreen/common/format.js");

function mmp() {

    this.data = {
        buy: [],
        sell: []
    }

    this.init();
}

mmp.prototype.init = function () {

    this.buy = $(".hqbj .buy");
    this.sell = $(".hqbj .sell");

    for (var i = 0, len = 10; i < len; i++) {
        var tr1 = $("<tr><td>卖" + (10 - i) + "</td><td>-</td><td>-</td><td>-</td></tr>");
        var tr2 = $("<tr><td>买" + (i + 1) + "</td><td>-</td><td>-</td><td>-</td></tr>");
        this.buy.append(tr1);
        this.sell.append(tr2);
    }

}

mmp.prototype.setData = function (fulldata, zs) {
    var sd = this.data;

    var data = fulldata.mmp;

    for (var key in data) {
        var dk = data[key];
        for (var i = 0, len = dk.length; i < len; i++) {
            var ar = dk[i];
            for (var ii = 0, len2 = ar.length; ii < len2; ii++) {
                var v = ar[ii];
                if (v + "" != "NaN" && v !== undefined && v !== '-') {
                    var td = this[key].find("tr").eq(i).find("td").eq(ii + 1);
                    
                    if (!sd[key][i]) {
                        sd[key][i] = [];
                    }
                    sd[key][i][ii] = v;
                    if (ii == 0) {
                        if (v > zs) {
                            td.removeClass().addClass("rise");
                        }
                        if (v < zs) {
                            td.removeClass().addClass("fall");
                        }
                        v = (v / 1).toFixed(3);
                    }
                    if (ii == 1) {
                        v = format.num(v);
                    }
                    if (ii == 2) {
                        v = "(" + v + ")";
                    }

                    
                    td.text(v)
                }
            }
        }
    }

}



module.exports = mmp;

/***/ }),

/***/ "./src/modules/old_fullscreen/hk/getdata/renderXddp.js":
/*!*************************************************************!*\
  !*** ./src/modules/old_fullscreen/hk/getdata/renderXddp.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (data) {

    if (!data) {
        return false;
    }
    
    var width = 160;

    var rows = $(".xddpbox .row");

    var month1 = data.month1 || 0;
    var month3 = data.month3 || 0;
    var week52 = data.week52 || 0;

    var max = Math.max(Math.abs(month1), Math.abs(month3), Math.abs(week52));

    var tit = ["1个月", "3个月", "52周"]
    var arr = [month1, month3, week52];

    for (var i = 0, len = arr.length; i < len; i++) {
        var val = arr[i];
        if (val && max > 0) {
            var row = rows.eq(i);
            row.find("label").text(tit[i] + " " + (val / 1).toFixed(2) + "%");

            var w = width * Math.abs(val) / max;
            var span = row.find("span");
            span.width(Math.abs(w + 1));
            span.removeClass();
            if (val > 0) {
                span.addClass("risebg")
            } else if (val < 0) {
                span.addClass("fallbg")
            } else {
                span.addClass("pingbg")
            }
        }
    }


};

/***/ }),

/***/ "./src/modules/old_fullscreen/hk/getdata/template.js":
/*!***********************************************************!*\
  !*** ./src/modules/old_fullscreen/hk/getdata/template.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_RESULT__;/*!art-template - Template Engine | http://aui.github.com/artTemplate/*/
!function () { function a(a) { return a.replace(t, "").replace(u, ",").replace(v, "").replace(w, "").replace(x, "").split(y) } function b(a) { return "'" + a.replace(/('|\\)/g, "\\$1").replace(/\r/g, "\\r").replace(/\n/g, "\\n") + "'" } function c(c, d) { function e(a) { return m += a.split(/\n/).length - 1, k && (a = a.replace(/\s+/g, " ").replace(/<!--[\w\W]*?-->/g, "")), a && (a = s[1] + b(a) + s[2] + "\n"), a } function f(b) { var c = m; if (j ? b = j(b, d) : g && (b = b.replace(/\n/g, function () { return m++ , "$line=" + m + ";" })), 0 === b.indexOf("=")) { var e = l && !/^=[=#]/.test(b); if (b = b.replace(/^=[=#]?|[\s;]*$/g, ""), e) { var f = b.replace(/\s*\([^\)]+\)/, ""); n[f] || /^(include|print)$/.test(f) || (b = "$escape(" + b + ")") } else b = "$string(" + b + ")"; b = s[1] + b + s[2] } return g && (b = "$line=" + c + ";" + b), r(a(b), function (a) { if (a && !p[a]) { var b; b = "print" === a ? u : "include" === a ? v : n[a] ? "$utils." + a : o[a] ? "$helpers." + a : "$data." + a, w += a + "=" + b + ",", p[a] = !0 } }), b + "\n" } var g = d.debug, h = d.openTag, i = d.closeTag, j = d.parser, k = d.compress, l = d.escape, m = 1, p = { $data: 1, $filename: 1, $utils: 1, $helpers: 1, $out: 1, $line: 1 }, q = "".trim, s = q ? ["$out='';", "$out+=", ";", "$out"] : ["$out=[];", "$out.push(", ");", "$out.join('')"], t = q ? "$out+=text;return $out;" : "$out.push(text);", u = "function(){var text=''.concat.apply('',arguments);" + t + "}", v = "function(filename,data){data=data||$data;var text=$utils.$include(filename,data,$filename);" + t + "}", w = "'use strict';var $utils=this,$helpers=$utils.$helpers," + (g ? "$line=0," : ""), x = s[0], y = "return new String(" + s[3] + ");"; r(c.split(h), function (a) { a = a.split(i); var b = a[0], c = a[1]; 1 === a.length ? x += e(b) : (x += f(b), c && (x += e(c))) }); var z = w + x + y; g && (z = "try{" + z + "}catch(e){throw {filename:$filename,name:'Render Error',message:e.message,line:$line,source:" + b(c) + ".split(/\\n/)[$line-1].replace(/^\\s+/,'')};}"); try { var A = new Function("$data", "$filename", z); return A.prototype = n, A } catch (B) { throw B.temp = "function anonymous($data,$filename) {" + z + "}", B } } var d = function (a, b) { return "string" == typeof b ? q(b, { filename: a }) : g(a, b) }; d.version = "3.0.0", d.config = function (a, b) { e[a] = b }; var e = d.defaults = { openTag: "<%", closeTag: "%>", escape: !0, cache: !0, compress: !1, parser: null }, f = d.cache = {}; d.render = function (a, b) { return q(a, b) }; var g = d.renderFile = function (a, b) { var c = d.get(a) || p({ filename: a, name: "Render Error", message: "Template not found" }); return b ? c(b) : c }; d.get = function (a) { var b; if (f[a]) b = f[a]; else if ("object" == typeof document) { var c = document.getElementById(a); if (c) { var d = (c.value || c.innerHTML).replace(/^\s*|\s*$/g, ""); b = q(d, { filename: a }) } } return b }; var h = function (a, b) { return "string" != typeof a && (b = typeof a, "number" === b ? a += "" : a = "function" === b ? h(a.call(a)) : ""), a }, i = { "<": "&#60;", ">": "&#62;", '"': "&#34;", "'": "&#39;", "&": "&#38;" }, j = function (a) { return i[a] }, k = function (a) { return h(a).replace(/&(?![\w#]+;)|[<>"']/g, j) }, l = Array.isArray || function (a) { return "[object Array]" === {}.toString.call(a) }, m = function (a, b) { var c, d; if (l(a)) for (c = 0, d = a.length; d > c; c++)b.call(a, a[c], c, a); else for (c in a) b.call(a, a[c], c) }, n = d.utils = { $helpers: {}, $include: g, $string: h, $escape: k, $each: m }; d.helper = function (a, b) { o[a] = b }; var o = d.helpers = n.$helpers; d.onerror = function (a) { var b = "Template Error\n\n"; for (var c in a) b += "<" + c + ">\n" + a[c] + "\n\n"; "object" == typeof console && console.error(b) }; var p = function (a) { return d.onerror(a), function () { return "{Template Error}" } }, q = d.compile = function (a, b) { function d(c) { try { return new i(c, h) + "" } catch (d) { return b.debug ? p(d)() : (b.debug = !0, q(a, b)(c)) } } b = b || {}; for (var g in e) void 0 === b[g] && (b[g] = e[g]); var h = b.filename; try { var i = c(a, b) } catch (j) { return j.filename = h || "anonymous", j.name = "Syntax Error", p(j) } return d.prototype = i.prototype, d.toString = function () { return i.toString() }, h && b.cache && (f[h] = d), d }, r = n.$each, s = "break,case,catch,continue,debugger,default,delete,do,else,false,finally,for,function,if,in,instanceof,new,null,return,switch,this,throw,true,try,typeof,var,void,while,with,abstract,boolean,byte,char,class,const,double,enum,export,extends,final,float,goto,implements,import,int,interface,long,native,package,private,protected,public,short,static,super,synchronized,throws,transient,volatile,arguments,let,yield,undefined", t = /\/\*[\w\W]*?\*\/|\/\/[^\n]*\n|\/\/[^\n]*$|"(?:[^"\\]|\\[\w\W])*"|'(?:[^'\\]|\\[\w\W])*'|\s*\.\s*[$\w\.]+/g, u = /[^\w$]+/g, v = new RegExp(["\\b" + s.replace(/,/g, "\\b|\\b") + "\\b"].join("|"), "g"), w = /^\d[^,]*|,\d[^,]*/g, x = /^,+|,+$/g, y = /^$|,+/; e.openTag = "{{", e.closeTag = "}}"; var z = function (a, b) { var c = b.split(":"), d = c.shift(), e = c.join(":") || ""; return e && (e = ", " + e), "$helpers." + d + "(" + a + e + ")" }; e.parser = function (a) { a = a.replace(/^\s/, ""); var b = a.split(" "), c = b.shift(), e = b.join(" "); switch (c) { case "if": a = "if(" + e + "){"; break; case "else": b = "if" === b.shift() ? " if(" + b.join(" ") + ")" : "", a = "}else" + b + "{"; break; case "/if": a = "}"; break; case "each": var f = b[0] || "$data", g = b[1] || "as", h = b[2] || "$value", i = b[3] || "$index", j = h + "," + i; "as" !== g && (f = "[]"), a = "$each(" + f + ",function(" + j + "){"; break; case "/each": a = "});"; break; case "echo": a = "print(" + e + ");"; break; case "print": case "include": a = c + "(" + b.join(",") + ");"; break; default: if (/^\s*\|\s*[\w\$]/.test(e)) { var k = !0; 0 === a.indexOf("#") && (a = a.substr(1), k = !1); for (var l = 0, m = a.split("|"), n = m.length, o = m[l++]; n > l; l++)o = z(o, m[l]); a = (k ? "=" : "=#") + o } else a = d.helpers[c] ? "=#" + c + "(" + b.join(",") + ");" : "=" + a }return a },  true ? !(__WEBPACK_AMD_DEFINE_RESULT__ = (function () { return d }).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)) : undefined }();

/***/ }),

/***/ "./src/modules/old_fullscreen/hk/main.html":
/*!*************************************************!*\
  !*** ./src/modules/old_fullscreen/hk/main.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"switchbar\">\r\n  <ul>\r\n    <li class=\"active\" data-type=\"r\">\r\n      <span>分时</span>\r\n    </li>\r\n    <li data-type=\"k\">\r\n      <span>日K</span>\r\n    </li>\r\n    <li data-type=\"wk\">\r\n      <span>周K</span>\r\n    </li>\r\n    <li data-type=\"mk\">\r\n      <span>月K</span>\r\n    </li>\r\n  </ul>\r\n  <ul class=\"fr r-box\" id=\"kchart-toolbar\" style=\"display: block;\">\r\n    <li id=\"btn-stretchout\">拉长</li>\r\n    <li id=\"btn-drawback\">缩短</li>\r\n    <li class=\"rk-a\" id=\"select-authority\">\r\n      <span><span class=\"selected-box\" value=\"\">前复权</span><i class=\"select-icon\"></i></span>\r\n      <div class=\"rk-options k-options\" id=\"authority-options\">\r\n        <span value=\"fa\" class=\"\">前复权</span>\r\n        <span value=\"ba\">后复权</span>\r\n        <span>不复权</span>\r\n      </div>\r\n    </li>\r\n  </ul>\r\n</div>\r\n<div class=\"chart\">\r\n  <div class=\"chart-box\"></div>\r\n</div>"

/***/ }),

/***/ "./src/modules/old_fullscreen/hk/right.html":
/*!**************************************************!*\
  !*** ./src/modules/old_fullscreen/hk/right.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- 相对恒指 -->\r\n<div class=\"xddp\">\r\n    <div class=\"xddpbox\">\r\n        <p class=\"ftitle\">相对恒指涨跌幅</p>\r\n        <div class=\"row\">\r\n            <label></label>\r\n            <span></span>\r\n        </div>\r\n        <div class=\"row\">\r\n            <label></label>\r\n            <span></span>\r\n        </div>\r\n        <div class=\"row\">\r\n            <label></label>\r\n            <span></span>\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n<!-- 行情报价 经济队列 -->\r\n<div class=\"hqbjjjdl\">\r\n\r\n    <div class=\"swtichtab\" style=\"display:none;\">\r\n        <div class=\"active\">行情报价</div>\r\n        <div>经济队列 </div>\r\n    </div>\r\n\r\n    <div class=\"hang_header\">\r\n        <a href=\"#\" class=\"hangqp\">行情报价</a><a href=\"#\" class=\"fiancequ\">经纪队列</a>\r\n    </div>\r\n\r\n    <div id=\"hangQA\">\r\n\r\n        <div class=\"dire\"><span>方向</span><span>挂单价</span><span>挂单量</span><span>席位数</span></div>\r\n        <div class=\"hqbj\">\r\n            <table>\r\n                <!-- <thead>\r\n                    <tr>\r\n                        <td>方向</td>\r\n                        <td>挂单价</td>\r\n                        <td>挂单量</td>\r\n                        <td>席位数</td>\r\n                    </tr>\r\n                </thead> -->\r\n                <tbody class=\"buy\"></tbody>\r\n            </table>\r\n            <div class=\"download\">\r\n                <a href=\"http://acttg.eastmoney.com/pub/web_app_ggy_jjdll_01_01_01_0\" target=\"_blank\"\r\n                    class=\"clearfloat\">\r\n                    <span>点击下载东方财富APP</span>\r\n                    <span>随时随地查看港股L2行情</span>\r\n                </a>\r\n            </div>\r\n            <table>\r\n                <tbody class=\"sell\"></tbody>\r\n            </table>\r\n\r\n\r\n        </div>\r\n\r\n    </div>\r\n\r\n\r\n    <script id=\"tmp_quote_list\" type=\"text/html\">\r\n        {{each list as value i}}\r\n        <tr>\r\n            <td style=\"width: 35px;\">{{value.Key}}</td>\r\n            <td style=\"width: 50px;\" class=\"{{value.Color}} w54\">{{value.Price}}</td>\r\n            <td style=\"width: 60px;\">{{value.Amount}}</td>\r\n            <td style=\"width: 53px;\">{{value.Seat}}</td>\r\n        </tr>\r\n        {{/each}}\r\n    </script>\r\n    <script id=\"tmp_finance_queue\" type=\"text/html\">\r\n        {{each list as value i}}\r\n        <tr>\r\n            <td style=\"width: 39px\">{{value.direction}}</td>\r\n            <td style=\"width: 59px\" class=\"textCenter\">{{value.seat}}</td>\r\n            <td style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\"><span title=\"{{value.name}}\">{{value.name}}</span></td>\r\n        </tr>\r\n        {{/each}}\r\n    </script>\r\n    <script id=\"tmp_href\" type=\"text/html\">\r\n        {{if logined}}\r\n        <a style=\"margin: 5px; line-height: 20px;\" href=\"http://acttg.eastmoney.com/pub/web_app_ggy_jjdll_01_01_01_0\" target=\"_blank\" class=\"red fz12\">点击下载东方财富网APP<br>&nbsp;随时随地查看港股L2行情</a>\r\n        {{else}}\r\n        <a href=\"https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=http%3a%2f%2f183.136.160.79%3a8080%2fEM_HKL2%2f%3fcode%3d00700\" target=\"_blank\" class=\"red fz12\">点击立即领取L2十档行情</a>\r\n        {{/if}}\r\n    </script>\r\n    <div id=\"finance_queue\" class=\"info_list Ie6Tab active\" style=\"padding-bottom: 10px;display:none;\">\r\n        <div class=\"dire2\"><span>方向</span><span>席位数</span><span>席位名称</span></div>\r\n\r\n        <div class=\"wrap\">\r\n            <div class=\"inner\">\r\n                <table class=\"list\" id=\"finance_queue_sell\">\r\n                    <thead>\r\n                        <!-- <tr>\r\n                            <th>方向</th>\r\n                            <th>席位号</th>\r\n                            <th>席位名称</th>\r\n                        </tr> -->\r\n                    </thead>\r\n                    <tbody>\r\n                        <tr>\r\n                            <td style=\"width: 39px\">卖1</td>\r\n                            <td style=\"width: 59px\" class=\"textCenter\">5999</td>\r\n                            <td\r\n                                style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\">\r\n                                <span title=\"中国创盈市场服\">中国创盈市场服</span></td>\r\n                        </tr>\r\n\r\n                        <tr>\r\n                            <td style=\"width: 39px\">卖2</td>\r\n                            <td style=\"width: 59px\" class=\"textCenter\">5999</td>\r\n                            <td\r\n                                style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\">\r\n                                <span title=\"中国创盈市场服\">中国创盈市场服</span></td>\r\n                        </tr>\r\n\r\n                        <tr>\r\n                            <td style=\"width: 39px\"></td>\r\n                            <td style=\"width: 59px\" class=\"textCenter\">5999</td>\r\n                            <td\r\n                                style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\">\r\n                                <span title=\"中国创盈市场服\">中国创盈市场服</span></td>\r\n                        </tr>\r\n\r\n                        <tr>\r\n                            <td style=\"width: 39px\">卖6</td>\r\n                            <td style=\"width: 59px\" class=\"textCenter\">5999</td>\r\n                            <td\r\n                                style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\">\r\n                                <span title=\"中国创盈市场服\">中国创盈市场服</span></td>\r\n                        </tr>\r\n\r\n                        <tr>\r\n                            <td style=\"width: 39px\">卖7</td>\r\n                            <td style=\"width: 59px\" class=\"textCenter\">2311</td>\r\n                            <td\r\n                                style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\">\r\n                                <span title=\"恒生证\">恒生证</span></td>\r\n                        </tr>\r\n                    </tbody>\r\n                </table>\r\n            </div>\r\n        </div>\r\n        <div id=\"finance_href\" style=\"text-align: center;\">\r\n            <a style=\"margin: 5px; line-height: 20px;\"\r\n                href=\"https://zqhd.eastmoney.com/Html/hkhd/pc/20171019/html/activity1.html?tz=web_act_161118ggl2_hdrk_01_01_20_0&cburl=http%3A%2F%2Fquote.eastmoney.com%2Fhk%2F00700.html\" target=\"_blank\"\r\n                class=\"red fz12\">点击下载东方财富网APP<br>&nbsp;随时随地查看港股L2行情</a>\r\n        </div>\r\n        <div class=\"wrap\">\r\n            <div class=\"inner\">\r\n                <table class=\"list\" id=\"finance_queue_buy\">\r\n                    <tbody>\r\n                        <tr>\r\n                            <td style=\"width: 39px\">买1</td>\r\n                            <td style=\"width: 59px\" class=\"textCenter\">5998</td>\r\n                            <td\r\n                                style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\">\r\n                                <span title=\"中国创盈市场服\">中国创盈市场服</span></td>\r\n                        </tr>\r\n\r\n                        <tr>\r\n                            <td style=\"width: 39px\">买5</td>\r\n                            <td style=\"width: 59px\" class=\"textCenter\">5999</td>\r\n                            <td\r\n                                style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\">\r\n                                <span title=\"中国创盈市场服\">中国创盈市场服</span></td>\r\n                        </tr>\r\n\r\n                        <tr>\r\n                            <td style=\"width: 39px\">买6</td>\r\n                            <td style=\"width: 59px\" class=\"textCenter\">5998</td>\r\n                            <td\r\n                                style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\">\r\n                                <span title=\"中国创盈市场服\">中国创盈市场服</span></td>\r\n                        </tr>\r\n\r\n                        <tr>\r\n                            <td style=\"width: 39px\">买13</td>\r\n                            <td style=\"width: 59px\" class=\"textCenter\">6698</td>\r\n                            <td\r\n                                style=\"width: 100px; max-width: 100px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;\">\r\n                                <span title=\"盈透证\">盈透证</span></td>\r\n                        </tr>\r\n                    </tbody>\r\n                </table>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"jjdl\"></div>\r\n\r\n</div>"

/***/ }),

/***/ "./src/modules/old_fullscreen/ie_sse_polyfill.js":
/*!*******************************************************!*\
  !*** ./src/modules/old_fullscreen/ie_sse_polyfill.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/*
   * EventSource polyfill version 0.9.7
   * Supported by sc AmvTek srl
   * :email: devel@amvtek.com
 */
;(function (global) {

    if (global.EventSource && !global._eventSourceImportPrefix){
        return;
    }

    var evsImportName = (global._eventSourceImportPrefix||'')+"EventSource";

    var EventSource = function (url, options) {

        if (!url || typeof url != 'string') {
            throw new SyntaxError('Not enough arguments');
        }

        this.URL = url;
        this.setOptions(options);
        var evs = this;
        setTimeout(function(){evs.poll()}, 0);
    };

    EventSource.prototype = {

        CONNECTING: 0,

        OPEN: 1,

        CLOSED: 2,

        defaultOptions: {

            loggingEnabled: false,

            loggingPrefix: "eventsource",

            interval: 500, // milliseconds

            bufferSizeLimit: 256*1024, // bytes

            silentTimeout: 300000, // milliseconds

            getArgs:{
                'evs_buffer_size_limit': 256*1024
            },

            xhrHeaders:{
                'Accept': 'text/event-stream',
                'Cache-Control': 'no-cache',
                'X-Requested-With': 'XMLHttpRequest'
            }
        },

        setOptions: function(options){

            var defaults = this.defaultOptions;
            var option;

            // set all default options...
            for (option in defaults){

                if ( defaults.hasOwnProperty(option) ){
                    this[option] = defaults[option];
                }
            }

            // override with what is in options
            for (option in options){

                if (option in defaults && options.hasOwnProperty(option)){
                    this[option] = options[option];
                }
            }

            // if getArgs option is enabled
            // ensure evs_buffer_size_limit corresponds to bufferSizeLimit
            if (this.getArgs && this.bufferSizeLimit) {

                this.getArgs['evs_buffer_size_limit'] = this.bufferSizeLimit;
            }

            // if console is not available, force loggingEnabled to false
            if (typeof console === "undefined" || typeof console.log === "undefined") {

                this.loggingEnabled = false;
            }
        },

        log: function(message) {

            if (this.loggingEnabled) {

                console.log("[" + this.loggingPrefix +"]:" + message)
            }
        },

        poll: function() {

            try {

                if (this.readyState == this.CLOSED) {
                    return;
                }

                this.cleanup();
                this.readyState = this.CONNECTING;
                this.cursor = 0;
                this.cache = '';
                this._xhr = new this.XHR(this);
                this.resetNoActivityTimer();

            }
            catch (e) {

                // in an attempt to silence the errors
                this.log('There were errors inside the pool try-catch');
                this.dispatchEvent('error', { type: 'error', data: e.message });
            }
        },

        pollAgain: function (interval) {

            // schedule poll to be called after interval milliseconds
            var evs = this;
            evs.readyState = evs.CONNECTING;
            evs.dispatchEvent('error', {
                type: 'error',
                data: "Reconnecting "
            });
            this._pollTimer = setTimeout(function(){evs.poll()}, interval||0);
        },


        cleanup: function() {

            this.log('evs cleaning up')

            if (this._pollTimer){
                clearInterval(this._pollTimer);
                this._pollTimer = null;
            }

            if (this._noActivityTimer){
                clearInterval(this._noActivityTimer);
                this._noActivityTimer = null;
            }

            if (this._xhr){
                this._xhr.abort();
                this._xhr = null;
            }
        },

        resetNoActivityTimer: function(){

            if (this.silentTimeout){

                if (this._noActivityTimer){
                    clearInterval(this._noActivityTimer);
                }
                var evs = this;
                this._noActivityTimer = setTimeout(
                        function(){ evs.log('Timeout! silentTImeout:'+evs.silentTimeout); evs.pollAgain(); },
                        this.silentTimeout
                        );
            }
        },

        close: function () {

            this.readyState = this.CLOSED;
            this.log('Closing connection. readyState: '+this.readyState);
            this.cleanup();
        },

        _onxhrdata: function() {

            var request = this._xhr;

            if (request.isReady() && !request.hasError() ) {
                // reset the timer, as we have activity
                this.resetNoActivityTimer();

                // move this EventSource to OPEN state...
                if (this.readyState == this.CONNECTING) {
                    this.readyState = this.OPEN;
                    this.dispatchEvent('open', { type: 'open' });
                }

                var buffer = request.getBuffer();

                if (buffer.length > this.bufferSizeLimit) {
                    this.log('buffer.length > this.bufferSizeLimit');
                    this.pollAgain();
                }

                if (this.cursor == 0 && buffer.length > 0){

                    // skip byte order mark \uFEFF character if it starts the stream
                    if (buffer.substring(0,1) == '\uFEFF'){
                        this.cursor = 1;
                    }
                }

                var lastMessageIndex = this.lastMessageIndex(buffer);
                if (lastMessageIndex[0] >= this.cursor){

                    var newcursor = lastMessageIndex[1];
                    var toparse = buffer.substring(this.cursor, newcursor);
                    this.parseStream(toparse);
                    this.cursor = newcursor;
                }

                // if request is finished, reopen the connection
                if (request.isDone()) {
                    this.log('request.isDone(). reopening the connection');
                    this.pollAgain(this.interval);
                }
            }
            else if (this.readyState !== this.CLOSED) {

                this.log('this.readyState !== this.CLOSED');
                this.pollAgain(this.interval);

                //MV: Unsure why an error was previously dispatched
            }
        },

        parseStream: function(chunk) {

            // normalize line separators (\r\n,\r,\n) to \n
            // remove white spaces that may precede \n
            chunk = this.cache + this.normalizeToLF(chunk);

            var events = chunk.split('\n\n');

            var i, j, eventType, datas, line, retry;

            for (i=0; i < (events.length - 1); i++) {

                eventType = 'message';
                datas = [];
                parts = events[i].split('\n');

                for (j=0; j < parts.length; j++) {

                    line = this.trimWhiteSpace(parts[j]);

                    if (line.indexOf('event') == 0) {

                        eventType = line.replace(/event:?\s*/, '');
                    }
                    else if (line.indexOf('retry') == 0) {

                        retry = parseInt(line.replace(/retry:?\s*/, ''));
                        if(!isNaN(retry)) {
                            this.interval = retry;
                        }
                    }
                    else if (line.indexOf('data') == 0) {

                        datas.push(line.replace(/data:?\s*/, ''));
                    }
                    else if (line.indexOf('id:') == 0) {

                        this.lastEventId = line.replace(/id:?\s*/, '');
                    }
                    else if (line.indexOf('id') == 0) { // this resets the id

                        this.lastEventId = null;
                    }
                }

                if (datas.length) {
                    // dispatch a new event
                    var event = new MessageEvent(eventType, datas.join('\n'), window.location.origin, this.lastEventId);
                    this.dispatchEvent(eventType, event);
                }
            }

            this.cache = events[events.length - 1];
        },

        dispatchEvent: function (type, event) {
            var handlers = this['_' + type + 'Handlers'];

            if (handlers) {

                for (var i = 0; i < handlers.length; i++) {
                    handlers[i].call(this, event);
                }
            }

            if (this['on' + type]) {
                this['on' + type].call(this, event);
            }

        },

        addEventListener: function (type, handler) {
            if (!this['_' + type + 'Handlers']) {
                this['_' + type + 'Handlers'] = [];
            }

            this['_' + type + 'Handlers'].push(handler);
        },

        removeEventListener: function (type, handler) {
            var handlers = this['_' + type + 'Handlers'];
            if (!handlers) {
                return;
            }
            for (var i = handlers.length - 1; i >= 0; --i) {
                if (handlers[i] === handler) {
                    handlers.splice(i, 1);
                    break;
                }
            }
        },

        _pollTimer: null,

        _noactivityTimer: null,

        _xhr: null,

        lastEventId: null,

        cache: '',

        cursor: 0,

        onerror: null,

        onmessage: null,

        onopen: null,

        readyState: 0,

        // ===================================================================
        // helpers functions
        // those are attached to prototype to ease reuse and testing...

        urlWithParams: function (baseURL, params) {

            var encodedArgs = [];

            if (params){

                var key, urlarg;
                var urlize = encodeURIComponent;

                for (key in params){
                    if (params.hasOwnProperty(key)) {
                        urlarg = urlize(key)+'='+urlize(params[key]);
                        encodedArgs.push(urlarg);
                    }
                }
            }

            if (encodedArgs.length > 0){

                if (baseURL.indexOf('?') == -1)
                    return baseURL + '?' + encodedArgs.join('&');
                return baseURL + '&' + encodedArgs.join('&');
            }
            return baseURL;
        },

        lastMessageIndex: function(text) {

            var ln2 =text.lastIndexOf('\n\n');
            var lr2 = text.lastIndexOf('\r\r');
            var lrln2 = text.lastIndexOf('\r\n\r\n');

            if (lrln2 > Math.max(ln2, lr2)) {
                return [lrln2, lrln2+4];
            }
            return [Math.max(ln2, lr2), Math.max(ln2, lr2) + 2]
        },

        trimWhiteSpace: function(str) {
            // to remove whitespaces left and right of string

            var reTrim = /^(\s|\u00A0)+|(\s|\u00A0)+$/g;
            return str.replace(reTrim, '');
        },

        normalizeToLF: function(str) {

            // replace \r and \r\n with \n
            return str.replace(/\r\n|\r/g, '\n');
        }

    };

    if (!isOldIE()){

        EventSource.isPolyfill = "XHR";

        // EventSource will send request using XMLHttpRequest
        EventSource.prototype.XHR = function(evs) {

            request = new XMLHttpRequest();
            this._request = request;
            evs._xhr = this;

            // set handlers
            request.onreadystatechange = function(){
                if (request.readyState > 1 && evs.readyState != evs.CLOSED) {
                    if (request.status == 200 || (request.status>=300 && request.status<400)){
                        evs._onxhrdata();
                    }
                    else {
                        request._failed = true;
                        evs.readyState = evs.CLOSED;
                        evs.dispatchEvent('error', {
                            type: 'error',
                            data: "The server responded with "+request.status
                        });
                        evs.close();
                    }
                }
            };

            request.onprogress = function () {
            };

            var fullurl = evs.urlWithParams(evs.URL, evs.getArgs)
            var posturl = fullurl.substring(0, fullurl.indexOf('?'))
            var search = fullurl.substring(fullurl.indexOf('?') + 1)

            request.open('POST', posturl, true);

            var headers = evs.xhrHeaders; // maybe null
            for (var header in headers) {
                if (headers.hasOwnProperty(header)){
                    request.setRequestHeader(header, headers[header]);
                }
            }
            if (evs.lastEventId) {
                request.setRequestHeader('Last-Event-Id', evs.lastEventId);
            }
            request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            //console.info(111)
            request.send(encodeURI(search));
            //console.info(222)
        };

        EventSource.prototype.XHR.prototype = {

            useXDomainRequest: false,

            _request: null,

            _failed: false, // true if we have had errors...

            isReady: function() {


                return this._request.readyState >= 2;
            },

            isDone: function() {

                return (this._request.readyState == 4);
            },

            hasError: function() {

                return (this._failed || (this._request.status >= 400));
            },

            getBuffer: function() {

                var rv = '';
                try {
                    rv = this._request.responseText || '';
                }
                catch (e){}
                return rv;
            },

            abort: function() {

                if ( this._request ) {
                    this._request.abort();
                }
            }
        };
    }
    else {

	EventSource.isPolyfill = "IE_8-9";

        // patch EventSource defaultOptions
        var defaults = EventSource.prototype.defaultOptions;
        defaults.xhrHeaders = null; // no headers will be sent
        defaults.getArgs['evs_preamble'] = 2048 + 8;

        // EventSource will send request using Internet Explorer XDomainRequest
        EventSource.prototype.XHR = function(evs) {

            request = new XDomainRequest();
            this._request = request;

            // set handlers
            request.onprogress = function(){
                request._ready = true;
                evs._onxhrdata();
            };

            request.onload = function(){
                this._loaded = true;
                evs._onxhrdata();
            };

            request.onerror = function(){
                this._failed = true;
                evs.readyState = evs.CLOSED;
                evs.dispatchEvent('error', {
                    type: 'error',
                    data: "XDomainRequest error"
                });
            };

            request.ontimeout = function(){
                this._failed = true;
                evs.readyState = evs.CLOSED;
                evs.dispatchEvent('error', {
                    type: 'error',
                    data: "XDomainRequest timed out"
                });
            };

            // XDomainRequest does not allow setting custom headers
            // If EventSource has enabled the use of GET arguments
            // we add parameters to URL so that server can adapt the stream...
            var reqGetArgs = {};
            if (evs.getArgs) {

                // copy evs.getArgs in reqGetArgs
                var defaultArgs = evs.getArgs;
                    for (var key in defaultArgs) {
                        if (defaultArgs.hasOwnProperty(key)){
                            reqGetArgs[key] = defaultArgs[key];
                        }
                    }
                if (evs.lastEventId){
                    reqGetArgs['evs_last_event_id'] = evs.lastEventId;
                }
            }
            // send the request


            // var fullurl = evs.urlWithParams(evs.URL, evs.getArgs)
            // var posturl = fullurl.substring(0, fullurl.indexOf('?')).replace('https://','http://')
            // var search = fullurl.substring(fullurl.indexOf('?') + 1)

            // console.info(111)
            // console.info(posturl)
            // console.info(search)

            // request.open('POST', posturl);
            // request.send(search);

            // console.info(222)
            // console.info(evs.urlWithParams(evs.URL,reqGetArgs).replace('https://','http://'))

            request.open('GET', evs.urlWithParams(evs.URL,reqGetArgs).replace('https://','http://'));
            request.send();
        };

        EventSource.prototype.XHR.prototype = {

            useXDomainRequest: true,

            _request: null,

            _ready: false, // true when progress events are dispatched

            _loaded: false, // true when request has been loaded

            _failed: false, // true if when request is in error

            isReady: function() {

                return this._request._ready;
            },

            isDone: function() {

                return this._request._loaded;
            },

            hasError: function() {

                return this._request._failed;
            },

            getBuffer: function() {

                var rv = '';
                try {
                    rv = this._request.responseText || '';
                }
                catch (e){}
                return rv;
            },

            abort: function() {

                if ( this._request){
                    this._request.abort();
                }
            }
        };
    }

    function MessageEvent(type, data, origin, lastEventId) {

        this.bubbles = false;
        this.cancelBubble = false;
        this.cancelable = false;
        this.data = data || null;
        this.origin = origin || '';
        this.lastEventId = lastEventId || '';
        this.type = type || 'message';
    }

    function isOldIE () {

        //return true if we are in IE8 or IE9
        return (window.XDomainRequest && (window.XMLHttpRequest && new XMLHttpRequest().responseType === undefined)) ? true : false;
    }

    global[evsImportName] = EventSource;
})(window);

/***/ }),

/***/ "./src/modules/old_fullscreen/img/fall.png":
/*!*************************************************!*\
  !*** ./src/modules/old_fullscreen/img/fall.png ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAALCAYAAABcUvyWAAAAX0lEQVQYlb3KsQ3CMAAF0YflUTwEDVTsESS3DBAmgMYDMI3noA0DkAmsFHHhhparTv/+wesCMx527ngGP/hXOCENW8I54og8hIx3QEEdQkUJaJjwxYorWuyvD27dF9gASI4O9LCYPTsAAAAASUVORK5CYII="

/***/ }),

/***/ "./src/modules/old_fullscreen/img/rise.png":
/*!*************************************************!*\
  !*** ./src/modules/old_fullscreen/img/rise.png ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAALCAYAAABcUvyWAAAAVklEQVQYlb3Nuw2DUBhD4S//HlmMNcg6tBmDhirMwAxhBFNweTRpY+nIll34Eae65m+QnWf4hrVlQoUxpDGGEvpbefAqzBiuKwM+hQnLbVgwlR/6x7AB78skgFcaQ/AAAAAASUVORK5CYII="

/***/ }),

/***/ "./src/modules/old_fullscreen/tools/random.js":
/*!****************************************************!*\
  !*** ./src/modules/old_fullscreen/tools/random.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {


//生成1-99的随机数
module.exports = function () {
    var getParam = function (name) {
        var urlpara = location.search;
        var par = {};
        if (urlpara != "") {
            urlpara = urlpara.substring(1, urlpara.length);
            var para = urlpara.split("&");
            var parname;
            var parvalue;
            for (var i = 0; i < para.length; i++) {
                parname = para[i].substring(0, para[i].indexOf("="));
                parvalue = para[i].substring(para[i].indexOf("=") + 1, para[i].length);
                par[parname] = parvalue;
            }
        }
        if (typeof (par[name]) != "undefined") {
            return par[name];
        } else {
            return null;
        }
    };

    if(getParam('num')) {
        return getParam('num');
    }else {
        return Math.floor(Math.random()*100+1)
    }


    
}

/***/ }),

/***/ "./src/modules/old_fullscreen/tools/url.js":
/*!*************************************************!*\
  !*** ./src/modules/old_fullscreen/tools/url.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var changeNum = __webpack_require__(/*! ./random */ "./src/modules/old_fullscreen/tools/random.js");

module.exports = {

    get_url: function () {
        var str = '';
        //测试环境 "http://61.152.230.153:38619/"
        str = "https://" + changeNum() + ".push2.eastmoney.com/";
        return str;
    },
    get_Hisurl: function () {
        var str = '';
        str = "http://" + changeNum() +".push2his.eastmoney.com/";
        return str;

    }
}

/***/ }),

/***/ "./src/modules/old_fullscreen/us.js":
/*!******************************************!*\
  !*** ./src/modules/old_fullscreen/us.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// require("../style/reset.less");
// require("../style/head.less");
// require("../style/right-us.less");

//require('eventsource-polyfill');
__webpack_require__(/*! ./ie_sse_polyfill */ "./src/modules/old_fullscreen/ie_sse_polyfill.js");


var main = __webpack_require__(/*! ./us/main.html */ "./src/modules/old_fullscreen/us/main.html");
var right = __webpack_require__(/*! ./us/right.html */ "./src/modules/old_fullscreen/us/right.html");

var uri = __webpack_require__(/*! ./common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var renderBlock = __webpack_require__(/*! ./common/renderBlock */ "./src/modules/old_fullscreen/common/renderBlock.js");

var config = __webpack_require__(/*! ./us/config */ "./src/modules/old_fullscreen/us/config.js");

var addEvent = __webpack_require__(/*! ./aindex/addEvent */ "./src/modules/old_fullscreen/aindex/addEvent.js");
var chartManager = __webpack_require__(/*! ./chart/index */ "./src/modules/old_fullscreen/chart/index.js");

var getdata = __webpack_require__(/*! ./us/getdata */ "./src/modules/old_fullscreen/us/getdata/index.js");

module.exports = function(){
    $(".main").html(main);
    $(".righ").html(right);


    renderBlock(config.head);
    var pars = uri.getParams();
    getdata(pars)


    var ctm = new chartManager(pars);
    addEvent(ctm, pars);



    // console.log('美股');

    //右侧
    var h = window.innerHeight;
    // console.log('h', h) 
    if (h <= 938) {
        //增加滚动条
        $(".jdzf").hide();

        var hei = (h - 150) + 'px';
        $(".fscj").css('height', hei);
        $(".fscj").css('overflow', 'auto');

    } 
}



/***/ }),

/***/ "./src/modules/old_fullscreen/us/config.js":
/*!*************************************************!*\
  !*** ./src/modules/old_fullscreen/us/config.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var fomrat = __webpack_require__(/*! ../common/format */ "./src/modules/old_fullscreen/common/format.js");
var geturl = __webpack_require__(/*! ../tools/url */ "./src/modules/old_fullscreen/tools/url.js");

module.exports = {
    host: geturl.get_url(),
    head: [
        [
            {
                name: "今开：",
                cls: "jk",
                color: "zs"
            },
            {
                name: "昨收：",
                cls: "zs",
                color: "zs"
            }
        ],
        [
            {
                name: "最高：",
                cls: "zg",
                color: "zs"
            },
            {
                name: "最低：",
                cls: "zd",
                color: "zs"
            }
        ],
        [
            {
                name: "成交量：",
                cls: "cjl",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "成交额：",
                cls: "cje",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "内盘：",
                cls: "np",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "外盘：",
                cls: "wp",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "总市值：",
                cls: "zsz",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "总股本：",
                cls: "zgb",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "换手：",
                sub: "%",
                cls: "hs",
            },
            {
                name: "振幅：",
                sub: "%",
                cls: "zf",
            }
        ],
        [
            {
                name: "市盈率：",             
                cls: "syl",
            },
            {
                name: "股息率：",
                cls: "gxl",
            }
        ],
        [
            {
                name: "每股收益：",
                cls: "mgsy",
            },
            {
                name: "每股净资产：",
                cls: "mgjzc",
            }
        ],
    ]


};

/***/ }),

/***/ "./src/modules/old_fullscreen/us/getdata/getBaseData.js":
/*!**************************************************************!*\
  !*** ./src/modules/old_fullscreen/us/getdata/getBaseData.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var merge = _.merge;

var renderHead = __webpack_require__(/*! ../../common/renderHead */ "./src/modules/old_fullscreen/common/renderHead.js");
var uri = __webpack_require__(/*! ../../common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var config = __webpack_require__(/*! ../config */ "./src/modules/old_fullscreen/us/config.js");

// var renderJdzf = require("./renderJdzf");
// var renderZjl = require("./renderZjl");

function data(par) {
    this.par = par;
    this.publicData = {};

    this.getData();
    this.getSSEData();
}

data.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58,106,108],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85],       // 基础字段
        [116, 84, 109, 126, 55, 92, 105,62],     
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 164],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                that.format(obj.data);
            }

        }
    });

}


data.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58,106,108],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85],       // 基础字段
        [116, 84, 109, 126, 55, 92, 105,62],     
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 164],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = config.host + "api/qt/stock/sse?" + uri.parStringify(data);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data);
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }
    

}


data.prototype.format = function (d) {
    var pdata = this.publicData;


    var oldo = this.o || {};       // 旧的对象

    var o = {};

    var f = oldo.f || Math.pow(10, d.f59) || 1;
    var f59 = oldo.f59 || d.f59;
    if (f59 < 2) {
        f59 = 2;
    }
    o.f59 = f59;
    o.f = f;

    if (d.f85) {
        o.ltg = d.f85;  // 流通股
    }



    if (d.f58) {
        o.name = d.f58;
    }
    if (d.f57) {
        o.code = d.f57;
    }


    if (d.f43) {
        o.xj = (d.f43 / f).toFixed(f59) || "-";
    }
    if (d.f46) {
        o.jk = (d.f46 / f).toFixed(f59) || "-";
    }
    if (d.f60) {
        o.zs = (d.f60 / f).toFixed(f59);
    }
    if (d.f44) {
        o.zg = (d.f44 / f).toFixed(f59) || "-";
    }
    if (d.f45) {
        o.zd = (d.f45 / f).toFixed(f59) || "-";
    }
    if (d.f43) {
        var zs = (oldo.zs || d.f60 / f);
        o.zde = (d.f43 / f - zs).toFixed(f59);
        o.zdf = ((d.f43 / f - zs) / zs * 100).toFixed(f59);
    }
    // if ((oldo.ltg || d.f85) && d.f47) {
    //     var ltg = oldo.ltg || d.f85;
    //     o.hs = ((d.f47 / ltg) * 100).toFixed(f59);
    // }
    if (d.f106) {
        o.f106 = d.f106;
    }
    if ((oldo.ltg || d.f85) && d.f47) {
        var ltg = oldo.ltg || d.f85;
        var f106 = oldo.f106 || d.f106;
        o.hs = ((d.f47 / ltg * f106) * 100).toFixed(f59);
    }
    if (d.f44 || d.f45) {
        var zg = d.f44 / f || oldo.zg;
        var zd = d.f45 / f || oldo.zd;
        var zs = oldo.zs || d.f60 / f;
        o.zf = ((zg - zd) / zs * 100).toFixed(f59);
    }
    if (d.f47) {
        o.cjl = d.f47;
    }
    if (d.f48) {
        o.cje = d.f48;
    }
    if (d.f49) {
        o.wp = d.f49;
        o.np = (oldo.cjl || d.f47) - d.f49;
    }
    if (d.f113) {
        o.szjs = d.f113;
    }
    if (d.f114) {
        o.xdjs = d.f114;
    }
    if (d.f115) {
        o.ppjs = d.f115;
    }
    if (d.f117) {
        o.lz = d.f117;
    }
    if(d.f116){
        o.zsz = d.f116;
    }
    if(d.f84){
        o.zgb = d.f84;
    }

    o.jdzf = {};
    if (d.f119) {
        o.jdzf.day5 = d.f119 / 100;
    }
    if (d.f120) {
        o.jdzf.day20 = d.f120 / 100;
    }
    if (d.f121) {
        o.jdzf.day60 = d.f121 / 100;
    }
    if (d.f122) {
        o.jdzf.dayyear = d.f122 / 100;
    }


    o.zjl = {}
    // 其他 4个
    if (d.f135 || d.f136 || d.f137) {
        o.zjl.zl = [d.f135, d.f136, d.f137];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.cd = [d.f138, d.f139, d.f140];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.dd = [d.f141, d.f142, d.f143];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.zd = [d.f144, d.f145, d.f146];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.xd = [d.f147, d.f148, d.f149];
    }


    if (d.f55) {
        o.mgsy = (d.f55).toFixed(f59)
    }
    if (d.f92) {
        o.mgjzc = (d.f92).toFixed(f59);
    }
    if (d.f126) {
        o.gxl = d.f126;
    }
    // if (d.f109) {
    //     o.syl = (d.f116 / d.f109).toFixed(f59)
    // }

    if (d.f105) {
        o.jlr = d.f105;
    }
    // 财报季度
    if (d.f62) {
        o.cbjd = d.f62;
    }
    
    // 静态市盈率
    // if (d.f109 || d.f116) {
    //     var zsz = oldo.zsz || d.f116;
    //     if (d.f109) {
    //         o.syl = (zsz / d.f116).toFixed(f59);
    //     } else {
    //         o.syl = "-";
    //     }
    // }

    // 动态市盈率
    // if (d.f116 || d.f105 || d.f62) {
    //     var zsz = d.f116 || oldo.zsz;
    //     var jlr = d.f105 || oldo.f105 || 0;
    //     var cbjd = d.f62 || oldo.cbjd;
    //     o.syl = (zsz / jlr * cbjd / 4).toFixed(f59);
    // }
    
    // 市盈率ttm
    // if (d.f43 || d.f60 || d.f108) {
    //     var xj = d.f43 / f || oldo.xj;
    //     var zs = d.f60 / f || oldo.zs;
    //     var mgsyttm = d.f108 || oldo.mgsyttm;

    //     var chu = xj || zs;
    //     if (mgsyttm) {
    //         o.syl = (chu / mgsyttm).toFixed(f59);
    //     } else {
    //         o.syl = "-";
    //     }
    // }

    //修改市盈率
    if (d.f164) {
        var shiyinglv = (d.f164 / f).toFixed(f59);
        if( shiyinglv >= 0 ) {
            o.syl = shiyinglv;
        }else if( shiyinglv < 0 ) {
            o.syl = "亏损";
        }
    }



    this.o = merge(oldo, o);

    this.render(o);

}


data.prototype.render = function (obj) {

    
    if (obj.zde) {
        $(".head .zde").text(obj.zde)
    }
    
    obj.zs = this.o.zs;

    renderHead(config.head, obj);


}

module.exports = data;

/***/ }),

/***/ "./src/modules/old_fullscreen/us/getdata/getFscj.js":
/*!**********************************************************!*\
  !*** ./src/modules/old_fullscreen/us/getdata/getFscj.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var renderFscj = __webpack_require__(/*! ./renderFscj */ "./src/modules/old_fullscreen/us/getdata/renderFscj.js");
var uri = __webpack_require__(/*! ../../common/uri */ "./src/modules/old_fullscreen/common/uri.js");
var config = __webpack_require__(/*! ../config */ "./src/modules/old_fullscreen/us/config.js");



function fscj(par) {
    this.par = par;

    this.fscj = new renderFscj();

    this.getData();
    // this.getSSEData();
}

fscj.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields1: "f1,f2,f3,f4",
        fields2: "f51,f52,f53,f54,f55",
        secid: par.market + "." + par.code,
        pos: '-30'
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/details/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb'
    })
    .then(function (msg) {
        var obj = msg;
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    })
    .always(function(){
        // console.info(2222)
        that.getSSEData();
    })

}

fscj.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields1: "f1,f2,f3,f4",
        fields2: "f51,f52,f53,f54,f55",
        secid: par.market + "." + par.code,
        pos: '-30'
    }

    var fullurl = config.host + "api/qt/stock/details/sse?" + uri.parStringify(data);

   this.fscj.clear();
    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }

}


fscj.prototype.format = function(data){
    this.fscj.setData(data)
}


module.exports = fscj;



/***/ }),

/***/ "./src/modules/old_fullscreen/us/getdata/index.js":
/*!********************************************************!*\
  !*** ./src/modules/old_fullscreen/us/getdata/index.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getBaseData = __webpack_require__(/*! ./getBaseData */ "./src/modules/old_fullscreen/us/getdata/getBaseData.js");
var getFscj = __webpack_require__(/*! ./getFscj */ "./src/modules/old_fullscreen/us/getdata/getFscj.js");

module.exports = function(par){

    new getBaseData(par);
    new getFscj(par);

};

/***/ }),

/***/ "./src/modules/old_fullscreen/us/getdata/renderFscj.js":
/*!*************************************************************!*\
  !*** ./src/modules/old_fullscreen/us/getdata/renderFscj.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var fall = __webpack_require__(/*! ../../img/fall.png */ "./src/modules/old_fullscreen/img/fall.png");
var rise = __webpack_require__(/*! ../../img/rise.png */ "./src/modules/old_fullscreen/img/rise.png");


function fscj() {
    this.count = 30;
    
}

fscj.prototype.clear = function() {
    this.list = []
}


fscj.prototype.setData = function (data) {
    if (data.prePrice) {
        this.prePrice = data.prePrice;
    }
    var list = this.list || [];

    var details = data.details;
    
    this.list = list.concat(details);
    if (this.list.length > this.count) {
        this.list.splice(0, this.list.length - this.count)//splice待考证，slice
    }

    this.render();
}



fscj.prototype.render = function () {

    var details = this.list;
    var prePrice = this.prePrice;

    var tbody = $(".fscj tbody").html("");
    
    for (var i = details.length - 1; i >= 0; i--) {
        var ar = details[i].split(",");

        var tr = $("<tr></tr>");
        var td1 = $("<td></td>").text(ar[0]);
        var td2 = $("<td></td>").text(ar[1]);


        if (ar[1] > prePrice) {
            td2.addClass("rise");
        } else if (ar[1] < prePrice) {
            td2.addClass("fall");
        }
        var td3 = $("<td></td>");

        // console.log(ar[1])
        // console.log(ar[2])
        if(ar[4] == 2 && ar[1]*ar[2] > 20*10000) {
            td3.addClass("zi")
        } else  if(ar[4] == 1 && ar[1]*ar[2] > 20*10000) {
            td3.addClass("qing")
        } else {
            if (ar[4] == 2) {
                td3.addClass("rise");
            } else if (ar[4] == 1) {
                td3.addClass("fall");
            } else {
                td3.addClass("rise");
            }

        }

        
        var span = $("<span></span>").text(ar[2]);
        var img = $("<img/>")
        if (ar[4] == 2) {
            img.attr("src", rise);
        } else if (ar[4] == 1){
            img.attr("src", fall);
        } else {
            img.attr("src", '');
        }
        span.append(img);
        td3.append(span);

        tr.append(td1, td2, td3);

        tbody.append(tr);
    }
}


module.exports = fscj;

/***/ }),

/***/ "./src/modules/old_fullscreen/us/main.html":
/*!*************************************************!*\
  !*** ./src/modules/old_fullscreen/us/main.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"switchbar\">\r\n    <ul>\r\n        <li class=\"active\" data-type=\"r\">\r\n            <span>分时</span>\r\n        </li>\r\n        <li data-type=\"k\">\r\n            <span>日K</span>\r\n        </li>\r\n        <li data-type=\"wk\">\r\n            <span>周K</span>\r\n        </li>\r\n        <li data-type=\"mk\">\r\n            <span>月K</span>\r\n        </li>\r\n    </ul>\r\n</div>\r\n<div class=\"chart\">\r\n    <div class=\"chart-box\"></div>\r\n</div>"

/***/ }),

/***/ "./src/modules/old_fullscreen/us/right.html":
/*!**************************************************!*\
  !*** ./src/modules/old_fullscreen/us/right.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n<!-- 分时成交 -->\r\n<p class=\"ftitle2\">分时成交</p>\r\n<div class=\"ming\"><span class=\"fri\">时间</span><span class=\"sec\">价格</span><span class=\"tir\">成交量</span></div>\r\n<div class=\"fscj\">\r\n    <!-- <p class=\"ftitle\">分时成交</p> -->\r\n    <table>\r\n        <!-- <thead>\r\n            <tr>\r\n                <td>时间</td>\r\n                <td>价格</td>\r\n                <td>成交量</td>\r\n            </tr>\r\n        </thead> -->\r\n        <tbody></tbody>\r\n    </table>\r\n</div>"

/***/ }),

/***/ "./src/modules/old_fullscreen/user/index.js":
/*!**************************************************!*\
  !*** ./src/modules/old_fullscreen/user/index.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * 用户信息
 */

var cookie = __webpack_require__(/*! ../cookie/ */ "./src/modules/old_fullscreen/cookie/index.js");

/**
 * 用户
 */
var user = {
    /**
     * 获取用户信息
     */
    get: function(){
        if (cookie.get('ut') && cookie.get('ct') && cookie.get('uidal')) {
            
            //获取加v信息
            var jiav = {vtype:null, state: null, name: ''};
            if (cookie.get('vtpst') && cookie.get('vtpst') != '|') {
                var jiavarr = cookie.get('vtpst').split('|');
                if( jiavarr.length > 1 ){
                    //console.info(typeof jiavarr[0]);
                    if (jiavarr[1] == "0" || jiavarr[1] == "3") {
                        switch (jiavarr[0]) {
                            case "301":
                                jiav.vtype = 1;
                                jiav.name = '理财师';
                                break;
                            case "302":
                                jiav.vtype = 2;
                                jiav.name = '非理财师';
                                break;
                            case "303":
                                jiav.vtype = 3;
                                jiav.name = '企业';
                                break;
                            default:
                                break;
                        }
                    }

                    switch (jiavarr[1]) {
                        case "0":
                            jiav.state = 0; //审核通过
                            break;                        
                        case "1":
                            jiav.state = 11; //审核未通过
                            break;
                        case "2":
                            jiav.state = 12; //审核中
                            break;
                        case "3":
                            jiav.state = 13; //加v用户修改审核
                            break;
                        case "8":
                            jiav.state = 18; //加v用户修改审核
                            break;
                        case "9":
                            jiav.state = 19; //加v用户修改审核
                            break;
                        default:
                            break;
                    }
                    
                    //console.info(jiav);

                }
            }
            
            return {
              id: cookie.get('uidal').substring(0,16),
              nick: cookie.get('uidal').substring(16),
              jiav: jiav
            };
        }
        return null; 
    },
    /**
     * 退出登录
     * @param  {function} 退出之后回调
     */
    logOut: function (callback) {
        var date = new Date();
        document.cookie = "pi=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "ct=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "ut=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "uidal=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        if (callback) {
            callback();
        }
    },
    isLogin: function (){
        if( this.get() ){
            return true;
        }
        else{
            return false;
        }
    }
};

module.exports = user;





/***/ })

/******/ });
//# sourceMappingURL=fullscreen_full.js.map