
var gdomain = "http://hqdigi2.eastmoney.com/EM_Quote2010NumericApplication/";
var PicK = "http://hqpick.eastmoney.com/k/";
// var PicN = "//pifm.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx?id={0}{1}&imageType={2}&token=44c9d251add88e27b65ed86506f6e5da";
var PicN = "//webquotepic.eastmoney.com/GetPic.aspx?id={0}{1}&imageType={2}&token=44c9d251add88e27b65ed86506f6e5da";
var token = "4f1862fc3b5e77c150a2b985b12db0fd";
var zxrc = 0; //未登陆用户自选不自刷
var isAbroadIp = false; //是否是国外ip

var commonApi = "//push2.eastmoney.com/"; //行情接口通用域名
var tsApi = "//" + (Math.floor(Math.random() * 99) + 1) + ".push2.eastmoney.com/"; //行情接口推送域名
/**
 * 获取url参数
 * @param {string} variable 参数名
 */
function getQueryString(variable) {
    try {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == variable) {
                return pair[1];
            }
        }
        return false;
    } catch (error) {
        return false;
    }
}

if (getQueryString("hq-env") === "test") {
    commonApi = "http://61.129.249.233:18665/";
    tsApi = "http://61.129.249.233:18665/";
}


var $x = function (id) { return "string" == typeof id ? document.getElementById(id) : id; };
function inArray(el, array) { for (var i = 0, n = array.length; i < n; i++) { if (array[i] === el) { return true; } } return false; }
function unique(array) { var i = 0, n = array.length, ret = []; for (; i < n; i++) { if (!inArray(array[i], ret)) { ret.push(array[i]); } } return ret; }
function ForDight(Dight, How) { rDight = parseFloat(Dight).toFixed(How); if (rDight == "NaN") { rDight = "--"; } return rDight; }
//显示完整时间
function GetFullWeekTime(time) {
    var dt = new Date(Date.parse(time.replace(/-/g, "/")));
    var day = dt.getDay();
    var arr_week = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");
    var week = arr_week[day];
    return time.replace(" ", " " + week + " ");
}
//刷新本页
function prefresh() {
    window.location.reload();
}
//新版闪烁
function blinker(num,dom) {
    if(num>0){
        dom.addClass('blinkred');
        setTimeout(function(){
           dom.removeClass('blinkred')
        }, 500);
    }else if(num<0){
        dom.addClass('blinkgreen');
        setTimeout(function(){
           dom.removeClass('blinkgreen')
        }, 500);
    }else{
        dom.addClass('blinkblue');
        setTimeout(function(){
           dom.removeClass('blinkblue')
        }, 500);
    }
    
}

//涨跌标记
function udt(vs) {
    if (vs > 0) {
        return "↑";
    } else if (vs < 0) {
        return "↓";
    } else { return ""; }
}

//涨跌颜色
function udcls(vsa, vsb) {
    // vsa = String(vsa).replace("%", "");
    // console.log(vsa)
    // console.log(vsb)
    if (arguments.length == 1) {
        if (vsa > 0) { return "red"; } else if (vsa < 0) { return "green"; } else { return ""; }
    } else {
        // vsb = vsb.replace("%", "");
        
        if (vsa - vsb > 0) {
            return "red";
        } else if (vsa - vsb < 0) {
            return "green";
        } else {
            return "";
        }
    }
}

//涨跌颜色
function udc(vsa, vsb) {
    vsa = vsa.replace("%", "");
    if (vsb == "" || vsb == null || vsb == "undefined") {
        if (vsa > 0) {
            return "#f00";
        } else if (vsa < 0) {
            return "#090";
        } else {
            return "";
        }
    } else {
        vsb = vsb.replace("%", "");
        if (vsa - vsb > 0) {
            return "#f00";
        } else if (vsa - vsb < 0) {
            return "#090";
        } else {
            return "";
        }
    }
}

//添加百分号
function addPercent(vs) {
    var num = parseFloat(vs), item;
    if (num == 0) {
        item = num.toFixed(2) + "%"
    } else if (num) {
        var abs = Math.abs(num);
        if (abs >= 1000) { //大于10倍的用倍来表示 1000%
            item = (num / 1000).toFixed(2) + "倍"
        } else {
            item = num.toFixed(2) + "%";
        }
    } else {
        item = vs;
    }
    return item
}

// 大额现价处理
function bigPriceFun(vs) {
    var num = parseFloat(vs), item;
    if (num >= 0) {
        if (num >= 10000) {
            item = (num / 10000).toFixed(2) + "万"
        } else {
            item = num.toFixed(2);
        }
    } else {
        item = vs
    }
    return item;
}

//涨跌颜色
function udcolor(vsa, vsb) {
    vsa = vsa.replace("%", "");
    if (vsb == "" || vsb == null || vsb == "undefined") {
        if (vsa > 0) {
            return "color:#f00";
        } else if (vsa < 0) {
            return "color:#090";
        } else {
            return "";
        }
    } else {
        vsb = vsb.replace("%", "");
        if (vsa - vsb > 0) {
            return "color:#f00";
        } else if (vsa - vsb < 0) {
            return "color:#090";
        } else {
            return "";
        }
    }
}

//涨跌平判断
function zdp(Pnum) {
    if (Pnum > 0) {
        return 1;
    } else if (Pnum < 0) {
        return -1;
    } else {
        return 0;
    }
}

//增减标记
function fvc(vs) {
    if (vs == 0 || vs == "") {
        return "";
    } else {
        if (vs > 0) {
            return "+" + vs;
        } else {
            return vs;
        }
    }
}

//数字格式化
function ForDight(Dight, How) {
    rDight = parseFloat(Dight).toFixed(How);
    if (rDight == "NaN") {
        rDight = "--";
    }
    return rDight;
}

//数字格式化
function ForWc(Di) {
    var chu = 1;
    var res = Di;
    if (Di > 0 && Di.length >= 6) {
        chu = 6;
    } if (Di < 0 && Di.length >= 7) {
        chu = 6;
    } if (chu == 6) {
        res = ForDight((Di / 10000), 2) + "万";
    }
    return res;
}

//获取市场
function getmarket(cd) {
    var j = cd.substring(0, 3);
    var i = j.substring(0, 1);
    if (i == "5" || i == "6" || i == "9") {
        return "1";
    } else {
        if (j == "009" || j == "126" || j == "110") {
            return "1";
        } else {
            return "2";
        }
    }
}

//写cookies
function WriteCookie(name, value, hours) {
    var expire = "";
    if (hours != null) {
        expire = new Date((new Date()).getTime() + hours * 3600000);
        expire = "; expires=" + expire.toGMTString() + ";path=/;domain=.eastmoney.com";
    }
    document.cookie = name + "=" + escape(value) + expire;
}
//取cookies
function GetCookie(name) {
    var dc = document.cookie;
    var prefix = name + "=";
    var begin = dc.indexOf("; " + prefix);
    if (begin == -1) {
        begin = dc.indexOf(prefix);
        if (begin != 0) {
            return null;
        };
    } else {
        begin += 2;
    }
    var end = document.cookie.indexOf(";", begin);
    if (end == -1) {
        end = dc.length;
    }
    return decodeURI(dc.substring(begin + prefix.length, end));
}

function Getcks(key) {
    var result = document.cookie.match(new RegExp(key + "=([^;]*)"));
    return result != null ? unescape(decodeURI(result[1])) : null;
}

//拉长缩短K线
function picklc() {
    KBd.Change('-');
}

//拉长缩短K线
function picksd() {
    KBd.Change('+');
}

/** 
* js截取字符串，中英文都能用 
* @param {string} str: 需要截取的字符串 
* @param {number} len: 需要截取的长度
* @param {string} ellipsis: 溢出文字
* @returns {string} 截取后的字符串
*/
function cutstr(str, len, ellipsis) {
    if (typeof ellipsis != "string") ellipsis = "...";
    var str_length = 0;
    var str_len = 0;
    str_cut = new String();
    if (str) {
        for (var i = 0; i < str.length; i++) {
            a = str.charAt(i);
            str_length++;
            if (escape(a).length > 4) {
                //中文字符的长度经编码之后大于4  
                str_length++;
            }
            //str_cut = str_cut.concat(a);
            if (str_length <= len) {
                str_len++;
            }
        }
        //如果给定字符串小于指定长度，则返回源字符串；  
        if (str_length <= len) {
            return str.toString();
        } else {
            return str.substr(0, str_len).concat(ellipsis);
        }
    }else{
        return ""
    }
   
}

(function () {
    var ggrlN = 0;
    var yestoday = 0;
    
    function QaDefault(Code, Market, Market_10, Name, HyId, RType, RCode, RMarket, tz, isag, lstng, cektp, ssrq, isxg, tfpxx) {
        //代码，市场_12，市场_10，名称，行业ID，关联类型，关联代码，关联市场, 通知页面刷新, 是否A股, 股票状态, 停牌检查, 上市日期, 是否新股, 停复牌信息
        _this = this; _this._Code = Code; _this._Market = Market; _this._Market_10 = Market_10; _this._Name = Name; _this._HyId = HyId;
        _this._RType = RType; _this._RCode = RCode; _this._RMarket = RMarket; _this.IsNotify = tz; _this.IsAGu = isag; _this.Lstng = lstng;
        _this.CekTp = cektp; _this.Ssrq = ssrq; _this.IsXg = isxg; _this.tfpxx = tfpxx; 
        _this.$ = function (id) { return "string" == typeof id ? document.getElementById(id) : id; };
        _this.sansuoNum = 0; _this.cbian = true; _this.sansuo; _this.tempStatus = {}; _this.ColorStatus = {};
        _this.hongdise = function () {
            var span = [_this.$("price9"), _this.$("km1"), _this.$("km2")];
            for (i = 0; i < 3; i++) {
                _this.ColorStatus[i] = (_this.ColorStatus[i]) ? false : true;
                if (_this.cbian&&span[i]) {
                    if (!_this.ColorStatus[i]) {
                        _this.tempStatus[i] = span[i].style.color; span[i].style.color = "#000000";
                    } else {
                        span[i].style.color = _this.tempStatus[i];
                    }
                }
            }
            
            _this.sansuoNum++;
            if (_this.sansuoNum > 6&&_this.$("km1")) {
                clearInterval(_this.sansuo);
                _this.sansuoNum = 0; _this.tempStatus = {}; _this.ColorStatus = {}; _this.cbian = false;
                _this.$("price9").style.color = ""; _this.$("km1").style.color = ""; _this.$("km2").style.color = "";
            }
        };
    };
    QaDefault.prototype = {
        code: "-",
        market: "-",
        init: function () {
            window.quoteIsFirst = true; window.quoteRefresh = 24000 //window.quoteRefresh = 12000;//行情
            window.zxgIsFirst = true; window.zxgRefresh = 30000; window.zxgDisNum = 9; window.favorsetInterval = 0;//自选股

            //window.quoteIsFirst = true; window.quoteRefresh = 12000;//行情
            //window.zxgIsFirst = true; window.zxgRefresh = 15000; window.zxgDisNum = 13; window.favorsetInterval = 0;//自选股

            window.GetTimeZoneInfo = false; window.phIsFirst = true;//行业排名
            _this.bindPageEvent();          
            _this.code = _this._Code;
            _this.market = _this._Market;
            //tixing("addTX1", _this._Market, _this._Code);
            // tixing("addTX2", _this._Market, _this._Code);
            //createSWF(_this._Code, _this._Market, _this._Name, 578, 276, 565, 415, "1", "0", "");
            
            //setTimeout(function () { _this.GetFavorList(_this._Code); }, 100);

            // setTimeout(_this.UpZjlx, 500); setInterval(_this.UpZjlx, 300000);//资金流向
            // _this.DISRSI(); setInterval(_this.DISRSI, 60000);//关联股票
            _this.YBCutstr();  

            // _this.Gethis(); //只渲染头部的最近访问，行情列表不加载
            var timer_history = null;
            $("#tab6 li").mouseover(function () {              
                if ($(this).find('h3').html() == "最近访问") {                    
                    if ($('#history-items tbody tr td').length < 2) {
                        //最近访问
                        _this.Gethis(true);//true是加载行情列表的
                        timer_history = setInterval(function () { _this.Gethis(true) }, 60 * 1000);
                    }
                } else {
                    if (timer_history) {
                        clearInterval(timer_history);
                        $('#history-items tbody').html("");
                    }      
                }
            })
            //setInterval(function () {              
            //    _this.Gethis()               
            //}, 30*1000);

            //加自选
             _this.GetFavorList()


            
          


            //百度隐藏广告
            if (_this.getQueryStringByName("from") == "BaiduAladdin") {
                $("#tbggiframe").hide();
                $("#ifhqheadad").hide();

                $.ajax({
                    url: "//emres.dfcfw.com/public/js/aldtg.js",
                    method: "GET",
                    scriptCharset: 'UTF-8',
                    dataType: "script"
                });

            } else {
                $.ajax({
                    url: "http://emres.dfcfw.com/public/js/left.js",
                    method: "GET",
                    scriptCharset: 'UTF-8',
                    dataType: "script"
                });

                $.ajax({
                    url: "http://hqres.eastmoney.com/emag14/js/em_news_fixed_right.js",
                    method: "GET",
                    scriptCharset: 'UTF-8',
                    dataType: "script"
                });
            }

  
        },
        stop: function () {
            clearInterval(this.quoteId);
        },

        //根据QueryString参数名称获取值
        getQueryStringByName: function (name) {
            var result = location.search.match(new RegExp("[\?\&]" + name + "=([^\&]+)", "i"));
            if (result == null || result.length < 1) {
                return "";
            }
            return result[1];
        },
        bindPageEvent: function () {//页面事件绑定
            if (_this.Lstng == "1") {
                // _this.DisQuote();
                // _this.DisQuote_sse();
                // phrankS();//行业个股排行
                // this.quoteId = setInterval(function () {
                    // _this.DisQuote();
                    //_this.GetAllPKYD();
                // }, window.quoteRefresh);
                
                // 分时成交自刷
                // this.GetFbFj(_this._Code + "" + _this._Market);
                // this.tradeId = setInterval(function () {
                //     _this.GetFbFj(_this._Code + "" + _this._Market);
                // }, window.quoteRefresh);
                // _this.GetFbFj_sse(_this._Code + "" + _this._Market);
                // setInterval(function () {
                //     phrankS();//行业个股排行
                // }, 90000);

                _this.GetTimeZone(_this._Code + "" + _this._Market);
                setInterval(function () { _this.GetTimeZone(_this._Code + "" + _this._Market); }, 60000);//时间戳
                //setInterval(function () {_this.UpPic(true);}, 180000);//更新R图和K线
            } else {
                var lststr = "";
                switch (_this.Lstng) { case "0": lststr = "未上市"; break; case "2": lststr = "已退市"; break; case "3": lststr = "暂停上市"; break; case "4": lststr = "终止上市"; break; }
                _this.$("price9").style.width = "130px";
                _this.$("price9").innerHTML = "<span class=\"lstng\">" + lststr + "</span>";
                _this.$("km1").innerHTML = ""; _this.$("km1").className = "xp3";
                _this.$("km2").innerHTML = ""; _this.$("km2").className = "xp4";
            }
            _this.$("hq_cr_close").onclick = function () { _this.$("hq_cr_tips").style.display = "none"; WriteCookie("emhq_cr", "1", 12); };
            _this.$("hq_cr_b").onmouseover = function () { _this.$("hq_cr_tips").style.display = "block"; };
            _this.$("hq_cr_b").onmouseout = function () { _this.$("hq_cr_tips").style.display = "none"; };
            //四分位属性
            this.quartile();           
       
            //个股研报
           this.stockReport();
            //行业研报
           this.hyReport();

        },
        
        testMethod: function () {
        },
        Bian: function (dt) {//是否在开盘期间
            var res = false;
            var hs = dt.getHours();
            var ms = dt.getMinutes();
            if (hs >= 9 && hs <= 11) {
                res = true;
                if ((hs == 11) && ms >= 30)
                    res = false;
            }
            if (hs >= 13 && hs < 15) { res = true; }
            return res;
        },
        PanQian: function (dt) {//是否在盘前期间
            var res = false;
            var hs = dt.getHours();
            var ms = dt.getMinutes();
            if (hs == 9) { if ((ms >= 14) && ms < 29) { res = true; } }
            return res;
        },
        setPicrTab: function (iftm) {
            var izpz = _this.Bian(iftm);
            if (izpz) {
                var res = _this.PanQian(iftm);
                if (res) {
                    if (_this.$("image_box").style.display != "none") {
                        _this.UpPic(false, true);
                    } else {
                        setTimeout(function () {
                            flyqd(8);
                        }, 5000);
                    }
                }
                else {
                    if (_this.$("image_box").style.display != "none") {
                        _this.UpPic(false, false);
                    } else {
                        setTimeout(function () {
                            flyqd(0);
                        }, 5000);
                    }
                }
            }
        },
        GetTimeZone: function (id) {//系统时间
            var ua = navigator.userAgent.toLowerCase();
            window.GetTimeZoneInfo=true;
        },
        NotifyPage: function (num) {//通知页面刷新
            window.Notifyed = true; window.NotifyS = setInterval("prefresh()", num);
        },       
        //加自选
        GetFavorList: function () {
            var iscks = true; // true是登录，false是非登录
            var url_status = "mystock_web"; //登录的            
            //判断是否登录  uidal ut ct 
            if (GetCookie("uidal") && GetCookie("ut") && GetCookie("ct") ) {
                    url_status = "mystock_web"; //已登录的                 
                    var _url = "http://myfavor1.eastmoney.com/" + url_status + "?f=gsaandcheck&sc=" + _this._Market_10 + "." + _this._Code;
                    $.ajax({
                        url: _url,
                        dataType: "jsonp",
                        jsonp: "cb",
                        success: function (json) {
                            // console.log(json,'登录后获取自选股ids')
                            var allstocklist = "";
                            if (json.result == "1") {
                                var sl = json.data.list.split(','); //已经是数组了
                                var check = json.data.check;                               
                                _this.FavorIsAdd(check, url_status);
                                if(!isAbroadIp){
                                    _this.FavorDis(sl);                                  
                                }
                            }
                        }
                    });
            } else {
                iscks = false;
            }
            if (!iscks) {
                //未登录的请求                
                url_status = "mystock_webanonym";
                var _url = "http://myfavor1.eastmoney.com/" + url_status + "?f=gsaandcheck&sc=" + _this._Market_10 + "." + _this._Code;
                $.ajax({
                    url: _url,
                    dataType: "jsonp",
                    jsonp: "cb",
                    success: function (json) {                       
                        if (json.result == "1") {                           
                            var sl = json.data.list.split(','); 
                            var check = json.data.check;                   
                            _this.FavorIsAdd(check, url_status);    
                            //未登陆用户页面打开自选股模块只会加载一次，不会自刷
                            if(zxrc === 0){                        
                                _this.FavorDis(sl);  
                            }                          
                        }
                    }
                });            
            }          
            
            _this.$("addZX1").onclick = function () {               
                _this.FavorEvent();
            };
            // _this.$("addZX2").onclick = function () {              
            //     _this.FavorEvent();
            // };
           
           
        },
         //判断是否是加自选        
        FavorIsAdd: function (check) {
            //check 是否加自选 false：删自选                     
            if (check == "True") {
                $("#addZX1_a").html("-删自选");
                $("#addZX2_a").html ( "-删自选");
                $("#addZX1_a").removeAttr("href");
                $("#addZX2_a").removeAttr("href");
                $("#addZX1").css("background", "#999");               
                $("#addZX2").css("background", "#999"); 
            } else {
               $("#addZX1_a").html( "+加自选" );
                $("#addZX2_a").html("+加自选");
                $("#addZX1").css("background", "#ff4a03");
                $("#addZX2").css("background", "#ff4a03");  
                $("#addZX1_a").attr("href", "//quote.eastmoney.com/zixuan/?from=zixuanmini"); //后期修改过来
                $("#addZX2_a").attr("href", "//quote.eastmoney.com/zixuan/?from=zixuanmini");               
            }
           
        },
        FavorEvent: function () {
            if (GetCookie("uidal") && GetCookie("ut") && GetCookie("ct")) {
                var url_status = "mystock_web"; //已登录的
            } else {
                var url_status = "mystock_webanonym"
            }
            var _html = $("#addZX1_a").html();
            if (_html == "+加自选") {
                var f = "asz";           
                var check = "True";
            } else {
                var f = "dsz";        
                var check = "False";
            }    
            var _url = "http://myfavor1.eastmoney.com/" + url_status + "?f=" + f + "&sc=" + _this._Market_10 + "." + _this._Code;
            $.ajax({
                url: _url,
                dataType: "jsonp",
                jsonp: "cb",
                success: function (json) {
                    if (json.result == "1") {
                        _this.FavorIsAdd(check);
                        _this.GetFavorList();
                    }
                }
            });
           
            
        },        

         //获取自选股行情列表
        FavorDis: function (arr) {
            // console.log('hahaaaaaaaaaaaaaa')
            // console.log(arr)
            var mathNum = Math.floor(Math.random() * 100);
            //var _url = "http://push2.eastmoney.com/api/qt/ulist.np/get?fields=f2,f3,f14,f12,f13&invt=2&fltt=2&fid=f3&ut=bd1d9ddb04089700cf9c27f6f7426281";
            var _url = commonApi + "api/qt/ulist.np/get?fields=f2,f3,f14,f12,f13&invt=2&fltt=2&fid=f3&ut=bd1d9ddb04089700cf9c27f6f7426281";
            //secids = 155.AVM, 0.300059
            var _arr = [];
            var len = arr.length >= 10 ? 10 : arr.length;
            if (arr && arr.length > 0) { //排除空数组和无用数组
                for (var i = 0; i < len; i++) {
                    if ($.trim(arr[i])) {
                        _arr.push(arr[i]);
                    }
                }
            }                      
            if (_arr && _arr.length > 0) {                         
                $.ajax({
                    url: _url,
                    data: { secids: _arr.join(",") },
                    type: "get",
                    dataType: "jsonp",
                    jsonp: "cb",
                    success: function (json) {
                        // console.log('自选股列表')
                        // console.log(json, '自选股列表');
                        // f13 市场 f12 code  f14 name f2 涨跌额 f3涨跌幅
                        if (json && json.data && json.data.diff) {
                            var obj = json.data.diff;
                            var arr = [];
                            for (var key = 0; key < obj.length;key++ ) {
                                if (obj[key]) {
                                    arr.push(obj[key])
                                }
                            }
                            //var items = arr;
                            if (arr.length > 6) {
                                var items = arr.splice(0, 6);
                                //console.log(items)
                            } else {
                                var items = arr;
                            }
                            _this.RenderFovarList(items,json.lt);
                        } 
                    }
                });
            } else {
                $("#favorTable tbody ").html('<tr><td colspan = "3" style = "height: 192px; text-align: center;" class= "waiting " > 暂无您的自选股</td ></tr >');
            }
           
        },
        RenderFovarList: function (arr,lt) {
            // console.log("自选股列表")
            // console.log(arr,"自选股列表")
            var items = arr,models =[],$html="";
             // f13 市场 f12 code  f14 name f2 涨跌额 f3涨跌幅
            for (var i = 0; i < items.length; i++) {
                var item = items[i];                
                var model = {
                    name: item.f14,
                    code: item.f12,
                    price: bigPriceFun(item.f2),
                    changePercent: addPercent(item.f3),
                    color: udcls(item.f3),
                    link: "//quote.eastmoney.com/unify/r/" + item.f13 + "." + item.f12,
                    dataSrc: "//webquotepic.eastmoney.com/GetPic.aspx?nid=" + item.f13 + "." + item.f12 + "&imageType=RJY&token=44c9d251add88e27b65ed86506f6e5da"
                };
                var _tr = _this.ImgHtml(model);
                $html += _tr;
            }
            $("#favorTable tbody").html($html);   
            zxrc++;    
            if(lt == "2"){
                isAbroadIp = true;
            }                  
        },
        ImgHtml: function (model) {
            var mathNum = Math.floor(Math.random() * 100);
            var Tr = '<tr>' +
                '<td><a title="' + model.name + '" href="' + model.link + '" target="_blank">' + cutstr(model.name,8,'..') + '<br>' + cutstr(model.code,8,'..') + '</a></td>' +
                '<td class="' + model.color + '">' + model.price + '<br>' + model.changePercent + '</td>' +
                '<td class="img-td"><a href="' + model.link + '" target="_blank" title="点击查看' + model.name + '分时图">' +
                ' <img   src="' + model.dataSrc +mathNum +'" data-src= "' + model.dataSrc + '"  >' +
                '</a ></td > ' +
                '</tr > ';
            return Tr;
        },
      


        // 最近访问和最近访问列表
        Gethis: function (status) {
            var _hismarket = "1";
            if (_this._Market_10 == "1") { _hismarket = "sh"; } else { _hismarket = "sz"; }
            var arg = { def: "", set: "a-" + _hismarket + "-" + _this._Code + "-" + _this._Name, lns: 11 };
            var HV = new HistoryViews("historyest", arg);
            // console.log(HV)           

            //var dis = $("#historyBox").css("display");
            if (status) {
                _this.HistoryList(HV);
            }
           
            //    timer = setInterval(function () { _this.HistoryList(HV); }, 30 * 1000)
            //})
            //$("#tab6 li").eq(0).mouseover(function () { 
            //    clearInterval(timer)
            //});                     
            
        },

        //最近访问列表
        HistoryList: function (hv) {
            var hvArr = hv.ret ? hv.ret : null;
            var ids = [];
            var len = hvArr.length ;
            for (var i = 0; i < len; i++) {
                var arr = hvArr[i].split('-');
                var code = "", market = "";
                if (arr[0] && arr[0] !== 'undefined') {
                    if (arr[0] === 'sh') {
                        market = "1";
                    } else if (arr[0] === 'sz') {
                        market = "0";
                    } else {
                        market = arr[0];
                    }                  
                };
                if (arr[1]) { code = arr[1] };

                ids.push(market+'.'+code);           
            }   
            // console.log(ids)        
            _this.RenderHistoryList(ids)

        },
        RenderHistoryList: function (ids) {         
            if (ids && ids.length > 0) {
                var secid = ids.join(',');
            } else {
                var secid = '';
            }
            // console.log(secid)
            // var ab = ['2', '3', '6', '7', '13', '80'];
            //var _url = '//push2.eastmoney.com/api/qt/ulist.np/get?fields=f12,f13,f14,f2,f1,f3,f152&invt=2&';
            var _url = commonApi + 'api/qt/ulist.np/get?fields=f12,f13,f14,f2,f1,f3,f152&invt=2&ut=bd1d9ddb04089700cf9c27f6f7426281';
            $.ajax({
                url: _url,
                data: { secids: secid },
                dataType: "jsonp",
                jsonp: "cb",
                success: function (json) {   
                    // console.log(json)          
                    if (json && json.data && json.data.diff && json.data.diff instanceof Array) {
                        var models = [], historyHtml = '';
                        // 最多显示6条
                        var len = json.data.diff.length > 6 ? 6 : json.length;
                        for (var i = 0; i < json.data.diff.length; i++) {
                            // if (typeof json[i] !== 'string') break;
                            var items = json.data.diff[i];
                            var model;
                            model = {
                                id: items.f13+'.'+items.f12,
                                code: items.f12,
                                market: items.f13 === '1' ? 'sh' : 'sz',
                                name: items.f14,
                                //close: items[3],
                                changePercent: typeof(items.f3) == 'number' ?addPercent(items.f3*Math.pow(10,-items.f152).toFixed(items.f152)): '-',
                                price: Number(items.f2) >= 0 ? (items.f2*Math.pow(10,-items.f1)).toFixed(items.f1) : '-',
                                // jys: items[6],
                                color: udcls(items.f3),
                                dataSrc: "//webquotepic.eastmoney.com/GetPic.aspx?nid=" + items.f13+'.'+items.f12 + "&imageType=RJY&token=44c9d251add88e27b65ed86506f6e5da"
                            }
                            // console.log(model)
                            // var link = model.market + model.code + '.html';
 
                            var link = (items.f13=='1'?'1':'0')+'.'+model.code;
                            model.link = '//quote.eastmoney.com/unify/r/' +  model.id;
                            if (i < 6) {
                                var _tr = _this.ImgHtml(model);
                                historyHtml += _tr;
                            }                          
                        }
                        $('#history-items tbody').html(historyHtml);
                    }
                }
            });
        },
        Setudclass: function (zd) {
            var hqcr = _this.$("arrowud").getAttribute("xid");
            if (zd > 0) {
                _this.$("arrowud").className = hqcr == "1" ? "cr red" : "red";
                _this.$("arrow-find").className = "xp2 up-arrow";
            } else if (zd < 0) {
                _this.$("arrowud").className = hqcr == "1" ? "cr green" : "green";
                _this.$("arrow-find").className = "xp2 down-arrow";
            } else {
                _this.$("arrowud").className = hqcr == "1" ? "cr" : "";
                _this.$("arrow-find").className = "";
            }
        },
    
        UpPic: function (refk, pq) {//更新图 (refk是否需要更新K图，是否为盘前图)
            var pqtit = _this.$("actTab4").getElementsByTagName("span");
            for (var i = 0; i < pqtit.length; i++) {
                pqtit[i].className = "";
            }
            if (pq) {
                pqtit[0].className = "cur";
                if (_this.Lstng == "0") {
                    _this.$("picr").src = "http://hqres.eastmoney.com/EMQuote_Lib/img/picrnotfund.gif";
                } else {
                    _this.$("picr").src = PicN.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "rc") + "&rt=" + formatm();
                }
            } else {
                pqtit[1].className = "cur";
                if (_this.Lstng == "0") {
                    _this.$("picr").src = "http://hqres.eastmoney.com/EMQuote_Lib/img/picrnotfund.gif";
                } else {
                    var pic_url = PicN;
                    if (Math.random() < 1) {
                        pic_url = "//webquotepic.eastmoney.com/GetPic.aspx?id={0}{1}&imageType={2}&token=44c9d251add88e27b65ed86506f6e5da";
                    }
                    if (_this.IsAGu == 1) {
                        _this.$("picr").src = pic_url.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "r") + "&rt=" + formatm();
                    } else {
                        _this.$("picr").src = PicN.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "rc") + "&rt=" + formatm();
                    }
                }
            }
            if (refk) {
                if (_this.Lstng == "0") {
                    _this.$("pick").src = "http://hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif?1";
                } else {
                    if (_this.CekNSSs()) {
                        _this.$("pick").src = "http://hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif?2";
                    } else {
                        _this.$("pick").src = PicN.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "KXL") + "&rt=" + formatm();
                    }
                }
            }
        },
        CekNSSs: function () {
            var res = false;
            var dt = new Date(window["bjTime"] * 1000);
            var ys = dt.getFullYear(); var ms = dt.getMonth() + 1; var ds = dt.getDate();
            var hs = dt.getHours(); var mms = dt.getMinutes();
            if (_this.Ssrq != "") {
                var _dt = new Date(_this.Ssrq);
                var _ys = _dt.getFullYear(); var _ms = _dt.getMonth() + 1; var _ds = _dt.getDate();
                if (ys == _ys && ms == _ms && ds == _ds) {
                    if (hs < 9 || (hs == 9 && mms < 28)) { res = true; }
                }
            } else {
                if (hs < 9 || (hs == 9 && mms < 28)) { res = true; }
            }
            return res;
        },
        DisTfpxx: function () {
            var __dt = new Date(window["bjTime"] * 1000);
            var __hs = __dt.getHours(); var __mms = __dt.getMinutes();
            if (__hs < 9 || (__hs <= 9 && __mms <= 14)) {
                _this.$("price9").innerHTML = "<span class=\"lstng\"><a href=\"http://data.eastmoney.com/tfpxx/\" target=\"_blank\" class=\"red tp\">停牌</a></span>";
                _this.$("arrow-find").className = "";
                _this.$("km1").innerHTML = ""; _this.$("km1").className = "xp3";
                _this.$("km2").innerHTML = ""; _this.$("km2").className = "xp4";
            }
        },
        hqcr: function (hq_cr_type, _hq_cr_time, hq_cr_cnt) {
            var hq_cr_time = _hq_cr_time.length > 5 ? _hq_cr_time.substring(16, 11) : "-";
            if (hq_cr_type == "8" || hq_cr_type == "9" || hq_cr_type == "10" || hq_cr_type == "11") {
                _this.$("hq_cr").style.display = "block";
                //_this.$("hq_cr_time").innerHTML = hq_cr_time == "-" ? "暂停交易" : "暂停交易至" + hq_cr_time;
                if (hq_cr_type == "8" || hq_cr_type == "10") { _this.$("hq_cr_time").innerHTML = "暂停交易15分钟"; } else { _this.$("hq_cr_time").innerHTML = "暂停交易至15:00"; }
                _this.$("arrowud").setAttribute("xid", "1");
                switch (hq_cr_type) {
                    case "8": _this.$("hq_cr_type").innerHTML = "5%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgr"; break;
                    case "9": _this.$("hq_cr_type").innerHTML = "7%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgr"; break;
                    case "10": _this.$("hq_cr_type").innerHTML = "-5%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgg"; break;
                    case "11": _this.$("hq_cr_type").innerHTML = "-7%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgg"; break;
                }
                var _rdContent = "";
                switch (hq_cr_cnt.toLowerCase()) {
                    case "aa1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "aa2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "aa3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，于9：30起暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "aa4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，于9：30起暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ab1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ab2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ab3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ab4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ad1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ad2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ad3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ad4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ba1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ba2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ba3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ba4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "bb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "bb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易至14：57。熔断期间您可以继续申报，也可以撤销申报。熔断结束后进入3分钟的尾盘集合竞价。";
                        break;
                    case "bc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易至14：57。熔断期间您可以继续申报，也可以撤销申报。熔断结束后进入3分钟的尾盘集合竞价。";
                        break;
                    case "bc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "be1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "be2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "be3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "be4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ca1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "ca2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "ca3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "ca4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间（熔断发生在11:15-11:18之间，下午开盘直接进入3分钟集合竞价），期间接受指令申报和撤销。";
                        break;
                    case "cb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间（熔断发生在11:15-11:18之间，下午开盘直接进入3分钟集合竞价），期间接受指令申报和撤销。";
                        break;
                    case "cb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定相关合约收市前15分钟内触发5%阈值，暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定相关合约收市前15分钟内触发5%阈值，暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "taa1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "taa2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "taa3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "taa4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tab1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tab2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tab3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tab4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tba1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tba2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tba3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tba4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tbb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tbb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tca1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tca2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tca3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tca4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tcb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tcb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tcb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tcb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tcc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tcc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tcc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tcc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                }
                var cookies_cr = GetCookie("emhq_cr");
                _this.$("hq_cr_cnt").innerHTML = _rdContent;
                if (_rdContent == "") { _this.$("hq_cr_tips").style.display = "none"; _this.$("hq_cr_b").style.display = "none"; }
                if ((cookies_cr == "" || cookies_cr == null) && _rdContent != "") { _this.$("hq_cr_tips").style.display = "block"; _this.$("hq_cr_b").style.display = "block"; }
            } else {
                _this.$("hq_cr").style.display = "none"; _this.$("hq_cr_type").className = "hq_cr_a"; _this.$("arrowud").setAttribute("xid", "0"); _this.$("arrowud").className = _this.$("arrowud").className.replace("cr", "");
            }
        },
        CheckBeforeNine: function () {
            var res = false;
            var __dt = new Date(window["bjTime"] * 1000);
            var __hs = __dt.getHours(); var __mms = __dt.getMinutes();
            if (__hs < 8 && __hs < 9) {
                res = true;
            }
            return res;
        },
        formateDate: function (date, fmt) {
            fmt = fmt || "yyyy-MM-dd HH:mm:ss"
            if (typeof date === "string")
                date = new Date(date.replace(/-/g, '/').replace('T', ' ').split('+')[0]);
            var o = {
                "M+": date.getMonth() + 1, //月份         
                "d+": date.getDate(), //日         
                "h+": date.getHours() % 12 == 0 ? 12 : date.getHours() % 12, //小时         
                "H+": date.getHours(), //小时         
                "m+": date.getMinutes(), //分         
                "s+": date.getSeconds(), //秒         
                "q+": Math.floor((date.getMonth() + 3) / 3), //季度         
                "S": date.getMilliseconds() //毫秒         
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[date.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        },
        //个股研报和行业研报的字数截断，js控制
        YBCutstr: function () {
            var $ggybTr = $('#ggybTable tr');
            var tr1_td0 = $ggybTr.eq(1).find('td:eq(0) a');
            var tr1_td1 = $ggybTr.eq(1).find('td:eq(1) span');

            var tr2_td0 = $ggybTr.eq(2).find('td:eq(0) a');
            var tr2_td1 = $ggybTr.eq(2).find('td:eq(1) span');

            var tr3_td0 = $ggybTr.eq(3).find('td:eq(0) a');
            var tr3_td1 = $ggybTr.eq(3).find('td:eq(1) span');

            var tr4_td0 = $ggybTr.eq(4).find('td:eq(0) a');
            var tr4_td1 = $ggybTr.eq(4).find('td:eq(1) span');

            var tr5_td0 = $ggybTr.eq(5).find('td:eq(0) a');
            var tr5_td1 = $ggybTr.eq(5).find('td:eq(1) span');         
            
            tr1_td0.attr("title", tr1_td0.html()).html(cutstr(tr1_td0.html(), 8, '..'));
            tr1_td1.attr("title", tr1_td1.html()).html(cutstr(tr1_td1.html(), 8, '..'));

            tr2_td0.attr("title", tr2_td0.html()).html(cutstr(tr2_td0.html(), 8, '..'));
            tr2_td1.attr("title", tr2_td1.html()).html(cutstr(tr2_td1.html(), 8, '..'));

            tr3_td0.attr("title", tr3_td0.html()).html(cutstr(tr3_td0.html(), 8, '..'));
            tr3_td1.attr("title", tr3_td1.html()).html(cutstr(tr3_td1.html(), 8, '..'));

            tr4_td0.attr("title", tr4_td0.html()).html(cutstr(tr4_td0.html(), 8, '..'));
            tr4_td1.attr("title", tr4_td1.html()).html(cutstr(tr4_td1.html(), 8, '..'));

            tr5_td0.attr("title", tr5_td0.html()).html(cutstr(tr5_td0.html(), 8, '..'));
            tr5_td1.attr("title", tr5_td1.html()).html(cutstr(tr5_td1.html(), 8, '..'));

            var $ggybTr = $('#hyybTable tr');
            var hyybTr1_td0 = $ggybTr.eq(1).find('td:eq(0) a');
            var hyybTr1_td1 = $ggybTr.eq(1).find('td:eq(1) span');

            var hyybTr2_td0 = $ggybTr.eq(2).find('td:eq(0) a');
            var hyybTr2_td1 = $ggybTr.eq(2).find('td:eq(1) span');

            var hyybTr3_td0 = $ggybTr.eq(3).find('td:eq(0) a');
            var hyybTr3_td1 = $ggybTr.eq(3).find('td:eq(1) span');

            var hyybTr4_td0 = $ggybTr.eq(4).find('td:eq(0) a');
            var hyybTr4_td1 = $ggybTr.eq(4).find('td:eq(1) span');

            var hyybTr5_td0 = $ggybTr.eq(5).find('td:eq(0) a');
            var hyybTr5_td1 = $ggybTr.eq(5).find('td:eq(1) span');

            hyybTr1_td0.attr('title', hyybTr1_td0.html()).html(cutstr(hyybTr1_td0.html(), 8,'..'));
            hyybTr1_td1.attr('title', hyybTr1_td1.html()).html(cutstr(hyybTr1_td1.html(), 8, '..'));

            hyybTr2_td0.attr('title', hyybTr2_td0.html()).html(cutstr(hyybTr2_td0.html(), 8, '..'));
            hyybTr2_td1.attr('title', hyybTr2_td1.html()).html(cutstr(hyybTr2_td1.html(), 8, '..'));

            hyybTr3_td0.attr('title', hyybTr3_td0.html()).html(cutstr(hyybTr3_td0.html(), 8, '..'));
            hyybTr3_td1.attr('title', hyybTr3_td1.html()).html(cutstr(hyybTr3_td1.html(), 8, '..'));

            hyybTr4_td0.attr('title', hyybTr4_td0.html()).html(cutstr(hyybTr4_td0.html(), 8, '..'));
            hyybTr4_td1.attr('title', hyybTr4_td1.html()).html(cutstr(hyybTr4_td1.html(), 8, '..'));

            hyybTr5_td0.attr('title', hyybTr5_td0.html()).html(cutstr(hyybTr5_td0.html(), 8, '..'));
            hyybTr5_td1.attr('title', hyybTr5_td1.html()).html(cutstr(hyybTr5_td1.html(), 8, '..'));
            
        },

        //四分位属性
        quartile:function () {
        //console.log(Def,'def')
            //注意域名
            $.ajax({
                // 'http://" + mathNum +".push2.eastmoney.com/api/qt/slist/get?secid=0.300059&spt=1&np=3&fltt=2&invt=2&fields=f137,f12,f13,f14,f20,f138,f37,f45,f49,f134,f135,f129,f1000,f2000&ut=bd1d9ddb04089700cf9c27f6f7426281
                url: "//push2.eastmoney.com/api/qt/slist/get?spt=1&np=3&fltt=2&invt=2&fields=f9,f12,f13,f14,f20,f23,f37,f45,f49,f134,f135,f129,f1000,f2000,f3000&ut=bd1d9ddb04089700cf9c27f6f7426281",
                data: { secid: Def._Market_10 + '.' + Def._Code },
                dataType: "jsonp",
                scriptCharset: "utf-8",
                jsonp: "cb",
                success: function (json) {                   
                    if (json && json.data) {
                        var items = json.data.diff;
                        if (items && items.length > 0) {
                            // 20总市值  135净资产  45净利润   9市盈率  23市净率  49毛利率  129净利率   37ROE                                                    
                            var models = [], obj = items[0], obj_1 = items[1], model = {}, model_1 = {}, model_2 = {}, model_2 = {};

                            //表格第一行数据
                             model = {
                                 name: '<a href="http://data.eastmoney.com/stockdata/'+obj.f12+'.html" target="_blank">' + obj.f14+'</a>',
                                 zsz: fmtdig(obj.f20, 1, 2, "",true),
                                 jzc: fmtdig(obj.f135, 1, 2, "", true),
                                 jlr: fmtdig(obj.f45, 1, 2, "", true),
                                 syl: specialData(obj.f9), 
                                 sjl: specialData(obj.f23), 
                                 mll: addPercent(obj.f49),
                                 jll: addPercent(obj.f129),
                                 ROE: addPercent(obj.f37) 
                             };
                            //行业平均数据
                            model_1 = {
                                name: '<a href="http://quote.eastmoney.com/center/boardlist.html#boards-'+obj_1.f12+'1"  target="_blank">' + obj_1.f14+'</a></br><b class="color979797">(行业平均)</b>',
                                zsz: fmtdig(obj_1.f2020, 1, 2, "", true),
                                jzc: fmtdig(obj_1.f2135, 1, 2, "", true),
                                jlr: fmtdig(obj_1.f2045, 1, 2, "", true),
                                syl: parseFloat(obj_1.f2009) ? obj_1.f2009.toFixed(2) : obj_1.f2009,  
                                sjl: parseFloat(obj_1.f2023) ? obj_1.f2023.toFixed(2) : obj_1.f2023,   
                                mll: addPercent(obj_1.f2049),
                                jll: addPercent(obj_1.f2129),
                                ROE: addPercent(obj_1.f2037) 
                            };
                            // 行业排名
                            model_2 = {
                                name: "<b>行业排名</b>",
                                zsz: obj.f1020 + '|' + obj_1.f134,
                                jzc: obj.f1135 + '|' + obj_1.f134,
                                jlr: obj.f1045 + '|' + obj_1.f134,
                                syl: specialData(obj.f9, obj.f1009,true)+ '|' + obj_1.f134, 
                                sjl: specialData(obj.f23, obj.f1023, true) + '|' + obj_1.f134,
                                mll: obj.f1049 + '|' + obj_1.f134,
                                jll: obj.f1129 + '|' + obj_1.f134,
                                ROE: obj.f1037 + '|' + obj_1.f134
                            };       
                            model_3 = CwzbHtml(obj)
                            models.push(model, model_1, model_2, model_3);
                            var $_html = "";
                            //console.log(models, '整理数据')
                            for (var i = 0; i < models.length; i++) {
                                var item = models[i];
                                $_html += '<tr>'+
                                    '<td> ' + item.name + '</td >'+                                              
                                    '<td> ' + item.zsz + '</td >' +
                                    '<td> ' + item.jzc + '</td >' +
                                    '<td> ' + item.jlr + '</td >' +
                                    '<td> ' + item.syl + '</td >' +
                                    '<td> ' + item.sjl + '</td >' +
                                    '<td> ' + item.mll + '</td >' +
                                    '<td> ' + item.jll + '</td >' +
                                    '<td> ' + item.ROE + '</td >' +
                                    '</tr > '
                                '</tr > '
                            }
                            $('#cwzbDataBox').html($_html);       
                            showRedTipsHover();
                        }
                    }
                }
            })
        },
        //个股研报
        stockReport:function(){
            var date = new Date();
            date = new Date(date.setFullYear(date.getFullYear()-2)) ;
            var  _url = "http://reportapi.eastmoney.com/report/list?beginTime="+this.formateDate(date,"yyyy-MM-dd")+"&endTime="+this.formateDate(new Date(),"yyyy-MM-dd")+"&fields=orgCode,orgSName,sRatingName,encodeUrl,title,publishDate,market&pageNo=1&pageSize=5&qType=0&code="+this._Code;
            var that = this;
            var html = '<tr><td align="center">机构</td><td align="center">评级</td><td class="text-indent10">研报</td></tr>';
            getNewReportUrl(_url,function(data){
                var market = data[0].market;
                for(var i = 0;i<data.length;i++){
                    var item = data[i];
                    html += '<tr><td align="center"><a target="_blank" href="http://data.eastmoney.com/report/'+item.orgCode+'_0.html" class="lightBlue" title="'+item.orgSName+'">'+cutstr(item.orgSName,8,"..")+'</a></td>'+
                            '<td align="center"><span title="'+item.sRatingName+'">'+cutstr(item.sRatingName,4,"..")+'</span></td>'+
                            '<td class="text-indent10"><span class="dt">'+that.formateDate(item.publishDate,"MM-dd")+'</span><a target="_blank"  href="http://data.eastmoney.com/report/zw_stock.jshtml?encodeUrl='+item.encodeUrl+'" title="'+item.title+'">'+cutstr(item.title,26)+'</a></td></tr>'
                }
                $("#ggybTable tbody").html(html)
                if(that._Code){
                    $('#stockReport').attr("href","http://data.eastmoney.com/report/singlestock.jshtml?stockcode="+that._Code+"&market="+market)
                    $('#stockReportMore').attr("href","http://data.eastmoney.com/report/singlestock.jshtml?stockcode="+that._Code+"&market="+market)
                }else{
                    $('#stockReport').attr("href","http://data.eastmoney.com/report/")
                    $('#stockReportMore').attr("href","http://data.eastmoney.com/report/")
                }
            },function(){
                html += "<tr><td colspan=\"3\"><span class=\"nodatalist\">暂无数据</span></td></tr>";
                $("#ggybTable tbody").html(html);
                $('#stockReport').attr("href","http://data.eastmoney.com/report/")
                $('#stockReportMore').attr("href","http://data.eastmoney.com/report/")
            })
        },
        //行业研报
        hyReport:function(){
            var date = new Date();
            date = new Date(date.setFullYear(date.getFullYear()-2)) ;
            var  _url = "http://reportapi.eastmoney.com/report/list?beginTime="+this.formateDate(date,"yyyy-MM-dd")+"&endTime="+this.formateDate(new Date(),"yyyy-MM-dd")+"&fields=orgCode,orgSName,sRatingName,encodeUrl,title,publishDate&pageNo=1&pageSize=5&qType=1&industryCode="+this._HyId;
            var that = this;
            var html = '<tr><td align="center">机构</td><td align="center">评级</td><td class="text-indent10">研报</td></tr>';
            getNewReportUrl(_url,function(data){
                for(var i = 0;i<data.length;i++){
                    var item = data[i];
                    html += '<tr><td align="center"><a target="_blank" href="http://data.eastmoney.com/report/'+item.orgCode+'_0.html" class="lightBlue" title="'+item.orgSName+'">'+cutstr(item.orgSName,8,"..")+'</a></td>'+
                            '<td align="center"><span title="'+item.sRatingName+'">'+cutstr(item.sRatingName,4,"..")+'</span></td>'+
                            '<td class="text-indent10"><span class="dt">'+that.formateDate(item.publishDate,"MM-dd")+'</span><a target="_blank" href="http://data.eastmoney.com/report/zw_industry.jshtml?encodeUrl='+item.encodeUrl+'" title="'+item.title+'">'+cutstr(item.title,26)+'</a></td></tr>'
                }
                $("#hyybTable tbody").html(html)
            },function(){
                html += "<tr><td colspan=\"3\"><span class=\"nodatalist\">暂无数据</span></td></tr>";
                $("#hyybTable tbody").html(html)
            })
        }

    };

    window.QaDefault = QaDefault;
})();


//市盈率特殊处理
function specialData(num,pm,status) {    
    var syl = parseFloat(num), item = "";
    if (!status) {
        if (syl >= 0 || syl < 0) {
            syl >= 0 ? item = syl.toFixed(2) : item = "亏损";
        } else {
            syl ? item = syl.toFixed(2) : item = "-";
        }
    } else {
        if (syl >= 0) {
            item = parseFloat(pm);
        } else {
            item = "-";
        }
    }
    
    return item;
}
//四分位的hover事件
function showRedTipsHover() {
    $(".showRedTips").mouseover(function () {
        $(".sfwsx_title").hide();
        if ($(this).find(".sfwsx_title").length != 0) {
            $(this).find(".sfwsx_title").show();
        } else {
            $(this).parent().find(".sfwsx_title").show();
        }

    });

    $(".showRedTips").mouseout(function () {
        $(".sfwsx_title").hide();
    });
}

//四分位数据逻辑
function CwzbHtml(obj) {
    var text = {
        td_0: '<div class="sfwsx_title" style = "display: none;">四分位属性是指根据每个指标的属性，进行数值大小排序，然后分为四等分，每个部分大约包含排名的四分之一。将属性分为高、较高、较低、低四类。<span class="red">注：鼠标移至四分位图标上时，会出现每个指标的说明和用途。</div>',
        td_1: '<div class="sfwsx_title" style = "display: none; margin-left:55px;margin-top:-40px;">公式为公司总股本乘以市价。该指标侧面反映出一家公司的规模和行业地位。总市值越大，公司规模越大，相应的行业地位也越高。<br><span class="red">注：四分位属性以行业排名为比较基准。</span> </div>',
        td_2: '<div class="sfwsx_title" style = "display: none; margin-left:55px;margin-top:-40px;">公式为资产总额减去负债后的净额。该指标由实收资本、资本公积、盈余公积和未分配利润等构成，反映企业所有者在企业中的财产价值。净资产越大，信用风险越低。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></div>',
        td_3: '<div class="sfwsx_title" style = "display: none; margin-left:55px;margin-top:-40px;">公式为：净利润=利润总额-所得税费用。净利润是一个企业经营的最终成果，净利润多，企业的经营效益就好。<br><span class="red">注：四分位属性以行业排名为比较基准。</span>',
        td_4: '<div class="sfwsx_title" style = "display: none; margin-left:55px;margin-top:-40px;">公式为公司股票价格除以每股利润。该指标主要是衡量公司的价值，高市盈率一般是由高成长支撑着。市盈率越低，股票越便宜，相对投资价值越大。<br><span class="red">注：四分位属性以行业排名为比较基准。</span> </div>',
        td_5: '<div class="sfwsx_title" style = "display: none; margin-left:55px;margin-top:-40px;">公式为每股股价与每股净资产的比率。市净率越低，每股内含净资产值越高，投资价值越高。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></div>',
        td_6: '<div class="sfwsx_title" style = "display: none; margin-left:55px;margin-top:-40px;">公式为毛利与销售收入的比率。毛利率越高，公司产品附加值越高，赚钱效率越高。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></div>',
        td_7: '<div class="sfwsx_title" style = "display: none; margin-left:55px;margin-top:-40px;">公式为净利润与主营业务收入的比率。该指标表示企业每单位资产能获得净利润的数量，这一比率越高，说明企业全部资产的盈利能力越强。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></div>',
        td_8: '<div class="sfwsx_title" style = "display: none; margin-left:55px;margin-top:-40px;">公式为税后利润与净资产的比率。该指标反映股东权益的收益水平，用以衡量公司运用自有资本的效率。指标值越高，说明投资带来的收益越高。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></div>'
    }; 

    model_3 = {
        name: '<b>四分位属性</b><b class="showRedTips hxsjccsyl" id="cwzb_sfwsxTit">' + text.td_0+'</b>',
        zsz: rankFun(obj.f3020) + '<p> ' + getDesc(obj.f3020) + '</p>'  + text.td_1,
        jzc: rankFun(obj.f3135) + '<p> ' + getDesc(obj.f3135 )+ '</p>' + text.td_2,
        jlr: rankFun(obj.f3045) + '<p> ' + getDesc(obj.f3045) + '</p>' + text.td_3,
        syl: rankFun(obj.f3009, obj.f9, "syl") + '<p> ' + getDesc(obj.f3009, obj.f9,"市盈率") + '</p>' + text.td_4,
        sjl: rankFun(obj.f3023, obj.f23, "sjl") + '<p> ' + getDesc(obj.f3023, obj.f23, "市净率") + '</p>' + text.td_5,
        mll: rankFun(obj.f3049) + '<p> ' + getDesc(obj.f3049 ) + '</p>' + text.td_6,
        jll: rankFun(obj.f3129) + '<p> ' + getDesc(obj.f3129 ) + '</p>' + text.td_7,
        ROE: rankFun(obj.f3037) + '<p> ' + getDesc(obj.f3037 ) + '</p>' + text.td_8
    }  
    return model_3
}
function getDesc(rank, num, dir) { //市盈率市净率还要重新考虑
    var item = "";
    var $html = '- - <b title="'+dir+'为负值，不参与四分位排名" class="hxsjccsyl" style="margin - top: 5px;"></b>'
    if (dir) {
        //市盈率市净率四分位属性判断之前先判断市净率市盈率值的正负，正的话直接用rank判断，负值直接--加title
        var _num = parseFloat(num);
        if (_num >= 0) {
            if (parseInt(rank)) {
                if (0 < rank < 5) {
                    var desc = ['高', '较高', '较低', '低'];
                    item = desc[rank - 1];
                } else {
                    item = '- -';
                }
            } else {
                item = $html;
            }
        } else if (_num < 0) {
            item = $html;
        } else {
            item =  '- -';
        }
    } else {
        if (parseInt(rank)) {
            if (0 < rank < 5) {
                var desc = ['高', '较高', '较低', '低'];
                item =  desc[rank - 1];
            } else {
                item =  '- -';
            }
        } else {
            item = $html;
        }
    }
    return item ;
}

function rankFun(str,num, dir) {
    //市盈率市净率的展示是反的
    var _str = Number(str);
    var bgColor_1 = "", bgColor_2 = "", bgColor_3 = "", bgColor_4 = "";   
    if (dir) {
        //市盈率市净率为负值时特殊处理
        var _num = parseFloat(num); 
        if (_num >= 0) {
            _str = _str;
        } else {            
            _str = 0;
        }
        if (_str >= 1) {
            bgColor_1 = "#deecff";
        }
        if (_str >= 2) {
            bgColor_2 = "#c4ddff";
        }
        if (_str >= 3) {
            bgColor_3 = "#a3cbff";
        }
        if (_str >= 4) {
            bgColor_4 = "#78b1ff";
        }        

    } else {

        if (_str <= 1) {
            bgColor_1 = "#78b1ff";
        }
        if (_str <= 2) {
            bgColor_2 = "#a3cbff";
        }
        if (_str <= 3) {
            bgColor_3 = "#c4ddff";
        }
        if (_str <= 4) {
            bgColor_4 = "#deecff";
        }

    }
    if (dir) {
        var list = '<ul class="showRedTips">' +
            '<li style="background-color: ' + bgColor_4 + '"></li>' +
            '<li style="background-color: ' + bgColor_3 + '"></li>' +
            '<li style="background-color: ' + bgColor_2 + '"></li>' +
            '<li style="border-bottom:none;background-color: ' + bgColor_1 + '"></li>' +
            '</ul >';

    } else {
        var list = '<ul class="showRedTips">' +
            '<li style="background-color: ' + bgColor_1 + '"></li>' +
            '<li style="background-color: ' + bgColor_2 + '"></li>' +
            '<li style="background-color: ' + bgColor_3 + '"></li>' +
            '<li style="border-bottom:none;background-color: ' + bgColor_4 + '"></li>' +
            '</ul >';
    }
   

    return list;
   
}

//异步加载图片
function imgLoader(setting) {
    if (typeof (setting) !== "object" || !setting["url"]) return false;
    var fCallback = typeof (setting["success"]) === "function" ? setting["success"] : null;
    var _url = setting["url"];
    if (setting["data"]) {
        var _data = $.param(setting["data"]);
        _url = _url.indexOf("?") > 0 ? _url + "&" + _data : _url + "?" + _data;
    }
    if (!setting["cache"]) {
        _url += _url.indexOf("?") > 0 ? "&_=" + (+new Date()) : "?_=" + (+new Date());
    }
    var _image = document.createElement("img");
    if (typeof (setting["height"]) === "number" && setting["height"] > 0) {
        _image.setAttribute("height", setting["height"] + "px");
    }
    if (typeof (setting["width"]) === "number" && setting["width"] > 0) {
        _image.setAttribute("width", setting["width"] + "px");
    }
    _image.setAttribute('src', _url);
    if (typeof (setting["error"]) === "function")
        $(_image).error(function () {
            setting["error"](_image);
        });
    _image.onload = _image.onreadystatechange = function (evt) {
        if (!_image.readyState || /loaded|complete/.test(_image.readyState)) {
            // Handle memory leak in IE
            _image.onload = _image.onreadystatechange = null;
            // Callback if not abort
            if (fCallback) fCallback(_image);
        }
    };
    return _image;
}


//大盘
function GetDP() {
    window.dpzs = 1;
    this.dis = function () {
        if (window.GetTimeZoneInfo == true || window.dpzs == 1) {
            $.getScript(gdomain + "CompatiblePage.aspx?Type=C&jsName=js_dp&ino=0000011,3990012&Reference=xml&rt=" + Math.random(), function () {
                var jnm = eval("js_dp");
                if (jnm.dpif != null && jnm.dpif != "") {
                    var tem_shdp = jnm.dpif[0].split(','); var tem_szdp = jnm.dpif[1].split(',');
                    $("#qqgs1").html("<p><a href=\"http://quote.eastmoney.com/zs000001.html\" target=\"_blank\" class=\"blue\">上证</a>：<span style=\"" + udcolor(tem_shdp[4]) + "\"><b>" + tem_shdp[3] + "</b> " + udt(tem_shdp[4]) + "<b>" + tem_shdp[4] + "</b>  " + udt(tem_shdp[4]) + "<b>" + tem_shdp[5] + "  " + ForDight(tem_shdp[6] / 10000, 2) + "</b></span>亿元&nbsp;(涨:<a href=\"http://quote.eastmoney.com/center/list.html#10_0_0_u?sortType=C&sortRule=-1\" target=\"_blank\" class=\"red\"><b>" + tem_shdp[7] + "</b></a> 平:<b>" + tem_shdp[8] + "</b> 跌:<a href=\"http://quote.eastmoney.com/center/list.html#10_0_0_d?sortType=C&sortRule=1\" target=\"_blank\" class=\"green\"><b>" + tem_shdp[9] + "</b></a>)</p><p><a href=\"http://quote.eastmoney.com/zs399001.html\" target=\"_blank\" class=\"blue\">深证</a>：<span style=\"" + udcolor(tem_szdp[4]) + "\"><b>" + tem_szdp[3] + "</b> " + udt(tem_szdp[4]) + "<b>" + tem_szdp[4] + "</b>  " + udt(tem_szdp[4]) + "<b>" + tem_szdp[5] + "  " + ForDight(tem_szdp[6] / 10000, 2) + "</b></span>亿元&nbsp;(涨:<a href=\"http://quote.eastmoney.com/center/list.html#20_0_0_u?sortType=C&sortRule=-1\" target=\"_blank\" class=\"red\"><b>" + tem_szdp[7] + "</b></a> 平:<b>" + tem_szdp[8] + "</b> 跌:<a href=\"http://quote.eastmoney.com/center/list.html#20_0_0_d?sortType=C&sortRule=1\" target=\"_blank\" class=\"green\"><b>" + tem_szdp[9] + "</b></a>)</p>");
                }
                window.dpzs = 0;
            });
        }
    }
}


function showMore(tp, obj) {
    var over = $x("xh" + tp + obj).style.display = "block";
}
function hideall(tp, obj) {
    var over = $x("xh" + tp + obj).style.display = "none";
}
function hotpersonafp(uid, oid, marketcode) {
    var iscks = false;
    if (GetCookie("pi")) {
        var gcks = Getcks("pi");
        if (gcks.split(';').length >= 3) {
            var name = gcks.split(';')[2];
            if (/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) { iscks = true; }
            else {
                var url = "http://iguba.eastmoney.com/action.aspx?callback=&action=oaddfollowperson&uid2=" + uid;
                $.getScript(url + "&v=" + formatm(), function () {
                    oid.className = "allow"; oid.innerHTML = ""; oid.onclick = null;
                });
            }
        }
        else { iscks = true; }
    }
    else { iscks = true; }
    if (iscks) {
        location.href = "http://passport2.eastmoney.com/pub/login?backurl=http://quote.eastmoney.com/" + marketcode + ".html";
    }
}

function fmtdig(Data, Mat, F, Unit, AutoF) {
    var res = Data;
    if (Data != "" && Data != "--" && Data != "-") {       
        var _temp = Math.abs(parseFloat(Data));
        var temp = parseFloat(Data);
        if (AutoF) {
            if (_temp > 1000000000000)//万亿
            {
                Mat = 100000000; Unit = "亿"; F = "0";
            }
            else if (_temp > 100000000000)//千亿
            {
                Mat = 100000000; Unit = "亿"; F = "0";
            }
            else if (_temp > 10000000000)//百亿
            {
                Mat = 100000000; Unit = "亿"; F = "1";
            }
            else if (_temp > 1000000000)//十亿
            {
                Mat = 100000000; Unit = "亿"; F = "2";
            }
            else if (_temp > 100000000)//亿
            {
                Mat = 100000000; Unit = "亿"; F = "2";
            }
            else if (_temp > 10000000)//千万
            {
                Mat = 10000; Unit = "万"; F = "0";
            }
            else if (_temp > 1000000)//百万
            {
                Mat = 10000; Unit = "万"; F = "1";
            }
            else if (_temp > 100000)//十万
            {
                Mat = 10000; Unit = "万"; F = "2";
            }
            else if (_temp > 10000) {
                Mat = 10000; Unit = "万"; F = "2";
            }
            else if (_temp > 1000) {
                Mat = 1; Unit = ""; F = "2";
            }
            else if (_temp > 100) {
                Mat = 1; Unit = ""; F = "2";
            }
            else if (_temp > 10) {
                Mat = 1; Unit = ""; F = "2";
            }
            else {
                Mat = 1; Unit = ""; F = "3";
            }
        }
        res = ForDight((temp / Mat), F);
    }
    return res + Unit;
}

//时间随机数
function formatm() {
    var now = new Date();
    return now.getTime();
}

//随机数
function GetRandomNum(Min, Max) { var Range = Max - Min; var Rand = Math.random(); return (Min + Math.round(Rand * Range)); }

function showimg() {
    //$x("flash_box").style.display = "none";
    $x("image_box").style.display = "block";
    $x("js_box").style.display = "none";
    window.zxgIsFirst = true;
    window.quoteIsFirst = true;
    // Def.DisQuote();
    // $x("ov3").className = "emhqbov3 mb10";
    $x("flsrmt7").className = "title1 mt6";
    WriteCookie("em_hq_fls", "old", 99999);
    //_this.GetFavorList(_this._Code);
}
//小写数字转换大写
function SectionToChinese(section){
    // console.log(section/10)
    var chnNumChar = ["零","一","二","三","四","五","六","七","八","九"];
    var chnUnitSection = ["","万","亿","万亿","亿亿"];
    var chnUnitChar = ["","十","百","千"];
    if(section/10<2&&section/10>1){
        return("十"+chnNumChar[section%10])
    }else if(section/10==1){
        return("十")
    }else{
        var strIns = '', chnStr = '';
        var unitPos = 0;
        var zero = true;
        while(section > 0){
            var v = section % 10;
            if(v === 0){
                if(!zero){
                    zero = true;
                    chnStr = chnNumChar[v] + chnStr;
                }
            }else{
                zero = false;
                strIns = chnNumChar[v];
                strIns += chnUnitChar[unitPos];
                chnStr = strIns + chnStr;
            }
            unitPos++;
            section = Math.floor(section / 10);
            // console.log(section);
        }      
        return chnStr;
        }      
}

function showjs() {
    $x("image_box").style.display = "none";
    // $x("image_box").style.display = "block";
    $x("js_box").style.display = "block";
    window.zxgIsFirst = true;
    window.quoteIsFirst = true;
    //Def.DisQuote();
    // $x("ov3").className = "emhqbov3 mb10";
    $x("flsrmt7").className = "title1 mt6";
    WriteCookie("em_hq_fls", "js", 99999);
    //_this.GetFavorList(_this._Code);
}

function showfls() {
    //$x("flash_box").style.display = "block";
    $x("image_box").style.display = "block"; window.zxgIsFirst = true; window.quoteIsFirst = true; 
    // Def.DisQuote();
    $x("js_box").style.display = "none";
    // $x("ov3").className = "emhqbov3 mb9";
    $x("flsrmt7").className = "title1 mt13";
    WriteCookie("em_hq_fls", "new", 99999);
    var picrtr = $x("actTab1").getElementsByTagName("span");
    var picrtk = $x("actTab2").getElementsByTagName("span");
    picrtr[1].click(); // 返回当天分时
    picrtk[0].click();
    //for (var j = 0; j < picrtk.length; j++) {
    //    if (picrtk[j].className == "cur") {
    //        setTimeout(function () { stock.kMT = false; stock.FlashObj.selectButton(j + 1, 10); }, 2000);
    //        break;
    //    }
    //}
    //_this.GetFavorList(_this._Code);
}

function smivckNew(code, znum, dnum) {
    var pi = "";
    var islow = $('input:radio[name="hqvote"]:checked').val();
    if (!islow) { alert("请先选择投票方向！"); return; };
    if (GetCookie("pi")) { pi = GetCookie("pi"); }
    var url = "http://hqstat.eastmoney.com/vote/QuoteGuBaLookUpOrDown.aspx?code=" + code + "&islow=" + islow + "&pi=" + pi + "&cb=var%20res=[{0}]&&num=1&rt=" + formatm();
    Mini.Loader.load(url, "gb2312", function () {
        alert(res[0].me);
        if (res[0].rc == 1) {
            switch (islow) { case "false": znum++; break; case "true": dnum++; break; }
            zdpc = znum + dnum;
            zhang = (znum / zdpc * 100).toFixed(1);
            die = (dnum / zdpc * 100).toFixed(1);
            $x("ivap").innerHTML = zhang + "%";
            $x("ivbp").innerHTML = die + "%";
            $x("ivra").style.width = (zhang / 110 * 100).toFixed(1) + "px";
            $x("ivrb").style.width = (die / 110 * 100).toFixed(1) + "px";
            //$x("kzps").innerHTML = znum;
            //$x("kdps").innerHTML = dnum;
            $x("ivbv").innerHTML = '<span style="color: #A1A1A1;background-color:#E4E4E4;display: inline-block;height: 20px;line-height: 20px;padding: 0 6px;border: 0 none;text-align: center;">已投票</span>';
        } else if (res[0].rc == 0) {
            $x("ivbv").innerHTML = '<span style="color: #A1A1A1;background-color:#E4E4E4;display: inline-block;height: 20px;line-height: 20px;padding: 0 6px;border: 0 none;text-align: center;">已投票</span>';
        }
    });
}

function smivck(code, islow, znum, dnum, el) {
    var pi = "";
    if (GetCookie("pi")) { pi = GetCookie("pi"); }
    var url = "http://hqstat.eastmoney.com/vote/QuoteGuBaLookUpOrDown.aspx?code=" + code + "&islow=" + islow + "&pi=" + pi + "&cb=var%20res=[{0}]&&num=1&rt=" + formatm();
    Mini.Loader.load(url, "gb2312", function () {
        alert(res[0].me);
        if (res[0].rc == 1) {
            switch (islow) { case "false": znum++; break; case "true": dnum++; break; }
            zdpc = znum + dnum;
            zhang = (znum / zdpc * 100).toFixed(1);
            die = (dnum / zdpc * 100).toFixed(1);
            $x("ivap").innerHTML = zhang + "%";
            $x("ivbp").innerHTML = die + "%";
            $x("ivra").style.width = (zhang / 110 * 100).toFixed(1) + "px";
            $x("ivrb").style.width = (die / 110 * 100).toFixed(1) + "px";
        }
    });
}

function getdomain(min, max) {
    var min = 1; var max = 10;
    var res = "nufm3.dfcfw.com"; var m2 = "nufm2.dfcfw.com";
    var rom = GetRandomNum(min, max);
    if (rom != "1" && rom != "2" && rom != "3") { res = m2; }//80% ->nufm2
    //if (rom == "1") { res = m2; }//10% ->nufm2
    return "nufm.dfcfw.com";//res;
}


/**
 * 是否支持canvas
 * 
 * @returns 
 */
function isSupportCanvas() {
    var elem = document.createElement('canvas');
    return !!(elem.getContext && elem.getContext('2d'));
}

var cookie = {
    get: function (name) {
        var xarr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
        if (xarr != null)
            return decodeURIComponent(xarr[2]);
        return null;
    },
    set: function (key, value, expiredays, domain) {
        var exdate = new Date();
        exdate.setDate(exdate.getDate() + expiredays);
        document.cookie = key + "=" + escape(value) + ";expires=" + exdate.toGMTString() + ";path=/;domain=" + domain;
    },
    del: function (key, domain) {
        var exdate = new Date((new Date).getTime() - 1);
        if (domain) {
            document.cookie = key + '=;path=/;expires=' + exdate.toGMTString() + ';domain=' + domain;
        }
        else {
            document.cookie = key + '=;path=/;expires=' + exdate.toGMTString();
        }

    }
};

var bid = {
    get: function () {
        var zw = cookie.get('qgqp_b_id')
        if (zw == null) {
            return this.make()
        }
        else {
            return zw;
        }

    },
    make: function () {
        var newid = Math.floor(Math.random() * 9 + 1).toString();
        for (var i = 0; i < 19; i++) {
            newid += Math.floor(Math.random() * 9).toString();

        }
        cookie.set('qgqp_b_id', newid, 10000, '.eastmoney.com');
        return newid;
    },
    init: function () {
        if (this.get() == null || this.get() == '') {
            return this.make();
        }
        else {
            return this.get();
        }
    }
}


//获取新版研报接口
function getNewReportUrl(url,sucess,fail){
    $.ajax({
        url:url,
        dataType: "jsonp",
        scriptCharset: "utf-8",
        jsonp:"cb",
        jsonpCallback:'callback' + Math.floor(Math.random() * 10000000 + 1)
    }).done(function(json){
        try{
            if(json && json.data && json.data.length){
                sucess &&sucess(json.data)
            }else{
                fail && fail()
            }
        }catch(error){
           console && console.log(error)
            fail && fail()
        }
    }).fail(function(error){
        console && console.log(error)
        fail && fail()
    })
}
