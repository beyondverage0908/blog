﻿;(function(){

var ua = window.navigator.userAgent.toLowerCase();
//网页
if (!(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))) {

}//手机
else if (ua.indexOf("iphone") >= 0 || ua.indexOf("android") >= 0) {
    var meta = findMeta("wapurl");
    if (!!meta.content) {
        location.href = meta.content;
        return;
    }
    var url = location.href;

    var stockType = url.split("/")[3].toLowerCase();

    //没市场虚拟目录为AB股
    if (stockType.indexOf("sz") >= 0 || stockType.indexOf("sh") >= 0) {

        var stockId = stockType.split(".")[0];

        if (stockId.indexOf("sz") >= 0) {
            market = "2";
        } else {
            market = "1";
        }
        var stockCode = stockId.substring(2, stockId.length);
        window.location.href = "http://m2.quote.eastmoney.com/h5stock/" + stockCode + market + ".html";
        return;
    }

    var code = url.split("/")[4].split(".")[0].toLowerCase();
    var market;

    if (stockType == "") {
        window.location.href = "http://m2.quote.eastmoney.com/";
        return;
    }

    switch (stockType) {
        case "forex":
            market = "0";
            break;
        case "globalfuture":
        case "gjqh":
            market = "0";
            break;
        case "cnyrate":
            market = "0";
            break;
        case "gb": market = "_UI"; break;
        case "hk":
            market = "5";
            break;
        case "us":
            market = "7";
            break;
        case "web":
            market = "";
            break;
        case "3ban":
            if (code.indexOf("sz") >= 0) {
                market = "2";
            } else {
                market = "1";
            }
            code = code.substring(2, code.length);
            break;
        default:
            market = "0";
    }

    //美元指数
    if (code == "dini") {
        code = "udi"
        market = "0";
    }

    //人民币相关
    if (code.length == 6 && code.substring(3, 6) == "cny") {
        code = code + "i";
        window.location.href = "http://m2.quote.eastmoney.com/h5stock/" + code + market + ".html";
        return;
    }

    //离岸人民币
    if (code.length == 6 && code.substring(3, 6) == "cnh") {
        market = "_fos";
        window.location.href = "http://m2.quote.eastmoney.com/h5stock/" + code + market + ".html";
        return;
    }

    //国际期货老码表映射
    if (stockType == "gjqh" || stockType == "globalfuture") {
        var codeList = ["CONC", "CRCC", "CTNC", "GLNC", "LALS", "LCPS", "LLDS", "LNKS", "LTNS", "LZNS", "OILC", "RBTC", "SBCC", "SGNC", "SMCC", "SOCC", "WHCC", "DINI", "SLNC"];

        if (contains(codeList, code.toUpperCase())) {
            window.location.href = "http://m2.quote.eastmoney.com/h5stock/" + code + "_UFFO.html";
            return;
        }
    }

    if (stockType && code) {
        window.location.href = "http://m2.quote.eastmoney.com/h5stock/" + code + market + ".html";
        return;
    }

    function contains(arr, obj) {
        var i = arr.length;
        while (i--) {
            if (arr[i] === obj) {
                return true;
            }
        }
        return false;
    }
}

function findMeta(name) {
    name = (name || "").toLowerCase();
    var metas = document.getElementsByTagName("meta") || [];
    for (var i = 0; i < metas.length; i++) {
        var meta = metas[i];
        if (!meta) continue;
        if (meta.name.toLowerCase() === name) return meta;
    }
}


})();


