var thissse = null;

$(document).ready(function () {
    var newcode = StockMarket_10 + '.' + StockCode 
    var not_h5 = !+"\v1";
    if (not_h5) { $(".js_show").hide(); return; }

    $.ajax({
        url: "//emcharts.dfcfw.com/ec/3.14.2/emcharts.min.js",
        method: "GET",
        cache: true,
        scriptCharset: "UTF-8",
        dataType: "script"
    }).success(function () {
        loadTimeSharingChart();
        // if(StockMarket_10 == '1'){
            loadCandleChartNew();
        // }
        // else{
        //     loadCandleChart();
        // }
        
    });

    /**
     * 分时图
     */
    function loadTimeSharingChart() {
        function getQueryString(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
            var r = window.location.search.substr(1).match(reg);
            if (r != null) return decodeURIComponent(r[2]);
            return null;
        }
        var c = _this._Market_10 +"."+ _this._Code;
        var sc = getQueryString("sc") || "";
        var sm = getQueryString("sm") || "";
        var type = getQueryString("type") || "r";
        var iscr = getQueryString("iscr");
        // console.log(iscr)
        if (!iscr || iscr == false || iscr == "") {
            iscr = 0
        } else {
            iscr = 1;
        }
        // console.log(iscr)
        var option = {
            container: "#emchart-0",
            width: 578,
            height: 276,
            type: 'r',
            iscr: 0,
            ndays:1,
            gridwh: {
                height: 25,
                width: 578
            },
            padding: {
                top: 0,
                bottom: 5
            },
            restline: {
                isshow: true,
                color: "#eee",
                solid: 3,       // 实线长度
                dashed: 0      // 虚线长度
            },
            tip: {
                trading: true
            },
            color: {
                    line: "#326fb2",
                    fill: ["rgba(101,202,254, 0.2)", "rgba(101,202,254, 0.1)"]
                },
            onClick: function () {
                if (typeof sendTrackLog === 'function') {
                    sendTrackLog('DIV', 'Click', 'xqzx_hsAgxqdy_hqt_djztlj');
                }
                // window.open("//quote.eastmoney.com/concept/" + (window.Def._Market === '1' ? 'sh' : 'sz') + window.Def._Code + ".html?from=classic");
            },
            onClickChanges: function () {
                window.open('//quote.eastmoney.com/changes/stocks/' + (window.Def._Market === '1' ? 'sh' : 'sz') + window.Def._Code + ".html");
            },
            onComplete: function () {
                //$("#emchart-0").remove('.loading');
            },
            onError: function (err) {
                // console.log(err);
            }
        }
        var time;
        time = new emcharts3.time(option);
        // console.log(time)
        var tps = {
            r: 1,
            t2: 2,
            t3: 3,
            t4: 4,
            t5: 5
        }
        test(1);
        function test(ndays) {
            if (typeof iscr === "number" && iscr) time.option.iscr = iscr;
            if (typeof ndays === "number" && ndays) time.option.ndays = ndays;
            if (typeof iscr === "number" && iscr) time.options.iscr = iscr;
            if (typeof ndays === "number" && ndays) time.options.ndays = ndays;
            // console.log(time.option.iscr)
            // console.log(time.options.iscr)
            if(ndays==1){
                var url = "http://push2.eastmoney.com/api/qt/stock/trends2/get" 
            }else{
                var url = "http://push2his.eastmoney.com/api/qt/stock/trends2/get"
            }
            var data = {
                fields1: "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13",
                fields2: "f51,f52,f53,f54,f55,f56,f57,f58",
                ut: "fa5fd1943c7b386f172d6893dbfba10b",
                ndays: time.option.ndays,
                iscr: time.option.iscr
            };
            if (c) {
                data.secid = c;
            }
            var arr = [];
            for (var k in data) {
                arr.push(k + "=" + data[k]);
            }
            // 请求分时数据
            $.ajax({
                type: "get",
                url: url + "?" + arr.join("&"),
                dataType: "jsonp",
                jsonp: "cb",
                success: function (msg) {
                    time.setData({
                        time: msg
                    });
                    time.redraw();
                }
            });
    
        }
    
        aa();
        function aa() {
            $.ajax({
                type: "get",
                url: "http://nuyd.eastmoney.com/EM_UBG_PositionChangesInterface/api/js",
                data: {
                    id: "3005042",
                    style: "top",
                    ac: "normal",
                    check: "itntcd",
                    // dtformat: "HH:mm:ss",
                    js: "changeData15125388([(x)])"
                },
                dataType: "jsonp",
                jsonp: "changeData15125388",
                jsonpCallback: "changeData15125388",
                success: function (msg) {
                    try {
                        if (msg[0].state) {
                            dataPositionChanges = [];
                        } else {
                            dataPositionChanges = msg;
                        }
                    } catch (error) {
                        dataPositionChanges = [];
                    }
                    time.setData({
                        positionChanges: dataPositionChanges
                    });
                    time.redraw();
                }
            });
        }
    
        bb();
        function bb() {
    
            var types = {
                "1": "有大买盘",
                "101": "有大卖盘",
                "2": "大笔买入",
                "102": "大笔卖出",
                "201": "封涨停板",
                "301": "封跌停板",
                "202": "打开涨停",
                "302": "打开跌停",
                "203": "高开5日线",
                "303": "低开5日线",
                "204": "60日新高",
                "304": "60日新低",
                "401": "向上缺口",
                "501": "向下缺口",
                "402": "火箭发射",
                "502": "高台跳水",
                "403": "快速反弹",
                "503": "快速下跌",
                "404": "竞价上涨",
                "504": "竞价下跌",
                "405": "60日大幅上涨",
                "505": "60日大幅下跌"
            }
    
            $.ajax({
                type: "get",
                url: "http://push2.eastmoney.com/api/qt/pkyd/get?fields=f2,f1,f4,f5,f6,f7&lmt=20&ut=fa5fd1943c7b386f172d6893dbfba10b&secids=" + c,
                dataType: "jsonp",
                jsonp: "cb",
                success: function (msg) {   
                    if (msg.rc == 0 && msg.data) {   
                        var pkyd = msg.data.pkyd;  
                        var newarr = [];  
                        for (var i = 0, len = pkyd.length; i < len; i++) {
                            var s = pkyd[i].split(",");  
                            var ar = [s[1], s[0].substr(0, 5), s[2], types[s[3]], s[4], s[5]];
                            newarr.push(ar.join(","));
                        }
                        time.setData({
                            positionChanges: newarr
                        });
                        time.redraw();
                    }
                }
            });
        }
        function events() {
            $(".changeFenshiTab span").click(function (e) {
                var params = time.option;
                var paramspic = time.options;
                params.iscr = 0;
                params.ndays = 1;
                paramspic.iscr = 0;
                paramspic.ndays = 1;
                $(".changeFenshiTab span").removeClass("cur");
                $(this).addClass("cur");
                switch ($(this).attr("type")) {
                    case "panqian":
                        params.iscr = 1;
                        params.ndays = 1;
                        params.type = "r";
                        paramspic.iscr = 1;
                        paramspic.ndays = 1;
                        paramspic.type = "r";
                        break;
                    case "oneday":
                        params.ndays = 1;
                        params.type = "r";
                        paramspic.ndays = 1;
                        paramspic.type = "r";
                        break;
                    case "twoday":
                        params.ndays = 2;
                        params.type = "t2";
                        paramspic.ndays = 2;
                        paramspic.type = "t2";
                        break;
                    case "threeday":
                        params.ndays = 3;
                        params.type = "t3";
                        paramspic.ndays = 3;
                        paramspic.type = "t3";
                        break;
                    case "fourday":
                        params.ndays = 4;
                        params.type = "t4";
                        paramspic.ndays = 4;
                        paramspic.type = "t4";
                        break;
                    case "fiveday":
                        params.ndays = 5;
                        params.type = "t5";
                        paramspic.ndays = 5;
                        paramspic.type = "t5";
                        break;
                }
                test(params.ndays);
                load_sse();
                return false;
            });
        }
        function init() {
            events();
            // if (window.bjTime && Def.PanQian(new Date(window.bjTime.replace(/-/g, "/")))) {
            //     $(".changeFenshiTab span[type=panqian]").click();
            // }
            // else $(".changeFenshiTab span[type=oneday]").click();  
            load_sse();   
        }
        function load_sse() {    
            try {
                thissse.close()
            } catch (error) {
                
            }
            if (typeof iscr === "number" && iscr) time.option.iscr = iscr;
            if (typeof ndays === "number" && ndays) time.option.ndays = ndays;
            var data={
                ndays: time.option.ndays,
                iscr: time.option.iscr,
            };
            var arr = [];
            for (var k in data) {
                arr.push(k + "=" + data[k]);
            } 
            // console.log(arr)
            var fullurl = 'http://'+(Math.floor(Math.random() * 99) + 1)+'.push2.eastmoney.com/api/qt/stock/trends2/sse?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&secid='+ c + "&" + arr.join("&");
            var nfullurl = 'http://'+(Math.floor(Math.random() * 99) + 1)+'.push2his.eastmoney.com/api/qt/stock/trends2/sse?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&secid='+ c + "&" + arr.join("&");
            //var evtSource = null
            if(data.ndays==1){
                thissse = new EventSource(fullurl);
            }else{
                thissse = new EventSource(nfullurl);
            }
            
            thissse.onmessage = function (msg) {
                // console.log(msg);
                var fdata = JSON.parse(msg.data)
                // console.log(fdata);
                var fulldata = '';
                if (fdata.rc == 0 && fdata.data) {
        
                    var data = fdata.data;
        
                    if (data.beticks) {
                        fullData = fdata;
                    } else {
        
                        var source = fullData.data.trends;
                        var last = source[source.length - 1].split(",");
                        
                        var trends = data.trends;
                        var frist = trends[0].split(",");
        
                        if (last[0] == frist[0]) {
                            source.pop();
                        }
                        for(var i = 0, len = trends.length ; i < len ; i++){
                            source.push(trends[i]);
                        }
                    }
        
                    // console.log(that.fullData);
                    time.setData({
                        time: fullData
                    });
                    time.redraw();
                }
        
            }
        }
    
        init();
    }

    /**
     * K图
     */
    function loadCandleChart() {
        //$("#emchartk").html($('<div class="loading"></div>'));
        var timer,
            kchart = new emcharts3.k2({
                container: "#emchartk",
                width: 585,
                height: 385,
                padding: {
                    top: 0,
                    bottom: 0
                },
                scale: {
                    pillar: 60,
                    min: 10
                },
                show: {
                    fold: true
                },
                color: {
                    background: "transparent"
                },
                popWin: { type: "move" },
                maxin: {
                    //show: true,
                    lineWidth: 30,     // 线长
                    skewx: 0,            // x偏移   
                    skewy: 0,            // y偏移
                },
                onComplete: function () {
                    //$("#emchartk").remove('.loading');
                },
                onFold: function (display, type) {
                    if (display === 'block') {
                        $('#cyq-btn').hide();
                    }
                    else {
                        $('#cyq-btn').show();
                    }
                },
                onClick: function () {
                    if (typeof sendTrackLog === 'function') {
                        sendTrackLog('DIV', 'Click', 'xqzx_hsAgxqdy_hqt_djztlj');
                    }
                    window.open("//quote.eastmoney.com/concept/" + (window.Def._Market === '1' ? 'sh' : 'sz') + window.Def._Code + ".html?from=classic");
                },
                onError: function (e) {
                    console.error(e)
                }
            }),
            params = {
                id: window.Def._Code + window.Def._Market,
                type: "k",
                authorityType: "",
            };
        function init() {

            events();
            // 复权判断
            var fq = GetCookie("emhq_picfq");
            if (fq === "1") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=before]").html());
                params.authorityType = "fa";
            }
            else if (fq === "2") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=before]").html());
                params.authorityType = "ba";
            }

            load();
        }

        function load() {
            $("#js_box").removeClass("hidefixed");
            clearTimeout(timer);
            var _load = function () {
                $.ajax({
                    url: "//pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js?rtntype=5&token=4f1862fc3b5e77c150a2b985b12db0fd",
                    dataType: "jsonp",
                    scriptCharset: 'utf-8',
                    data: params,
                    jsonp: "cb",
                    success: function (json) {
                        // console.log(json)
                        if (!json || json.stats === false) return false;
                        kchart.setData({ k: json });
                        kchart.draw();
                    },
                    error: function (e) {
                        console.error(e);
                    },
                    complate: function () {
                        timer = setTimeout(load, 60 * 1000);
                    }
                });
            };
            _load();
        }

        function events() {
            $("#beforeBackRight dl dd").click(function () {
                $("#beforeBackRight span").html($(this).html());
                var v = $(this).attr("value");
                $("#beforeBackRight").attr("value", v);
                params.authorityType = v === "before" ? "fa" : v === "back" ? "ba" : "";
                load();
                var at = v === "before" ? "1" : v === "back" ? "2" : "0";
                if ($("#js_box").is(":visible")) {
                    $("#select4 dd[value=" + at + "]").click();
                    WriteCookie("emhq_picfq", at, 8760);
                }
            });

            $("#changektab span").click(function () {
                $("#changektab span").removeClass("cur");
                $(this).addClass("cur");
                switch ($(this).attr("value")) {
                    case "D":
                        params.type = "k";
                        break;
                    case "W":
                        params.type = "wk";
                        break;
                    case "M":
                        params.type = "mk";
                        break;
                    case "M5":
                        params.type = "m5k";
                        break;
                    case "M15":
                        params.type = "m15k";
                        break;
                    case "M30":
                        params.type = "m30k";
                        break;
                    case "M60":
                        params.type = "m60k";
                        break;
                }
                load();
            });

            $("#scale-plus").click(function () {
                kchart.shorten();
            });

            $("#scale-minus").click(function () {
                kchart.elongate();
            });

            $("#beforeBackRight").mouseenter(function () {
                this.getElementsByTagName("dl")[0].style.display = "block";
            });

            $("#beforeBackRight").mouseleave(function () {
                this.getElementsByTagName("dl")[0].style.display = "none";
            });
        }
        init();
    }

    function loadCandleChartNew() {
        //$("#emchartk").html($('<div class="loading"></div>'));
        var timer,
            kchart = new quotekchart.k({
                code: newcode,
                container: "#emchartk",
                width: 585,
                height: 385,
                padding: {
                    top: 0,
                    bottom: 0
                },
                scale: {
                    pillar: 60,
                    min: 10
                },
                show: {
                    fold: true
                },
                color: {
                    background: "transparent"
                },
                popWin: { type: "move" },
                maxin: {
                    //show: true,
                    lineWidth: 30,     // 线长
                    skewx: 0,            // x偏移   
                    skewy: 0,            // y偏移
                },
                onComplete: function () {
                    //$("#emchartk").remove('.loading');
                },
                onFold: function (display, type) {
                    if (display === 'block') {
                        $('#cyq-btn').hide();
                    }
                    else {
                        $('#cyq-btn').show();
                    }
                },
                onClick: function () {
                    if (typeof sendTrackLog === 'function') {
                        sendTrackLog('DIV', 'Click', 'xqzx_hsAgxqdy_hqt_djztlj');
                    }
                    window.open("//quote.eastmoney.com/concept/" + (window.Def._Market === '1' ? 'sh' : 'sz') + window.Def._Code + ".html?from=classic");
                },
                onError: function (e) {
                    console.error(e)
                }
            }),
            params = {
                id: window.Def._Code + window.Def._Market,
                type: "k",
                authorityType: "",
            };
        function init() {

            events();
            // 复权判断
            var fq = GetCookie("emhq_picfq");
            if (fq === "1") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=before]").html());
                params.authorityType = "fa";
            }
            else if (fq === "2") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=before]").html());
                params.authorityType = "ba";
            }

            load();
        }

        var isinit = true

        function load() {
            $("#js_box").removeClass("hidefixed");
            clearTimeout(timer);
            // var _load = function () {
            //     $.ajax({
            //         url: "//pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js?rtntype=5&token=4f1862fc3b5e77c150a2b985b12db0fd",
            //         dataType: "jsonp",
            //         scriptCharset: 'utf-8',
            //         data: params,
            //         jsonp: "cb",
            //         success: function (json) {
            //             // console.log(json)
            //             if (!json || json.stats === false) return false;
            //             kchart.setData({ k: json });
            //             kchart.draw();
            //         },
            //         error: function (e) {
            //             console.error(e);
            //         },
            //         complate: function () {
            //             timer = setTimeout(load, 60 * 1000);
            //         }
            //     });
            // };
            // _load();
            if (isinit) {
                kchart.draw()
                isinit = false
            }
            else{
                kchart.reDraw()
            }
            
            timer = setTimeout(load, 60 * 1000);
        }

        function events() {
            $("#beforeBackRight dl dd").click(function () {
                $("#beforeBackRight span").html($(this).html());
                var v = $(this).attr("value");
                $("#beforeBackRight").attr("value", v);
                //var authorityType = v === "before" ? "fa" : v === "back" ? "ba" : "";
                var authorityType = v === "before" ? 1 : v === "back" ? 2 : 0;
                // console.info(authorityType)
                kchart.setCfq(authorityType)
                //load();
                var at = v === "before" ? "1" : v === "back" ? "2" : "0";
                if ($("#js_box").is(":visible")) {
                    $("#select4 dd[value=" + at + "]").click();
                    WriteCookie("emhq_picfq", at, 8760);
                }
            });

            $("#changektab span").click(function () {
                $("#changektab span").removeClass("cur");
                $(this).addClass("cur");
                kchart.setKType($(this).attr("value"))
                // switch ($(this).attr("value")) {
                //     case "D":
                //         params.type = "k";
                //         break;
                //     case "W":
                //         params.type = "wk";
                //         break;
                //     case "M":
                //         params.type = "mk";
                //         break;
                //     case "M5":
                //         params.type = "m5k";
                //         break;
                //     case "M15":
                //         params.type = "m15k";
                //         break;
                //     case "M30":
                //         params.type = "m30k";
                //         break;
                //     case "M60":
                //         params.type = "m60k";
                //         break;
                // }
                // load();
            });

            $("#scale-plus").click(function () {
                kchart.shorten();
            });

            $("#scale-minus").click(function () {
                kchart.elongate();
            });

            $("#beforeBackRight").mouseenter(function () {
                this.getElementsByTagName("dl")[0].style.display = "block";
            });

            $("#beforeBackRight").mouseleave(function () {
                this.getElementsByTagName("dl")[0].style.display = "none";
            });
        }
        init();
    }
});

if(0){
    $('#image_box').show();  
    $('#js_box').hide(); 
    $('#image_box .js_show').hide();
}  