
// require(["emcharts4"], function (emcharts3) {

;(function(){
  


//data.js
/**
 * Created by zbc on 14-5-6.
 */
// "use strict";
var params = {
    // id: window.Def._Code + window.Def._Market,
    klt: "101",
    fqt: "0",//复权
    testenv:"2"
};
window.allUri = {
    imageURL: "//pifm.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx?nid=0.300059&UnitWidth=-6&imageType=KXL&EF=&Formula=RSI&AT=&&type=m5&token=44c9d251add88e27b65ed86506f6e5da"
};
window.imageOpition = {
    nid: '1'+kLine.stockCode,
    type: "",
    Formula: "RSI",
    EF: "",
    UnitWidth: -6,
    AT: ""
};

    var commonApi = "//push2.eastmoney.com/"; //行情接口通用域名
    var tsApi = "//" + (Math.floor(Math.random() * 99) + 1) + ".push2.eastmoney.com/"; //行情接口推送域名
    /**
     * 获取url参数
     * @param {string} variable 参数名
     */
    function getQueryString(variable) {
        try {
            var query = window.location.search.substring(1);
            var vars = query.split("&");
            for (var i = 0; i < vars.length; i++) {
                var pair = vars[i].split("=");
                if (pair[0] == variable) {
                    return pair[1];
                }
            }
            return false;
        } catch (error) {
            return false;
        }
    }

    if (getQueryString("hq-env") === "test") {
        commonApi = "http://61.129.249.233:18665/";
        tsApi = "http://61.129.249.233:18665/";
    }

(function () {
    $('#select2').mouseenter(function () {
        $('#select2 dl').show();
    });
    $('#select2').mouseleave(function () {
        $('#select2 dl').hide();
    });
    function myselect(ap, func) {
        if (!FUC.$(ap)) return;
        FUC.addEvent(FUC.$(ap), "mouseenter", function (e) {
            this.getElementsByTagName("dl")[0].style.display = "block";
        }, false);

        FUC.addEvent(FUC.$(ap), "mouseleave", function (e) {
            this.getElementsByTagName("dl")[0].style.display = "none";
        }, false);

        var b = FUC.$(ap).getElementsByTagName("dl")[0];
        var a = b.children;

        for (var i = 0; i < a.length; i++) {
            a[i].onclick = function () {
                var is = i;
                FUC.$(ap).getElementsByTagName("span")[0].innerHTML = this.innerHTML;
                FUC.$(ap).getElementsByTagName("span")[0].setAttribute("value", this.getAttribute("value"));
                b.style.display = 'none';
                func && func(this.getAttribute("value"));
            }
        }
    }

    myselect("select1", function (a) {

    });
    myselect("select2", function (a) {

        var hyid = $("#pylist").attr("value");
        window.phIsFirst = true;
        phrank(a, hyid);
    });
    //myselect("select3", function (a) {

    //});
    myselect("select4", function (a) {
        if ($("#image_box").is(":visible")) {
            switch (a) {
                case "1":
                    $("#beforeBackRight dl dd[value=before]").click();
                    break;
                case "2":
                    $("#beforeBackRight dl dd[value=back]").click();
                    break;
                default: $("#beforeBackRight dl dd[value=]").click();
                    break;
            }
            WriteCookie("emhq_picfq", a, 8760);
        }
        imageOpition.AT = a;
        changeImage();
              
       
    });

    LiPic.changeDiv({
        id: "tab1",
        dom: ["hqbj", "zjl"],
        selectedClass: "cur"
    });

    // LiPic.changeDiv({
    //     id: "plydUl",
    //     dom: ["pkydList", "allpkydBox"],
    //     selectedClass: "cur",
    //     callBacks: function (sender, changed) {
    //         if (!_this) return;
    //         if ($("#pkydList").is(":visible") && changed) {
    //             _this.GetPKYD(_this._Code, _this._Market);
    //         } else if (changed) {
    //             _this.GetAllPKYD();
    //         }
    //     }
    // });

    //LiPic.changeDiv2({
    //    id:"tab3",
    //    selectedClass:"cur",
    //    dom: ["cggy1", "cggy2"],
    //    domt: ["cgyyt1", "cgyyt2"]
    //});

    // LiPic.changeDiv2({
    //     id: "tab4",
    //     dom: ["sszj", "phzj"],
    //     domt: ["zjlxuptb", "zjlxuptc"],
    //     selectedClass: "cur"
    // });

    LiPic.changeDiv({ 
        id: "tab6",
        dom: ["favorBox", "historyBox"],    
        selectedClass: "cur"
    });
    LiPic.changeDiv({
        id: "tab5",
        dom: ["wahaha", "jdzfox"],
        selectedClass: "cur",
        callBacks: function () {
            if ($("#tab5 .cur h3").html() == "阶段涨幅") {
                getzdzf();
                getzdzf_sse();
            }
        }
    });
    new LIB.actTab({
        pnode: "actTab4",
        callBacks: function (a) {
            imgChangeNode1(a);
        }
    });

    new LIB.actTab({
        pnode: "pictit",
        callBacks: getImageValue
    });

    //LiPic.changeDiv({
    //    id: "tab6",
    //    dom: ["cyggzh", "fxgs"],
    //    selectedClass: "cur"
    //});

    //LiPic.changeDiv({
    //    id: "tab7",
    //    dom: ["zbList", "mnmmList"],
    //    selectedClass: "cur"
    //});

    /*new LIB.actTab({
        pnode: "actTab3"
    });*/

    //新版阶段涨幅
    function getzdzf() {
        //var url = 'http://push2.eastmoney.com/api/qt/slist/get?pi=0&pz=20&po=1&fields=f12,f14,f3,f127,f109,f149,f160&spt=1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=' + stockEnity.UnifiedId;
        var url = commonApi + 'api/qt/slist/get?pi=0&pz=20&po=1&fields=f12,f14,f3,f127,f109,f149,f160&spt=1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=' + stockEnity.UnifiedId
        // var url = "http://61.129.249.233:18665/api/qt/slist/get?fid=f3&pi=0&pz=20&po=1&fields=f12,f14,f3,f127,f109,f149,f160&spt=1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" +stockEnity.UnifiedId;
        $.ajax({
            url: url,
            dataType: "jsonp",
            scriptCharset: "utf-8",
            jsonp: "cb",
            success: function (json) {
                // console.log(json)
                if(json.data){
                    var stockdata = json.data.diff[0];
                    var blockdata = json.data.diff[1];
                    // console.log(stockdata)
                    // console.log(blockdata)
                    var to1 = stockdata.f3>0?'red':(stockdata.f3<0?'green':'#494949');
                    var to3 = stockdata.f127>0?'red':(stockdata.f127<0?'green':'#494949');
                    var to5 = stockdata.f109>0?'red':(stockdata.f109<0?'green':'#494949');
                    var to6 = stockdata.f149>0?'red':(stockdata.f149<0?'green':'#494949');
                    var to10 = stockdata.f160>0?'red':(stockdata.f160<0?'green':'#494949');
                    var block1 = blockdata.f3>0?'red':(blockdata.f3<0?'green':'#494949');
                    var block3 = blockdata.f127>0?'red':(blockdata.f127<0?'green':'#494949');
                    var block5 = blockdata.f109>0?'red':(blockdata.f109<0?'green':'#494949');
                    var block6 = blockdata.f149>0?'red':(blockdata.f149<0?'green':'#494949');
                    var block10 = blockdata.f160>0?'red':(blockdata.f160<0?'green':'#494949');
                    $("#jdzf").html(
                        '<tr><td>今日</td><td style=color:'+to1+'>'+(stockdata.f3/100).toFixed(2)+'%</td><td style=color:'+block1+'>'+(blockdata.f3/100).toFixed(2)+'%</td></tr>'+
                        '<tr><td>3日</td><td style=color:'+to3+'>'+(stockdata.f127/100).toFixed(2)+'%</td><td style=color:'+block3+'>'+(blockdata.f127/100).toFixed(2)+'%</td></tr>'+
                        '<tr><td>5日</td><td style=color:'+to5+'>'+(stockdata.f109/100).toFixed(2)+'%</td><td style=color:'+block5+'>'+(blockdata.f109/100).toFixed(2)+'%</td></tr>'+
                        '<tr><td>6日</td><td style=color:'+to6+'>'+(stockdata.f149/100).toFixed(2)+'%</td><td style=color:'+block6+'>'+(blockdata.f149/100).toFixed(2)+'%</td></tr>'+
                        '<tr><td>10日</td><td style=color:'+to10+'>'+(stockdata.f160/100).toFixed(2)+'%</td><td style=color:'+block10+'>'+(blockdata.f160/100).toFixed(2)+'%</td></tr>'                    
                    ).css('text-align','center');
                }
                
            }
        });
    }
    //新版阶段涨幅推送
    function getzdzf_sse() {
        //var url = 'http://'+(Math.floor(Math.random() * 99) + 1)+'.push2.eastmoney.com/api/qt/slist/sse?fid=f3&pi=0&pz=20&po=1&fields=f12,f14,f3,f127,f109,f149,f160&spt=1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" +stockEnity.UnifiedId'
        var url = tsApi + 'api/qt/slist/sse?fid=f3&pi=0&pz=20&po=1&fields=f12,f14,f3,f127,f109,f149,f160&spt=1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" +stockEnity.UnifiedId'
        // var url = "http://61.129.249.233:18665/api/qt/slist/sse?fid=f3&pi=0&pz=20&po=1&fields=f12,f14,f3,f127,f109,f149,f160&spt=1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" +stockEnity.UnifiedId;
        var evtSource = new EventSource(url);
        evtSource.onmessage = function (msg) {
            var json = msg.data;
            // console.log(json)
            if(json.data){
                var stockdata = json.data.diff[0];
                var blockdata = json.data.diff[1];
                var to1 = stockdata.f3>0?'red':(stockdata.f3<0?'green':'#494949');
                var to3 = stockdata.f127>0?'red':(stockdata.f127<0?'green':'#494949');
                var to5 = stockdata.f109>0?'red':(stockdata.f109<0?'green':'#494949');
                var to6 = stockdata.f149>0?'red':(stockdata.f149<0?'green':'#494949');
                var to10 = stockdata.f160>0?'red':(stockdata.f160<0?'green':'#494949');
                var block1 = blockdata.f3>0?'red':(blockdata.f3<0?'green':'#494949');
                var block3 = blockdata.f127>0?'red':(blockdata.f127<0?'green':'#494949');
                var block5 = blockdata.f109>0?'red':(blockdata.f109<0?'green':'#494949');
                var block6 = blockdata.f149>0?'red':(blockdata.f149<0?'green':'#494949');
                var block10 = blockdata.f160>0?'red':(blockdata.f160<0?'green':'#494949');
                $("#jdzf").html(
                    '<tr><td>今日</td><td style=color:'+to1+'>'+(stockdata.f3/100).toFixed(2)+'%</td><td style=color:'+block1+'>'+(blockdata.f3/100).toFixed(2)+'%</td></tr>'+
                    '<tr><td>3日</td><td style=color:'+to3+'>'+(stockdata.f127/100).toFixed(2)+'%</td><td style=color:'+block3+'>'+(blockdata.f127/100).toFixed(2)+'%</td></tr>'+
                    '<tr><td>5日</td><td style=color:'+to5+'>'+(stockdata.f109/100).toFixed(2)+'%</td><td style=color:'+block5+'>'+(blockdata.f109/100).toFixed(2)+'%</td></tr>'+
                    '<tr><td>6日</td><td style=color:'+to6+'>'+(stockdata.f149/100).toFixed(2)+'%</td><td style=color:'+block6+'>'+(blockdata.f149/100).toFixed(2)+'%</td></tr>'+
                    '<tr><td>10日</td><td style=color:'+to10+'>'+(stockdata.f160/100).toFixed(2)+'%</td><td style=color:'+block10+'>'+(blockdata.f160/100).toFixed(2)+'%</td></tr>'                    
                ).css('text-align','center');
            }
            
        }
        
    }
    function imgChangeNode1(a) {
        var t = parseInt(a.getAttribute("index"));
        if (t == 0) {
            $x("picr").src = PicN.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "rc") + "&rt=" + formatm();
        } else if (t == 1) {
            if (_this.IsAGu == "1") {
                $x("picr").src = PicN.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "r") + "&rt=" + formatm();
            } else {
                $x("picr").src = PicN.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "rc") + "&rt=" + formatm();
            }
        } else {
            var md = "M" + (t - 1);
            // $x("picr").src = "//webquotepic.eastmoney.com/GetPic.aspx?imagetype=t&type=" + md + "&id=" + _this._Code + "" + _this._Market + "&token=" + window.token + "&rt=" + formatm();
        }
    }
    function changeImage(link) {
        var url = link || allUri.imageURL;
        var image_url = FUC.changeURL(url, imageOpition);
        var PicUrl = image_url + "&_=" + Math.random();
        // FUC.$("pick").setAttribute("src", PicUrl);
    }

    function InitFQImg() {
        var num = GetCookie("emhq_picfq");
        var itemName = "不复权";
        var itemNum = num == "" ? "0" : num;
        window.imageOpition.AT = num;
        switch (num) {
            case "1": {
                itemName = "前复权";
                break;
            }
            case "2": {
                itemName = "后复权";
                break;
            }
        }
        FUC.$("select4").getElementsByTagName("span")[0].innerHTML = itemName;
        changeImage();
    }
    function getImageValue(arr) {
        var link;
        imageOpition.type = arr.getAttribute("value");
        switch (imageOpition.type) {
            case "M5":
            case "M15":
            case "M30":
            case "M60":
                link = "//pifm3.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx?ID={id}&UnitWidth={uw}&imageType=KXL&EF=&Formula={formula}&AT=&&type={type}&token=44c9d251add88e27b65ed86506f6e5da";
                break;
            default: break;
        }
        changeImage(link);
        return;
    }
    new LiPic.change({
        dom1: FUC.$("zkeyb"), dom2: FUC.$("zkeyc"), callbacks: function (arg) {
            imageOpition.Formula = arg.getAttribute("value");
            changeImage();
        }
    });
    new LiPic.change({
        dom1: FUC.$("zkeyc"), dom2: FUC.$("zkeyb"), callbacks: function (arg) {
            imageOpition.Formula = arg.getAttribute("value");
            changeImage();
        }
    });
    new LiPic.change({
        dom1: FUC.$("zkeya"), callbacks: function (arg) {
            imageOpition.EF = arg.getAttribute("value");
            changeImage();
        }
    });

    //拉长 缩短线
    FUC.addEvent(FUC.$("picklc"), "click", function (e) {
        var width = imageOpition.UnitWidth;
        if (width <= -8) return;
        imageOpition.UnitWidth = width - 1;
        changeImage();
    }, false);
    FUC.addEvent(FUC.$("picksd"), "click", function (e) {
        var width = imageOpition.UnitWidth;
        if (width >= 0) return;
        imageOpition.UnitWidth = width + 1;
        changeImage();
    }, false);

    $(".flash_show, #flash_box").hide();
    //$(".flash_show").click(function () {
    //    if (/\((iPhone|iPad|iPod)/i.test(navigator.userAgent)) {
    //        showimg();
    //    } else {
    //        showfls();
    //    }
    //});

    $(".img_show, .image_show2").click(function () {
        showimg();
    });


    
    InitFQImg();
        
    // icomet();
    //remember();
    //gotobeta();
    //window.rememberversion = remember;      

    // function icomet() {
    //     var cname = "TSQ_" + (Def.market === "1" ? "SH" : "SZ") + Def.code,
    //         tsq;
    //     Def.stop();
    //     // tsq = new TopSpeedQuote(cname, {
    //     //     host: "push1.eastmoney.com",
    //     //     loadPage: true,
    //     //     enableMutiDomain: true
    //     // });
    //     tsq = new TSQrepalce(cname, {
    //             host: "push1.eastmoney.com",
    //             loadPage: true,
    //             enableMutiDomain: true
    //         });
    //     setTimeout(function () {
    //         tsq.start();
    //     }, 2.5 * 1000);
    // }

    //function gotobeta() {
    //    var type = GetCookie("em-quote-version") ;       
    //    if (type === 'topspeed') {
    //        location.replace('//quote.eastmoney.com/concept/' + (Def.market === "1" ? "sh" : "sz") + Def.code + '.html');
    //    }
    //}

    //function remember(value) {
    //    if (localStorage) {
    //        if (value) localStorage.setItem('rememberme', value);
    //        if (localStorage.getItem('rememberme') === '1') {
    //            gotobeta();
    //        }
    //    }
    //}   
    
})();
//个股行情 
$.ajax({
    // url:'http://61.152.230.191/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f288&secid=' +stockEnity.UnifiedId,
    //url:'http://push2.eastmoney.com/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f288&secid=' +stockEnity.UnifiedId,
    url: commonApi + 'api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f163,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f288&secid=' + stockEnity.UnifiedId,
    scriptCharset: "utf-8",
    dataType: "jsonp",
    jsonp: "cb",
    success: function (json) {  
        // console.log('个股行情')

        // console.log(json) 
        if(!json.data) return
        //行业
        // console.log(json.data.f127.length)
        if(json.data.f127.length>3){
            $('.xggpbox .tit').html('<a href=http://quote.eastmoney.com/center/boardlist.html#boards-'+json.data.f198+'1 target="_blank">'+json.data.f127.substring(0,2)+'<br>'+json.data.f127.substring(2,4)+'</a>')                
        }else{
            $('.xggpbox .tit').html('<a href=http://quote.eastmoney.com/center/boardlist.html#boards-'+json.data.f198+'1 target="_blank">'+json.data.f127+'</a>')                
        }
        if(json.data.f127 && json.data.f127.length > 4){
            $('#restock').html(json.data.f127.substring(0,4)+"..")
        }else{
            $('#restock').html(json.data.f127)
        }
        
        $('#restock').attr('href','http://quote.eastmoney.com/center/boardlist.html#boards-'+json.data.f198+'1')
        $('#restockmore').attr('href','http://quote.eastmoney.com/center/boardlist.html#boards-'+json.data.f198+'1')
        // $('#hyybhref').attr('href','http://data.eastmoney.com/report/'+json.data.f198.substring(3,6)+'yb.html')
        // $('#hyybmore').attr('href','http://data.eastmoney.com/report/'+json.data.f198.substring(3,6)+'yb.html')
        
        var hyUrl = 'http://data.eastmoney.com/report/';
        if(json.data.f198 && json.data.f198.length>=6){
            var hyUrl = 'http://data.eastmoney.com/report/industry.jshtml?hyid='+json.data.f198.substring(3,6)
        }
        $('#hyybhref').attr('href',hyUrl)
        $('#hyybmore').attr('href',hyUrl)
        
        $('#career').html(json.data.f127)
        $('#hystock').attr('href','http://stock.eastmoney.com/hangye/hy'+json.data.f198.substring(3,6)+'.html')
        if(!json.data.f198){
            $('#hyyw').hide();
        }
        //面包屑导航
        $('#histit').before('<div class="nav"><a href="http://quote.eastmoney.com/center/" target="_blank">行情首页</a> &gt;<a href="http://quote.eastmoney.com/center/list.html#10" target="_blank">上证A股</a> &gt;<a href=http://quote.eastmoney.com/center/boardlist.html#boards-'+json.data.f198+'1 target="_blank">'+json.data.f127+'</a> &gt; '+json.data.f58+'</div>')
        //名称标记
        $('.qphox #name').html(json.data.f58);
        $('.qphox #code').html(stockEnity.Code);
        //新版两融，深股通，创业板，转债标志
        if(json.data.f110 == 1&&json.data.f111 == 2){
            $('#jys-box').show().find("b ").text("沪主板");
            $('#jys-box').attr("title", "该股票在沪主板上市");
            $('#jys-box').find("a").attr("href", "//quote.eastmoney.com/center/gridlist.html#sh_a_board");
        }
        if(json.data.f110 == 0&&json.data.f111 == 6){
            $('#jys-box').show().find("b ").text("深主板");
            $('#jys-box').attr("title", "该股票在深主板上市");
            $('#jys-box').find("a").attr("href", "//quote.eastmoney.com/center/gridlist.html#sz_a_board");
        }
        if(json.data.f107==0&&json.data.f111==13){
            $('#jys-box').show().find("b ").text("中小板");
            $('#jys-box').attr("title", "该股票在中市");
            $('#jys-box').find("a").attr("href", "//quote.eastmoney.com/center/gridlist.html#sme_board");
        }
        if(json.data.f107==0&&json.data.f111==80){
            $('#jys-box').show().find("b ").text("创业板");
            $('#jys-box').attr("title", "该股票在创业板上市");
            $('#jys-box').find("a").attr("href", "//quote.eastmoney.com/center/gridlist.html#gem_board");
        }
        if ((json.data.f177)&512) {
            $("#hgt_icon").show();
        } else if ((json.data.f177)&1024) {
            $("#sgt_icon").show();
        }
        if ((json.data.f177)&64) {
            $("#rongi").show();
        }else {
            $("#rongi").hide();
        }
        if (json) {
            $("#kcb").show();
        }
        if(json.data.f177 & 32768){
            $("#hlt").show().find("b ").text("沪伦通");
            $("#hlt").attr("title", "该股票为沪伦通标的");
            $("#hlt").find("a").attr("href", "http://quote.eastmoney.com/uk/"+json.data.f286+"."+json.data.f285+".html");
        
        
            $("#GDR").show().find("b ").text("GDR");
            $("#GDR").attr("title", "该股票存在关联的GDR（全球存托凭证）");
            $("#GDR").find("a").attr("href", "http://quote.eastmoney.com/uk/"+json.data.f286+"."+json.data.f285+".html");
        }
        var marketzhai = json.data.f263 == "1" ? "sh" : "sz";
        if (json.data.f262&&json.data.f262!='-') {
            $("#Z-box").show().find("b").text("可转债");
            $("#Z-box").attr("title", "点击查看关联可转债行情");
            $("#Z-box").find("a").attr("href", "http://quote.eastmoney.com/bond/" +marketzhai+ json.data.f262+".html");
        }else{
            $("#Z-box").hide()
        }
        var marketH = json.data.f257;
        if (json.data.f256&&json.data.f256!='-') {
            $("#H-box").show().find("b").text("H股");
            $("#H-box").attr("title", "点击查看关联H股行情");
            $("#H-box").find("a").attr("href", "http://quote.eastmoney.com/unify/r/" +marketH+'.'+json.data.f256);
        }else{
            $("#H-box").hide()
        } 
        var marketB = json.data.f270 == "1" ? "sh" : "sz";
        if (json.data.f269&&json.data.f269!='-') {
            $("#B-box").show().find("b ").text("B股");
            $("#B-box").attr("title", "点击查看关联B股行情");
            $("#B-box").find("a").attr("href", "http://quote.eastmoney.com/" +marketB+ json.data.f269+".html");
        }else{
            $("#B-box").hide();
        }
        //新版时间
        var timehq = formateDate(new Date(json.data.f86*1000), "HH:mm");
        if(time_range('9:15','9:30',timehq)){
            $(".changeFenshiTab span[type=panqian]").click()
        } 
        var time = formateDate(new Date(json.data.f86*1000), "yyyy年MM月dd日");
        var minute = (new Date(json.data.f86*1000).toString()).split(" ");
        // console.log(new Date(json.data.f86*1000))
        var d = new Date();
        weekday = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");   
        var n = weekday[d.getDay()];
        $("#day").html('('+time+' '+n+' '+minute[4]+')');
        //交易状态
        if(json.data.f259){
            var jycontent='';
            if(json.data.f259==1){
                jycontent="启动"
            }
            else if(json.data.f259==2){
                jycontent="开盘集合竞价"
            }
            else if(json.data.f259==3){
                jycontent="连续自动撮合"
            }
            else if(json.data.f259==4){
                jycontent="停牌"
            }
            else if(json.data.f259==5){
                jycontent="收盘集合竞价"
            }
            else if(json.data.f259==6){
                jycontent="闭市"
            }
            else if(json.data.f259==7){
                jycontent="交易结束"
            }
            else if(json.data.f259==8){
                jycontent="启动时段"
            }
            else if(json.data.f259==9){
                jycontent="集中撮合时段"
            }
            else if(json.data.f259==10){
                jycontent="盘后固定价格交易"
            }
            else if(json.data.f259==11){
                jycontent="闭市时段"
            }
            else if(json.data.f259==12){
                jycontent="停牌"
            }
            $('#tradestatus').html(jycontent)            
        }
        yestoday= json.data.f60;
        //判断是否停牌 暂停上市
        if((json.data.f177)&32){
            $("#arrowud").html('<strong id="price9" class="xp1" data-bind="43" style="width: 130px;"><span class="lstng">暂停上市</span></strong>')
        }
        // else if(json.data.f78==3||json.data.f78==2){
        //     $("#arrowud").html('<strong id="price9" class="xp1" data-bind="43""><span class="lstng"><a href="http://data.eastmoney.com/tfpxx/" target="_blank" class="red wz">停牌</a></span></strong>')
        // }
        else if((json.data.f177)&16){
            $("#arrowud").html('<strong id="price9" class="xp1" data-bind="43" style="width: 130px;"><span class="lstng">未上市</span></strong>')
        }else{
            if(json.data.f43!='-'){
                if(json.data.f43>=1000){
                    $("#price9").css({'top':'20px','font-size':'25px'})
                }
                $("#price9").html(json.data.f43.toFixed(2)); 
            }
            if(json.data.f169!='-'){
                $("#km1").html(json.data.f169.toFixed(2));
            }
            if(json.data.f170!='-'){
                if(json.data.f170>=1000){
                    $("#km2").html((json.data.f170/100).toFixed(2)+"倍"); 
                }else{
                    $("#km2").html(json.data.f170.toFixed(2)+"%");            
                }
            }
            
            
        }  
        if(json.data.f169){
            if(json.data.f169<0){
                $("#arrowud").css('color','green');
                $("#arrow-find").removeClass("xp2 up-arrow");
                $("#arrow-find").addClass("xp2 down-arrow");
                $("#rgt3").css('color','green');
            }else if(json.data.f169>0){
                $("#arrowud").css('color','red');
                $("#arrow-find").removeClass("xp2 down-arrow");
                $("#arrow-find").addClass("xp2 up-arrow");
                $("#rgt3").css('color','red');
            }
        }
        else{
            $("#arrow-find").removeClass("xp2 up-arrow");
            $("#arrow-find").removeClass("xp2 down-arrow");
            $("#arrowud").css('color','#494949');
            $("#rgt3").css('color','#494949');
            document.title = (json.data.f58 + " " + json.data.f43.toFixed(2) + " " + json.data.f169.toFixed(2) + "(" + json.data.f170.toFixed(2) + "%) _ 股票行情 _ 东方财富网");
        }
        if(json.data.f60!='-'){
            $("#gt8").html(json.data.f60.toFixed(2));//昨收
        }
        if(json.data.f43!='-'){
            $("#gt15").html(json.data.f43.toFixed(2)).addClass(udcls(json.data.f43,json.data.f60));//最新            
        }
        if(json.data.f46!='-'){
            $("#gt1").html(json.data.f46.toFixed(2)).addClass(udcls(json.data.f46,json.data.f60));$("#gt1").addClass('txtl');//今开            
        }
        if(json.data.f44!='-'){
            $("#gt2").html(json.data.f44.toFixed(2)).addClass(udcls(json.data.f44,json.data.f60));$("#gt2").addClass('txtl');//最高            
        }
        if(json.data.f168!='-'){
            $("#gt4").html(json.data.f168.toFixed(2)+"%");//换手                                            
        }
        if(json.data.f277!='-'){
            $("#gt16").html(fmtdig(json.data.f277, 1, 2, "", true));//注册资本
        }
        if(json.data.f51!='-'){
            $("#gt3").html(json.data.f51.toFixed(2)).addClass('red');//涨停
            $("#zthq").html(json.data.f51.toFixed(2)).addClass('red');//涨停
        }
        if(json.data.f260!='-'){
            // $("#gt17").html(fmtdig(json.data.f260, 1, 2, "", true) + "手");//盘后成交量
            $("#gt17").html(precision(json.data.f260) + "手");//盘后成交量
            
        }
        if(json.data.f47!='-'){
            $("#gt5").html(fmtdig(json.data.f47, 1, 2, "", true) + "手");//成交量            
        }
        if(json.data.f45!='-'){
            $("#gt9").html(json.data.f45.toFixed(2)).addClass(udcls(json.data.f45,json.data.f60));$("#gt9").addClass('txtl');//最低            
        }
        if(json.data.f50!='-'){
            $("#gt11").html(json.data.f50.toFixed(2));//量比            
        }
        if(json.data.f278!='-'){
            $("#gt21").html(fmtdig(json.data.f278, 1, 2, "", true));//发行股本
        }
        if(json.data.f52!='-'){
            $("#gt10").html(json.data.f52.toFixed(2)).addClass("txtl green");//跌停
            $("#dthq").html(json.data.f52.toFixed(2)).addClass("txtl green");//跌停
        }
        if(json.data.f261!='-'){
            $("#gt18").html(fmtdig(json.data.f261, 1, 2, "", true));//盘后成交额
        }
        if(json.data.f48!='-'){
            $("#gt12").html(fmtdig(json.data.f48, 1, 2, "", true));//成交额            
        }
        if(json.data.f171!='-'){
            $("#gt19").html(json.data.f171.toFixed(2)+'%');//振幅
        }
        if(json.data.f71!='-'){
            $("#gt20").html(json.data.f71.toFixed(2)).addClass(udcls(json.data.f44,json.data.f60));//均价            
        }
        if(json.data.f164!='-'){
            $("#gt6").html(json.data.f164.toFixed(2));//市盈滚动      
            $("#gdsyl").html(json.data.f164.toFixed(2));//市盈滚动        
        }
        if(json.data.f162!='-'){
            $("#dtsyl").html(json.data.f162.toFixed(2));//市盈动态     
        }
        if(json.data.f163!='-'){
            $("#jtsyl").html(json.data.f163.toFixed(2));//市盈静态     
        }
        if(json.data.f85!='-'){
            $("#gt14").html((json.data.f85/100000000).toFixed(2)+'亿');//流通股本            
        }
        if(json.data.f279!='-'){
            $("#gt7").html((json.data.f279==1)?'是':'否');//同权同股比例
        }
        if(json.data.f288!=-1){
            var profit = json.data.f288>0?'否':'是'
            $('#gt13').html(profit)
        }
        //行情报价
        if(json.data.f191!='-'){
            $("#irwb").html(json.data.f191.toFixed(2) + "%").addClass(udcls(json.data.f191));//委比            
        }
        if(json.data.f192!='-'){
            $("#irwc").html(precision(json.data.f192)).addClass(udcls(precision(json.data.f192)));//委差   
        }
        if(json.data.f31!='-'){
            $("#gts5a").html(json.data.f31.toFixed(2)).addClass(udcls(json.data.f31, json.data.f60)); 
        }
        if(json.data.f32!='-'){
            $("#gts5b").html(precision(json.data.f32)); 
        }
        if(json.data.f33!='-'){
            $("#gts4a").html(json.data.f33.toFixed(2)).addClass(udcls(json.data.f33, json.data.f60));  
        }
        if(json.data.f34!='-'){
            $("#gts4b").html(precision(json.data.f34));
        }
        if(json.data.f35!='-'){
            $("#gts3a").html(json.data.f35.toFixed(2)).addClass(udcls(json.data.f35, json.data.f60));
        }
        if(json.data.f36!='-'){
            $("#gts3b").html(precision(json.data.f36)); 
        }
        if(json.data.f37!='-'){
            $("#gts2a").html(json.data.f37.toFixed(2)).addClass(udcls(json.data.f37, json.data.f60)); 
        }
        if(json.data.f38!='-'){
            $("#gts2b").html(precision(json.data.f38)); 
        }
        if(json.data.f39!='-'){
            $("#gts1a").html(json.data.f39.toFixed(2)).addClass(udcls(json.data.f39, json.data.f60)); 
        }
        if(json.data.f40!='-'){
            $("#gts1b").html(precision(json.data.f40)); 
        }
        if(json.data.f19!='-'){
            $("#gtb1a").html(json.data.f19.toFixed(2)).addClass(udcls(json.data.f19, json.data.f60)); 
        }
        if(json.data.f20!='-'){
            $("#gtb1b").html(precision(json.data.f20));
        }
        if(json.data.f17!='-'){
            $("#gtb2a").html(json.data.f17.toFixed(2)).addClass(udcls(json.data.f17, json.data.f60));  
        }
        if(json.data.f18!='-'){
            $("#gtb2b").html(precision(json.data.f18));
        }
        if(json.data.f15!='-'){
            $("#gtb3a").html(json.data.f15.toFixed(2)).addClass(udcls(json.data.f15, json.data.f60));  
        }
        if(json.data.f16!='-'){
            $("#gtb3b").html(precision(json.data.f16));
        }
        if(json.data.f13!='-'){
            $("#gtb4a").html(json.data.f13.toFixed(2)).addClass(udcls(json.data.f13, json.data.f60)); 
        }
        if(json.data.f14!='-'){
            $("#gtb4b").html(precision(json.data.f14)); 
        }
        if(json.data.f11!='-'){
            $("#gtb5a").html(json.data.f11.toFixed(2)).addClass(udcls(json.data.f11, json.data.f60));  
        }
        if(json.data.f12!='-'){
            $("#gtb5b").html(precision(json.data.f12));
        }
        
         //资金流分析
        if (json.data.f135 != "-") {
            $("#hz_a").html(ForDight(parseFloat(json.data.f135/10000), 2));
            $("#hz_a").addClass(udcls(json.data.f135));
        }
        if (json.data.f136 != "-") {
            $("#hz_b").html(ForDight(parseFloat(json.data.f136/10000), 2).replace("-", ""));
            $("#hz_b").addClass(udcls(-json.data.f136));
        }
        if (json.data.f137 != "-") {
            $("#hz_c").html((json.data.f137/10000).toFixed(2));
            $("#hz_c").addClass(udcls(json.data.f137));
        } 
        if (json.data.f138 != "-"){
            $("#hz_d").html((json.data.f138 / 10000).toFixed(2) || "");        
        }
        if (json.data.f139 != "-"){
            $("#hz_e").html((json.data.f139 / 10000).toFixed(2).replace("-", "") || "");         
        }
        if (json.data.f141 != "-"){
            $("#hz_f").html((json.data.f141 / 10000).toFixed(2) || "");
        } 
        if (json.data.f142 != "-"){
            $("#hz_g").html((json.data.f142 / 10000).toFixed(2).replace("-", "") || "");
        }
        if (json.data.f144 != "-"){
            $("#hz_h").html((json.data.f144 / 10000).toFixed(2) || "");
        }
        if (json.data.f145 != "-"){
            $("#hz_i").html((json.data.f145 / 10000).toFixed(2).replace("-", "") || "");
        }
        if (json.data.f147 != "-"){
            $("#hz_j").html((json.data.f147 / 10000).toFixed(2) || "");
        }
        if (json.data.f148 != "-"){
            $("#hz_k").html((json.data.f148 / 10000).toFixed(2).replace("-", "") || "");
        }                                          
         //资金流柱状图
         var total = Math.abs(parseFloat(json.data.f140)) + Math.abs(parseFloat(json.data.f143)) + Math.abs(parseFloat(json.data.f146)) + Math.abs(parseFloat(json.data.f149));
         var i=[json.data.f140,json.data.f143,json.data.f146,json.data.f149]
         $(".picNum ul").each(function (index, elm) {                              
             if (i[index] > 0) {
                 $(this).find("div").eq(0).html("<div class=\"box\" id=\"hz_" + index + "h\"></div><span class=\"red\">" + parseFloat(Math.floor(i[index]/10000)).toFixed(0) + "</span>");
                 $(this).find("div").eq(0).css("border-bottom", "1px solid #ccc");
                 $("#hz_" + index + "h").css('height',(Math.abs(parseFloat(i[index])) / total * 36 + "px"));
             }
             if (i[index] < 0) {
                 $(this).find("div").eq(1).html("<div class=\"box\" id=\"hz_" + index + "h\"></div><span class=\"green\">" + parseFloat(Math.floor(i[index]/10000)).toFixed(0) + "</span>");
                 $(this).find("div").eq(1).css("border-top", "1px solid #ccc");
                 $("#hz_" + index + "h").css('height',(Math.abs(parseFloat(i[index])) / total * 36 + "px"));
             }  
             if (i[index] == 0) {
                $(this).find("div").eq(1).html("<div class=\"box\" id=\"hz_" + index + "h\"></div><span class=\"\">" + parseFloat(Math.floor(i[index]/10000)).toFixed(0) + "</span>");
                $(this).find("div").eq(1).css("border-top", "1px solid #ccc");
                $("#hz_" + index + "h").css('height',(Math.abs(parseFloat(i[index])) / total * 36 + "px"));
            }                             
         }); 
       
       disquote_sse(json.data.f60);
    }
});
//是否盈利测试临时安放处
// $.ajax({
//     url:'http://61.152.230.191/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&fields=f288&secid=' +stockEnity.UnifiedId,
//     scriptCharset: "utf-8",
//     dataType: "jsonp",
//     jsonp: "cb",
//     success: function (json) { 
//         console.log(json)
//         // if(json.data.f288!=-1){
//         //     var profit = json.data.f288>0?'否':'是'
//         //     $('#gt13').html(profit)
//         // }
//     }
// })
// console.log(yestoday)
//个股行情推送
function disquote_sse(yestoday){
    // var url = "http://61.152.230.191/api/qt/stock/sse?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&volt=2&fields=f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279&secid=" +stockEnity.UnifiedId;
    var url = "http://"+(Math.floor(Math.random() * 99) + 1)+".push2.eastmoney.com/api/qt/stock/sse?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&volt=2&fields=f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279&secid=" +stockEnity.UnifiedId;
    var evtSource = new EventSource(url);
    evtSource.onmessage = function (msg) {
        var json = JSON.parse(msg.data);
        if(!json.data) return
        if(json.data.f43){
            $("#price9").html(json.data.f43.toFixed(2));
            if(json.data.f43>=1000){
                $("#price9").css({'top':'20px','font-size':'25px'})
            } 
            blinker(json.data.f169,$("#price9"))    
            $("#gt15").html(json.data.f43.toFixed(2)).addClass(udcls(json.data.f43,yestoday));//最新   
            blinker(json.data.f169,$("#gt15"))  
        }
        if(json.data.f169){
            $("#km1").html(json.data.f169.toFixed(2));
            blinker(json.data.f169,$("#km1")) 
            if(json.data.f169<0){
                $("#arrowud").css('color','green');
                $("#arrow-find").removeClass("xp2 up-arrow");
                $("#arrow-find").addClass("xp2 down-arrow");
            }else if(json.data.f169>0){
                $("#arrowud").css('color','red');
                $("#arrow-find").removeClass("xp2 down-arrow");
                $("#arrow-find").addClass("xp2 up-arrow");
            }else{
                $("#arrow-find").removeClass("xp2 up-arrow");
                $("#arrow-find").removeClass("xp2 down-arrow");
                $("#arrowud").css('color','#494949');
            }
        }
        if(json.data.f170){
            if(json.data.f170>=1000){
                $("#km2").html((json.data.f170/100).toFixed(2)+"倍");          
                $("#rgt3").html((json.data.f170/100).toFixed(2)+"倍");
            }else{
                $("#km2").removeClass('red');
                $("#km2").removeClass('green');
                $("#rgt3").removeClass('red');
                $("#rgt3").removeClass('green');
                $("#km2").html(json.data.f170.toFixed(2)+"%").addClass(udcls(json.data.f170));          
                $("#rgt3").html(json.data.f170.toFixed(2)+"%").addClass(udcls(json.data.f170));           
            }
            blinker(json.data.f170,$("#km2"))
            blinker(json.data.f170,$("#rgt3")) 
        }
        if(json.data.f168){
            $("#gt4").html(json.data.f168.toFixed(2)+"%")
            blinker(0,$("#gt4"))
        }
        if(json.data.f47){
            $("#gt5").html(fmtdig(json.data.f47, 1, 2, "", true) + "手");
            blinker(0,$("#gt5"))
        }
        if(json.data.f164){
            $("#gt6").html(json.data.f164.toFixed(2));//市盈滚动
            $("#gdsyl").html(json.data.f164.toFixed(2));//市盈滚动
            blinker(0,$("#gt6"))
        }
        if(json.data.f162){
            $("#dtsyl").html(json.data.f162.toFixed(2));//动态市盈率
        }
        if(json.data.f163){
            $("#jtsyl").html(json.data.f163.toFixed(2));//静态市盈率
        }
        if(json.data.f45){
            $("#gt9").html(json.data.f45.toFixed(2)).addClass(udcls(json.data.f45,yestoday));$("#gt9").addClass('txtl');//最低        
            blinker(json.data.f169,$("#gt9"))
        }
        if(json.data.f50){
            $("#gt11").html(json.data.f50.toFixed(2));//量比
            blinker(0,$("#gt11"))
        }
        if(json.data.f48){
            $("#gt12").html(fmtdig(json.data.f48, 1, 2, "", true));//成交额
            blinker(0,$("#gt12"))                    
        }
        if(json.data.f44){
            $("#gt2").html(json.data.f44.toFixed(2)).addClass(udcls(json.data.f44,yestoday));$("#gt2").addClass('txtl');//最高
            blinker(0,$("#gt2"))                    
        }
        if(json.data.f260){
            // $("#gt17").html(fmtdig(json.data.f260, 1, 2, "", true) + "手");//盘后成交量        
            $("#gt17").html(precision(json.data.f260) + "手");//盘后成交量
            blinker(0,$("#gt17"))                    
        }
        if(json.data.f261){
            $("#gt18").html(fmtdig(json.data.f261, 1, 2, "", true));//盘后成交额     
            blinker(0,$("#gt18"))                    
        }
        if(json.data.f171){
            $("#gt19").html(json.data.f171.toFixed(2)+'%');//振幅
            blinker(0,$("#gt19"))                    
        }

        if(json.data.f71){
            $("#gt20").html(json.data.f71.toFixed(2)).addClass(udcls(json.data.f44,yestoday));//均价    
            blinker(0,$("#gt20"))                    
        }
        if(json.data.f191){
            $("#irwb").removeClass('red')
            $("#irwb").removeClass('green')
            $("#irwb").html(json.data.f191.toFixed(2) + "%").addClass(udcls(json.data.f191));//委比        
            blinker(json.data.f191,$("#irwb")) 
        }
        if(json.data.f192){
            $("#irwc").removeClass('red')
            $("#irwc").removeClass('green')
            $("#irwc").html(precision(json.data.f192)).addClass(udcls(json.data.f192));//委差        
            blinker(json.data.f192,$("#irwc"))      
        }
        //行情报价
        if(json.data.f31&&json.data.f32){
            $("#gts5a").html(json.data.f31.toFixed(2)).addClass(udcls(json.data.f31, yestoday)); $("#gts5b").html(precision(json.data.f32)); 
            blinker(json.data.f31-yestoday,$("#gts5a"))  
            blinker(0,$("#gts5b"))
        }
        if(json.data.f33&&json.data.f34){
            $("#gts4a").html(json.data.f33.toFixed(2)).addClass(udcls(json.data.f33, yestoday)); $("#gts4b").html(precision(json.data.f34)); 
            blinker(json.data.f33-yestoday,$("#gts4a"))  
            blinker(0,$("#gts4b"))
        }
        if(json.data.f35&&json.data.f36){
            $("#gts3a").html(json.data.f35.toFixed(2)).addClass(udcls(json.data.f35, yestoday)); $("#gts3b").html(precision(json.data.f36)); 
            blinker(json.data.f35-yestoday,$("#gts3a"))  
            blinker(0,$("#gts3b"))
        }
        if(json.data.f37&&json.data.f38){
            $("#gts2a").html(json.data.f37.toFixed(2)).addClass(udcls(json.data.f37, yestoday)); $("#gts2b").html(precision(json.data.f38)); 
            blinker(json.data.f37-yestoday,$("#gts2a"))  
            blinker(0,$("#gts2b"))
        }
        if(json.data.f39&&json.data.f40){
            $("#gts1a").html(json.data.f39.toFixed(2)).addClass(udcls(json.data.f39, yestoday)); $("#gts1b").html(precision(json.data.f40)); 
            blinker(json.data.f39-yestoday,$("#gts1a"))  
            blinker(0,$("#gts1b"))
        }
        if(json.data.f19&&json.data.f20){
            $("#gtb1a").html(json.data.f19.toFixed(2)).addClass(udcls(json.data.f19, yestoday)); $("#gtb1b").html(precision(json.data.f20)); 
            blinker(json.data.f19-yestoday,$("#gtb1a"))  
            blinker(0,$("#gtb1b"))
        }
        if(json.data.f17&&json.data.f18){
            $("#gtb2a").html(json.data.f17.toFixed(2)).addClass(udcls(json.data.f17, yestoday)); $("#gtb2b").html(precision(json.data.f18)); 
            blinker(json.data.f17-yestoday,$("#gtb2a"))  
            blinker(0,$("#gtb2b"))
        }
        if(json.data.f15&&json.data.f16){
            $("#gtb3a").html(json.data.f15.toFixed(2)).addClass(udcls(json.data.f15, yestoday)); $("#gtb3b").html(precision(json.data.f16)); 
            blinker(json.data.f15-yestoday,$("#gtb3a"))  
            blinker(0,$("#gtb3b"))
        }
        if(json.data.f13&&json.data.f14){
            $("#gtb4a").html(json.data.f13.toFixed(2)).addClass(udcls(json.data.f13, yestoday)); $("#gtb4b").html(precision(json.data.f14)); 
            blinker(json.data.f13-yestoday,$("#gtb4a"))  
            blinker(0,$("#gtb4b"))
        }
        if(json.data.f11&&json.data.f12){
            // console.log(typeof(json.data.f12))
            $("#gtb5a").html(json.data.f11.toFixed(2)).addClass(udcls(json.data.f11, yestoday)); $("#gtb5b").html(precision(json.data.f12)); 
            blinker(json.data.f11-yestoday,$("#gtb5a"))  
            blinker(0,$("#gtb5b"))
        }
        
        
        //资金流分析
        if(json.data.f135){
            $x("hz_a").innerHTML = ForDight(parseFloat(json.data.f135/10000), 2);    
            $x("hz_a").className = udcls(json.data.f135);                        
        }
        if(json.data.f136){
            $x("hz_b").innerHTML = ForDight(parseFloat(json.data.f136/10000), 2).replace("-", "");
            $x("hz_b").className = udcls(-json.data.f136);
        }
        if(json.data.f137){
            $x("hz_c").innerHTML = (json.data.f137/10000).toFixed(2);
            $x("hz_c").className = udcls(json.data.f137);
        }
        if(json.data.f138){
            $x("hz_d").innerHTML = (json.data.f138 / 10000).toFixed(2) || "";                        
        }
        if(json.data.f139){
            $x("hz_e").innerHTML = (json.data.f139 / 10000).toFixed(2).replace("-", "") || "";                        
        }
        if(json.data.f141){
            $x("hz_f").innerHTML = (json.data.f141 / 10000).toFixed(2) || "";                        
        }
        if(json.data.f142){
            $x("hz_g").innerHTML = (json.data.f142 / 10000).toFixed(2).replace("-", "") || "";                        
        }
        if(json.data.f144){
            $x("hz_h").innerHTML = (json.data.f144 / 10000).toFixed(2) || "";                        
        }
        if(json.data.f145){
            $x("hz_i").innerHTML = (json.data.f145 / 10000).toFixed(2).replace("-", "") || "";                        
        }
        if(json.data.f147){
            $x("hz_j").innerHTML = (json.data.f147 / 10000).toFixed(2) || "";                        
        }
        if(json.data.f148){
            $x("hz_k").innerHTML = (json.data.f148 / 10000).toFixed(2).replace("-", "") || "";                        
        }
        if(json.data.f206){
            _this.$("gts5c").innerHTML = precision(json.data.f206); _this.$("gts5c").className = udcls(json.data.f206);                                                                         
        }
        if(json.data.f206==0.0){
            _this.$("gts5c").innerHTML = '';                                  
        }
        if(json.data.f207){          
            _this.$("gts4c").innerHTML = precision(json.data.f207); _this.$("gts4c").className = udcls(json.data.f207);                                                   
        }
        if(json.data.f207==0.0){
            _this.$("gts4c").innerHTML = '';                                                 
        }
        if(json.data.f208){
            _this.$("gts3c").innerHTML = precision(json.data.f208); _this.$("gts3c").className = udcls(json.data.f208); 
        }
        if(json.data.f208==0.0){
            _this.$("gts3c").innerHTML = '';                                                 
        }
        if(json.data.f209){
            _this.$("gts2c").innerHTML = precision(json.data.f209); _this.$("gts2c").className = udcls(json.data.f209);                         
        }
        if(json.data.f209==0.0){
            _this.$("gts2c").innerHTML = '';                         
        }
        if(json.data.f210){
            _this.$("gts1c").innerHTML = precision(json.data.f210); _this.$("gts1c").className = udcls(json.data.f210); 
                // if(json.data.f210>0){
                //     $("gts1c").css('backgro')
                // }
        }
        if(json.data.f210==0.0){
            _this.$("gts1c").innerHTML = '';                         
        }
        if(json.data.f211){
            _this.$("gtb1c").innerHTML = precision(json.data.f211); _this.$("gtb1c").className = udcls(json.data.f211);                         
        }
        if(json.data.f211==0.0){
            _this.$("gtb1c").innerHTML = '';                         
        }
        if(json.data.f212){
            _this.$("gtb2c").innerHTML = precision(json.data.f212); _this.$("gtb2c").className = udcls(json.data.f212);                 
        }
        if(json.data.f212==0.0){
            _this.$("gtb2c").innerHTML = '';                         
        }
        if(json.data.f213){
            _this.$("gtb3c").innerHTML = precision(json.data.f213); _this.$("gtb3c").className = udcls(json.data.f213);                
        }
        if(json.data.f213==0.0){
            _this.$("gtb3c").innerHTML = '';                         
        }
        if(json.data.f214){
            _this.$("gtb4c").innerHTML = precision(json.data.f214); _this.$("gtb4c").className = udcls(json.data.f214);                
        }
        if(json.data.f214==0.0){
            _this.$("gtb4c").innerHTML = '';                         
        }
        if(json.data.f215){
            _this.$("gtb5c").innerHTML = precision(json.data.f215); _this.$("gtb5c").className = udcls(json.data.f215);                
        }
        if(json.data.f215==0.0){
            _this.$("gtb5c").innerHTML = '';                         
        }
    }
}

//分时成交
$.ajax({
    // url:"http://61.152.230.191/api/qt/stock/details/get?ut=fa5fd1943c7b386f172d6893dbfba10b&volt=2&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55&pos=-11&secid=" +stockEnity.UnifiedId,
    url:"http://push2.eastmoney.com/api/qt/stock/details/get?ut=fa5fd1943c7b386f172d6893dbfba10b&volt=2&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55&pos=-11&secid=" +stockEnity.UnifiedId,
    dataType: "jsonp",
    jsonp: "cb",
    beforeSend: function () {
        $("#fblist").html('<td colspan="3" style="height: 249px; text-align: center;" class="waiting ">加载中...</td>');
    },
    success: function (json) {
        //t-时间，p-价格，v-成交量，bs-内外盘，wh-仓差，type-性质，vc-成交笔数或增仓量,pch-方向
        //内外盘：1:内盘(流出) 2:外盘(流入) 3:未知 4:集合竞价
        // console.log('分时成交')
        // console.log(json)
        if(!json.data) return
        if (!json|| !(json.data.details.length)) {
            //var height = _num == 21 ? 462 : 396;
            var height = " 271px";
            $("#fblist").html("<tr><td colspan=3 style='height: " + height + "px;text-align:center'>暂无数据</td></tr>");
            $("#vvcc .more3").hide();
            return;
        }
        if (json.data.details.length==1) {
            //var height = _num == 21 ? 462 : 396;
            var height = " 271px";
            $("#fblist").html("<tr><td colspan=3 style='height: " + height + "px;text-align:center'>暂无数据</td></tr>");
            $("#vvcc .more3").hide();
            return;
        }
        var pc = parseFloat(json.data.prePrice), $tbody = $("<tbody></tbody>");
        var price =[]; 
        for(var i = 0; i < json.data.details.length; i++){
            price.push(parseFloat(json.data.details[i].substring(9,14)))
        }
        // console.log(JSON.stringify(price))
        var pch=[];
        for(var i = 0; i < price.length-1; i++){
            pch[i]=price[i+1]-price[i];
        }
        // console.log(pch)
        var data=[];
        var singledata=[];
        for (var i = 1; i < json.data.details.length; i++) {
            // console.log()
            // data.push(json.data.details[i]);
            singledata = JSON.stringify(json.data.details[i])
            data = singledata.split(',');
            data[0]=data[0].substring(1);
            data[4]=data[4].substring(0,1);
            // console.log(data)
            var $tr = $("<tr></tr>"),
                
                priceColor = data[4] != 4 ? data[1] - pc > 0 ? "red" : data[1] - pc < 0 ? "green" : "#333333" : "",
                dir = pch[i-1] < 0 ? "↓" : pch[i-1] > 0 ? "↑" : "",
                dir_c = pch[i-1] < 0 ? "green" : pch[i-1] > 0 ? "red" : "",
                vp = data[2] * data[1] * 100 * (data[4] == 1 ? -1 : data[4] == 2 ? 1 : 0),
                v_c = data[4] != 4 ? vp >= 200000 ? "#ff00ff" : vp > 0 ? "red" : vp <= -200000 ? "#14c3dc" : vp < 0 ? "green" : "" : "";

            $("<td />").text(data[0]).appendTo($tr);
            $("<td />").text(data[1]).css("color", priceColor).appendTo($tr);
            $("<td class=jtTd />")
                .append($("<span />").text(precision(parseFloat(data[2]))).css("color", v_c))
                .append($("<span class=jtIcon />").text(dir).css("color", dir_c))
                .appendTo($tr);
            $tbody.append($tr);
        }
        // console.log(data)
        // for (var i = 1; i < json.data.details.length; i++) {
        //     $tbody.append("<tr><td>-</td><td>-</td><td>-</td></tr>");
        // }
        $("#fblist").html($tbody.html());
        // // 修改盘口异动边框高度
        // //$("#pkydList").height($("#vvcc").outerHeight(true));
    }
});
//时间日期格式
function formateDate(date, fmt) {
    fmt = fmt || "yyyy-MM-dd HH:mm:ss"
    if (typeof date === "string")
        date = new Date(date.replace(/-/g, '/').replace('T', ' ').split('+')[0]);
    var o = {
        "M+": date.getMonth() + 1, //月份         
        "d+": date.getDate(), //日         
        "h+": date.getHours() % 12 == 0 ? 12 : date.getHours() % 12, //小时         
        "H+": date.getHours(), //小时         
        "m+": date.getMinutes(), //分         
        "s+": date.getSeconds(), //秒         
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度         
        "S": date.getMilliseconds() //毫秒         
    };
    var week = {
        "0": "\u65e5",
        "1": "\u4e00",
        "2": "\u4e8c",
        "3": "\u4e09",
        "4": "\u56db",
        "5": "\u4e94",
        "6": "\u516d"
    };
    if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    if (/(E+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[date.getDay() + ""]);
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        }
    }
    return fmt;
}
//当前时间段
function time_range(beginTime, endTime, nowTime) {
    var strb = beginTime.split (":");
    if (strb.length != 2) {
      return false;
    }
   
    var stre = endTime.split (":");
    if (stre.length != 2) {
      return false;
    }
   
    var strn = nowTime.split (":");
    if (stre.length != 2) {
      return false;
    }
    var b = new Date ();
    var e = new Date ();
    var n = new Date ();
    // console.log(b)
    b.setHours (strb[0]);
    b.setMinutes (strb[1]);
    e.setHours (stre[0]);
    e.setMinutes (stre[1]);
    n.setHours (strn[0]);
    n.setMinutes (strn[1]);
   
    if (n.getTime () - b.getTime () > 0 && n.getTime () - e.getTime () < 0) {
      return true;
    } else {
    //   alert ("当前时间是：" + n.getHours () + ":" + n.getMinutes () + "，不在该时间范围内！");
      return false;
    }
}

//涨跌颜色
function udcls(vsa, vsb) {
    // vsa = String(vsa).replace("%", "");
    // console.log(vsa)
    // console.log(vsb)
    if (arguments.length == 1) {
        if (vsa > 0) { return "red"; } else if (vsa < 0) { return "green"; } else { return ""; }
    } else {
        // vsb = vsb.replace("%", "");
        
        if (vsa - vsb > 0) {
            return "red";
        } else if (vsa - vsb < 0) {
            return "green";
        } else {
            return "";
        }
    }
}
//数据格式
function fmtdig(Data, Mat, F, Unit, AutoF) {
    var res = Data;
    if (Data != "" && Data != "--" && Data != "-") {       
        var _temp = Math.abs(parseFloat(Data));
        var temp = parseFloat(Data);
        if (AutoF) {
            if (_temp > 1000000000000)//万亿
            {
                Mat = 100000000; Unit = "亿"; F = "0";
            }
            else if (_temp > 100000000000)//千亿
            {
                Mat = 100000000; Unit = "亿"; F = "0";
            }
            else if (_temp > 10000000000)//百亿
            {
                Mat = 100000000; Unit = "亿"; F = "1";
            }
            else if (_temp > 1000000000)//十亿
            {
                Mat = 100000000; Unit = "亿"; F = "2";
            }
            else if (_temp > 100000000)//亿
            {
                Mat = 100000000; Unit = "亿"; F = "2";
            }
            else if (_temp > 10000000)//千万
            {
                Mat = 10000; Unit = "万"; F = "0";
            }
            else if (_temp > 1000000)//百万
            {
                Mat = 10000; Unit = "万"; F = "1";
            }
            else if (_temp > 100000)//十万
            {
                Mat = 10000; Unit = "万"; F = "2";
            }
            else if (_temp > 10000) {
                Mat = 10000; Unit = "万"; F = "2";
            }
            else if (_temp > 1000) {
                Mat = 1; Unit = ""; F = "2";
            }
            else if (_temp > 100) {
                Mat = 1; Unit = ""; F = "2";
            }
            else if (_temp > 10) {
                Mat = 1; Unit = ""; F = "2";
            }
            else {
                Mat = 1; Unit = ""; F = "3";
            }
        }
        res = ForDight((temp / Mat), F);
    }
    return res + Unit;
}
//科创板精度
function precision(num){
    var pnum = 0;
    var jdz = Math.abs(num)
    if(jdz>0&&jdz<100){
        pnum = num.toFixed(2)
    }else if(jdz>=100&&jdz<1000){
        pnum = num.toFixed(1)
    }else if(jdz>=1000){
        pnum = num.toFixed(0)
    }else if(jdz==0){
        pnum=0
    }
    return pnum
}
function ForDight(Dight, How) { rDight = parseFloat(Dight).toFixed(How); if (rDight == "NaN") { rDight = "--"; } return rDight; }
//新版所属板块
function bankuai() {

    $.ajax({
        // url: "http://61.129.249.233:18665/api/qt/slist/get?ut=fa5fd1943c7b386f172d6893dbfba10b&spt=3&pi=0&pz=5&po=1&fields=f14,f3,f128,f12,f13,f100,f102,f103&secid=" +stockEnity.UnifiedId,
        //url:"http://push2.eastmoney.com/api/qt/slist/get?ut=fa5fd1943c7b386f172d6893dbfba10b&spt=3&pi=0&pz=5&po=1&fields=f14,f3,f128,f12,f13,f100,f102,f103&secid=" +stockEnity.UnifiedId,
        url: commonApi + "api/qt/slist/get?ut=fa5fd1943c7b386f172d6893dbfba10b&spt=3&pi=0&pz=5&po=1&fields=f14,f3,f128,f12,f13,f100,f102,f103&secid=" + stockEnity.UnifiedId,
        dataType: "jsonp",
        scriptCharset: "utf-8",
        jsonp: "cb",
        success: function (json) {
            // console.log('所属板块')
            // console.log(json)
            var html = "";
            if(json.data){
                var count = json.data.total >= 5 ? 5 : json.data.total;
                var item=[];
                for (var i = 0; i < count; i++) {
                    item = json.data.diff[i];
                    var color = item.f3 >= 0 ? "red" : "green";
                    var market = item.f141 == "1" ? "sh" : "sz";
                    // if(item.f140){
                    //     html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/center/boardlist.html#boards-' + item.f13+'.'+item.f12 + '" target="_blank" title="' + item.f14 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                    //     '<td class="' + color + '">' + (item.f3/100).toFixed(2)+'%' + '</td><td><a href="http://quote.eastmoney.com/' + market + item.f140 + '.html" target="_blank" title="' + item.f128 + '">' + cutstr(item.f128, 8) + '</a></td></tr>';
                    // }else{
                    //     html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/center/boardlist.html#boards-' + item.f13+'.'+item.f12 + '" target="_blank" title="' + item.f14 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                    //     '<td class="' + color + '">' + (item.f3/100).toFixed(2)+'%' + '</td><td><a>' +'-  ' + '</a></td></tr>';
                    // }
                    if(item.f140){
                        html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/center/boardlist.html#boards-' + item.f12 + '1" target="_blank" title="' + item.f14 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                        '<td class="' + color + '">' + (item.f3/100).toFixed(2)+'%' + '</td><td><a href="http://quote.eastmoney.com/unify/r/' + item.f141 +'.' + item.f140 + '" target="_blank" title="' + item.f128 + '">' + cutstr(item.f128, 8) + '</a></td></tr>';
                    }else{
                        html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/center/boardlist.html#boards-' +item.f12 + '1" target="_blank" title="' + item.f14 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                        '<td class="' + color + '">' + (item.f3/100).toFixed(2)+'%' + '</td><td><a>' +'-  ' + '</a></td></tr>';
                    }
                
                }
                if(count<5){
                    for(var i=0;i<5-count;i++){
                        html += '<tr><td>-</td><td>-</td><td>-</td></tr>';
                    }
                }
                
                $("#zjlxbk").html(html);
                
            }
      
        }
    });
}

bankuai();
setInterval(function () {
    bankuai();
}, 90000);
// 行业个股排行数据
function phrankS() {
    var def = "C";
    var sed = $("#select2 span:first-child").attr("value");
    // console.log(sed)
    // var hyid = $x("pylist").getAttribute("value");
    if (sed != null) {
        def = sed;
    }
    phrankk();
    phrank(def)
    // phrank_sse(def)
}
//新版相关个股
function phrankk(){
    // var url = "http://61.129.249.233:18665/api/qt/slist/get?pi=0&pz=5&po=1&spt=4&fields=f12,f13,f14,f2,f3,f4,f6,f5,f11,f10&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" +stockEnity.UnifiedId+"&fid=f3";    
    //var url = "http://push2.eastmoney.com/api/qt/slist/get?pi=0&pz=5&po=1&spt=4&fields=f12,f13,f14,f2,f3,f4,f6,f5,f11,f10&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + stockEnity.UnifiedId + "&fid=f3";
    var url = commonApi + "api/qt/slist/get?pi=0&pz=5&po=1&spt=4&fields=f12,f13,f14,f2,f3,f4,f6,f5,f11,f10&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + stockEnity.UnifiedId + "&fid=f3";
    $.ajax({
        url: url,
        dataType: "jsonp",
        scriptCharset: "utf-8",
        jsonp: "cb",
        success: function (json) {
            // console.log('相关个股')
            // console.log(json)
            var item=[];
            var html='';
            var xggp = [];
            if(json.data){
                for (var i = 0; i < 5; i++) {
                    item = json.data.diff[i];
                    var color = item.f3 >= 0 ? "red" : "green";
                    var market = item.f13 == "1" ? "sh" : "sz";
                    xggp.push("<li><a href=\"http://quote.eastmoney.com/unify/r/" + item.f13 +'.'+ item.f12 + "\" target=\"_blank\" title=\"" + item.f14 + "\">" + cutstr(item.f14, 8) + "</a>(" + (item.f2/100).toFixed(2) + " <span class="+color+">"+ (item.f3/100).toFixed(2)+'%' + "</span>)</li>");               
                }
                $("#xggp").html(xggp.toString().replace(/,/g, ""));
            }
            

        }
    });
}
//新版相关个股
function phrank(def) {
    var fids={ "C": 'f3', "D": 'f4', "E": 'f6', "F": 'f5', "G": 'f11', "H": 'f10' };
    var sytn = { "C": "涨跌幅", "D": "涨跌", "E": "成交额", "F": "成交量", "G": "涨跌幅", "H": "量比" };
    // console.log(fids[def])
    // var url = "http://61.129.249.233:18665/api/qt/slist/get?pi=0&pz=5&po=1&spt=4&fields=f12,f13,f14,f2,f3,f4,f6,f5,f11,f10&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" +stockEnity.UnifiedId+"&fid="+fids[def];
    //var url = "http://push2.eastmoney.com/api/qt/slist/get?pi=0&pz=5&po=1&spt=4&fields=f12,f13,f14,f2,f3,f4,f6,f5,f11,f10&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" +stockEnity.UnifiedId+"&fid="+fids[def];
    var url = commonApi + "api/qt/slist/get?pi=0&pz=5&po=1&spt=4&fields=f12,f13,f14,f2,f3,f4,f6,f5,f11,f10&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + stockEnity.UnifiedId + "&fid=" + fids[def];
    $.ajax({
        url: url,
        dataType: "jsonp",
        scriptCharset: "utf-8",
        jsonp: "cb",
        success: function (json) {
            // console.log(json)
            var item=[];
            var html='';
            // console.log(sytn[def])
            $("#pytitnme").html(sytn[def]);
            if(json.data){
                for (var i = 0; i < 5; i++) {
                    item = json.data.diff[i];
                    var color = item.f3 >= 0 ? "red" : "green";
                    var market = item.f13+'.';
                    switch (def) {
                        case "C":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td class="' + color + '">' + (item.f3/100).toFixed(2)+'%' + '</td></tr>';
                            break;
                        case "D":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td class="' + color + '">' + (item.f4/100).toFixed(2)+ '</td></tr>';
                            break;
                        case "E":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td>' + (item.f6/100000000).toFixed(2)+'亿'+ '</td></tr>';
                            break;
                        case "F":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td>' + (item.f5/10000).toFixed(2)+'万'+ '</td></tr>';
                            break;
                        case "G":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td class="' + color + '">' + (item.f11/100).toFixed(2)+'%' + '</td></tr>';
                            break;
                        case "H":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td>' + (item.f10/100).toFixed(2)+ '</td></tr>';
                            break;
                        default:
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + item.f2/100+'%' + '</td>'+
                            '<td class="' + color + '">' + item.f3/100+'%' + '</td></tr>';
                            break;
                    }     
                }
                $("#pylist").html(html);
            }
        }
    });
}
//新版相关个股推送
function phrank_sse(def) {
    var fids={ "C": 'f3', "D": 'f4', "E": 'f6', "F": 'f5', "G": 'f11', "H": 'f10' };
    var sytn = { "C": "涨跌幅", "D": "涨跌", "E": "成交额", "F": "成交量", "G": "涨跌幅", "H": "量比" };
    // console.log(fids[def])
    // var url = "http://61.129.249.233:18665/api/qt/slist/sse?pi=0&pz=5&po=1&spt=4&fields=f12,f13,f14,f2,f3,f4,f6,f5,f11,f10&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" +stockEnity.UnifiedId+"&fid="+fids[def];
    //var url = "http://"+(Math.floor(Math.random() * 99) + 1)+".push2.eastmoney.com/api/qt/slist/sse?pi=0&pz=5&po=1&spt=4&fields=f12,f13,f14,f2,f3,f4,f6,f5,f11,f10&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" +stockEnity.UnifiedId+"&fid="+fids[def];
    var url = tsApi + "api/qt/slist/sse?pi=0&pz=5&po=1&spt=4&fields=f12,f13,f14,f2,f3,f4,f6,f5,f11,f10&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + stockEnity.UnifiedId + "&fid=" + fids[def];
    var evtSource = new EventSource(url);
    evtSource.onmessage = function (msg) {
            var json = msg.data;
            // console.log(json)
            if(json.data){
                var item=[];
                var html='';
                $("#pytitnme").html(sytn[def]);
                for (var i = 0; i < 5; i++) {
                    item = json.data.diff[i];
                    var color = item.f3 >= 0 ? "red" : "green";
                    var market = item.f13+'.';
                    switch (def) {
                        case "C":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td class="' + color + '">' + (item.f3/100).toFixed(2)+'%' + '</td></tr>';
                            break;
                        case "D":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td class="' + color + '">' + (item.f4/100).toFixed(2)+ '</td></tr>';
                            break;
                        case "E":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td>' + (item.f6/100000000).toFixed(2)+'亿'+ '</td></tr>';
                            break;
                        case "F":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td>' + (item.f5/10000).toFixed(2)+'万'+ '</td></tr>';
                            break;
                        case "G":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td class="' + color + '">' + (item.f11/100).toFixed(2)+'%' + '</td></tr>';
                            break;
                        case "H":
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '." target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + (item.f2/100).toFixed(2) + '</td>'+
                            '<td>' + (item.f10/100).toFixed(2)+ '</td></tr>';
                            break;
                        default:
                            html += '<tr><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                            '<td class="' + color + '">' + item.f2/100+'%' + '</td>'+
                            '<td class="' + color + '">' + item.f3/100+'%' + '</td></tr>';
                            break;
                    }
                    
                }
    
                $("#pylist").html(html);
            }
            
        }
    
}
phrankS();
setInterval(function () {
    phrankS();//行业个股排行
}, 30000);
//股吧旁边的热门个股
getFamousGu2();
function getFamousGu2() {
    var url = "http://searchapi.eastmoney.com/api/hotkeyword/get?token=9CB9D8BA6D611925DAAAF0E7788791D2&tag=2&count=32";
    $.ajax({
        type: "get",
        data: '',
        url: url,
        dataType: 'jsonp',
        jsonp: 'cb',
        success: function (msg) {
            // console.log('热门股吧')
            // console.log(msg)

            var arr = [];
            if (msg.Data) {
                for (var i = 0; i < msg.Data.length; i++) {
                    // if (msg.Data[i].MktNum == 0) {
                    //     if (msg.Data[i].JYS == 6 || msg.Data[i].JYS == 7 || msg.Data[i].JYS == 13 || msg.Data[i].JYS == 80) {
                    //         arr.push(msg.Data[i])
                    //     }
                    // }
                    // if (msg.Data[i].MktNum == 1) {
                    //     if (msg.Data[i].JYS == 2 || msg.Data[i].JYS == 3) {
                    //         arr.push(msg.Data[i])
                    //     }
                    // }
                    // if (msg.Data[i].MktNum == 90) {
                    //     if (msg.Data[i].JYS == 2 || msg.Data[i].JYS == 3) {
                    //         arr.push(msg.Data[i])
                    //     }
                    // }
                    arr.push(msg.Data[i])
                }

                // console.log('arr')
                // console.log(arr);

                var secids = '';
                if (arr.length >= 15) {
                    for (var i = 0; i < 14; i++) {
                        var each = arr[i].MktNum + '.' + arr[i].Code;
                        secids += each + ',';
                    }
                    var each = arr[i].MktNum + '.' + arr[i].Code;
                    secids += each;

                } else {
                    for (var i = 0; i < arr.length; i++) {
                        var each = arr[i].MktNum + '.' + arr[i].Code;
                        secids += each + ',';
                    }
                    var each = arr[i].MktNum + '.' + arr[i].Code;
                    secids += each;

                }

                //批量去获得行情数据
                if (secids) {
                    //var url = "http://" + "push2.eastmoney.com/api/qt/ulist.np/get?ut=bd1d9ddb04089700cf9c27f6f7426281&fields=f2,f3,f14,f12,f13&fltt=2&secids=" + secids;
                    var url = commonApi + "api/qt/ulist.np/get?ut=bd1d9ddb04089700cf9c27f6f7426281&fields=f2,f3,f14,f12,f13&fltt=2&secids=" + secids;
                    $.ajax({
                        type: "get",
                        data: '',
                        url: url,
                        dataType: "jsonp",
                        jsonp: 'cb',
                        success: function (msg) {
                            // console.log('批量去获得行情数据')
                            // console.log(msg)
                        if(msg.data) {
                            
                            var arr = msg.data.diff;
                            var famiousEg = $("#hotGuba tbody");

                            var famiousEg_Data = "";

                            for (var i = 0; i < arr.length; i++) {
                                var zhengquancode = arr[i].f13+'.'+arr[i].f12;
                                // if (arr[i].f13 == 1) {
                                //     zhengquancode = 'sh' + arr[i].f12;
                                // }
                                // if (arr[i].f13 == 0) {
                                //     zhengquancode = 'sz' + arr[i].f12;
                                // }


                                if (arr[i].f3 > 0) {
                                    famiousEg_Data += "<tr>" + "<td class='td_width'>" + '<a href="http://quote.eastmoney.com/unify/r/' + zhengquancode + '" target="_blank" title="' + arr[i].f14 + '">' + cutstr(arr[i].f14,8,"..") + '</a>' + "</td>" + "<td class='red'>" + (arr[i].f2).toFixed(2) + "</td>" + "<td class='red'>" + (arr[i].f3).toFixed(2) + "%" + "</td>" + "</tr>";
                                } else if (arr[i].f3 < 0) {
                                    famiousEg_Data += "<tr>" + "<td class='td_width'>" + '<a href="http://quote.eastmoney.com/unify/r/' + zhengquancode + '" target="_blank" title="' + arr[i].f14 + '">' + cutstr(arr[i].f14,8,"..") + '</a>' + "</td>" + "<td class='green'>" + (arr[i].f2).toFixed(2) + "</td>" + "<td class='green'>" + (arr[i].f3).toFixed(2) + "%" + "</td>" + "</tr>";
                                } else if (arr[i].f3 == 0) {
                                    famiousEg_Data += "<tr>" + "<td class='td_width'>" + '<a href="http://quote.eastmoney.com/unify/r/' + zhengquancode + '" target="_blank" title="' + arr[i].f14 + '">' + cutstr(arr[i].f14,8,"..") + '</a>' + "</td>" + "<td >" + (arr[i].f2).toFixed(2) + "</td>" + "<td >" + (arr[i].f3).toFixed(2) + "%" + "</td>" + "</tr>";
                                }

                            }

                            famiousEg.html(famiousEg_Data);

                        }

                        }
                    });

                }


            }



        }
    });

    //全部和热帖
    // this.setall(code);

}
setInterval(function () {
    getFamousGu2();
}, 30000);
//公司公告
$.ajax({
    url:'http://newsnotice.eastmoney.com/webapi/api/Notice?Time=&CodeType=0&StockCode='+stockEnity.Code+'&FirstNodeType=0&SecNodeType=0&PageIndex=1&PageSize=50&Token=WZSJPD161130',
    dataType: "jsonp",
    scriptCharset: "utf-8",
    // jsonp: "cb",
    accept:"json",
    success: function (json) {
        // console.log('公司公告')
        // console.log(json)
        var html = '';
        if(json.data.length){
            var count = json.TotalCount >= 5 ? 5 : json.TotalCount;
            var item=[];
            for (var i = 0; i < count; i++) {
                item = json.data[i];
                if(item.NOTICETITLE){
                    html+='<li><span>'+item.NOTICEDATE.substring(5,10)+'</span><a target="_blank" title='+item.CDSY_SECUCODES[0].SECURITYSHORTNAME+':'+item.NOTICETITLE+' href='+item.Url+'>'+item.CDSY_SECUCODES[0].SECURITYSHORTNAME+':'+item.NOTICETITLE.substring(0,18)+'...</a></li>'
                }
                
            }
            $("#cplist").html(html);
        }else{
            $("#cplist").html('<span class="nodatalist" style=height:135px;line-height:133px;margin-left:70px;font-weight:bolder;width:230px;font-size:14px;>暂无数据</span>');            
        }
        

    }
});
//个股要闻
$.ajax({
    url:'http://cmsdataapi.eastmoney.com/api/StockNews?mktNum=1&stockCode='+stockEnity.Code+'&stockName='+stockEnity.Name+'&returnFields=Art_Title,Art_Showtime,Art_Url',
    dataType: "jsonp",
    scriptCharset: "utf-8",
    jsonp: "cb",
    // accept:"json",
    success: function (json) {
        // console.log('个股要闻')
        // console.log(json)
        var html = '';
        if(json.Data){
            var count = json.TotalCount >= 5 ? 5 : json.TotalCount;
            var item={};
            for (var i = 0; i < count; i++) {
                item = json.Data[i];
                // console.log(item)
                // console.log(item.Art_ShowTime)
                // console.log(item.Art_Title)
                if(item){
                    html+='<li><span>'+item.Art_ShowTime.substring(5,10)+'</span><a target="_blank" title='+item.Art_Title+' href='+item.Art_Url+ ' style=cursor: pointer;>'+item.Art_Title.substring(0,20)+'...</a></li>'
                }
                
            }
            $("#cggy1").html(html);
        }else{
            $("#cggy1").html('<span class="nodatalist" style=height:135px;line-height:133px;margin-left:70px;font-weight:bolder;width:230px;font-size:14px;>暂无数据</span>');            
        }
        

    }
});

//科创板概念股
function kcbstock(){
    var url = "http://dcfm.eastmoney.com/em_mutisvcexpandinterface/api/js/get?js=callback111({data:(x),totalPages:(tp),totalCount:(tc),requestCost:(cost)})"; 
    var pars = {
        token: "70f12f2f4f091e459a279469fe49eca5",
        type: "KCB_HQGD",
        ps: 10,
        p: 1,
        st: 'rank',
        sr: 1
    }

    $.ajax({
        type: "get",
        data: pars,
        url: url,
        dataType: "jsonp",
        jsonp: "js",
        jsonpCallback: "callback111",
        success: function (json) {
            // console.log(json)
            var name=[];
            var code={};
            var secids='';
            var market={};
            var count = json.data.length<10?json.data.length:10;
            for (var i = 0; i < count; i++) {
                name[i] = json.data[i].sname;
                market = json.data[i].mkt
                code[i] = market+"."+json.data[i].scode;
                secids += code[i] + ',';
                // console.log(secids)
                
            }
            if(secids){
                var url = "http://push2.eastmoney.com/api/qt/ulist/get?";
                var pars = {
                    secids: secids,
                    pz: 10,
                    pi: 0,
                    ut: 'bd1d9ddb04089700cf9c27f6f7426281',
                    po: 1,
                    fields: 'f2,f3,f4,f5,f6,f12,f13,f14',
                    fltt: 2,
                    invt: 2,
                    np: 1
                }
                $.ajax({
                    type: "get",
                    data: pars,
                    url: url,
                    dataType: "jsonp",
                    jsonp: "cb",
                    success: function (json) {
                        // console.log(json)
                        var item={};
                        var html='';       
                        if(json){
                            for (var i = 0; i < count; i++) {
                                item = json.data.diff[i];
                                var color = item.f3 >= 0 ? "red" : "green";
                                var market = item.f13+'.';  
                                if(item.f2!="-"){
                                    html += '<tr><td>'+parseInt(i+1)+'</td><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                                    '<td class="' + color + '">' + (item.f2).toFixed(2) + '</td>'+'<td class="' + color + '">' + (item.f3/100).toFixed(2)+'%' + '</td></tr>';       
                                }
                                         
                            }
                            $("#kcblist").html(html);
                        }
                    }
            
                });
                setInterval(function () {
                    $.ajax({
                        type: "get",
                        data: pars,
                        url: url,
                        dataType: "jsonp",
                        jsonp: "cb",
                        success: function (json) {
                            var item={};
                            var html='';       
                            if(json){
                                for (var i = 0; i < count; i++) {
                                    item = json.data.diff[i];
                                    var color = item.f3 >= 0 ? "red" : "green";
                                    var market = item.f13+'.';  
                                    if(item.f2!="-"){
                                        html += '<tr><td>'+parseInt(i+1)+'</td><td class="nm"><a href="http://quote.eastmoney.com/unify/r/' + market + item.f12 + '" target="_blank" title="' + item.f12 + '">' + cutstr(item.f14, 8) + '</a></td>' +
                                        '<td class="' + color + '">' + (item.f2).toFixed(2) + '</td>'+'<td class="' + color + '">' + (item.f3/100).toFixed(2)+'%' + '</td></tr>';                                         
                                    }
                                }
                                $("#kcblist").html(html);
                            }
                        }
                
                    });
                }, 10000);
            }
            
        }
    });
}
// kcbstock();
//科创板大事提醒
function dstx() {
    $.ajax({
        url:'http://dcfm.eastmoney.com/em_mutisvcexpandinterface/api/js?type=GGSJ20_ZDGZ&token=70f12f2f4f091e459a279469fe49eca5&st=rq&sr=-1&p=1&filter=(gpdm%3D%27'+stockEnity.Code+'%27)(rq%3E%3D%5E2019-01-21%5E+and+rq%3C%3D%5E2020-01-16%5E)&ps=3',
        dataType: "jsonp",
        // data: {
        //     filter: '(gpdm=\'' + _opt.stockentry.code + '\' and rq>=^' + region.begin + '^ and rq < ^' + region.end + '^)'
        // },
        success: function (json) {
            // console.log(json)
            var html = '',item;
            if(json){
                for (var i = 0; i < json.length; i++) {
                    item = json[i]; 
                    // console.log(formateDate(item.rq,"MM-dd"))
                    // console.log(formateDate(item.rq,"yyyy"))
                    if(item.gptm!="-"){
                        html += '<tr>'+
                        '<td class="date">'+
                            '<div>'+ formateDate(item.rq,"MM-dd")+'</div>'+
                            '<div class="year">'+ formateDate(item.rq,"yyyy")+'</div>'+
                       ' </td>'+
                        '<td class="event" style=white-space:"">'+
                            '<b class="circle-b">●</b>'+
                            '<div class="title">'+ item.sjlx +'</div>'+
                            '<div class="description" title="'+item.sjms+'">'+
                                '<a href="'+getLink(item)+'" target="_blank">'+item.sjms+'</a>'+
                            '</div>'+
                        '</td>'+
                    '</tr>';       
                    }        
                }
                $("#dstx").html(html);
            }

        }
    });
}
dstx()
function getLink(item) {
    var href = "";
    switch (item.sjlxz) {
        // 停牌日期
        case "TFP":
            href = "http://data.eastmoney.com/tfpxx/";
            break;
        // 龙虎榜
        case "LHB":
            href = "http://data.eastmoney.com/stock/lhb/" + item.gpdm + ".html";
            break;
        // 大宗交易
        case "DZJY":
            href = "http://data.eastmoney.com/dzjy/detail/" + item.gpdm + ".html";
            break;
        // 公告
        case "GG":
            href = "http://data.eastmoney.com/notices/stock/" + item.gpdm + ".html";
            break;
        // 研报
        case "YB":
            href = "http://data.eastmoney.com/report/" + item.gpdm + ".html";
            break;
        // 机构调研
        case "JGDY":
            href = "http://data.eastmoney.com/jgdy/gsjsdy/" + item.gpdm + ".html";
            break;
        // 股东增减持日
        case "GDZJC":
            href = "http://data.eastmoney.com/executive/gdzjc/" + item.gpdm + ".html";
            break;
        // 限售解禁日
        case "XSJJ":
            href = "http://data.eastmoney.com/dxf/q/" + item.gpdm + ".html";
            break;
        // 高管持股
        case "GGZJC":
            href = "http://data.eastmoney.com/executive/" + item.gpdm + ".html";
            break;
        // 高管关联人持股
        case "GGXGZJC":
            href = "http://data.eastmoney.com/executive/" + item.gpdm + ".html";
            break;
        // 预约披露日
        case "YYPL":
            href = "http://data.eastmoney.com/bbsj/" + item.gpdm + ".html";
            break;
        // 业绩预告
        case "YJYG":
            href = "http://data.eastmoney.com/bbsj/" + item.gpdm + ".html";
            break;
        // 业绩快报
        case "YJKB":
            href = "http://data.eastmoney.com/bbsj/" + item.gpdm + ".html";
            break;
        // 业绩报表
        case "YJBB":
            href = "http://data.eastmoney.com/bbsj/" + item.gpdm + ".html";
            break;
        // 股本变动
        case "GBBD":
            href = "http://emweb.securities.eastmoney.com/f10_v2/CapitalStockStructure.aspx?type=web&code=sh" + stockEnity.Code
            break;
        // 新股
        case "XGSG":
            href = "http://data.eastmoney.com/xg/xg/detail/" + item.gpdm + ".html";
            break;
        // 分红
        case "FHPS":
            href = "http://data.eastmoney.com/yjfp/detail/" + item.gpdm + ".html";
            break;
        // 股东大会
        case "GDDH":
            href = "http://data.eastmoney.com/gddh/list/" + item.gpdm + ".html";
            break;
        // 股东户数
        case "GDHS":
            href = "http://data.eastmoney.com/gdhs/detail/" + item.gpdm + ".html";
            break;
        case "BGCZ":
            href = "http://data.eastmoney.com/bgcz/detail/" + item.gpdm + ".html";
            break;
        //公司投资
        case "GSTZ":
            href = " http://data.eastmoney.com/gstz/stock/" + item.gpdm + ".html";
            break;
        //股权质押
        case "GQZY":
            href = "http://data.eastmoney.com/gpzy/detail/" + item.gpdm + ".html";
            break;
        //委托理财
        case "WTLC":
            href = "http://data.eastmoney.com/wtlc/detail/" + item.gpdm + ".html";
            break;
        //重大合同
        case "ZDHT":
            href = " http://data.eastmoney.com/zdht/detail/" + item.gpdm + ".html";
            break;
        //股票回购
        case "GPHG":
            href = "http://data.eastmoney.com/gphg/" + item.gpdm + ".html";
            break;
        //关联交易
        case "GLJY":
            href = "http://data.eastmoney.com/gljy/detail/" + item.gpdm + ".html";
            break;
        default:
            break;
    }
    return href;
}
//分时图
var thissse = null;
$(document).ready(function () {

    var not_h5 = !+"\v1";
    if (not_h5) {        
        $(".js_show").hide();
        $(".img_show").click();
    }

    if (not_h5) { $(".js_show").hide(); return;}

    //K线图
    var kLineDraw={
        isFirst:true,
        timer:null,
        kchart:new emcharts3.k4({
            container: "#emchartk",
            width: 585,
            height: 385,
            padding: {
                top: 0,
                bottom: 0
            },
            scale: {
                pillar: 60,
                min: 10
            },
            show: {
                // fold: true
            },
            color: {
                background: "transparent"
            },
            popWin: { type: "move" },
            maxin: {
                //show: true,
                lineWidth: 30,     // 线长
                skewx: 0,            // x偏移   
                skewy: 0            // y偏移
            },
            onComplete: function () {
                //$("#emchartk").remove('.loading');
            },
            onFold: function (display, type) {
                if (display === 'block') {
                    $('#cyq-btn').hide();
                }
                else {
                    $('#cyq-btn').show();
                }
            },
            onClick: function () {
                if (typeof sendTrackLog === 'function') {
                    sendTrackLog('DIV', 'Click', 'xqzx_hsAgxqdy_hqt_djztlj');
                }
                // window.open("//quote.eastmoney.com/concept/" + (window.Def._Market === '1' ? 'sh' : 'sz') + window.Def._Code + ".html?from=classic");
            },
            onError: function (e) {
                console.error(e)
            }
        }),
        init :function () {
                        
            // 复权判断
            var fq = GetCookie("emhq_picfq");
            if (fq === "0") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value='']").html());
                params.fqt = "0";
            }
            if (fq === "1") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=before]").html());
                params.fqt = "1";
            }
            else if (fq === "2") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=back]").html());
                params.fqt = "2";
            }
            this.load();
            if(this.isFirst){
                this.events();
            }
        },
            
        load:function () {
                $x("image_box").style.display = "none";
                $x("js_box").style.display = "block";
                $("#js_box").removeClass("hidefixed");
                // clearTimeout(timer);
                var _thisKchart=this.kchart;
                var _load = function () {
                    // console.log(_thisKchart)
                    _thisKchart.setStock({
                        secid: stockEnity.UnifiedId,
                        klt: params.klt
                    });                
                };
                _load();
                
                        
        },
        events:function () {    
            var _this=this;                    
                $("#beforeBackRight dl dd").click(function () {
                    $("#beforeBackRight span").html($(this).html());
                    var v = $(this).attr("value");
                    $("#beforeBackRight").attr("value", v);
                    params.fqt = v === "before" ? "1" : v === "back" ? "2" : "";
                    _this.load();
                    var at = v === "before" ? "1" : v === "back" ? "2" : "0";
                    if ($("#js_box").is(":visible")) {
                        $("#select4 dd[value=" + at + "]").click();
                        WriteCookie("emhq_picfq", at, 8760);
                    }
                });
        
                $("#changektab span").click(function () {
                    $x("image_box").style.display = "none";
                    $x("js_box").style.display = "block";
                    $("#js_box").removeClass("hidefixed");
                    console.log($("#js_box").css('display'))
                    $("#changektab span").removeClass("cur");
                    $(this).addClass("cur");
                    switch ($(this).attr("value")) {
                        case "D":
                            params.klt = "101";
                            break;
                        case "W":
                            params.klt = "102";
                            break;
                        case "M":
                            params.klt = "103";
                            break;
                        case "M5":
                            params.klt = "5";
                            break;
                        case "M15":
                            params.klt = "15";
                            break;
                        case "M30":
                            params.klt = "30";
                            break;
                        case "M60":
                            params.klt = "60";
                            break;
                    }
                    _this.load();
                });
        
                $("#scale-plus").click(function () {
                    kchart.shorten();
                });
        
                $("#scale-minus").click(function () {
                    kchart.elongate();
                });
        
                $("#beforeBackRight").mouseenter(function () {
                    this.getElementsByTagName("dl")[0].style.display = "block";
                });
        
                $("#beforeBackRight").mouseleave(function () {
                    this.getElementsByTagName("dl")[0].style.display = "none";
                });
                this.isFirst=false;
        }
        
    }

    var not_h5 = !+"\v1";
    if (not_h5) { $(".js_show").hide(); return; }
    function getQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return decodeURIComponent(r[2]);
        return null;
    }
    var c = stockEnity.UnifiedId;
    var testenv = getQueryString("testenv") || "";
    var sc = getQueryString("sc") || "";
    var sm = getQueryString("sm") || "";
    var type = getQueryString("type") || "r";
    var iscr = getQueryString("iscr");
    var iscca = getQueryString("iscca");
    if (!iscr || iscr == false || iscr == "") {
        iscr = 0
    } else {
        iscr = 1;
    }
    if (!iscca || iscca == false || iscca == "false") {
        iscca = 0
    } else {
        iscca = 1;
    }  
    var option = {
        container: "#emchart-0",
        width: 578,
        height: 276,
        type: 'r',
        iscr: 0,
        iscca:iscca,
        ndays:1,
        gridwh: {
            height: 25,
            width: 578
        },
        padding: {
            top: 0,
            bottom: 5
        },
        restline: {
            isshow: true,
            color: "#eee",
            solid: 3,       // 实线长度
            dashed: 0      // 虚线长度
        },
        tip: {
            trading: true
        },
        color: {
                line: "#326fb2",
                fill: ["rgba(101,202,254, 0.2)", "rgba(101,202,254, 0.1)"]
            },
        onClick: function () {
            if (typeof sendTrackLog === 'function') {
                sendTrackLog('DIV', 'Click', 'xqzx_hsAgxqdy_hqt_djztlj');
            }
            // window.open("//quote.eastmoney.com/concept/" + (window.Def._Market === '1' ? 'sh' : 'sz') + window.Def._Code + ".html?from=classic");
        },
        onClickChanges: function () {
            window.open('//quote.eastmoney.com/changes/stocks/' + 'sh' + window.Def._Code + ".html");
        },
        onComplete: function () {
            //$("#emchart-0").remove('.loading');
        },
        onError: function (err) {
            // console.log(err);
        }
    }
    var time;
    time = new emcharts3.time(option);
    
    var tps = {
        r: 1,
        t2: 2,
        t3: 3,
        t4: 4,
        t5: 5
    }
    test(1);
    function test(ndays) {
        if (typeof iscr === "number" && iscr) time.option.iscr = iscr;
        if (typeof iscca === "number" && iscca) time.option.iscca = iscca;
        if (typeof ndays === "number" && ndays) time.option.ndays = ndays;
        if (typeof iscr === "number" && iscr) time.options.iscr = iscr;
        if (typeof iscca === "number" && iscca) time.options.iscca = iscca;
        if (typeof ndays === "number" && ndays) time.options.ndays = ndays;
        // var url = "http://61.129.249.233:18665/api/qt/stock/trends2/get";
        if(ndays==1){
            var url = "http://push2.eastmoney.com/api/qt/stock/trends2/get" 
        }else{
            var url = "http://push2his.eastmoney.com/api/qt/stock/trends2/get"
        }
        var data = {
            fields1: "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13",
            fields2: "f51,f52,f53,f54,f55,f56,f57,f58",
            ut: "fa5fd1943c7b386f172d6893dbfba10b",
            ndays: time.option.ndays,
            iscr: time.option.iscr,
            iscca:time.option.iscca
        };

        if (c) {
            data.secid = c;
        }
        


        var arr = [];
        for (var k in data) {
            arr.push(k + "=" + data[k]);
        }
        // console.log(url + "?" + arr.join("&"))
        // 请求分时数据
        $.ajax({
            type: "get",
            url: url + "?" + arr.join("&"),
            // data: data,
            dataType: "jsonp",
            jsonp: "cb",
            success: function (msg) {
                // msg.data.trendsTotal = 482
                // console.log(time)
                time.setData({
                    time: msg
                });
                // console.log(time)
                time.redraw();
            }
        });

    }

    aa();
    function aa() {
        $.ajax({
            type: "get",
            url: "http://nuyd.eastmoney.com/EM_UBG_PositionChangesInterface/api/js",
            data: {
                id: "3005042",
                style: "top",
                ac: "normal",
                check: "itntcd",
                // dtformat: "HH:mm:ss",
                js: "changeData15125388([(x)])"
            },
            dataType: "jsonp",
            jsonp: "changeData15125388",
            jsonpCallback: "changeData15125388",
            success: function (msg) {
                try {
                    if (msg[0].state) {
                        dataPositionChanges = [];
                    } else {
                        dataPositionChanges = msg;
                    }
                } catch (error) {
                    dataPositionChanges = [];
                }
                time.setData({
                    positionChanges: dataPositionChanges
                });
                time.redraw();
            }
        });
    }

    bb();
    function bb() {

        var types = {
            "1": "有大买盘",
            "101": "有大卖盘",
            "2": "大笔买入",
            "102": "大笔卖出",
            "201": "封涨停板",
            "301": "封跌停板",
            "202": "打开涨停",
            "302": "打开跌停",
            "203": "高开5日线",
            "303": "低开5日线",
            "204": "60日新高",
            "304": "60日新低",
            "401": "向上缺口",
            "501": "向下缺口",
            "402": "火箭发射",
            "502": "高台跳水",
            "403": "快速反弹",
            "503": "快速下跌",
            "404": "竞价上涨",
            "504": "竞价下跌",
            "405": "60日大幅上涨",
            "505": "60日大幅下跌"
        }

        $.ajax({
            type: "get",
            // url: "http://61.129.249.233:18665/api/qt/pkyd/get?fields=f2,f1,f4,f5,f6,f7&lmt=20&ut=fa5fd1943c7b386f172d6893dbfba10b&secids="+c,
            url: "http://push2.eastmoney.com/api/qt/pkyd/get?fields=f2,f1,f4,f5,f6,f7&lmt=20&ut=fa5fd1943c7b386f172d6893dbfba10b&secids=" + c,
            dataType: "jsonp",
            jsonp: "cb",
            success: function (msg) {

                if (msg.rc == 0 && msg.data) {

                    var pkyd = msg.data.pkyd;

                    var newarr = [];

                    for (var i = 0, len = pkyd.length; i < len; i++) {
                        var s = pkyd[i].split(",");

                        var ar = [s[1], s[0].substr(0, 5), s[2], types[s[3]], s[4], s[5]];
                        newarr.push(ar.join(","));
                    }

                    // console.log(newarr);
                    time.setData({
                        positionChanges: newarr
                    });
                    time.redraw();
                }



            }
        });
    }
    function events() {
        
        $(".changeFenshiTab span").click(function (e) {
            var params = time.option;
            var paramspic = time.options;
            params.iscr = 0;
            params.iscca = 0;
            params.ndays = 1;
            paramspic.iscr = 0;
            paramspic.iscca = 0;
            paramspic.ndays = 1;
            $(".changeFenshiTab span").removeClass("cur");
            $(this).addClass("cur");
            switch ($(this).attr("type")) {
                case "panqian":
                    params.iscr = 1;
                    params.ndays = 1;
                    params.type = "r";
                    paramspic.iscr = 1;
                    paramspic.ndays = 1;
                    paramspic.type = "r";
                    break;
                case "panhou":
                    params.iscca = 1;
                    params.ndays = 1;
                    params.type = "r";
                    paramspic.iscca = 1;
                    paramspic.ndays = 1;
                    paramspic.type = "r";
                    break;
                case "oneday":
                    params.ndays = 1;
                    params.type = "r";
                    paramspic.ndays = 1;
                    paramspic.type = "r";
                    break;
                case "twoday":
                    params.ndays = 2;
                    params.type = "t2";
                    paramspic.ndays = 2;
                    paramspic.type = "t2";
                    break;
                case "threeday":
                    params.ndays = 3;
                    params.type = "t3";
                    paramspic.ndays = 3;
                    paramspic.type = "t3";
                    break;
                case "fourday":
                    params.ndays = 4;
                    params.type = "t4";
                    paramspic.ndays = 4;
                    paramspic.type = "t4";
                    break;
                case "fiveday":
                    params.ndays = 5;
                    params.type = "t5";
                    paramspic.ndays = 5;
                    paramspic.type = "t5";
                    break;
            }
            test(params.ndays);
            load_sse();
            return false;
        });
    }
    function init() {
        events();
        // if (window.bjTime && Def.PanQian(new Date(window.bjTime.replace(/-/g, "/")))) {
        //     $(".changeFenshiTab span[type=panqian]").click();
        // }
        // else $(".changeFenshiTab span[type=oneday]").click();
        load_sse();     
        if(time_range('15:00','15:30',formateDate(new Date(new Date()), "HH:mm"))){
            $(".changeFenshiTab span[type=panhou]").click()
        }     
    }
    function load_sse() {       
        try {
            thissse.close()
        } catch (error) {
            
        }
        if (typeof iscr === "number" && iscr) time.option.iscr = iscr;
        if (typeof iscca === "number" && iscca) time.option.iscca = iscca;
        if (typeof ndays === "number" && ndays) time.option.ndays = ndays;
        var data={
            ndays: time.option.ndays,
            iscr: time.option.iscr,
            iscca:time.option.iscca
        };
        var arr = [];
        for (var k in data) {
            arr.push(k + "=" + data[k]);
        } 
        // var fullurl = 'http://61.129.249.233:18665/api/qt/stock/trends2/sse?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=1.'+ stockEnity.Code + "&" + arr.join("&");
        // thissse=new EventSource(fullurl);
        var fullurl = 'http://'+(Math.floor(Math.random() * 99) + 1)+'.push2.eastmoney.com/api/qt/stock/trends2/sse?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=1.'+ stockEnity.Code + "&" + arr.join("&");
        var nfullurl = 'http://'+(Math.floor(Math.random() * 99) + 1)+'.push2his.eastmoney.com/api/qt/stock/trends2/sse?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=1.'+ stockEnity.Code + "&" + arr.join("&");
        if(data.ndays==1){
            thissse = new EventSource(fullurl);
        }else{
            thissse = new EventSource(nfullurl);
        }
        
        thissse.onmessage = function (msg) {
            // console.log(msg);
            var fdata = JSON.parse(msg.data)
            // console.log(fdata);
            var fulldata = '';
            if (fdata.rc == 0 && fdata.data) {
    
                var data = fdata.data;
    
                if (data.beticks) {
                    fullData = fdata;
                } else {
    
                    var source = fullData.data.trends;
                    var last = source[source.length - 1].split(",");
                    
                    var trends = data.trends;
                    var frist = trends[0].split(",");
    
                    if (last[0] == frist[0]) {
                        source.pop();
                    }
                    for(var i = 0, len = trends.length ; i < len ; i++){
                        source.push(trends[i]);
                    }
                }
    
                // console.log(that.fullData);
                time.setData({
                    time: fullData
                });
                // console.log(time)
                time.redraw();
            }
    
        }
    }

    init();
   
    var not_h5 = !+"\v1";
    if (not_h5) {        
        $(".js_show").hide();
        $(".img_show").click();
    }
    else {
        var ct = GetCookie("em_hq_fls");
        $(".js_show").click(function (e) {       
            console.log('jsclick555555555555')
            showjs();
            $x("image_box").style.display = "none";
            $x("js_box").style.display = "block";
            $("#js_box").removeClass("hidefixed");
            $x("flsrmt7").className = "title1 mt6";
            kLineDraw.init();
        });
        if (!ct) {
            // console.log('动图1')
            showjs();
            kLineDraw.init();
        } else if (ct === "old") {
            console.log('静图')
             $(".img_show").click();
             $("#js_box").addClass("hidefixed");
        } else {
            // console.log('动图2')
            kLineDraw.init();
        }
    }

        //k线图
    function loadCandleChart() {
        console.log($("#js_box").css('display'))
        // $("#js_box").removeClass("hidefixed");
        // $("#js_box").show();
        //$("#emchartk").html($('<div class="loading"></div>'));
        var timer,
            kchart = new emcharts3.k4({
                container: "#emchartk",
                width: 585,
                height: 385,
                padding: {
                    top: 0,
                    bottom: 0
                },
                scale: {
                    pillar: 60,
                    min: 10
                },
                show: {
                    // fold: true
                },
                color: {
                    background: "transparent"
                },
                popWin: { type: "move" },
                maxin: {
                    //show: true,
                    lineWidth: 30,     // 线长
                    skewx: 0,            // x偏移   
                    skewy: 0            // y偏移
                },
                onComplete: function () {
                    //$("#emchartk").remove('.loading');
                },
                onFold: function (display, type) {
                    if (display === 'block') {
                        $('#cyq-btn').hide();
                    }
                    else {
                        $('#cyq-btn').show();
                    }
                },
                onClick: function () {
                    if (typeof sendTrackLog === 'function') {
                        sendTrackLog('DIV', 'Click', 'xqzx_hsAgxqdy_hqt_djztlj');
                    }
                    // window.open("//quote.eastmoney.com/concept/" + (window.Def._Market === '1' ? 'sh' : 'sz') + window.Def._Code + ".html?from=classic");
                },
                onError: function (e) {
                    console.error(e)
                }
            });
            
            // console.log(kchart)
        function init() {

            events();
            // 复权判断
            var fq = GetCookie("emhq_picfq");
            if (fq === "0") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=]").html());
                params.fqt = "0";
            }
            if (fq === "1") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=before]").html());
                params.fqt = "1";
            }
            else if (fq === "2") {
                $("#beforeBackRight span").html($("#beforeBackRight dl dd[value=back]").html());
                params.fqt = "2";
            }

            load();
        }

        function load() {
            $x("image_box").style.display = "none";
            $x("js_box").style.display = "block";
            $("#js_box").removeClass("hidefixed");
            clearTimeout(timer);
            var _load = function () {
                console.log(kchart)
                kchart.setStock({
                    secid: stockEnity.UnifiedId,
                    klt: params.klt
                });                
            };
            _load();
            
        }

        // function events() {
            
        //     $("#beforeBackRight dl dd").click(function () {
        //         $("#beforeBackRight span").html($(this).html());
        //         var v = $(this).attr("value");
        //         $("#beforeBackRight").attr("value", v);
        //         params.fqt = v === "before" ? "1" : v === "back" ? "2" : "";
        //         load();
        //         var at = v === "before" ? "1" : v === "back" ? "2" : "0";
        //         if ($("#js_box").is(":visible")) {
        //             $("#select4 dd[value=" + at + "]").click();
        //             WriteCookie("emhq_picfq", at, 8760);
        //         }
        //     });

        //     $("#changektab span").click(function () {
        //         $x("image_box").style.display = "none";
        //         $x("js_box").style.display = "block";
        //         $("#js_box").removeClass("hidefixed");
        //         console.log($("#js_box").css('display'))
        //         $("#changektab span").removeClass("cur");
        //         $(this).addClass("cur");
        //         switch ($(this).attr("value")) {
        //             case "D":
        //                 params.klt = "101";
        //                 break;
        //             case "W":
        //                 params.klt = "102";
        //                 break;
        //             case "M":
        //                 params.klt = "103";
        //                 break;
        //             case "M5":
        //                 params.klt = "5";
        //                 break;
        //             case "M15":
        //                 params.klt = "15";
        //                 break;
        //             case "M30":
        //                 params.klt = "30";
        //                 break;
        //             case "M60":
        //                 params.klt = "60";
        //                 break;
        //         }
        //         load();
        //     });

        //     $("#scale-plus").click(function () {
        //         kchart.shorten();
        //     });

        //     $("#scale-minus").click(function () {
        //         kchart.elongate();
        //     });

        //     $("#beforeBackRight").mouseenter(function () {
        //         this.getElementsByTagName("dl")[0].style.display = "block";
        //     });

        //     $("#beforeBackRight").mouseleave(function () {
        //         this.getElementsByTagName("dl")[0].style.display = "none";
        //     });
        // }
        init();
    }
   

    

    // function events() {
        
    //     $("#beforeBackRight dl dd").click(function () {
    //         $("#beforeBackRight span").html($(this).html());
    //         var v = $(this).attr("value");
    //         $("#beforeBackRight").attr("value", v);
    //         params.fqt = v === "before" ? "1" : v === "back" ? "2" : "";
    //         load();
    //         var at = v === "before" ? "1" : v === "back" ? "2" : "0";
    //         if ($("#js_box").is(":visible")) {
    //             $("#select4 dd[value=" + at + "]").click();
    //             WriteCookie("emhq_picfq", at, 8760);
    //         }
    //     });

    //     $("#changektab span").click(function () {
    //         $x("image_box").style.display = "none";
    //         $x("js_box").style.display = "block";
    //         $("#js_box").removeClass("hidefixed");
    //         console.log($("#js_box").css('display'))
    //         $("#changektab span").removeClass("cur");
    //         $(this).addClass("cur");
    //         switch ($(this).attr("value")) {
    //             case "D":
    //                 params.klt = "101";
    //                 break;
    //             case "W":
    //                 params.klt = "102";
    //                 break;
    //             case "M":
    //                 params.klt = "103";
    //                 break;
    //             case "M5":
    //                 params.klt = "5";
    //                 break;
    //             case "M15":
    //                 params.klt = "15";
    //                 break;
    //             case "M30":
    //                 params.klt = "30";
    //                 break;
    //             case "M60":
    //                 params.klt = "60";
    //                 break;
    //         }
    //         load();
    //     });

    //     $("#scale-plus").click(function () {
    //         kchart.shorten();
    //     });

    //     $("#scale-minus").click(function () {
    //         kchart.elongate();
    //     });

    //     $("#beforeBackRight").mouseenter(function () {
    //         this.getElementsByTagName("dl")[0].style.display = "block";
    //     });

    //     $("#beforeBackRight").mouseleave(function () {
    //         this.getElementsByTagName("dl")[0].style.display = "none";
    //     });
    // }
}); 



//静图地址
imageurl(stockEnity.Code+'1')
function imageurl(id) {
    $("#actTab4 span").click(function (e) {
        $("#actTab4 span").removeClass("cur");
        $(this).addClass("cur");
        // console.log($(this).attr("data-id"))
        switch ($(this).attr("data-id")) {
            case "imageper":
                $("#picr-link img").attr('src','http://webquotepic.eastmoney.com/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=rc')
                // $("#picr-link img").attr('src',' http://61.129.249.32:8870/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=rc')
                break;
            case "imageaf":
                $("#picr-link img").attr('src','http://webquotepic.eastmoney.com/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=rp')
                // $("#picr-link img").attr('src',' http://61.129.249.32:8870/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=rp')
                break;
            case "image1":
                $("#picr-link img").attr('src','http://webquotepic.eastmoney.com/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=r') 
                // $("#picr-link img").attr('src',' http://61.129.249.32:8870/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=r')           
                break;
            case "image2":
                $("#picr-link img").attr('src','http://webquotepic.eastmoney.com/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=t&type=M1')
                // $("#picr-link img").attr('src',' http://61.129.249.32:8870/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=t&type=M1')            
                break;
            case "image3":
                $("#picr-link img").attr('src','http://webquotepic.eastmoney.com/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=t&type=M2') 
                // $("#picr-link img").attr('src',' http://61.129.249.32:8870/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=t&type=M2')     
                break;
            case "image4":
                $("#picr-link img").attr('src','http://webquotepic.eastmoney.com/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=t&type=M3')   
                // $("#picr-link img").attr('src',' http://61.129.249.32:8870/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=t&type=M3')           
                break;
            case "image5":
                $("#picr-link img").attr('src','http://webquotepic.eastmoney.com/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=t&type=M4')   
                // $("#picr-link img").attr('src',' http://61.129.249.32:8870/GetPic.aspx?nid=1.'+stockEnity.Code+'&imageType=t&type=M4')  
                break;
        }
        return false;
    });
}
//行情图片点击事件
var nid = stockEnity.UnifiedId;

function bindChartImgEvent(options, nid) {
    var self;
    var defualtUrls = {
        "url_r": "//webquoteklinepic.eastmoney.com/GetPic.aspx?",
        "url_k": "http://webquoteklinepic.eastmoney.com/GetPic.aspx?"
        // "url_r": " http://61.129.249.32:8871/GetPic.aspx?",
        // "url_k": " http://61.129.249.32:8871/GetPic.aspx?"
       
    };
    var _options = $.extend(defualtUrls, options);
    return {
        unitWidth: -6,
        stockId: this.stockId,
        bindEvent: function () {
            if (!self) self = this;
            $("#pictit span").click(function () {
                $("#pictit span").removeClass("cur");
                $(this).addClass("cur");
                self.changeImg("k");
            });

            $("#zkeya li").click(function () {
                $("#zkeya li").removeClass("at");
                $(this).addClass("at");
                self.changeImg("k");
            });

            $("#zkeyb li").click(function () {
                $("#zkeyb li").removeClass("at");
                $("#zkeyc li").removeClass("at");
                $(this).addClass("at");
                $("#zkeyc li[type=" + $(this).attr("type") + "]").addClass("at");
                self.changeImg("k");
            });

            $("#zkeyc li").click(function () {
                $("#zkeyb li").removeClass("at");
                $("#zkeyc li").removeClass("at");
                $(this).addClass("at");
                $("#zkeyb li[type=\"" + $(this).attr("type") + "\"]").addClass("at");
                self.changeImg("k");
            });

            $("#select4 dd").click(function () {
                // $("#select4 dd[value=" + $(this).attr("value") + "]").addClass("at");
                self.changeImg("k");
            });

            $("#picklc").click(function () {
                if (self.unitWidth <= -8) {
                    return;
                }
                self.unitWidth = self.unitWidth - 1;
                self.changeImg("k");
            });

            $("#picksd").click(function () {
                if (self.unitWidth >= 0) {
                    return;
                }
                self.unitWidth = self.unitWidth + 1;
                self.changeImg("k");
            });

            //分时
            $("#actTab1 span").click(function () {
                $("#actTab1 span").removeClass("cur");
                $(this).addClass("cur");
                self.changeImg("r");

            });
        },
        changeImg: function (type) {
            if (!self) self = this;
            if (typeof type === "string") {
                switch (type) {
                    case "r":
                        var rtype = $("#actTab1 .cur").attr("value");
                        loadimg("picr", 276, 578, _options.url_r, {
                            // id: self.stockId,
                            nid: nid,
                            type: rtype === "M0" ? "" : rtype === "PQ" ? "" : rtype || "r",
                            imageType: rtype === "PQ" ? "rc" : (rtype === "M0" || !rtype) ? "rf" : "t"
                        }, "//hqres.eastmoney.com/EMQuote_Lib/img/picrnotfund.gif");
                        break;
                    case "k":
                        // K图
                        loadimg("pick-link", 365, 520, _options.url_k, {
                            nid: '1.'+stockEnity.Code,
                            // nid: nid,
                            at:$("#select4 span").attr("value"),
                            type: $("#pictit .cur").attr("value"),
                            unitWidth: self.unitWidth,
                            ef: $("#zkeya .at").attr("type"),
                            formula: $("#zkeyb .at").attr("type"),
                            imageType: "KXL"
                        }, "//hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif");
                        break;
                    default:
                        break;
                }
            } else {
                self.changeImg("r");
                self.changeImg("k");
            }

            function loadimg(container, height, width, url, data, errurl) {
                var $container = $("#" + container);
                if ($container.length === 0) return false;
                imgLoader({
                    url: url,
                    data: data,
                    height: height,
                    width: width,
                    success: function (image) {
                        $container.html(image);
                    },
                    error: function (image) {
                        // $container.html(image);
                        $container.html($(image).attr("src", errurl || "//hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif"));
                    }
                });
            }


            function imgLoader(setting) {
                if (typeof (setting) !== "object" || !setting["url"]) return false;
                var fCallback = typeof (setting["success"]) === "function" ? setting["success"] : null;
                var _url = setting["url"];
                if (setting["data"]) {
                    var _data = $.param(setting["data"]);
                    _url = _url.indexOf("?") > 0 ? _url + "&" + _data : _url + "?" + _data;
                }
                if (!setting["cache"]) {
                    _url += _url.indexOf("?") > 0 ? "&_=" + (+new Date()) : "?_=" + (+new Date());
                }
                var _image = document.createElement("img");
                if (typeof (setting["height"]) === "number" && setting["height"] > 0) {
                    _image.setAttribute("height", setting["height"] + "px");
                }
                if (typeof (setting["width"]) === "number" && setting["width"] > 0) {
                    _image.setAttribute("width", setting["width"] + "px");
                }
                _image.setAttribute('src', _url);
                if (typeof (setting["error"]) === "function")
                    $(_image).error(function () {
                        setting["error"](_image);
                    });
                _image.onload = _image.onreadystatechange = function (evt) {
                    if (!_image.readyState || /loaded|complete/.test(_image.readyState)) {
                        // Handle memory leak in IE
                        _image.onload = _image.onreadystatechange = null;
                        // Callback if not abort
                        if (fCallback) fCallback(_image);
                    }
                };
            }
        }
    };
}

var options = {
    type: '',
    unitWidth: '-6',
    ef: '',
    formula: 'rsi',
    imageType: 'KXL'
};
bindChartImgEvent(options, nid).bindEvent();

$("#gt13").mouseover(function(){
    // console.log('aaa')
    $(".morelian").css('color','red');
});
$("#gt13").mouseleave(function(){
    // console.log('bbb')
    $(".morelian").css('color','#039');
});

})();
