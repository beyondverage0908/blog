/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./jssrc/cnyrate.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./jssrc/cnyrate.ts":
/*!**************************!*\
  !*** ./jssrc/cnyrate.ts ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * 外汇 人民币汇率中间价
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var gotowap_1 = __importDefault(__webpack_require__(/*! ../src/modules/gotowap */ "./src/modules/gotowap/index.ts"));
gotowap_1["default"](stockcode, newmarket);
__webpack_require__(/*! ../src/modules/old_cnyrate/main */ "./src/modules/old_cnyrate/main.js");


/***/ }),

/***/ "./src/modules/cookie/index.ts":
/*!*************************************!*\
  !*** ./src/modules/cookie/index.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * 浏览器操作cookie
 */
exports.__esModule = true;
exports["default"] = {
    /**
     * 获取cookie
     * @param name cookie名称
     */
    get: function (name) {
        var xarr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
        if (xarr != null)
            return decodeURIComponent(xarr[2]);
        return null;
    },
    /**
     * 设置cookie
     * @param key cookie名称
     * @param value cookie的值
     * @param expiredays 过期时间（天）
     * @param domain cookie的domain
     */
    set: function (key, value, expiredays, domain) {
        var cookiestr = key + "=" + escape(value);
        if (expiredays != undefined) {
            var exdate = new Date();
            exdate.setDate(exdate.getDate() + expiredays);
            cookiestr += ";expires=" + exdate.toUTCString();
        }
        if (domain != undefined) {
            cookiestr += ";domain=" + domain;
        }
        cookiestr += ';path=/';
        document.cookie = cookiestr;
    },
    /**
     * 删除cookie
     * @param key cookie名称
     * @param domain cookie的domain
     */
    del: function (key, domain) {
        var exdate = new Date((new Date).getTime() - 1);
        if (domain) {
            document.cookie = key + '=;path=/;expires=' + exdate.toUTCString() + ';domain=' + domain;
        }
        else {
            document.cookie = key + '=;path=/;expires=' + exdate.toUTCString();
        }
    }
};


/***/ }),

/***/ "./src/modules/gotowap/index.ts":
/*!**************************************!*\
  !*** ./src/modules/gotowap/index.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * 跳转wap网站
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var cookie_1 = __importDefault(__webpack_require__(/*! ../cookie */ "./src/modules/cookie/index.ts"));
function isMobile() {
    var ua = navigator.userAgent;
    var res = false;
    var ipad = ua.match(/(iPad).*OS\s([\d_]+)/), isIphone = !ipad && ua.match(/(iPhone\sOS)\s([\d_]+)/), isAndroid = ua.match(/(Android)\s+([\d.]+)/) && ua.match(/(Mobile)\s+/), isMobile = isIphone || isAndroid;
    if (isMobile) {
        res = true;
    }
    else {
        res = false;
    }
    return res;
}
/**
 * 跳转wap
 * @param code 代码
 * @param market 市场
 */
function gotowap(code, market) {
    var isJump = cookie_1["default"].get("has_jump_to_web");
    console.info(isJump);
    if (isJump && isJump == "1") {
        return false;
    }
    if (isMobile()) {
        self.location.href = "https://wap.eastmoney.com/quota/hq/stock?id=" + code + "&mk=" + market;
    }
}
exports["default"] = gotowap;


/***/ }),

/***/ "./src/modules/old_cnyrate/agiotage.js":
/*!*********************************************!*\
  !*** ./src/modules/old_cnyrate/agiotage.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// define(['IOScript', 'agiotage_temp'], function(IO, temp){
    var IO = __webpack_require__(/*! ./ioscript */ "./src/modules/old_cnyrate/ioscript.js")
    var temp = __webpack_require__(/*! ./agiotage_temp */ "./src/modules/old_cnyrate/agiotage_temp.js")

    Function.prototype.Bind = function() { 
        var __m = this, object = arguments[0], args = new Array(); 
        for(var i = 1; i < arguments.length; i++){
            args.push(arguments[i]);
        }
        
        return function() {
            return __m.apply(object, args);
        }
    };

    var forex = {
        computeF: function () {
            var bsv = $("#bs").val();
            if (isNaN(bsv)) {
                alert("金额必须为数字.");
                return false;
            }
            $("#res").value = "正在计算..";
            var x = $("#c1")[0][$("#c1")[0].selectedIndex].value;
            var y = $("#c2")[0][$("#c2")[0].selectedIndex].value;
            var url = "http://hq.sinajs.cn/list=" + x + "," + y;
            var scriptLoader = new IO.Script();
            scriptLoader.load(url, forex.deal.Bind(forex, x, y, bsv));

        },
        deal: function (x, y, bsv) {
            var forex1 = forex.dealSpe(x, eval("hq_str_" + x).split(",")[8]);
            var forex2 = forex.dealSpe(y, eval("hq_str_" + y).split(",")[8]);
            var result = (forex2 / forex1) * bsv;
            result = result.toFixed(4);
            $("#res").val(result);
        },

        dealSpe: function (type, val) {
            switch (type) {
                case 'US':
                    return 1;
                    break;
                case 'GBP':
                case 'EUR':
                case 'AUD':
                    return (1 / val).toFixed(4);
                    break;
                default:
                    return val;
                    break;
            }
        },

        addListener: function(){
            var computeF = this.computeF;
            $('#agiotage_btn').on('click',function(){
                computeF();
            })
        },

        temp: function(){
            $('#agiotage').html(temp);
        },

        init: function(){
            this.temp();
            this.addListener();
        }

    }

module.exports = forex
    // return forex;
// })

/***/ }),

/***/ "./src/modules/old_cnyrate/agiotage_tasks.js":
/*!***************************************************!*\
  !*** ./src/modules/old_cnyrate/agiotage_tasks.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// define(function(){
    var $l =  $("#tab_wyzgzgp li");
    $l.on("click", function(){
        var $t = $(this);
        var ind = $t.prevAll("li").length;
        $l.removeClass("cur");
        $t.addClass("cur");
    
        var $tb = $t.parents(".wyzgzgp").next().find("tbody");
        $tb.hide().eq(ind).show();
    });
    $("#select3").hover(function(e){
        $(this).children("dl").css("display","block");
    },function(e){
        $(this).children("dl").css("display","none");
    });
    $("#RefPR").on("click", function(){
         window.location.reload();
    });
    
    

    /**
    * @description get cookie with param(cookie.name)
    * @param {string} name
    * @return {string|null} .val
    */
    function getCookie(t) {
        var i = document.cookie;
        t += "=";
        for (var e = 0; e < i.length; ) {
            var s = e + t.length;
            if (i.substring(e, s) == t) {
                var n = i.indexOf(";", s);
                return -1 == n && (n = i.length),
                unescape(i.substring(s, n))
            }
            if (e = i.indexOf(" ", e) + 1,0 === e){
                break;
            }
                
        }
        return null 
    }

    //@description  refresh 
    function GetRandomNum(e, t) {
        var s = t - e;
        var a = Math.random();
        return e + Math.round(a * s);
    }
    $("#refgbauls").on("click", function (){for(var e=$("#gbauls")[0].getElementsByTagName("dl"),t=GetRandomNum(0,e.length-1),s=0;s<e.length;s++)if(s==t){if(e[s].hasChildNodes())for(var a=e[s].childNodes,i=0;i<a.length;i++)if(a[i].hasChildNodes()){var n=a[i].childNodes[0].getElementsByTagName("img")[0];n&&!n.getAttribute("src")&&n.setAttribute("src",n.getAttribute("data-value"))}e[s].style.display=""}else e[s].style.display="none"});
    
    window.hotpersonafp = function hotpersonafp(e, t, s) {
        var a = !1;
        if (getCookie("pi")) {
            var i = getCookie("pi");
            if (i.split(";").length >= 3) {
               
                var n = i.split(";")[2];

                if (/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(n))
                    a = !0; 
                else { 
                    var r = "http://iguba.eastmoney.com/action.aspx?callback=&action=oaddfollowperson&uid2=" + e;
                    var now=new Date();

                    var script = document.createElement('script');
                    script.src = r + "&v=" + now.getDate()+""+now.getHours()+""+now.getMinutes()+"";
                    script.id = 'hotpersonafp';
                    document.getElementsByTagName('head')[0].appendChild(script);

                    function action(t){
                        t.className = "allow",
                        t.innerHTML = "",
                        t.onclick = null;
                        document.getElementsByTagName('head')[0].removeChild(script || document.getElementById('rmb_script'));
                    }

                    if (!!window.ActiveXObject || "ActiveXObject" in window){
                        script.onreadystatechange = function(){
                            
                            if(script.readyState === 'complete' || script.readyState === 'loaded'){
                                action(t)
                            }
                        }
                    }else{
                        $(script).on('load', function(){
                            action(t)
                        })
                    }
                }
            }else{
                
                a = !0;
            }
                
        }else{
            
            a = !0;
        }
        // TODO
        t.className = "allow",
        t.innerHTML = "",
        t.onclick = null;   
        // a && (location.href = "http://guba.eastmoney.com/login.aspx?url=http://quote.eastmoney.com/" + s + ".html");
    }

    //@description  vote
    // var date = new Date();
    // var _date = date.getUTCFullYear() +''+ (date.getUTCMonth() < 9 ? ( 0 + ''+ (date.getUTCMonth() + 1)) : date.getUTCMonth() + 1) + date.getUTCDate();
  
    // var url_vote = 'http://iguba.eastmoney.com/gubaapi/v3/read/Guba/GubaInfo.aspx?code='+ window.stockcode +'&pi=&deviceid=21163A425F7727789381D8356B6068E2&version=180&product=Eastmoney&plat=web&rt=' + _date;
    // $.ajax({type: "get", dataType: "jsonp", jsonpCallback: "callback", url: url_vote}).done(function (data){
    //     var countAgree,countOppose;
 
    //     var sum = parseInt(data.stockbar_look_high_count + data.stockbar_look_low_count, 10);
    //     countAgree = 100 * data.stockbar_look_high_count/sum;
    //     countOppose = 100 - countAgree;
    
    //     $("#ivap").text(countAgree + '%');
    //     $("#ivbp").text(countOppose + '%');
    //     $("#ivra").css("width", countAgree);
    //     $("#ivrb").css("width", countOppose);

    // });
    // window.smivckNew = function smivckNew(e, t, s) {
    //     var a = "";
    //     var i = $('input:radio[name="hqvote"]:checked').val();
    //     if (!i)
    //         return alert("请先选择投票方向！");
    //     getCookie("pi") && (a = getCookie("pi"));
    //     var n = "http://hqstat.eastmoney.com/vote/QuoteGuBaLookUpOrDown.aspx?code=" + e + "&islow=" + i + "&pi=" + a + "&cb=var%20res=[{0}]&&num=1&rt=" + formatm();

    //     //

    // }

    /**
    * @description  logout
    */
    window.dcookies = function dcookies(sName) {
        var date = new Date();
        document.cookie = "dcusername=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserinfo=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcusermingchen=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserpass=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserpubinfo=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserpubs=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserkeys=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_name=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_info=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_mingchen=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_pass=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_pubinfo=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_pubs=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_keys=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "puser_pname=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "puser_pinfo=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "pi=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        window.location.reload();
    } 
// });

/***/ }),

/***/ "./src/modules/old_cnyrate/agiotage_temp.js":
/*!**************************************************!*\
  !*** ./src/modules/old_cnyrate/agiotage_temp.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// define(function(){
	module.exports =  '<div class="exchange clear">' +
            '     <label>所持有货币：</label><p>' +
            '         <select id="c1" name="c1">' +
            '             <option value="US">美元</option>' +
            '             <option value="EUR">欧元</option>' +
            '             <option value="GBP">英镑</option>' +
            '             <option value="AUD">澳元</option>' +
            '             <option value="JPY">日元</option>' +
            '             <option value="CHF">瑞郎</option>' +
            '             <option value="CAD">加元</option>' +
            '             <option value="HKD">港币</option>' +
            '             <option value="USDCNY">人民币</option>' +
            '         </select>' +
            '     </p>' +
            '     <label>兑换的货币：</label><p>' +
            '         <select id="c2" name="c2">' +
            '             <option value="US">美元</option>' +
            '             <option value="EUR">欧元</option>' +
            '             <option value="GBP">英镑</option>' +
            '             <option value="AUD">澳元</option>' +
            '             <option value="JPY">日元</option>' +
            '             <option value="CHF">瑞郎</option>' +
            '             <option value="CAD">加元</option>' +
            '             <option value="HKD">港币</option>' +
            '             <option value="USDCNY">人民币</option>' +
            '         </select>' +
            '     </p>' +
            '     <label>资金额：</label><p><input name="bs" type="text" id="bs" value="100" size="8"></p>' +
            '     <label>兑换后金额：</label><p><input name="res" type="text" id="res" value="100" size="14" readonly="readonly"></p>' +
            ' </div>' +
            ' <div class="btnCalc" ><b id="agiotage_btn">计 算</b></div>'
    ;
// })

/***/ }),

/***/ "./src/modules/old_cnyrate/em.forex.cnyc.min.js":
/*!******************************************************!*\
  !*** ./src/modules/old_cnyrate/em.forex.cnyc.min.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

﻿var jquery = jQuery
var template = __webpack_require__(/*! ./template */ "./src/modules/old_cnyrate/template.js")
    //主业务模块
    window.baseUrl = 'http://push2.eastmoney.com'
    window.ut = 'bd1d9ddb04089700cf9c27f6f7426281'
    function getColor(str) {
        var context = str.toString();
        context = context.replace("%", "");
        if (context == 0 || isNaN(context)) {
            return "";
        } else if (context > 0) {
            return "red";
        } else {
            return "green";
        }
    }

    function EM_Forex_CNYC(code) {
        if (!code) code = window.stockcode;
        this.code = code;
        var _instance = this;
        var dataRefresher = this.dataRefresher = {};
        var defaultApiURI = this["defaultApiURI"] = "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx";
        var defaultInterval = window["defaultInterval"] = 1000 * 60;
        var apiToken = "4f1862fc3b5e77c150a2b985b12db0fd";
        this.pageInit = function () {
            var _url = window.location.href;
            $("#guba_reg").attr("href", "//guba.eastmoney.com/reg.aspx?url=" + _url);
            $("#guba_login").attr("href", "//guba.eastmoney.com/login.aspx?url=" + _url);

            $(".RMBTab_rate .tabLi").mouseover(function () {
                $(this).addClass("cur").siblings().removeClass("cur");
                var i = $(this).index();
                $(".RMBCont .info_list").eq(i).addClass("active").siblings().removeClass("active");
            });

            $("#pictit span").click(function () {
                $(this).addClass("cur").siblings().removeClass("cur");
                initChart();
            });
            $("#submitdate").on("click", function () {
                var date = $("#querydate").val();
                if (date === "") { return; }
                var re = /(\d{4})(\d{2})(\d{2})/;
                var matches = re.exec(date);
                if (matches !== null) {
                    window.open('http://forex.eastmoney.com/fc.html?Date=' + matches[1] + '-' + matches[2] + '-' + matches[3], '_blank');
                } else {
                    window.open('http://forex.eastmoney.com/fc.html?Date=' + date, '_blank');
                }
            });
            _pageInit(code);
        };

        // 页面初始化
        var _pageInit = function (code) {
            initCC(code);
            initChart();
            //initPeriodicalASC(code);
            initMiddlePrice();
            initRMBRate();
            initRefRate(code);
            initBaseRate();
            initForexPrice();
            initCOMP();
            initCrossRate();
        };

        //当前货币图表
        function initChart() {
            var _img_url = "http://pifm3.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx";
            var _uw = $("#pictit span.cur").attr("value") || 90;
            var params = { id: window.stockcode + "0", imageType: "TLH", unitWidth: _uw, token: apiToken, "_": Math.random() };
            $("#picr img").attr("src", _img_url + "?" + $.parseParam(params));
            if (dataRefresher["ChartData"]) clearTimeout(dataRefresher["ChartData"]);
            dataRefresher["ChartData"] = setTimeout(initChart, defaultInterval);
        }

        //当前货币相关
        function initCC(code) {
            //57证券代码 58证券名称 107市场号 43最新价 44最高价 45最低价 46开盘价
            //60昨收  59小数 152小数 170涨跌幅 169涨跌值 174 52周最高价 175	52周最低价
            //119 5日涨跌幅 120	20日涨跌幅 121 60日涨跌幅 122 年初至今涨跌幅
            var _auto = dataRefresher["CCData"] = $.dataAutoRefresh({
                url: window.baseUrl + '/api/qt/stock/get?secid=120.' + code + '&ut=' + window.ut + '&fields=f57,f58,f59,f107,f43,f44,f45,f46,f60,f152,f169,f170,f119,f120,f121,f122,f169,f170,f174,f175&invt=2',
                type: "GET",
                dataType: "jsonp",
                jsonp: "cb",
                data: null,
                success: function (res) {
                    // console.log(res)
                    var data = res.data
                    if (!data) return false;
                    $("#brief_info li i").eq(0).text(data.f43 == '-' ? "-" : ((data.f43 / Math.pow(10, data.f59)).toFixed(data.f59))).addClass((data.f169 + '').isPositive() ? 'red' : 'green')
                    $("#brief_info li i").eq(1).text(data.f60 == '-' ? "-" : ((data.f60 / Math.pow(10, data.f59)).toFixed(data.f59)))
                    $("#brief_info li i").eq(2).text(data.f169 == '-' ? "-" : ((data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))).addClass((data.f169 + '').isPositive() ? 'red' : 'green')
                    $("#brief_info li i").eq(3).text(data.f170 == '-' ? "-" : ((data.f170 / Math.pow(10, data.f152)).toFixed(data.f152) + '%')).addClass((data.f169 + '').isPositive() ? 'red' : 'green')

                    $(".brief_topP i").text(data.f43 == '-' ? "-" : ((data.f43 / Math.pow(10, data.f59)).toFixed(data.f59))).addClass((data.f169 + '').isPositive() ? 'red' : 'green')
                    $(".brief_topP em").addClass((data.f169 + '').isPositive() ? 'arrow_up' : 'arrow_down')
                    $(".brief_botP i").eq(0).text((data.f169 > 0 ? '+' : '') + (data.f169 == '-' ? "-" : ((data.f169 / Math.pow(10, data.f59)).toFixed(data.f59)))).addClass((data.f169 + '').isPositive() ? 'red' : 'green')
                    $(".brief_botP i").eq(1).text((data.f169 > 0 ? '+' : '') + (data.f170 == '-' ? "-" : ((data.f170 / Math.pow(10, data.f152)).toFixed(data.f152) + '%'))).addClass((data.f169 + '').isPositive() ? 'red' : 'green')

                    $("#phase_increases td[data-cc=5] i").text(data.f43 == '-' ? "-" : ((data.f43 / Math.pow(10, data.f59)).toFixed(data.f59))).addClass((data.f169 + '').isPositive() ? 'red' : 'green')
                    $("#phase_increases td[data-cc=4] i").text(data.f60 == '-' ? "-" : ((data.f60 / Math.pow(10, data.f59)).toFixed(data.f59)))
                    $("#phase_increases td[data-cc=6] i").text(data.f169 == '-' ? "-" : ((data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))).addClass((data.f169 + '').isPositive() ? 'red' : 'green')
                    $("#phase_increases td[data-cc=7] i").text(data.f170 == '-' ? "-" : ((data.f170 / Math.pow(10, data.f152)).toFixed(data.f152) + '%')).addClass((data.f169 + '').isPositive() ? 'red' : 'green')

                    $("#brief_info li[data-ex=high] i").text(data.f60 == '-' ? "-" : ((data.f174 / Math.pow(10, data.f59)).toFixed(data.f59))).addClass("red")
                    $("#brief_info li[data-ex=low] i").text(data.f60 == '-' ? "-" : ((data.f175 / Math.pow(10, data.f59)).toFixed(data.f59))).addClass("green")

                    $("#phase_increases td[data-ex=high] i").text(data.f60 == '-' ? "-" : ((data.f174 / Math.pow(10, data.f59)).toFixed(data.f59))).addClass("red")
                    $("#phase_increases td[data-ex=low] i").text(data.f60 == '-' ? "-" : ((data.f175 / Math.pow(10, data.f59)).toFixed(data.f59))).addClass("green")

                    var model = {
                        day5: { value: (data.f119 == '-' ? "-" : ((data.f119 / Math.pow(10, data.f152)).toFixed(data.f152) + '%')), color: (data.f119 + '').isPositive() ? "red" : "green" },
                        day20: { value: (data.f120 == '-' ? "-" : ((data.f120 / Math.pow(10, data.f152)).toFixed(data.f152) + '%')), color: (data.f120 + '').isPositive() ? "red" : "green" },
                        day60: { value: (data.f121 == '-' ? "-" : ((data.f121 / Math.pow(10, data.f152)).toFixed(data.f152) + '%')), color: (data.f121 + '').isPositive() ? "red" : "green" },
                        uptonow: { value: (data.f122 == '-' ? "-" : ((data.f122 / Math.pow(10, data.f152)).toFixed(data.f152) + '%')), color: (data.f122 + '').isPositive() ? "red" : "green" }
                    };
                    $("#phase_increases2").html(template("tmp_phase_increases2", model));
                },
                error: function (err) {
                }
            });
            //_auto.start();
            //var _auto = dataRefresher["CCData"] = $.dataAutoRefresh({
            //    url: defaultApiURI,
            //    type: "GET",
            //    dataType: "jsonp",
            //    jsonp: "cb",
            //    timeout: 5000,
            //    data: {
            //        type: "CT",
            //        cmd: code + "0",
            //        sty: "MPICT",
            //        st: "(Code)",
            //        token: apiToken
            //    },
            //    success: function (data) {
            //        if (!data || data.length === 0) return false;
            //        var model = data[0].split(',');
            //        var pnf = model[6].isPositive();
            //        $("#brief_info li,#quote_brief [data-cc],#phase_increases [data-cc]").each(function (idx, target) {
            //            var _target = $(target), pos = parseInt(_target.data()["cc"]);
            //            if (pos) {
            //                var $ele = null, value = !model[pos] ? "-" : model[pos];
            //                if (target.tagName.toLowerCase() === "i") {
            //                    $ele = _target;
            //                    if (model[pos] && pnf && model[pos].indexOf("+") !== 0)
            //                        value = "+" + value;
            //                }
            //                else {
            //                    $ele = _target.find("i");
            //                    value = model[pos];
            //                }
            //                var _org = $ele.html();
            //                $ele.html(value);
            //                if (pos !== 4) {
            //                    if (pnf === true) {
            //                        $ele.attr("class", "red");
            //                        if (_org !== value)
            //                            $ele.textBlink({ color: ["#FFDDDD", "#FFEEEE", ""], blinktime: 150 });
            //                        _target.find("em").attr("class", "arrow_up");
            //                    }
            //                    else if (pnf === false) {
            //                        $ele.attr("class", "green");
            //                        if (_org !== value)
            //                            $ele.textBlink({ color: ["#b4f7af", "#ccffcc", ""], blinktime: 150 });
            //                        _target.find("em").attr("class", "arrow_down");
            //                    }
            //                }
            //            }
            //        });
            //    },
            //    error: function () { }
            //});
            _auto.start();
        }

        //阶段涨幅
        function initPeriodicalASC(code) {
            var _auto = dataRefresher["PascData"] = $.dataAutoRefresh({
                url: defaultApiURI,
                type: "GET",
                dataType: "jsonp",
                jsonp: "cb",
                data: {
                    type: "CT",
                    cmd: code + "0",
                    sty: "FDPSUD",
                    token: apiToken
                },
                success: function (json) {
                    if (!json || json.length <= 0) return false;
                    var str = json[0].split(",")[10];
                    if (!str || str === "-") return false;
                    var _data = str.split("|");
                    var model = {
                        day5: { value: _data[0], color: _data[0].isPositive() ? "red" : "green" },
                        day10: { value: _data[1], color: _data[1].isPositive() ? "red" : "green" },
                        day20: { value: _data[2], color: _data[2].isPositive() ? "red" : "green" },
                        day60: { value: _data[3], color: _data[3].isPositive() ? "red" : "green" },
                        uptonow: { value: _data[4], color: _data[4].isPositive() ? "red" : "green" }
                    };
                    $("#phase_increases2").html(template("tmp_phase_increases2", model));
                    var extremum = json[0].split(",")[9];
                    if (!extremum) return false;
                    var high = extremum.split('|')[0] ? extremum.split('|')[0] : "-", low = extremum.split('|')[1] ? extremum.split('|')[1] : "-";
                    $("#brief_info [data-ex],#phase_increases [data-ex]").each(function (idx, ele) {
                        if ($(ele).data()["ex"] === "high") {
                            $(ele).find("i").attr("class", "red").html(high);
                        }
                        else if ($(ele).data()["ex"] === "low") {
                            $(ele).find("i").attr("class", "green").html(low);
                        }
                    });
                },
                error: function () { }
            });
            //_auto.start();
        }

        //人民币中间价
        function initMiddlePrice() {
            var url = window.baseUrl + '/api/qt/clist/get?pn=1&pz=9&po=1&np=1&ut=' + window.ut + '&fltt=2&invt=2&fid=f3&fs=m:120&fields=f1,f2,f3,f12,f13,f4,f14,f152'
            var _auto = dataRefresher["MPData"] = $.dataAutoRefresh({
                url: url,
                type: "GET",
                dataType: "jsonp",
                jsonp: "cb",
                timeout: 5000,
                data: {
                    type: "GET",
                    url: url,
                    data: null,
                    dataType: "jsonp",
                    jsonp: 'cb'
                },
                success: function (res) {
                    if (!res || !res.data || !res.data.diff || !res.data.diff.length) {
                        return false;
                    }
                    var data = res.data.diff
                    var models = new Array();
                    for (var i = 0; i < data.length; i++) {
                        if (!data[i]) continue;
                        var name = data[i].f14.replace(/中间价$/, "").replace(/^人民币/, "人民币/").replace(/人民币$/, "/人民币");
                        var change = data[i].f4 == '-' ? '-' : ((data[i].f4) * 10000).toFixed(0)
                        models.push({
                            Code: data[i].f12,
                            Title: name,
                            Name: name.cutstr(14, '...'),
                            Close: data[i].f2 == '-' ? '-' : data[i].f2.toFixed(4),
                            Change: change > 0 ? ('+' + change) : change,
                            Color: data[i].f3 >= 0 ? "red" : "green"
                        });
                    }
                    var html = template("tmp_middlePrice", { list: models });
                    $("#middlePrice tbody").html(html);
                },
                error: function () { }
            });
            _auto.start();
        }

        //人民币汇率
        function initRMBRate() {
            _load();
            setInterval(_load, defaultInterval);
            function _load() {
                var url = window.baseUrl + '/api/qt/clist/get?pn=1&pz=5&po=1&np=1&ut=' + window.ut + '&fltt=2&invt=2&fid=f3&fs=m:121+t:1,m:120&fields=f1,f2,f3,f12,f13,f4,f14,f152'
                $.ajax({
                    url: url,
                    data: null,
                    dataType: "jsonp",
                    jsonp: "cb",
                    success: function (res) {
                        if (!res || !res.data || !res.data.diff || !res.data.diff.length) {
                            return false;
                        }
                        var data = res.data.diff
                        var models = new Array();
                        for (var i = 0; i < data.length; i++) {
                            if (!data[i]) continue;
                            models.push({
                                id: data[i].f12 + '0',
                                Name: data[i].f14.cutstr(10, '...'),
                                Title: data[i].f14,
                                Close: data[i].f2.toFixed(4),
                                ChangePercent: data[i].f3 == '-' ? '-' : ((data[i].f3).toFixed(2)) + "%",
                                Color: parseFloat(data[i].f3) > 0 ? 'red' : parseFloat(data[i].f3) < 0 ? 'green' : ''
                            });
                        }
                        var html = template("tmp_CNYRate", { list: models });
                        $("#CNYRate tbody").html(html);
                    }
                });
            }
        }

        //相关汇率
        function initRefRate(code) {
            if (!code) return false;
            var code1 = code.substring(0, 3), code2 = code.substring(3, 6);
            var notcny = code1 === "CNY" ? code2 : code1;

            _load();
            setInterval(_load, defaultInterval);
            function _load() {
                var url =  window.baseUrl + '/api/qt/clist/get?pn=1&np=1&pz=5&po=1&fid=f3&fs=m:119+c:' + notcny
                $.ajax({
                    url: url,
                    data: null,
                    dataType: "jsonp",
                    jsonp: "cb",
                    success: function (res) {
                        if (!res || !res.data || !res.data.diff || !res.data.diff.length) {
                            html = template("tmp_RCRate", { hasdata: false });
                            $("#RCRate tbody").html(html);
                            return false;
                        }
                        var data = res.data.diff
                        if (!data || data.length === 0) {
                            html = template("tmp_RCRate", { hasdata: false });
                            $("#RCRate tbody").html(html);
                            return false;
                        } else {
                            var models = new Array();
                            for (var i in data) {
                                if (!data[i]) continue;
                                var _color = data[i].f3 > 0 ? 'red' : data[i].f3 < 0 ? 'green' : ''
                                models.push({
                                    Code: data[i].f12,
                                    Name: data[i].f14.cutstr(10, ".."),
                                    Title: data[i].f14,
                                    Close: (data[i].f2 == '-' ? '-' : (data[i].f2 / 10000).toFixed(4)),
                                    ChangePercent: (data[i].f3 == '-' ? '-' : ((data[i].f3 / 100).toFixed(2)) + "%"),
                                    Color: _color
                                });
                            }
                            html = template("tmp_RCRate", { hasdata: true, list: models });
                            $("#RCRate tbody").html(html);
                        }
                    }
                });
            }

            // var _auto = dataRefresher["RCData"] = $.dataAutoRefresh({
            //     url: window.baseUrl + '/api/qt/clist/get?pn=1&pz=5&po=1&fid=f3&fs=m:119+c:' + notcny,
            //     type: "GET",
            //     data: null,
            //     dataType: "jsonp",
            //     jsonp: 'cb',
            //     success: function (res) {

            //         if (!res || !res.data || !res.data.diff || !res.data.diff.length) {
            //             html = template("tmp_RCRate", { hasdata: false });
            //             $("#RCRate tbody").html(html);
            //             return false;
            //         }
            //         var data = res.data.diff
            //         if (!data || data.length === 0) {
            //             html = template("tmp_RCRate", { hasdata: false });
            //             $("#RCRate tbody").html(html);
            //             return false;
            //         } else {
            //             var models = new Array();
            //             for (var i in data) {
            //                 if (!data[i]) continue;
            //                 var _color = data[i].f3 > 0 ? 'red' : data[i].f3 < 0 ? 'green' : ''
            //                 models.push({
            //                     Code: data[i].f12,
            //                     Name: data[i].f14.cutstr(10, ".."),
            //                     Title: data[i].f14,
            //                     Close: (data[i].f2 == '-' ? '-' : (data[i].f2 / 10000).toFixed(4)),
            //                     ChangePercent: (data[i].f3 == '-' ? '-' : ((data[i].f3 / 100).toFixed(2)) + "%"),
            //                     Color: _color
            //                 });
            //             }
            //             html = template("tmp_RCRate", { hasdata: true, list: models });
            //             $("#RCRate tbody").html(html);
            //         }
            //     }
            // });
            // _auto.start();
        }
        // function initRefRate(code) {
        //     if (!code) return false;
        //     var code1 = code.substring(0, 3), code2 = code.substring(3, 6);
        //     var notcny = code1 === "CNY" ? code2 : code1;
        //     var _auto = dataRefresher["RCData"] = $.dataAutoRefresh({
        //         url: window.baseUrl + '/api/qt/clist/get?pn=1&pz=5&po=1&fid=f3&fs=m:119+c:' + notcny,
        //         type: "GET",
        //         data: null,
        //         dataType: "jsonp",
        //         jsonp: 'cb',
        //         success: function (res) {

        //             if (!res || !res.data || !res.data.diff || !res.data.diff.length) {
        //                 html = template("tmp_RCRate", { hasdata: false });
        //                 $("#RCRate tbody").html(html);
        //                 return false;
        //             }
        //             var data = res.data.diff
        //             if (!data || data.length === 0) {
        //                 html = template("tmp_RCRate", { hasdata: false });
        //                 $("#RCRate tbody").html(html);
        //                 return false;
        //             } else {
        //                 var models = new Array();
        //                 for (var i in data) {
        //                     if (!data[i]) continue;
        //                     var _color = data[i].f3 > 0 ? 'red' : data[i].f3 < 0 ? 'green' : ''
        //                     models.push({
        //                         Code: data[i].f12,
        //                         Name: data[i].f14.cutstr(10, ".."),
        //                         Title: data[i].f14,
        //                         Close: (data[i].f2 == '-' ? '-' : (data[i].f2 / 10000).toFixed(4)),
        //                         ChangePercent: (data[i].f3 == '-' ? '-' : ((data[i].f3 / 100).toFixed(2)) + "%"),
        //                         Color: _color
        //                     });
        //                 }
        //                 html = template("tmp_RCRate", { hasdata: true, list: models });
        //                 $("#RCRate tbody").html(html);
        //             }
        //         }
        //     });
        //     _auto.start();
        // }

        //基本汇率行情
        function initBaseRate() {
            var url = window.baseUrl + '/api/qt/clist/get?pn=1&pz=5&po=1&np=1&ut=' + window.ut + '&fltt=2&invt=2&fid=f3&fs=b:MK0300&fields=f1,f2,f3,f12,f13,f14,f152'
            var _auto = dataRefresher["CRData"] = $.dataAutoRefresh({
                url: url,
                dataType: "jsonp",
                jsonp: 'cb',
                data: null,
                success: function (res) {
                    if (!res || !res.data || !res.data.diff || !res.data.diff.length) {
                        return false;
                    }
                    var data = res.data.diff
                    var models = new Array();
                    for (var i = 0; i < data.length; i++) {
                        if (!data[i]) continue;

                        var _color = data[i].f3 > 0 ? 'red' : data[i].f3 < 0 ? 'green' : ''
                        models.push({
                            Code: data[i].f12,
                            Name: data[i].f14,
                            Title: data[i].f14,
                            Close: (data[i].f2 == '-' ? '-' : (data[i].f2).toFixed(4)),
                            ChangePercent: (data[i].f3 == '-' ? '-' : ((data[i].f3).toFixed(2)) + "%"),
                            Color: _color,
                            Link: "//quote.eastmoney.com/forex/" + data[i].f12 + ".html"
                        });
                    }
                    $("#base_rate tbody").html(template("tmp_base_rate", { list: models }));
                }
            });
            _auto.start();
        }

        //外汇牌价
        function initForexPrice() {
            var _auto = dataRefresher["FPData"] = $.dataAutoRefresh({
                url: "http://183.136.160.92/EM_UBG_Finance2016TransferExtendInterface/js.ashx",
                type: "GET",
                dataType: "jsonp",
                jsonp: "js",
                timeout: 5000,
                data: {
                    type: "ForexPrevailingPrice",
                    cmd: "9"
                },
                success: function (data) {
                    if (!data || data.length === 0) return false;
                    var models = data[0];
                    $("#forex_price tbody").html(template("tmp_forex_price", { list: models }));
                },
                error: function () { }
            });
            _auto.start();
        }

        //贵金属原油
        function initCOMP() {
            //var url =  window.baseUrl + '/api/qt/clist/get?pn=1&pz=7&po=1&np=1&ut=' + window.ut + '&fltt=2&invt=2&fid=f3&fs=m:102,m:103,m:108,m:109,m:111,m:112&fields=f1,f2,f3,f12,f13,f14,f152'
            var url = window.baseUrl + '/api/qt/ulist.np/get?secids=112.BC,101.GC00Y,109.LCPS,111.JRUC,108.CTC,109.LTNS,109.LZNS&ut=' + window.ut + '&fid=f3&fields=f1,f2,f3,f4,f12,f13,f14,f152&invt=2'
            var _auto = dataRefresher["COMPData"] = $.dataAutoRefresh({
                url: url,
                type: "GET",
                dataType: "jsonp",
                jsonp: 'cb',
                data: null,
                timeout: 5000,
                success: function (res) {
                    if (!res || !res.data || !res.data.diff || !res.data.diff.length) {
                        return false;
                    }
                    var data = res.data.diff
                    var models = new Array();
                    for (var i = 0; i < data.length; i++) {
                        if (!data[i]) continue;
                        models.push({
                            Code: data[i].f12,
                            Name: data[i].f14.cutstr(10, "..."),
                            Title: data[i].f14,
                            Close: (data[i].f2 == '-' ? '-' : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)),
                            ChangePercent: (data[i].f3 == '-' ? '-' : ((data[i].f3 / 100).toFixed(2)) + "%"),
                            Color: data[i].f3 > 0 ? 'red' : data[i].f3 < 0 ? 'green' : '',
                            Link: 'http://quote.eastmoney.com/globalfuture/' + data[i].f12 + '.html'
                        });
                    }
                    var html = template("tmp_oil_metal", { list: models });
                    $("#oil_metal tbody").html(html);
                },
                error: function () { }
            });
            _auto.start();
        }

        //var html = template("tmp_oil_metal", { list: models });
        //$("#oil_metal tbody").html(html);
        //交叉汇率行情
        function initCrossRate() {
            var url = window.baseUrl + '/api/qt/clist/get?pn=1&pz=5&po=1&np=1&ut=' + window.ut + '&fltt=2&invt=2&fid=f3&fs=b:MK0301&fields=f1,f2,f3,f12,f13,f14,f152'
            var _auto = dataRefresher["CRData"] = $.dataAutoRefresh({
                url: url,
                dataType: "jsonp",
                jsonp: 'cb',
                data: null,
                success: function (res) {
                    if (!res || !res.data || !res.data.diff || !res.data.diff.length) {
                        return false;
                    }
                    var data = res.data.diff
                    var models = new Array();
                    for (var i = 0; i < data.length; i++) {
                        if (!data[i]) continue;
                        var _color = data[i].f3 > 0 ? 'red' : data[i].f3 < 0 ? 'green' : ''
                        models.push({
                            Code: data[i].f12,
                            Name: data[i].f14,
                            Title: data[i].f14,
                            Close: (data[i].f2 == '-' ? '-' : (data[i].f2).toFixed(4)),
                            ChangePercent: (data[i].f3 == '-' ? '-' : ((data[i].f3).toFixed(2)) + "%"),
                            Color: _color,
                            Link: "//quote.eastmoney.com/forex/" + data[i].f12 + ".html"
                        });
                    }
                    $("#cross_rate tbody").html(template("tmp_cross_rate", { list: models }));
                },
                error: function () { }
            });
            _auto.start();
        }
    }
    // 扩展方法定义
    function extendFuncs(jQuery, template) {
        // jquery扩展
        jQuery.extend({
            //定时数据获取扩展
            dataAutoRefresh: function (settings) {
                var fname = "";
                var _init = false, _intInterval = !window["defaultInterval"] ? 1000 * 20 : window.defaultInterval, _intThread = -1;
                if (!settings["dataType"]) settings["dataType"] = "text";
                if (!!settings["dataType"] && settings["dataType"] === "jsonp") {
                    if (!settings["jsonpCallback"] || settings["jsonpCallback"] === "?") {
                        var fCallback = null;
                        fname = "jQuery" + Math.random().toString().split('.')[1] + "_" + Math.random().toString().split('.')[1];
                        // 不可改
                        window.eval("jQuery.extend({" + fname + ":" + settings["success"] + "});");
                        fCallback = window.eval("jQuery." + fname);
                        settings["jsonpCallback"] = "jQuery." + fname;
                    }
                }
                return {
                    init: _init,
                    intInterval: _intInterval,
                    intThread: _intThread,
                    callback: fname,
                    load: function () {
                        this.init = true;
                        if (typeof (settings) !== "object" || !settings)
                            return false;
                        if (settings.dataType.toLowerCase() === "js") {
                            $.jsLoader(settings);
                        }
                        else if (settings.dataType.toLowerCase() === "img") {
                            $.imgLoader(settings);
                        }
                        else {
                            var _timeout = 5000;
                            settings["timeout"] = !settings.timeout ? _timeout : settings["timeout"];
                            if (!!settings.dataType && settings.dataType.toLowerCase() === "jsonp") {
                                settings["type"] = "GET";
                                settings["jsonp"] = !settings.jsonp ? "cb" : settings.jsonp;
                            }
                            $.ajax(settings);
                        }
                    },
                    start: function () {
                        this.stop();
                        this.load();
                        this.intThread = setInterval(this.load, this.intInterval);
                    },
                    stop: function () {
                        if (this.intThread !== -1) {
                            clearInterval(this.intThread);
                            delete settings.jsonpCallback;
                        }
                        this.intThread = -1;
                    }
                }
            },
            //异步动态图片加载
            imgLoader: function (setting) {
                if (typeof (setting) !== "object" || !setting["url"]) return false;
                var fCallback = typeof (setting["success"]) === "function" ? setting["success"] : null;
                var _url = setting["url"];
                if (setting["data"]) {
                    var _data = $.parseParam(setting["data"]);
                    _url = _url.indexOf("?") > 0 ? _url + "&" + _data : _url + "?" + _data;
                }
                if (!setting["cache"]) {
                    _url += _url.indexOf("?") > 0 ? "&_=" + Math.random() : "?_=" + Math.random();
                }
                var _image = document.createElement("img");
                if (typeof (setting["height"]) === "number" && setting["height"] > 0) {
                    _image.setAttribute("height", setting["height"] + "px");
                }
                if (typeof (setting["width"]) === "number" && setting["width"] > 0) {
                    _image.setAttribute("width", setting["width"] + "px");
                }
                _image.setAttribute('src', _url);
                if (typeof (setting["error"]) === "function")
                    $(_image).error(function () { setting["error"](_image); });
                _image.onload = _image.onreadystatechange = function (evt) {
                    if (!_image.readyState || /loaded|complete/.test(_image.readyState)) {
                        // Handle memory leak in IE
                        _image.onload = _image.onreadystatechange = null;
                        // Callback if not abort
                        if (fCallback) fCallback(_image);
                    }
                };
            },
            //异步动态脚本加载
            jsLoader: function (setting) {
                if (typeof (setting) !== "object" || !setting["url"]) return false;
                var fCallback = typeof (setting["success"]) === "function" ? setting["success"] : null;
                var _url = setting["url"], _charset = !setting["charset"] ? "utf-8" : setting["charset"];
                if (setting["data"]) {
                    var _data = $.parseParam(setting["data"]);
                    _url = _url.indexOf("?") > 0 ? _url + "&" + _data : _url + "?" + _data;
                }
                if (!setting["cache"]) {
                    _url += _url.indexOf("?") > 0 ? "&_=" + Math.random() : "?_=" + Math.random();
                }
                var _script = document.createElement('script');
                if (typeof (setting["async"]) !== "boolean") {
                    _script.async = _script.defer = true;
                }
                else _script.async = _script.defer = setting["async"];
                _script.setAttribute('charset', _charset);
                _script.setAttribute('type', 'text/javascript');
                _script.setAttribute('src', _url);
                _script.onload = _script.onreadystatechange = function () {
                    if (!_script.readyState || /loaded|complete/.test(_script.readyState)) {
                        // Handle memory leak in IE
                        _script.onload = _script.onreadystatechange = null;
                        // Callback if not abort
                        if (fCallback) fCallback();
                        // Remove the script
                        if (_script.parentNode) {
                            _script.parentNode.removeChild(_script);
                        }
                        // Dereference the script
                        _script = null;
                    }
                };
                document.getElementsByTagName('head')[0].appendChild(_script);
            },
            //URL参数生成器
            parseParam: function (param, key) {
                var paramStr = "";
                if (typeof (param) === "string" || typeof (param) === "number" || typeof (param) === "boolean") {
                    paramStr += "&" + key + "=" + encodeURIComponent(param);
                }
                else {
                    $.each(param, function (i, e) {
                        var k = !key ? i : key + (param instanceof Array ? "[" + i + "]" : "." + i);
                        paramStr += '&' + $.parseParam(e, k);
                    });
                }
                return paramStr.substr(1);
            }
        });
        jQuery.fn.extend({
            //让文字闪烁起来
            textBlink: function (options) {
                var defaults = {
                    color: ["#fff", "#ffe2d1", "#ffc2a1", "#ffa370", "#ff8340", "#ff630f"], //轮番颜色 默认橙色
                    blinktime: 60, //每帧时间 毫秒
                    circle: 2 //闪烁次数
                }
                var _options = jQuery.extend(defaults, options);
                var loop = 0;
                for (var i = 0; i < _options.color.length * _options.circle; i++) {
                    setTimeout(function () {
                        jQuery(this).attr("style", "background-color:" + _options.color[loop]);
                        loop++;
                        loop = loop % _options.color.length;
                    }, _options.blinktime * i);
                }
            }
        });
        String.prototype.isPositive = function () {
            var context = this;
            if (typeof (context).toLowerCase() === "string") {
                context = context.replace("%", "");
                var regNum = new RegExp("^([\\-\\+]?\\d+(\\.\\d+)?)$");
                if (regNum.test(context)) {
                    var reg = new RegExp("^-");
                    return !reg.test(context);
                }
                else return Number.NaN;
            }
        }
        //字符串模板处理
        String.prototype.template = function (args) {
            var result = this;
            var reg = null;
            if (arguments.length > 0) {
                if (arguments.length === 1 && typeof (args) === "object") {
                    for (var key in args) {
                        if (args[key] !== undefined) {
                            reg = new RegExp("({{" + key + "}})", "g");
                            result = result.replace(reg, args[key]);
                        }
                    }
                }
                else {
                    for (var i = 0; i < arguments.length; i++) {
                        if (arguments[i] !== undefined) {
                            reg = new RegExp("({{)" + i + "(}})", "g");
                            result = result.replace(reg, arguments[i]);
                        }
                    }
                }
            }
            return result;
        }
        /**
         * 对Date的扩展，将 Date 转化为指定格式的String
         * 月(M)、日(d)、12小时(h)、24小时(H)、分(m)、秒(s)、周(E)、季度(q) 可以用 1-2 个占位符
         * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
         * eg:
         * (new Date()).pattern("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
         * (new Date()).pattern("yyyy-MM-dd E HH:mm:ss") ==> 2009-03-10 二 20:09:04
         * (new Date()).pattern("yyyy-MM-dd EE hh:mm:ss") ==> 2009-03-10 周二 08:09:04
         * (new Date()).pattern("yyyy-MM-dd EEE hh:mm:ss") ==> 2009-03-10 星期二 08:09:04
         * (new Date()).pattern("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18
         * @param {string} fmt format for date.
         * @returns {string} string date.
        **/
        Date.prototype.pattern = function (fmt) {
            var o = {
                "M+": this.getMonth() + 1, //月份
                "d+": this.getDate(), //日
                "h+": this.getHours() % 12 === 0 ? 12 : this.getHours() % 12, //小时
                "H+": this.getHours(), //小时
                "m+": this.getMinutes(), //分
                "s+": this.getSeconds(), //秒
                "q+": Math.floor((this.getMonth() + 3) / 3), //季度
                "S": this.getMilliseconds() //毫秒
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\fu5468") : "") + week[this.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        }
        // template扩展
        template.helper('dateFormat', function (date, formate) {
            var o = {
                "M+": this.getMonth() + 1, //月份
                "d+": this.getDate(), //日
                "h+": this.getHours() % 12 === 0 ? 12 : this.getHours() % 12, //小时
                "H+": this.getHours(), //小时
                "m+": this.getMinutes(), //分
                "s+": this.getSeconds(), //秒
                "q+": Math.floor((this.getMonth() + 3) / 3), //季度
                "S": this.getMilliseconds() //毫秒
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\fu5468") : "") + week[this.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        });
        //字符串长度处理，超出部分变为...
        String.prototype.interceptString = function (length, length1) {
            var str = this;
            if (!length1) length1 = 0;
            if (typeof (length) !== "number") return str;
            str = str.replace(/[" "|"　"]/g, "");//去半角+全角空格
            if (str.length > length) {
                if (length1 === 0) {
                    length1 = length;
                }
                if (str.length >= length1) {
                    var str_left = str;//.substr(0, length1);
                    //var str_right = str.substr(length1);
                    var banjiao = 0;
                    var quanjiao = 0;
                    var strCode;
                    for (var i = 0; i < str.length; i++) {
                        strCode = str.charCodeAt(i);
                        if (strCode >= 33 && strCode <= 126) {
                            banjiao++;
                        }
                        else {
                            quanjiao++;
                        }
                    }
                    if ((quanjiao + banjiao / 2) > length || (quanjiao + banjiao / 2) - length === 0.5) {
                        str_left = str_left.substr(0, str_left.length - 1.5);
                        return str_left;
                    }
                    else if ((quanjiao + banjiao / 2) - length !== 0) {
                        if (length1 + 1 <= str.length) {
                            str_left = str.interceptString(length, length1 + 1);
                        }
                    }
                    return str_left;
                }
            }
            else return str;
        }
        /** 
         * js截取字符串，中英文都能用 
         * @param len: 需要截取的长度
         * @param ellipsis: 溢出文字
         */
        String.prototype.cutstr = function (len, ellipsis) {
            var str = this;
            ellipsis = ellipsis || "...";
            var str_length = 0;
            var str_len = 0;
            for (var i = 0; i < str.length; i++) {
                var a = str.charAt(i);
                str_length++;
                if (escape(a).length > 4) {
                    //中文字符的长度经编码之后大于4  
                    str_length++;
                }
                //str_cut = str_cut.concat(a);
                if (str_length <= len) {
                    str_len++;
                }
            }
            //如果给定字符串小于指定长度，则返回源字符串；  
            if (str_length <= len) {
                return str.toString();
            }
            else {
                return str.substr(0, str_len).concat(ellipsis);
            }
        }
    }

    // RequireJS && SeaJS
    // if (typeof define === 'function') {
    //     define(["jquery", "template"], function ($, template) {
    //         if (!window["$"]) window["$"] = $;
    //         if (!window["template"]) window["template"] = template;
    //         extendFuncs($, template);
    //         return EM_Forex_CNYC;
    //     });
    // } else {
    //     extendFuncs();
    //     this.EM_Forex_CNYC = EM_Forex_CNYC;
    // }
extendFuncs($, template)
    module.exports = EM_Forex_CNYC


/***/ }),

/***/ "./src/modules/old_cnyrate/globaltime.min.js":
/*!***************************************************!*\
  !*** ./src/modules/old_cnyrate/globaltime.min.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

﻿var global_deviation = 0; var _GlobalTime = function (b, a) { this.id = b; this.cache = {}; this.deviation = 0; this.opt = a; this.Option = { citys: [{ city: "\u5317\u4eac\u65f6\u95f4", utc: +8, id: 41 }, { city: "\u4f26\u6566\u65f6\u95f4", utc: +0, id: 2 }, { city: "\u7ebd\u7ea6\u65f6\u95f4", utc: -4, id: 78 }, { city: "\u6089\u5c3c\u65f6\u95f4", utc: +11, id: 53 }], display: "MM\u6708dd\u65e5 HH:mm:ss", styles: ".globaltime_city{padding:0 25px 0 30px;}.globaltime_time{padding:0 5px}", load: "now", url: "http://cmsjs.eastmoney.com/TimeZone/Default.aspx?type=utctime&ids={ids}&jn={jsName}" }; this.init() }; _GlobalTime.prototype.utils = { $: function (a) { return typeof (a) == "string" ? document.getElementById(a) : a }, extend: function (a, c) { for (var b in c) { a[b] = c[b] } return a }, attchEvent: function (e, b, c, a) { if (e.addEventListener) { e.addEventListener(b, c, a); return true } else { if (e.attachEvent) { var d = e.attachEvent("on" + b, c); return d } else { e["on" + b] = c } } }, detachEvent: function (e, b, c, a) { if (e.removeEventListener) { e.removeEventListener(b, c, a); return true } else { if (e.detachEvent) { var d = e.detachEvent("on" + b, c); return d } else { e["on" + b] = null; return } } }, dateFromat: function (c, a) { if (typeof c == "undefined") { c = new Date() } var g; var f = ""; a = (a == null) ? "yyyy-MM-dd HH:mm:ss" : a; var j = c.getFullYear(); var h = c.getMonth() + 1; var i = c.getDate(); var o = c.getHours(); var b = c.getMinutes(); var q = c.getSeconds(); var n = (h > 9) ? h : "0" + h; var l = (i > 9) ? i : "0" + i; var k = (o > 9) ? o : "0" + o; var e = (b > 9) ? b : "0" + b; var p = (q > 9) ? q : "0" + q; f = a.replace("yyyy", j).replace("MM", n).replace("dd", l).replace("HH", k).replace("mm", e).replace("ss", p).replace("M", h).replace("d", i).replace("H", o).replace("m", b).replace("s", q); return f }, jsLoad: function (d, c, b) { var a = document.createElement("script"); a.setAttribute("charset", c); a.setAttribute("type", "text/javascript"); a.setAttribute("src", d); document.getElementsByTagName("head")[0].appendChild(a); a.onload = a.onreadystatechange = function () { if (!this.readyState || this.readyState == "loaded" || this.readyState == "complete") { b(); b = null; a.parentNode.removeChild(a) } } }, now: function () { return new Date().getTime() }, formatTime: function (a, b) { return new Date(a + (3600000 * b)) } }; _GlobalTime.prototype.init = function () { var a = this; a.setOption(); if (a.Option.load == "onload") { a.utils.attchEvent(window, "load", function () { a.getServiceTime() }) } else { a.getServiceTime() } }; _GlobalTime.prototype.setOption = function () { var a = this; a.utils.extend(a.Option, a.opt || {}) }; _GlobalTime.prototype.builderCss = function () { var a = this.Option.styles; var c = document.createElement("style"); document.getElementsByTagName("HEAD").item(0).appendChild(c); c.type = "text/css"; if (c.styleSheet) { c.styleSheet.cssText = a } else { var b = document.createTextNode(a); c.appendChild(b) } }; _GlobalTime.prototype.getUtcIndent = function () { var a = this, d = a.Option.url, g = a.Option.citys.length, f = ""; for (var e = 0, c = g; e < c; e++) { f += f == "" ? a.Option.citys[e].id : "," + a.Option.citys[e].id } d = d.replace("{ids}", f); d = d.replace("{jsName}", "emutc"); d = d + "&rt=" + new Date().getTime(); var b = function () { _emutc = a.cache.emutc; if (_emutc.length != g) { alert("\u6709\u8bef"); return } for (var l = 0, k = g; l < k; l++) { var m = _emutc[l].split(":"), h = m[0] * 1; gmt_min = m[1] * 1; m = parseInt(h) + parseFloat(parseInt((gmt_min / 60) * 100) / 100); a.Option.citys[l].utc = m } }; if (!(typeof (emutc) == "undefined" || emutc == null || emutc == "")) { a.cache.emutc = emutc; b() } else { a.utils.jsLoad(d, "utf-8", function () { if (!(typeof (emutc) == "undefined" || emutc == null || emutc == "")) { a.cache.emutc = emutc; b() } }) } }; _GlobalTime.prototype.show = function () { var a = this; var f = a.Option; var b = f.citys.length; var l = [], k = []; for (var e = 0; e < b; e++) { k[e] = "globaltime_" + a.id + "_" + (a.utils.now() + e); l[e] = '<span class="globaltime_city">' + f.citys[e].city + '<span id="' + k[e] + '" class="globaltime_time"></span></span>' } a.utils.$(a.id).innerHTML = l.join(""); var h = function () { var d = a.utils.now() + a.deviation - (3600000 * 8); for (var c = 0; c < b; c++) { var j = a.utils.formatTime(d, f.citys[c].utc); a.utils.$(k[c]).innerHTML = a.utils.dateFromat(j, f.display) } }; h(); var g = setInterval(h, 1000) }; _GlobalTime.prototype.getServiceTime = function () { var a = this, d = a.Option.url, h = a.Option.citys.length, f = ""; for (var e = 0, c = h; e < c; e++) { f += f == "" ? a.Option.citys[e].id : "," + a.Option.citys[e].id } d = d.replace("{ids}", f); d = d.replace("{jsName}", "emutc"); d = d + "&rt=" + new Date().getTime(); var b = function () { _emutc = a.cache.emutc; if (_emutc.length != h) { return } for (var m = 0, l = h; m < l; m++) { var n = _emutc[m].split(":"), k = n[0] * 1; gmt_min = n[1] * 1; n = parseInt(k) + parseFloat(parseInt((gmt_min / 60) * 100) / 100); a.Option.citys[m].utc = n } a.builderCss(); a.show() }; var g = new Date().getTime(); a.utils.jsLoad(d, "utf-8", function () { if (!(typeof (emutc) == "undefined" || emutc == null || emutc == "")) { a.cache.emutc = emutc.GMT; var i = new Date().getTime(); a.deviation = emutc.UTCTIME + (i - g) * 0.5 - i; global_deviation = a.deviation; b() } }) };

module.exports = _GlobalTime

/***/ }),

/***/ "./src/modules/old_cnyrate/guba_cookie.js":
/*!************************************************!*\
  !*** ./src/modules/old_cnyrate/guba_cookie.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// define(function() {

var CookieUtil = {
    get: function (name){
        var cookieArray = document.cookie.split(";");
		for (var i = 0; i < cookieArray.length; i++) {
			var arr = cookieArray[i].split("=");
			if (arr[0].replace(" ", "") == name) return unescape(decodeURI(arr[1]));
		}
		return "";
    },
    set: function (name, value, expires, path, domain, secure) {
        var cookieText = encodeURIComponent(name) + "=" + 
                         encodeURIComponent(value);
     
        if (expires instanceof Date) {
            cookieText += "; expires=" + expires.toGMTString();
        }
     
        if (path) {
            cookieText += "; path=" + path;
        }
     
        if (domain) {
            cookieText += "; domain=" + domain;
        }
     
        if (secure) {
            cookieText += "; secure";
        }
     
        document.cookie = cookieText;
    },
    unset: function (name, path, domain, secure){
        this.set(name, "", new Date(0), path, domain, secure);
    }
};

module.exports = CookieUtil
// return CookieUtil;

// });

/***/ }),

/***/ "./src/modules/old_cnyrate/guba_postbox.js":
/*!*************************************************!*\
  !*** ./src/modules/old_cnyrate/guba_postbox.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

﻿// define(['jquery','guba_text'], function($, text) {

var text = __webpack_require__(/*! ./guba_text */ "./src/modules/old_cnyrate/guba_text.js")

	$.fn.gredit = function (options) { //textarea编辑器 参数 bindface:插入表情
		var defaults = {
			openface: function (){
			return false;
			},
			closeface: function (){
			return false;
			}
		};
		var options = $.extend(defaults, options);
		this.each(function () {
			var thisedit = $(this);
			//if (options.bindface) { //插入表情
			//options.bindface.live("click",function () {
			//inserttext("[" + $(this).attr("title") + "]")
			//});
			//}
			if( options.bindface ){ //绑定表情
				options.bindface.click(function(){
					//greditmethod.insertface($(this),nowedit);
					var thislink = $(this);
					var temphtml = '<div class="shadowbox" id="insertfacediv">';
					if( options.facearrow == "bottom" ){
						temphtml += '<div class="shadowboxbottomarrow"></div>';
					}
					else{
						temphtml += '<div class="shadowboxtoparrow"></div>';
					}
					temphtml += '<table class="shadowboxt" cellspacing="0" cellpadding="0"><tr><td class="l7"></td><td class="l8"></td><td class="l9"></td></tr><tr><td class="l4">&nbsp;</td><td class="l5"><div class="shadowboxbody"><div id="facediv"><ul id="facelist"><li title="微笑"><img title="微笑" src="http://gbres.dfcfw.com/face/emot/emot01.png" alt="微笑"></li><li title="大笑"><img title="大笑" src="http://gbres.dfcfw.com/face/emot/emot02.png" alt="大笑"></li><li title="鼓掌"><img title="鼓掌" src="http://gbres.dfcfw.com/face/emot/emot03.png" alt="鼓掌"></li><li title="不说了"><img title="不说了" src="http://gbres.dfcfw.com/face/emot/emot04.png" alt="不说了"></li><li title="为什么"><img title="为什么" src="http://gbres.dfcfw.com/face/emot/emot05.png" alt="为什么"></li><li title="哭"><img title="哭" src="http://gbres.dfcfw.com/face/emot/emot06.png" alt="哭"></li><li title="不屑"><img title="不屑" src="http://gbres.dfcfw.com/face/emot/emot07.png" alt="不屑"></li><li title="怒"><img title="怒" src="http://gbres.dfcfw.com/face/emot/emot08.png" alt="怒"></li><li title="滴汗"><img title="滴汗" src="http://gbres.dfcfw.com/face/emot/emot09.png" alt="滴汗"></li><li title="拜神"><img title="拜神" src="http://gbres.dfcfw.com/face/emot/emot10.png" alt="拜神"></li><li title="胜利"><img title="胜利" src="http://gbres.dfcfw.com/face/emot/emot11.png" alt="胜利"></li><li title="亏大了"><img title="亏大了" src="http://gbres.dfcfw.com/face/emot/emot12.png" alt="亏大了"></li><li title="赚大了"><img title="赚大了" src="http://gbres.dfcfw.com/face/emot/emot13.png" alt="赚大了"></li><li title="牛"><img title="牛" src="http://gbres.dfcfw.com/face/emot/emot14.png" alt="牛"></li><li title="俏皮"><img title="俏皮" src="http://gbres.dfcfw.com/face/emot/emot15.png" alt="俏皮"></li><li title="傲"><img title="傲" src="http://gbres.dfcfw.com/face/emot/emot16.png" alt="傲"></li><li title="好困惑"><img title="好困惑" src="http://gbres.dfcfw.com/face/emot/emot17.png" alt="好困惑"></li><li title="兴奋"><img title="兴奋" src="http://gbres.dfcfw.com/face/emot/emot18.png" alt="兴奋"></li><li title="赞"><img title="赞" src="http://gbres.dfcfw.com/face/emot/emot19.png" alt="赞"></li><li title="不赞"><img title="不赞" src="http://gbres.dfcfw.com/face/emot/emot20.png" alt="不赞"></li><li title="摊手"><img title="摊手" src="http://gbres.dfcfw.com/face/emot/emot21.png" alt="摊手"></li><li title="好逊"><img title="好逊" src="http://gbres.dfcfw.com/face/emot/emot22.png" alt="好逊"></li><li title="失望"><img title="失望" src="http://gbres.dfcfw.com/face/emot/emot23.png" alt="失望"></li><li title="加油"><img title="加油" src="http://gbres.dfcfw.com/face/emot/emot24.png" alt="加油"></li><li title="困顿"><img title="困顿" src="http://gbres.dfcfw.com/face/emot/emot25.png" alt="困顿"></li><li title="想一下"><img title="想一下" src="http://gbres.dfcfw.com/face/emot/emot26.png" alt="想一下"></li><li title="围观"><img title="围观" src="http://gbres.dfcfw.com/face/emot/emot27.png" alt="围观"></li><li title="献花"><img title="献花" src="http://gbres.dfcfw.com/face/emot/emot28.png" alt="献花"></li><li title="大便"><img title="大便" src="http://gbres.dfcfw.com/face/emot/emot29.png" alt="大便"></li><li title="爱心"><img title="爱心" src="http://gbres.dfcfw.com/face/emot/emot30.png" alt="爱心"></li><li title="心碎"><img title="心碎" src="http://gbres.dfcfw.com/face/emot/emot31.png" alt="心碎"></li><li title="毛估估"><img title="毛估估" src="http://gbres.dfcfw.com/face/emot/emot32.png" alt="毛估估"></li><li title="成交"><img title="成交" src="http://gbres.dfcfw.com/face/emot/emot33.png" alt="成交"></li><li title="财力"><img title="财力" src="http://gbres.dfcfw.com/face/emot/emot34.png" alt="财力"></li><li title="护城河"><img title="护城河" src="http://gbres.dfcfw.com/face/emot/emot35.png" alt="护城河"></li><li title="复盘"><img title="复盘" src="http://gbres.dfcfw.com/face/emot/emot36.png" alt="复盘"></li><li title="买入"><img title="买入" src="http://gbres.dfcfw.com/face/emot/emot37.png" alt="买入"></li><li title="卖出"><img title="卖出" src="http://gbres.dfcfw.com/face/emot/emot38.png" alt="卖出"></li><li title="满仓"><img title="满仓" src="http://gbres.dfcfw.com/face/emot/emot39.png" alt="满仓"></li><li title="空仓"><img title="空仓" src="http://gbres.dfcfw.com/face/emot/emot40.png" alt="空仓"></li><li title="抄底"><img title="抄底" src="http://gbres.dfcfw.com/face/emot/emot41.png" alt="抄底"></li><li title="看多"><img title="看多" src="http://gbres.dfcfw.com/face/emot/emot42.png" alt="看多"></li><li title="看空"><img title="看空" src="http://gbres.dfcfw.com/face/emot/emot43.png" alt="看空"></li><li title="加仓"><img title="加仓" src="http://gbres.dfcfw.com/face/emot/emot44.png" alt="加仓"></li><li title="减仓"><img title="减仓" src="http://gbres.dfcfw.com/face/emot/emot45.png" alt="减仓"></li></ul><div class="clear"></div></div></div></td><td class="l6"></td></tr><tr><td class="l1"></td><td class="l2"></td><td class="l3"></td></tr></table></div>';
					if( $("#insertfacediv").length > 0 ){
						$("#insertfacediv").remove();
						options.closeface();
						return false;
					}
					else{
						thislink.after(temphtml);
						options.openface();
						if( options.facearrow == "bottom" ){
							$("#insertfacediv").css({left:thislink.position().left ,top:thislink.position().top - $("#insertfacediv").height() - 7});
						}
						else{
							$("#insertfacediv").css({left:thislink.position().left ,top:thislink.position().top + 20});
						}
						
						if( $("#sendpicurl").val() == "" ){
							if( $("#insertimgdiv").data("load") == "1" ){ //正在上传
								
							}
							else{
								$("#insertimgdiv").remove();
							}
						}
					}
					$("#insertfacediv li").click(function(){
						inserttext("[" + $(this).attr("title") + "]");
						$("#insertfacediv").remove();
						options.closeface();
					});
				});
			}


			var inserttext = function (text) { //插入文字
				if(thisedit[0]){
					if( thisedit.val() == '文明上网，理性发言' ){
						thisedit.val(text).css('color','#000').focus();
						return false;
					}
				}
				
				if (document.selection) {
					thisedit.get(0).focus();
					var sel = document.selection.createRange();
					sel.text = text;
				} else {
					var prefix, main, suffix;
					prefix = thisedit.get(0).value.substring(0, thisedit.get(0).selectionStart);
					main = thisedit.get(0).value.substring(thisedit.get(0).selectionStart, thisedit.get(0).selectionEnd);
					suffix = thisedit.get(0).value.substring(thisedit.get(0).selectionEnd);
					if (main == "") {
						thisedit.get(0).value = prefix + text + suffix;
					}
					else {
						thisedit.get(0).value = prefix + text + suffix;
					}
				}
			}
		});
	};

	/*
	 * textBlink 0.2
	 * Date: 2013-03-29
	 * 让文字闪烁起来
	 */
	(function($){
		$.fn.textBlink = function(options){
			var defaults = {
				color:["#fff","#ffe2d1","#ffc2a1","#ffa370","#ff8340","#ff630f"], //轮番颜色 默认橙色
				blinktime:60, //每帧时间 毫秒
				circle:2 //闪烁次数
			}
			var options = $.extend(defaults, options);
			var loop = 0;
			this.each(function(){
				var thisobj = $(this);
				for (var i = 0; i < options.color.length * options.circle; i ++ ){
					setTimeout(function (){
						thisobj.css('background-color',options.color[loop]);
						loop ++;
						loop = loop % options.color.length;
					},options.blinktime * i);
				}
			});
		};
	})($);

	window.titleistesu = function(text){ //判断标题特殊字符  不允许连续超过3个特殊字符 不允许累计超过5个 ？和！除外
		var re1 = /[^ \u4E00-\uFA29\uE7C7-\uE7F3\w\?\!]/g;
		var re2 = /[^ \u4E00-\uFA29\uE7C7-\uE7F3\w\?\!]{4}/;
		if( text.match(re1) == null ) return false;
		if( text.match(re1).length > 5 ) return true;
		return text.match(re2) != null;
	}

	window.gbpopbox = { //股吧默认弹框样式
		show:function (title,html){ //弹出
			var temphtml = '<div class="gbpopbox"><div class="gbpopboxclose" onclick="gbpopbox.close(this)" title="关闭">X</div><div class="gbpopboxtitle">使用该功能请先登录</div><div class="gbpopboxbody"></div></div>';
			if( $("#talkcont").length > 0 ){
				$("body").prepend(temphtml);
				$("body").prepend('<div class="gbmask"></div>');
				$(".gbmask").show();
			}
			else{
				$(".gbpopbox").remove();
				if( $(".gbpopbox").length == 0 ){
					$("body").prepend(temphtml);
				}
				else{
					$(".gbpopbox").show();
				}
				if( $(".gbmask").length == 0 ){
					$("body").prepend('<div class="gbmask"></div>');
				}
				else{
					$(".gbmask").show();
				}
			}

			//<div class="gbmask"></div>
			//if( $(".gbmask").length == 0 ){
				//$("body").prepend('<div class="gbmask"></div>');
			//}
			//else{
				//$(".gbmask").show();
			//}
			$(".gbmask").height($(document).height());

			if( $(".gbpopbox").length > 0 ){
				//$("body").prepend('<div class="gbmask"></div>');
				$(".gbmask:first").css("z-index",$(".gbpopbox").eq(1).css("z-index") + 1);
				$(".gbpopbox:first").css("z-index",$(".gbpopbox").eq(1).css("z-index") + 2);
			}
			
			
			$(".gbpopbox:first .gbpopboxtitle").html(title);
			$(".gbpopbox:first .gbpopboxbody").html(html);
			//alert($(window).height()/2);
			//alert($(".gbpopbox").height()/2 );
			//alert($(window).scrollTop());
			$(".gbpopbox:first").css({left:$(document).width()/2 - $(".gbpopbox").width()/2,top:$(window).height()/2 - $(".gbpopbox").height()/2  + $(window).scrollTop()});
		},
		close: function (thislink){ //关闭
			//alert($(thislink).parents(".gbpopbox").index(".gbpopbox"));
			if( $("#talkcont").length > 0 ){
				$(thislink).parents(".gbpopbox").prev(".gbmask").remove();		
				$(thislink).parents(".gbpopbox").remove();
			}
			else{
				$(".gbpopbox").remove();
				$(".gbmask").remove();			
			}
			


			//$(".gbmask").eq($(thislink).parents(".gbpopbox").index(".gbpopbox")).remove();
		},
		reposition : function (){
			$(".gbpopbox").css({left:$(document).width()/2 - $(".gbpopbox").width()/2,top:$(window).height()/2 - $(".gbpopbox").height()/2  + $(window).scrollTop()});
		}
	}

	window.clickone = true;
	var postbox = {
		init : function (container, code){
			container = $("#" + container);
			this.inserthtmlcss(container);
			$("#gbtainput").gredit({ bindface: $("#gbtainpubtn4") });
			//$("#gbtainput").gredit({ bindface: $("#gbtainpubtn4"), bindimg: $("#gbtainpubtn5") });
			$("#gbsform").submit(function () {
				postbox.submit(code);
				return false;
			});
			$('<script type="text/javascript" src="http://hqres.eastmoney.com/emag14/js/tvcode.js?v=1.1"></script>').appendTo($("head")); //验证码js

			$(document).click(function (e) { //绑定点击其他地方让其框消失
				var target = $(e.target);
				//console.info(target);
				if( $("#insertfacediv").length > 0 ){
					if( target.is("#insertfacediv") || target.parents().is("#insertfacediv") || target.is("#gbtainpubtn4") || target.parents().is("#gbtainpubtn4")) {
						
					}
					else{
						$("#insertfacediv").remove();
						if( typeof textareafacelose != "undefined" ){
							textareafacelose();
						}
					}
				}
			});

		},
		inserthtmlcss : function (container){
		    var css = '.gbsform { display: block; background-color: #EAF2FF; margin: 0px; padding: 13px 0 0 0; float: left; width: 100%; font-family: simsun; font-size:12px; }.gbsform button, .gbsform input, .gbsform textarea { font-family: simsun; }.gbsform label.l { width: 55px; text-align: right; float: left;  }.gbsform .gbsformi1 { width: 705px; border: 1px solid #D9E3F5;  padding: 8px 4px; *vertical-align: middle; float: left; outline:none;}.gbsform .gbsformt1 { width: 705px; /*height: auto;  max-height:500px;*/ height: 80px; border: 1px solid #D9E3F5; line-height: 130%; padding: 4px 4px; vertical-align: top; resize:none; background-color: #fff; float: left; outline:0; overflow: auto; word-wrap : break-word;   }.gbsform .gbsformt1 em { font-style:italic; }.gbsform .mtj1 { margin-top: -2px; clear: both;  }.gbsform .mtj2 { padding-left: 53px; clear: both;  }.gbsform .mtj2 .mtjchbox { vertical-align: middle; }.gbsform .tzla { padding-top: 6px; }.gbsform .editorfuns { padding-top: 13px; padding-bottom: 13px; float: left; }.gbsform .editorfuns a { color: #333333; margin-right: 10px; _margin-right: 5px; }.gbsform .editorfuns a:link, .gbsform .editorfuns a:visited { text-decoration: none;  }.gbsform .editorfuns a:hover { text-decoration: underline; }.gbsform .gbsformbtns { float: right; padding-right: 20px; padding-top: 5px;  }.gbsform .gbsformi3 { width: 121px; height: 31px; border: 0; color: #fff; cursor: pointer;background-color:#FF8400; vertical-align: middle; font-size: 14px; font-weight: bold;}.gbsform .gbsformi3:hover { background-color:#FF4800; }.gbsform .gbsformi3:disabled {background-color: #8A8B8E; cursor: default; }.gbsform .gbsformi4:disabled {background-color: #8A8B8E; cursor: default; }.gbsform .gbsformi3send {background: url(http://guba.eastmoney.com/images/bgg.jpg) no-repeat 0px -420px;}.gbsform .gbsformi3gd { width: 121px; height: 31px; border: 0; color: #fff; cursor: pointer;background-color: #FF3333; vertical-align: middle; font-size: 14px; font-weight: bold;}.gbsform .gbsformi3gd:hover { background-color: #F30909; }.gbsform .gbsformi4 { width: 61px; height: 31px; background-color: #B5B6BA; border: 0; color: #fff; cursor: pointer; margin-left: 3px; vertical-align: middle; font-size: 14px; font-weight: bold;}.gbsform .gbsformi4:hover { background-color: #8A8B8E; }.iconface { display: inline-block; width: 16px; height: 16px; background: url(http://hqres.eastmoney.com/emag14/images/gbbg.png?v=7) no-repeat -90px -180px; vertical-align: -3px; margin-right: 3px; }.iconimg { display: inline-block; width: 16px; height: 14px; background: url(http://hqres.eastmoney.com/emag14/images/gbbg.png?v=7) no-repeat -120px -180px; vertical-align: -2px; margin-right: 3px; }.shadowbox { position: absolute; z-index: 1001; }.shadowboxt td { overflow: hidden; font-size: 1px; text-overflow:ellipsis;}.shadowboxt .l1,.shadowboxt .l2,.shadowboxt .l3,.shadowboxt .l4,.shadowboxt .l6,.shadowboxt .l7,.shadowboxt .l8,.shadowboxt .l9 { background: url(http://hqres.eastmoney.com/emag14/images/gbshadowbg.png?v=2); _background: url(http://guba.eastmoney.com/images/shadowbgie6.gif?v=2) no-repeat 0 0; font-size: 1px; }.shadowboxt .l7,.shadowboxt .l9,.shadowboxt .l1,.shadowboxt .l3{ height: 4px; width: 4px; }.shadowboxt .l5 { background-color: #fff; padding: 1px; border:1px solid #B7B7B7; font-size: 12px; }.shadowboxt .l7 { background-position:0 0; }.shadowboxt .l8 { background-position:0 -14px; }.shadowboxt .l9 { background-position:-4px 0; }.shadowboxt .l4 { background-position:0 -14px; background-color: transparent; }.shadowboxt .l6 { background-position:0 -14px; width: 4px; overflow: hidden; }.shadowboxt .l1 { background-position:0 -4px; }.shadowboxt .l2 { background-position:0 -14px; }.shadowboxt .l3 { background-position:-4px -4px; }.shadowbox .shadowboxtoparrow { position: absolute; left: 20px; top: -7px; width: 14px; height: 12px; background: url(http://hqres.eastmoney.com/emag14/images/gbshadowbg.png?v=2) no-repeat -18px 0px; }.shadowbox .shadowboxrightarrow { position: absolute; right: -7px; top: 20px; width: 12px; height: 14px; background: url(http://hqres.eastmoney.com/emag14/images/gbshadowbg.png?v=2) no-repeat -102px 0px; _background: url(http://guba.eastmoney.com/images/shadowbgie6.gif?v=2) no-repeat -102px 0px; }.shadowbox .shadowboxbottomarrow { position: absolute; left: 20px; bottom: -9px; width: 12px; height: 14px; background: url(http://hqres.eastmoney.com/emag14/images/gbshadowbg.png?v=2) no-repeat -57px 0px; _background: url(http://guba.eastmoney.com/images/shadowbgie6.gif?v=2) no-repeat -57px 0px; _bottom:-10px; }#facediv { padding-bottom: 4px; }#facelist { list-style: none; margin: 0px; padding: 0px 0 0 4px; width: 310px;  }#facelist li { float: left; width: 28px; height: 28px; border: 1px solid #DADADA; margin-top: 4px; margin-right: 4px; text-align: center; padding-top: 3px; cursor: pointer; }#facelist li img { width: 28px; height: 28px; }#facelist li:hover { border: 1px solid #5FABDF; } #interested .pername { padding-bottom: 5px; }#uploadimgtips { text-align: center; width: 300px; padding: 20px 0; }#uploadimgtips #selectimglink { font-size: 14px;  height: 40px; width: 140px; margin: 0px auto;  cursor: pointer; background-color: #F0F0F0; line-height: 40px; border: 1px solid #A0A0A0; display: inline-block; margin-bottom: 10px;  }.editorinsertimgubtn {  font-size: 14px;  height: 40px; width: 140px; margin: 0px auto;  cursor: pointer; background-color: #F0F0F0; line-height: 40px; border: 1px solid #A0A0A0; }#uploadpreviewdiv { padding: 10px 20px; text-align: center; }#uploadpreviewdiv img { margin-top: 5px; }#uploadpreviewdiv ul li { float: left; width: 120px; }#uploadpreviewdiv #contupload { font-size: 14px;  height: 40px; width: 100px; margin: 0px auto;  cursor: pointer; background-color: #F0F0F0; line-height: 40px; border: 1px solid #A0A0A0; margin-top: 35px; }#uploadpreviewdiv .uploadmoreing { display: none; margin-top: 35px; }#uploadpreviewdiv .uploadmoreing img { vertical-align: -3px; }a#newstip { background-color: #FEFDED; border: 1px solid #F9F2A7; height: 24px; line-height: 24px; cursor:pointer; text-align:center; color:#F48C12; margin-top:4px; display:none; }a#newstip:hover { background-color: #FCF8C2; border:1px solid #EFE467; }/*文字验证码*/#tvcode {  background-color: #fff;  width: 360px; font-size: 12px; }#tvcode .b { padding: 20px 30px 30px 30px; }#tvcode .in { font-size: 14px; }#tvcode .tes { border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; vertical-align: middle; display: inline-block; height: 40px; }#tvcode .tes #t3 { display: none; }#tvcode .tes #t4 { display: none; }#tvcode .te { display: inline-block; width: 46px; height: 40px; border-left: 1px solid #ccc; cursor: default; }#tvcode #back { display: inline-block; width: 46px; height: 40px; border-left: 1px solid #ccc; cursor: pointer; border-right: 1px solid #ccc; background: url(http://hqres.eastmoney.com/emag14/images/gbtvcodeback.png?v=2) 3px 0 #CDCDCD; }#tvcode .ans { padding: 8px 0 8px 56px; }#tvcode #ansi { width: 150px; height: 36px; display: inline-block; vertical-align: middle; cursor: pointer;  }#tvcode .st { padding-left: 56px; }#tvcode #answul { width: 183px; padding-top: 4px; }#tvcode #answul li { width: 54px; height: 40px; border: 1px solid #ccc; float: left; margin: 0 5px 5px 0;   background-repeat:no-repeat; cursor: pointer; display: none; border-collapse: #fff;}#tvcode #answul li:hover { border: 1px solid #5a6fb4; }#tvcode .tvt { font-size: 14px; font-weight: bold; text-align: center; padding-bottom: 10px; }.gbpopbox { position: absolute; z-index: 1001; border: 1px solid #B1D1E6; background-color: #fff;  }.gbpopbox .gbpopboxtitle {  font-size: 14px; font-weight: bold; color: #fff;  background-color: #466B98; padding: 8px 0 8px 12px;  }.gbpopbox .gbpopboxclose {  position: absolute; right: 15px; top: 8px; width: 9px; height: 9px; cursor: pointer; color: #fff; font-size: 18px; font-family: Arial;  }.gbpopbox .gbpopboxclose:hover { text-decoration: underline; }.gbmask { position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; z-index: 1000; background: url(http://hqres.eastmoney.com/emag14/images/gbmask.png); _background:none; _filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, sizingMethod=scale, src="http://hqres.eastmoney.com/emag14/images/gbmask.png"); }';
			$('<style type="text/css">' + css + '</style>').appendTo($("head"))
			var html = '<form method="post" action="" target="_self" id="gbsform" class="gbsform"><div class="cls"><label for="gbtaintitle" class="l tzla">标题：</label><input type="text" name="" class="gbsformi1" id="gbtaintitle" maxlength="80" /></div><div class="mtj1 cls" id="yzmp"><label for="gbtainput" class="l tzla">内容：</label><textarea class="gbsformt1" id="gbtainput"></textarea> </div><div class="mtj2 cls"><div class="editorfuns" id="editorfuns"><a href="javascript:;" id="gbtainpubtn4" data-fun="face" target="_self"><em class="iconface"></em>表情</a>  </div><div class="gbsformbtns"><span id="gdregbtn"></span>&nbsp;<button type="submit" class="gbsformi3">发 布</button><input type="reset" id="gbsformreset" class="gbsformi4" value="清 除" /></div><input type="hidden" id="sendpicurl" /></div></form>';
			container.html(html);
		},
		submit : function (code, para){
			var defaultpara = { isgudong: false }; //默认参数 
			var options = $.extend(defaultpara, para); 
			var swtitle = $.trim($("#gbtaintitle").val());
			if( swtitle == "" ){
				$("#gbtaintitle").textBlink({color:["#FFDDDD","#FFEEEE","#fff"],blinktime:150});
			}
			var swcontent = $.trim($("#gbtainput").val());
			if( swcontent == "" ){
				$("#gbtainput").textBlink({color:["#FFDDDD","#FFEEEE","#fff"],blinktime:150});
				return false;
			}
			if( swtitle == "" || swcontent == "" ){
				return false;
			}
			if( titleistesu(swtitle) ){
				$("#gbtaintitle").textBlink({color:["#FFDDDD","#FFEEEE","#fff"],blinktime:150});
				alert("您输入的标题符号过多，请修改后再发！");
				return false;
			}

			var quanxian = 0;
			var gudongstemp = 0;
			if( $("#gdsubmitlimit").length > 0 ){
				if( $("#gdsubmitlimit").is(":checked") ){
					quanxian = 2;
					gudongstemp = 10;
				}
				gudongstemp = 11;
			}

			if (!clickone) {
				return false;
			}
			clickone = false;

			$(".gbsformi3").text("发布中...");
//			if( gudongstemp > 0 ){
//				gudong.stat(gudongstemp);
//			}
			//alert(quanxian);
			$.ajax({
				type: "GET",
				url: "http://igubacs.eastmoney.com/action.aspx",
				dataType: "jsonp",
				data:{action:"osendwz",yuan_id:0,title:text.titleclean($.trim($("#gbtaintitle").val())),text:swcontent,code:code.toLowerCase(),pdf:"",pic:$("#sendpicurl").val(),postvalid:1,yzmid:tvcode.cbid,yzm:tvcode.value, quanxian:quanxian},
				success: function (json) {
					
					clickone = true;
					//股东发帖统计

	//				if( options.isgudong ){
	//					$(".gbsformi3gd").removeClass("gbsformi3gdsend");
	//				}
	//				else{
	//					$(".gbsformi3").removeClass("gbsformi3send");
	//				}
					//$(".gbsformi3").removeClass("gbsformi3send");
					$(".gbsformi3").text("发  布");
					if (json.result) {
						//gubalist.clearremember();
						//guba.sendok('list,' + code + '.html');
						$("#gbtainput").val('');
						$("#gbtaintitle").val('');
						//stat(1);
						tvcode.checktrue();
						
						//guba.sendok('list,' + code + '.html');
						alert("发布成功！");
					}
					else {    				
						if (json.error == "出验证码") {
							tvcode.init(function (){
								$("#gbsform").submit();
							});
						}
						else if(json.error == "验证码输入错误！"){
							tvcode.checkfalse();
						}
						else if(json.error == "请修改昵称"){
							gbpopbox.close();
							//guba.sendok3();
						}
						else{
							gbpopbox.close();
							//alert(json.error);
						}
					}
				},
				error: function (XMLHttpRequest, textStatus, errorThrown) {
					clickone = true;
					//$(".gbsformi3").removeClass("gbsformi3send");
					$(".gbsformi3").text("发  布");
					alert("系统忙，请稍后再试！");
					try{
						console.error("XMLHttpRequest="+XMLHttpRequest.responseText+"\ntextStatus="+textStatus+"\nerrorThrown="+errorThrown);
					}
					catch (e){}
				}
			});
			return false;
		}
	}
	module.exports = postbox
	// return postbox;
// });

/***/ }),

/***/ "./src/modules/old_cnyrate/guba_text.js":
/*!**********************************************!*\
  !*** ./src/modules/old_cnyrate/guba_text.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// define(function() {
	
var text = {
	titleclean : function (txt){
		if( $.trim(txt) == "" ){
			return "";
		}
		var re = /[☆★●◎◆■▲〓◢█◣▌◥◤▓※⊙☂▆【】✪▉▊▋▌︻▏▎▍☀▅]/g;
		return txt.replace(re,"");		
	},
	TxtLeft: function (txt, n) {
		if( txt == null || txt == "" ){
			return "";
		}
		var thislength = 0;
		for (var i = 0; i < txt.length; i++) {
			if (txt.charCodeAt(i) > 255) {
				thislength += 2;
			}
			else {
				thislength++;
			}
			//console.info(thislength);
			if (thislength > n) {
				return txt.substring(0, i) + "...";
				break;
			}
		}
		return txt;
	},
	TxtLeftNoDot: function (txt, n) {
		if( txt == null || txt == "" ){
			return "";
		}
		var thislength = 0;
		for (var i = 0; i < txt.length; i++) {
			if (txt.charCodeAt(i) > 255) {
				thislength += 2;
			}
			else {
				thislength++;
			}
			//console.info(thislength);
			if (thislength > n) {
				return txt.substring(0, i);
				break;
			}
		}
		return txt;
	},
	TxtLeftta: function (txt, n) { 
		var thislength = 0;
		for (var i = 0; i < txt.length; i++) {
			if (txt.charCodeAt(i) > 255) {
				thislength += 2;
			}
			else {
				thislength++;
			}
			//console.info(thislength);
			if (thislength > n) {
				return txt.substring(0, i) + "..";
				break;
			}
		}
		return txt;
	},
	TxtLength: function (txt) {
		var thislength = 0;
		for (var i = 0; i < txt.length; i++) {
			if (txt.charCodeAt(i) > 255) {
				thislength += 2;
			}
			else {
				thislength++;
			}
		}
		return thislength;
	},
	numshow: function (num) {
		if (num == 0) return "";
		return "(" + num.toString() + ")";
	},
	smallimg : function (url){
		if( url == null || url == "" ){
			return ""
		}
		if( url.match(/\d{8}/) == null ){
			return "";
		}
		var position = url.match(/\d{8}/).index;
		return url.substring(0,position + 8) + "/size100" + url.substring(position + 8,url.length);
	},
	atlength : function (text){ //有多少个@某人
		var temp = text.match(/@\S+(\s|$)/g);
		if( temp == null ){
			return 0;
		}
		return temp.length;
	},
	isstock:function (code){ //简单判断是否是股票号码
		if( /\d{6}/.test(code)){
			code = code.toString();
			if( code.substring(0,1) == "4" ){ //三板
				return false;
			}
			else if ("100,101,108,109,111,112,115,119,125,126,129,131,010,019,020,130,110,113,104,105,106,107,201,202,203,204".indexOf(code.substring(0, 3)) > -1 || "75,12".indexOf(code.substring(0, 2)) > -1){ //债券
				return false;
			}
			else{
				return true;
			}
		}
		else{
			return false;
		}
	},
	clearhtml :function (text){
		return text.replace(/<[^>]*?>/ig, '');
	},
	gettime :function (){ //获得当前时间 例子 2021-04-03 23:12:52
		var temptime = new Date();
		var month = (temptime.getMonth() + 1).toString();
		month = month.length == 1?"0" + month:month;
		var day = temptime.getDate().toString();
		day = day.length == 1?"0" + day:day;
		return temptime.getFullYear() + '-' + month + '-' + day + ' ' + temptime.getHours() + ':' + temptime.getMinutes() + ":" + temptime.getMinutes();
	},
	getshorttime :function (){ //获得当前时间 例子 2021-04-03
		var temptime = new Date();
		var month = (temptime.getMonth() + 1).toString();
		month = month.length == 1?"0" + month:month;
		var day = temptime.getDate().toString();
		day = day.length == 1?"0" + day:day;
		return temptime.getFullYear() + '-' + month + '-' + day;
	},
	replyadd : function (text){ //回复数字加1
		var num = 0;
		var linktext = "";
		if( text.indexOf("(") > 0 ){
			linktext = text.substring(0,text.indexOf("("));
			num = parseInt(text.substring(text.indexOf("(") + 1,text.indexOf(")")));
			num ++
			return linktext + "(" + num.toString() + ")";
		}
		else{
			return text + "(1)";
		}
	},
	cleartext : function (text){
		text = text.replace(/<br>/g," ");
		return text;
	},
	clearquot : function (text){ //转换引号
		text = text.replace(/\'/g,"\\\'");
		text = text.replace(/\"/g,"\\\"");
		return text;
	},
	arraychaos : function (arr){ //数组乱序
		if( arr.length == 0 ){
			return arr;
		}
		arr.sort(function(a,b){ return Math.random()>.5 ? -1 : 1;});
		return arr;
	},
	getmarketcode: function ( code ) {
		var sh_or_sz = "1";
		var i = code.substring(0, 1);
		var j = code.substring(0, 3);
		if (i == "5" || i == "6" || i == "9"){
			//上证股票
		}
		else{
			if (code == "000003" || code == "000300"){
				//上证股票
			}
			if (j == "009" || j == "126" || j == "110"){
				//上证股票
			}
			else{
				sh_or_sz = "2";//深圳股票
			}
		}
		return code + sh_or_sz;
	},
	gecodetmarket: function ( code ) {
		var sh_or_sz = "1";
		var i = code.substring(0, 1);
		var j = code.substring(0, 3);
		if (i == "5" || i == "6" || i == "9"){
			//上证股票
		}
		else{
			if (code == "000003" || code == "000300"){
				//上证股票
			}
			if (j == "009" || j == "126" || j == "110"){
				//上证股票
			}
			else{
				sh_or_sz = "2";//深圳股票
			}
		}
		return sh_or_sz;
	}

}

module.exports = text
// return text;

// });

/***/ }),

/***/ "./src/modules/old_cnyrate/guba_user.js":
/*!**********************************************!*\
  !*** ./src/modules/old_cnyrate/guba_user.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// define(['guba_cookie'],function(cookie) {

var cookie = __webpack_require__(/*! ./guba_cookie */ "./src/modules/old_cnyrate/guba_cookie.js")

	var user = {
		get : function (){
			var cVal = cookie.get("pi");
			if (cVal && cVal != null && cVal != "") {
				var cVals = cVal.split(";");
				return {
					id: cVals[0],
					name: cVals[1],
					nick: cVals[2],
					photo: "http://mp.dfcfw.com/" + cVals[0] + "/48/0"
				};
			} else {
				return null;
			}
		}
	}
// 	return user;
// });

module.exports = user

/***/ }),

/***/ "./src/modules/old_cnyrate/ioscript.js":
/*!*********************************************!*\
  !*** ./src/modules/old_cnyrate/ioscript.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// define(function(){
	/**
	 * Bind Method
	 */

	var isIE = false;
	var userAgent = navigator.userAgent.toLowerCase();
	if ((userAgent.indexOf('msie') != -1) && (userAgent.indexOf('opera') == -1)) {
		isIE = true;
	}

	if(typeof IO == 'undefined' )IO = {};
	IO.Script = function(){
		this.Init.apply(this, arguments);
	};

	IO.Script.prototype = {
		_scriptCharset: 'gb2312',
		_oScript: null,
		
		/**
		 * Constructor
		 * 
		 * @param {Object} opts
		 */
		Init : function(opts){
			this._setOptions(opts);
		},
		
		_setOptions: function(opts) {
			if (typeof opts != 'undefined') {
				if (opts['script_charset']) {
					this._scriptCharset = opts['script_charset'];
				}
			}
		},
		
		_clearScriptObj: function() {
			if (this._oScript) {
				try {
					this._oScript.onload = null;
					if (this._oScript.onreadystatechange) {
						this._oScript.onreadystatechange = null;
					}
					
					this._oScript.parentNode.removeChild(this._oScript);
					//this._oScript = null;
				} catch (e) {
					// Do nothing here
				}
			}
		},
		
		_callbackWrapper: function(callback) {
			if (this._oScript.onreadystatechange) {
				if (this._oScript.readyState != 'loaded' && this._oScript.readyState != 'complete') {
					return;
				}
			}
			
			if (typeof callback != 'undefined') {
				callback();
			}
			
			this._clearScriptObj();
		},
		
		load: function(url, callback){
			this._oScript = document.createElement('SCRIPT');
			this._oScript.type = "text/javascript";
			
			if (isIE) {
				this._oScript.onreadystatechange = this._callbackWrapper.Bind(this, callback);
			} else {
				this._oScript.onload = this._callbackWrapper.Bind(this, callback);
			}
			
			this._oScript.charset = this._scriptCharset;
			this._oScript.src = url;
			
			document.body.appendChild(this._oScript);
		}
	} 

	module.exports = IO
	// return IO;
// })

/***/ }),

/***/ "./src/modules/old_cnyrate/main.js":
/*!*****************************************!*\
  !*** ./src/modules/old_cnyrate/main.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


    // var _baseurl = document.getElementById("main_script").getAttribute("data-baseurl");
    // require.config({
    //     baseUrl: _baseurl ? _baseurl : "/Scripts",
    //     paths: {
    //         jquery: "http://www.eastmoney.com/js/jquery.min",
    //         agiotage: 'build/agiotage',
    //         agiotage_tasks: 'build/agiotage_tasks',
    //         IOScript: 'build/IOScript',
    //         agiotage_temp: 'build/agiotage_temp',
    //         guba_postbox: 'build/guba_postbox',
    //         guba_user: 'build/guba_user',
    //         guba_text: 'build/guba_text',
    //         guba_cookie: 'build/guba_cookie',
    //         globaltime: "globaltime.min",
    //         template: 'template',
    //         page: 'em.forex.cnyc.min',
    //         suggest: '//emcharts.dfcfw.com/suggest/stocksuggest2017.min'
    //     },
    //     shim: {
    //         'jquery': {
    //             exports: '$'
    //         },
    //         "suggest": {
    //             deps: ["jquery"]
    //         }
    //     }
    // });

    // require(['page', "suggest", 'globaltime'], function (page, suggest2017) {


var _GlobalTime = __webpack_require__(/*! ./globaltime.min */ "./src/modules/old_cnyrate/globaltime.min.js")
var page = __webpack_require__(/*! ./em.forex.cnyc.min */ "./src/modules/old_cnyrate/em.forex.cnyc.min.js")
var agiotage = __webpack_require__(/*! ./agiotage */ "./src/modules/old_cnyrate/agiotage.js")
__webpack_require__(/*! ./agiotage_tasks */ "./src/modules/old_cnyrate/agiotage_tasks.js")
var postbox = __webpack_require__(/*! ./guba_postbox */ "./src/modules/old_cnyrate/guba_postbox.js")
var guba_user = __webpack_require__(/*! ./guba_user */ "./src/modules/old_cnyrate/guba_user.js")

var template = __webpack_require__(/*! ./template */ "./src/modules/old_cnyrate/template.js")

window.template = template

        try {
            var suggest = new suggest2017({
                inputid: "search_box",
                offset: { left: -91, top: 5 },
                shownewtips: true,
                newtipsoffset: { top: -3, left: 0 }
            });
        } catch (e) {
            console.error(e);
        }
        $(document).ready(function () {
            var globalTime = new _GlobalTime("worldtime");
            _GlobalTime.prototype.show = function () {
                var a = this;
                var f = a.Option;
                var b = f.citys.length;
                var l = [], k = [];
                var el = document.getElementById("worldtime").getElementsByTagName("i");
                var date = "";
                var h = function () {
                    var d = a.utils.now() + a.deviation - (3600000 * 8);
                    for (var c = 0; c < b; c++) {
                        var j = a.utils.formatTime(d, f.citys[c].utc);
                        el[c].innerHTML = a.utils.dateFromat(j, f.display);
                    }
                    var bj = a.utils.formatTime(d, f.citys[0].utc);
                    $("#querydate").html("(" + bj.pattern("yyyy-MM-dd EEE HH:mm") + ")");
                    date = j.pattern("yyyy-MM-dd");
                };
                h();
                var g = setInterval(h, 1000);
                document.getElementById("querydate").value = date;
            };

            new page(stockcode).pageInit();
            // require(['agiotage', 'agiotage_tasks'], function (agiotage) {
                agiotage.init();
            // });

            /**
             * @description 股吧发布框
             * @param {Object} postbox 发布框
             */
            // require(['guba_postbox'], function (postbox) {
                postbox.init('sendnew', "waihui");
            // });

            /**
             * @description logout
             * @param {Object} guba_user 用户
             */
            // require(['guba_user'], function (guba_user) {
                if (guba_user.get() !== null) {
                    var thisuser = guba_user.get();
                    $("#loginstate").html("<span class=\"fr f12\">" + thisuser.nick + "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"javascript:void(0);\" onclick=\"dcookies()\">退出</a></span>");
                }
            // });
        });
    // });

/***/ }),

/***/ "./src/modules/old_cnyrate/template.js":
/*!*********************************************!*\
  !*** ./src/modules/old_cnyrate/template.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_RESULT__;/*!art-template - Template Engine | http://aui.github.com/artTemplate/*/
!function(){function a(a){return a.replace(t,"").replace(u,",").replace(v,"").replace(w,"").replace(x,"").split(y)}function b(a){return"'"+a.replace(/('|\\)/g,"\\$1").replace(/\r/g,"\\r").replace(/\n/g,"\\n")+"'"}function c(c,d){function e(a){return m+=a.split(/\n/).length-1,k&&(a=a.replace(/\s+/g," ").replace(/<!--[\w\W]*?-->/g,"")),a&&(a=s[1]+b(a)+s[2]+"\n"),a}function f(b){var c=m;if(j?b=j(b,d):g&&(b=b.replace(/\n/g,function(){return m++,"$line="+m+";"})),0===b.indexOf("=")){var e=l&&!/^=[=#]/.test(b);if(b=b.replace(/^=[=#]?|[\s;]*$/g,""),e){var f=b.replace(/\s*\([^\)]+\)/,"");n[f]||/^(include|print)$/.test(f)||(b="$escape("+b+")")}else b="$string("+b+")";b=s[1]+b+s[2]}return g&&(b="$line="+c+";"+b),r(a(b),function(a){if(a&&!p[a]){var b;b="print"===a?u:"include"===a?v:n[a]?"$utils."+a:o[a]?"$helpers."+a:"$data."+a,w+=a+"="+b+",",p[a]=!0}}),b+"\n"}var g=d.debug,h=d.openTag,i=d.closeTag,j=d.parser,k=d.compress,l=d.escape,m=1,p={$data:1,$filename:1,$utils:1,$helpers:1,$out:1,$line:1},q="".trim,s=q?["$out='';","$out+=",";","$out"]:["$out=[];","$out.push(",");","$out.join('')"],t=q?"$out+=text;return $out;":"$out.push(text);",u="function(){var text=''.concat.apply('',arguments);"+t+"}",v="function(filename,data){data=data||$data;var text=$utils.$include(filename,data,$filename);"+t+"}",w="'use strict';var $utils=this,$helpers=$utils.$helpers,"+(g?"$line=0,":""),x=s[0],y="return new String("+s[3]+");";r(c.split(h),function(a){a=a.split(i);var b=a[0],c=a[1];1===a.length?x+=e(b):(x+=f(b),c&&(x+=e(c)))});var z=w+x+y;g&&(z="try{"+z+"}catch(e){throw {filename:$filename,name:'Render Error',message:e.message,line:$line,source:"+b(c)+".split(/\\n/)[$line-1].replace(/^\\s+/,'')};}");try{var A=new Function("$data","$filename",z);return A.prototype=n,A}catch(B){throw B.temp="function anonymous($data,$filename) {"+z+"}",B}}var d=function(a,b){return"string"==typeof b?q(b,{filename:a}):g(a,b)};d.version="3.0.0",d.config=function(a,b){e[a]=b};var e=d.defaults={openTag:"<%",closeTag:"%>",escape:!0,cache:!0,compress:!1,parser:null},f=d.cache={};d.render=function(a,b){return q(a,b)};var g=d.renderFile=function(a,b){var c=d.get(a)||p({filename:a,name:"Render Error",message:"Template not found"});return b?c(b):c};d.get=function(a){var b;if(f[a])b=f[a];else if("object"==typeof document){var c=document.getElementById(a);if(c){var d=(c.value||c.innerHTML).replace(/^\s*|\s*$/g,"");b=q(d,{filename:a})}}return b};var h=function(a,b){return"string"!=typeof a&&(b=typeof a,"number"===b?a+="":a="function"===b?h(a.call(a)):""),a},i={"<":"&#60;",">":"&#62;",'"':"&#34;","'":"&#39;","&":"&#38;"},j=function(a){return i[a]},k=function(a){return h(a).replace(/&(?![\w#]+;)|[<>"']/g,j)},l=Array.isArray||function(a){return"[object Array]"==={}.toString.call(a)},m=function(a,b){var c,d;if(l(a))for(c=0,d=a.length;d>c;c++)b.call(a,a[c],c,a);else for(c in a)b.call(a,a[c],c)},n=d.utils={$helpers:{},$include:g,$string:h,$escape:k,$each:m};d.helper=function(a,b){o[a]=b};var o=d.helpers=n.$helpers;d.onerror=function(a){var b="Template Error\n\n";for(var c in a)b+="<"+c+">\n"+a[c]+"\n\n";"object"==typeof console&&console.error(b)};var p=function(a){return d.onerror(a),function(){return"{Template Error}"}},q=d.compile=function(a,b){function d(c){try{return new i(c,h)+""}catch(d){return b.debug?p(d)():(b.debug=!0,q(a,b)(c))}}b=b||{};for(var g in e)void 0===b[g]&&(b[g]=e[g]);var h=b.filename;try{var i=c(a,b)}catch(j){return j.filename=h||"anonymous",j.name="Syntax Error",p(j)}return d.prototype=i.prototype,d.toString=function(){return i.toString()},h&&b.cache&&(f[h]=d),d},r=n.$each,s="break,case,catch,continue,debugger,default,delete,do,else,false,finally,for,function,if,in,instanceof,new,null,return,switch,this,throw,true,try,typeof,var,void,while,with,abstract,boolean,byte,char,class,const,double,enum,export,extends,final,float,goto,implements,import,int,interface,long,native,package,private,protected,public,short,static,super,synchronized,throws,transient,volatile,arguments,let,yield,undefined",t=/\/\*[\w\W]*?\*\/|\/\/[^\n]*\n|\/\/[^\n]*$|"(?:[^"\\]|\\[\w\W])*"|'(?:[^'\\]|\\[\w\W])*'|\s*\.\s*[$\w\.]+/g,u=/[^\w$]+/g,v=new RegExp(["\\b"+s.replace(/,/g,"\\b|\\b")+"\\b"].join("|"),"g"),w=/^\d[^,]*|,\d[^,]*/g,x=/^,+|,+$/g,y=/^$|,+/;e.openTag="{{",e.closeTag="}}";var z=function(a,b){var c=b.split(":"),d=c.shift(),e=c.join(":")||"";return e&&(e=", "+e),"$helpers."+d+"("+a+e+")"};e.parser=function(a){a=a.replace(/^\s/,"");var b=a.split(" "),c=b.shift(),e=b.join(" ");switch(c){case"if":a="if("+e+"){";break;case"else":b="if"===b.shift()?" if("+b.join(" ")+")":"",a="}else"+b+"{";break;case"/if":a="}";break;case"each":var f=b[0]||"$data",g=b[1]||"as",h=b[2]||"$value",i=b[3]||"$index",j=h+","+i;"as"!==g&&(f="[]"),a="$each("+f+",function("+j+"){";break;case"/each":a="});";break;case"echo":a="print("+e+");";break;case"print":case"include":a=c+"("+b.join(",")+");";break;default:if(/^\s*\|\s*[\w\$]/.test(e)){var k=!0;0===a.indexOf("#")&&(a=a.substr(1),k=!1);for(var l=0,m=a.split("|"),n=m.length,o=m[l++];n>l;l++)o=z(o,m[l]);a=(k?"=":"=#")+o}else a=d.helpers[c]?"=#"+c+"("+b.join(",")+");":"="+a}return a}, true?!(__WEBPACK_AMD_DEFINE_RESULT__ = (function(){return d}).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)):undefined}();

/***/ })

/******/ });
//# sourceMappingURL=cnyrate.js.map