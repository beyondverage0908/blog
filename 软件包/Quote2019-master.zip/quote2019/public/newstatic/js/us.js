/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./jssrc/us.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./jssrc/us.ts":
/*!*********************!*\
  !*** ./jssrc/us.ts ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
/**
 * 美股JS
 */
var gotowap_1 = __importDefault(__webpack_require__(/*! ../src/modules/gotowap */ "./src/modules/gotowap/index.ts"));
gotowap_1["default"](stockEnity.stockCode, stockEnity.MktNum);
__webpack_require__(/*! ../src/modules/old_us/us */ "./src/modules/old_us/us.js");


/***/ }),

/***/ "./src/modules/cookie/index.ts":
/*!*************************************!*\
  !*** ./src/modules/cookie/index.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * 浏览器操作cookie
 */
exports.__esModule = true;
exports["default"] = {
    /**
     * 获取cookie
     * @param name cookie名称
     */
    get: function (name) {
        var xarr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
        if (xarr != null)
            return decodeURIComponent(xarr[2]);
        return null;
    },
    /**
     * 设置cookie
     * @param key cookie名称
     * @param value cookie的值
     * @param expiredays 过期时间（天）
     * @param domain cookie的domain
     */
    set: function (key, value, expiredays, domain) {
        var cookiestr = key + "=" + escape(value);
        if (expiredays != undefined) {
            var exdate = new Date();
            exdate.setDate(exdate.getDate() + expiredays);
            cookiestr += ";expires=" + exdate.toUTCString();
        }
        if (domain != undefined) {
            cookiestr += ";domain=" + domain;
        }
        cookiestr += ';path=/';
        document.cookie = cookiestr;
    },
    /**
     * 删除cookie
     * @param key cookie名称
     * @param domain cookie的domain
     */
    del: function (key, domain) {
        var exdate = new Date((new Date).getTime() - 1);
        if (domain) {
            document.cookie = key + '=;path=/;expires=' + exdate.toUTCString() + ';domain=' + domain;
        }
        else {
            document.cookie = key + '=;path=/;expires=' + exdate.toUTCString();
        }
    }
};


/***/ }),

/***/ "./src/modules/gotowap/index.ts":
/*!**************************************!*\
  !*** ./src/modules/gotowap/index.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * 跳转wap网站
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var cookie_1 = __importDefault(__webpack_require__(/*! ../cookie */ "./src/modules/cookie/index.ts"));
function isMobile() {
    var ua = navigator.userAgent;
    var res = false;
    var ipad = ua.match(/(iPad).*OS\s([\d_]+)/), isIphone = !ipad && ua.match(/(iPhone\sOS)\s([\d_]+)/), isAndroid = ua.match(/(Android)\s+([\d.]+)/) && ua.match(/(Mobile)\s+/), isMobile = isIphone || isAndroid;
    if (isMobile) {
        res = true;
    }
    else {
        res = false;
    }
    return res;
}
/**
 * 跳转wap
 * @param code 代码
 * @param market 市场
 */
function gotowap(code, market) {
    var isJump = cookie_1["default"].get("has_jump_to_web");
    console.info(isJump);
    if (isJump && isJump == "1") {
        return false;
    }
    if (isMobile()) {
        self.location.href = "https://wap.eastmoney.com/quota/hq/stock?id=" + code + "&mk=" + market;
    }
}
exports["default"] = gotowap;


/***/ }),

/***/ "./src/modules/old_b/common.js":
/*!*************************************!*\
  !*** ./src/modules/old_b/common.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// define(["jQuery", "template"], function ($, template) {
  var template = __webpack_require__(/*! ./template */ "./src/modules/old_b/template.js")

    var common = {
        //文字闪动
        setFlash: function (obj, cls1, cls2) {
            setTimeout(function () { common.setClass(obj, cls1) }, 800);
            setTimeout(function () { common.setClass(obj, cls2) }, 1000);
            setTimeout(function () { common.setClass(obj, cls1) }, 1200);
            setTimeout(function () { common.setClass(obj, cls2) }, 1400);
        },
        //获取季度中文
        getJiduByDate: function (date) {
            var jidu = "";
            var m = date.split('-')[1];
            switch (m) {
                case "03":
                    jidu = "(一)";
                    break;
                case "06":
                    jidu = "(二)";
                    break;
                case "09":
                    jidu = "(三)";
                    break;
                case "12":
                    jidu = "(四)";
                    break;
            }
            return jidu;
        },
        //触发element的eventName事件
        trigger: function (element, eventName) {
            if (typeof element == "undefined" || element == null) return;
            if (document.all) {
                element[eventName]();
            } else {
                var evt = document.createEvent("MouseEvents");
                evt.initEvent(eventName, true, true);
                element.dispatchEvent(evt);
            }
        },
        //Cookie Common Class
        getCookie: function (key) {
            var result = document.cookie.match(new RegExp("(^| )" + key + "=([^;]*)"));
            return result != null ? unescape(decodeURI(result[2])) : null;
        },
        //写cookies
        setCookie: function (name, value, hours) {
            var expire = "";
            if (typeof hours === "number") {
                expire = new Date((new Date()).getTime() + hours * 3600000);
                expire = "; expires=" + expire.toGMTString() + ";";
            }
            expire += "; path=/;domain=.eastmoney.com;";
            document.cookie = name + "=" + escape(value) + expire;
        },
        //通过cookie:pi获取uid
        getUid: function () {
            var webPi = common.getCookie("pi");
            if (webPi && webPi.split(';').length >= 3) {
                var uid = webPi.split(';')[0];
                if (uid.length == 16) {
                    return uid;
                }
            }
            return "";
        },
        //根据股票代码获取市场
        getMarketCode: function (sc) {
            var i = sc.substring(0, 1);
            var j = sc.substring(0, 3);
            if (i == "5" || i == "6" || i == "9") {
                return "1"; //上证股票
            } else {
                if (j == "009" || j == "126" || j == "110") {
                    return "1"; //上证股票
                } else {
                    return "2"; //深圳股票
                }
            }
        },
        getStatusDescription: function (stat) {
            switch (stat) {
                case "-2": return "已收盘";
                case "-1": return "停牌";
                case "0": return "交易中";
                case "1": return "已收盘";
                case "2": return "午间休市";
                case "3": return "已休市";
                case "4": return "未开盘";
                case "5": return "已收盘";
                case "6": return "已收盘";
                case "7": return "已收盘";
                case "8": return "暂停交易";
                case "9": return "暂停交易";
                case "10": return "暂停交易";
                case "11": return "暂停交易";
                case "12": return "未上市";
                default: return "";
            }
        },
        jsonP: function (url, successMethod, errorMethod) {
            $.ajax({
                url: url,
                async: true,
                dataType: "jsonp",
                success: successMethod,
                error: errorMethod
            });
        },
        jsonPnew: function (url, successMethod, errorMethod) {
            $.ajax({
                url: url,
                async: true,
                dataType: "jsonp",
                jsonp: 'cb',
                success: successMethod,
                error: errorMethod
            });
        },
        getQueryString: function (name) {
            var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
            var r = window.location.search.substr(1).match(reg);
            if (r != null) {
                return unescape(r[2]);
            }
            return null;
        },
        formatDate: function (date, fmt) {
            // return date
            if (typeof date === "string"){
                //date = new Date(date.replace(/-/g, '/').replace('T', ' ').split('+')[0]);
                date = new Date(date.substring(0,19).replace(/-/g, '/').replace('T', ' '));                
            }

            var o = {
                "M+": date.getMonth() + 1, //月份         
                "d+": date.getDate(), //日         
                "h+": date.getHours() % 12 == 0 ? 12 : date.getHours() % 12, //小时         
                "H+": date.getHours(), //小时         
                "m+": date.getMinutes(), //分         
                "s+": date.getSeconds(), //秒         
                "q+": Math.floor((date.getMonth() + 3) / 3), //季度         
                "S": date.getMilliseconds() //毫秒         
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[date.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        },
        getByteLen: function (str) {
            var len = 0;
            for (var i = 0; i < str.length; i++) {
                var regNum = new RegExp("[^\x00-\xff]");
                if (regNum.test(str[i])) {
                    len += 2;
                } else {
                    len += 1;
                };
            }
            return len;
        },
        getColor: function (str) {
            var context = str.toString();
            context = context.replace("%", "");
            if (context == 0 || isNaN(context)) {
                return "";
            } else if (context > 0) {
                return "red";
            } else {
                return "green";
            }
        },
        cutString: function (str, len) {
            var content = str.toString();
            if (content.length > len) {
                return content.substring(0, len) + "...";
            } else {
                return str;
            }
        },
        /** 
         * js截取字符串，中英文都能用 
         * @param {string} str: 需要截取的字符串 
         * @param {number} len: 需要截取的长度
         * @param {string} ellipsis: 溢出文字
         * @returns {string}
         */
        cutstr: function (str, len, ellipsis) {
            if (typeof ellipsis != "string") ellipsis = "...";
            var str_length = 0;
            var str_len = 0;
            str_cut = new String();
            for (var i = 0; i < str.length; i++) {
                a = str.charAt(i);
                str_length++;
                if (escape(a).length > 4) {
                    //中文字符的长度经编码之后大于4  
                    str_length++;
                }
                //str_cut = str_cut.concat(a);
                if (str_length <= len) {
                    str_len++;
                }
            }
            //如果给定字符串小于指定长度，则返回源字符串；  
            if (str_length <= len) {
                return str.toString();
            }
            else {
                return str.substr(0, str_len).concat(ellipsis);
            }
        },
        /**
         * 秒表计时器模块
         * @param {any} options: 设置
         * @param {number} seconds: 秒针
         */
        timer: function (options, seconds) {
            var _this = this;
            seconds = seconds || 60;
            if (!options || !options.dom) return;
            var default_options = {
                counter: 60,
                interval: 1000
            };
            var _options = $.extend(options, default_options);
            var $dom = _options.dom, _interval = isNaN(_options.interval) ? 1000 : _options.interval;
            if (typeof _options.dom === "string") {
                var dom = _options.dom;
                if ($(dom).length == 0) return;
                $dom = $(dom);
            }
            var timerId = -1, paused = false, counter = seconds;
            function handler() {
                if (!paused) {
                    $dom.html(counter);
                }
                if (--counter > 0) {
                    timerId = setTimeout(handler, _interval);
                }
                else if (typeof options.callback === "function") {
                    _options.callback(_options.args);
                }
            }
            function pause() { paused = true; }
            function resume() { paused = false; }
            function start() {
                handler();
            }
            function stop() {
                if (timerId != -1) clearTimeout(timerId);
                timerId = -1;
                counter = _options.counter;
            }
            return {
                start: start, stop: stop, reset: function () {
                    stop(), start();
                },
                pause: function () { paused = true; },
                resume: function () { paused = false; }
            };
        },
        /** 
         * js分页功能
         * var pagenav = new PageNavigation("container", 6);
	     * pagenav.onchange = function(i){ alert(i) }
	     * pagenav.nav(1)
         * pagenav.render();
         * @param {string} container: 分页容器
         * @param {number} pagecount: 页数
         */
        pageNavigation: function (container, pagecount) {
            var get = function (id) {
                return $("#" + container + " " + id);
            };
            var _this = this;
            _this.container = document.getElementById(container);
            if (!_this.container) throw "Untouchable container";
            _this.nextpage = get("nextpage");
            _this.prepage = get("prepage");
            _this.pagecount = pagecount || 0;
            _this.container.onclick = function (event) {
                event = event || window.event;
                var target = event.target || event.srcElement;
                var page = target.getAttribute("data-page");
                var controlid = target.getAttribute("data-get");
                var property = target.getAttribute("data-property");

                if (controlid && property) {//转到

                    page = get(controlid).attr(property);
                }

                if (page !== null && !isNaN(page)) {
                    _this.change(page);
                }
            };
            //根据UI 设置config
            _this.config = {
                itemscount: 5,
                disable: "<span>{$text}</span>",
                nextpage: " <a class=\"nextpage\" href=\"javascript:void(null)\"  data-page='{$nextpage}'>下一页</a> ",
                prepage: " <a class=\"prepage\" href=\"javascript:void(null)\" data-page='{$prepage}'>上一页</a> ",
                pageitem: " <a href=\"javascript:void(null)\" data-page='{$num}'>{$num}</a> ",
                current: " <span class='current'>{$num}</span> ",
                firstpage: "<a data-page='1'>1</a><span class='page-break'>...</span>",
                lastpage: "<span class='page-break'>...</span><a data-page='{$pagecount}'>{$pagecount}</a>",
                gopage: '转到<input type="text" value="{$num}" name="pageNum" class="pagenum"/>页 ' +
                    '<input type="button" data-get=".pagenum" data-property="value" class="go-btn" value="Go"/>'
            };
            _this.change = function (num) {
                var _this = this;
                if (!isNaN(num)) {
                    _this.listitems = [];
                    _this.nav(parseInt(num));
                    _this.render();
                }
                _this.onchange(num);
                _this.pageChange(num);
            };
            _this.reset = function () {
                this.listitems = [];
                this.prepage = false;
                this.firstpage = false;
                this.nextpage = false;
                this.lastpage = false;
            };
            //回调函数
            _this.onchange = new Function();
            _this.pageChange = new Function();
            //分页逻辑
            _this.nav = function (n) {
                var startpagenum = 1, endpagenum = this.pagecount, length = (this.config.itemscount - 1) / 2;
                this.reset();
                if (isNaN(n)) { n = 1; }
                if (n < 1) n = 1;
                if (n > this.pagecount) n = this.pagecount;
                if (n !== 1) {
                    this.prepage = this.config.prepage;
                    if (n - length > 1) {
                        startpagenum = n - length;
                        this.firstpage = this.config.firstpage;
                        if (n == 4) {
                            this.firstpage = this.firstpage.replace("...", "");
                        }
                    }

                    for (var i = startpagenum; i < n; i++) {
                        this.listitems.push(this.createPageItem(i));
                    }
                }
                this.listitems.push(this.createCurrentItem(n));
                if (n !== this.pagecount) {
                    this.nextpage = this.config.nextpage;
                    length = this.config.itemscount - this.listitems.length;
                    if (n + length < this.pagecount) {
                        endpagenum = n + length;
                        this.lastpage = this.config.lastpage;
                        if (this.pagecount - n == 3) {
                            this.lastpage = this.lastpage.replace("...", "");
                        }
                    }

                    for (var i = n + 1; i <= endpagenum; i++) {
                        this.listitems.push(this.createPageItem(i));
                    }
                }
                this.page = n;
            };
            _this.render = function () {

                var listitems = this.listitems.join("");
                var nextpage = this.nextpage;
                var prepage = this.prepage;
                var gopage = this.config.gopage;

                var html = [];
                if (!prepage) {
                    prepage = this.config.disable.replace(/\{\$text\}/g, "上一页");
                }
                html.push(prepage.replace(/\{\$prepage\}/g, this.page - 1));

                if (this.firstpage) {
                    html.push(this.firstpage);
                }

                html.push(listitems);

                if (this.lastpage) {
                    html.push(this.lastpage.replace(/\{\$pagecount\}/g, this.pagecount));
                }

                if (!nextpage) {
                    nextpage = this.config.disable.replace(/\{\$text\}/g, "下一页");
                }

                html.push(nextpage.replace(/\{\$nextpage\}/g, this.page + 1));

                html.push(gopage.replace(/\{\$num\}/g, this.page));

                if (this.container) {
                    this.container.innerHTML = html.join("");
                }
                return html.join("");

            };
            _this.createPageItem = function (i) {
                return this.config.pageitem.replace(/\{\$num\}/g, i);
            };
            _this.createCurrentItem = function (i) {
                return this.config.current.replace(/\{\$num\}/g, i);
            };
        }
    }

    String.prototype.cutstr = function (len) {
        return common.cutstr(this, len);
    }

    String.prototype.isPositive = function () {
        var context = this;
        if (typeof (context).toLowerCase() === "string") {
            context = context.replace("%", "");
            var regNum = new RegExp("^([\\-\\+]?\\d+(\\.\\d+)?)$");
            if (regNum.test(context)) {
                var reg = new RegExp("^-");
                return !reg.test(context);
            } else return Number.NaN;
        }
    }

    String.prototype.NumbericFormat = function (fixed) {
        var context = this;
        //var fushu = false;
        fixed = typeof fixed === "number" && fixed >= 0 ? fixed : NaN;
        if (!isNaN(context)) {
            var item = parseInt(this);
            if ((item > 0 && item < 1e4) || (item < 0 && item > -1e4)) {
                return item;
            } else if ((item > 0 && item < 1e6) || (item < 0 && item > -1e6)) {
                item = item / 10000;
                return item.toFixed(fixed || 2) + "万";
            } else if ((item > 0 && item < 1e7) || (item < 0 && item > -1e7)) {
                item = item / 10000;
                return item.toFixed(fixed || 1) + "万";
            } else if ((item > 0 && item < 1e8) || (item < 0 && item > -1e8)) {
                item = item / 10000;
                return item.toFixed(fixed || 0) + "万";
            } else if ((item > 0 && item < 1e10) || (item < 0 && item > -1e10)) {
                item = item / 1e8;
                return item.toFixed(fixed || 2) + "亿";
            } else if ((item > 0 && item < 1e11) || (item < 0 && item > -1e11)) {
                item = item / 1e8;
                return item.toFixed(fixed || 1) + "亿";
            } else if ((item > 0 && item < 1e12) || (item < 0 && item > -1e12)) {
                item = item / 1e8;
                return item.toFixed(fixed || 0) + "亿";
            } else if ((item > 0 && item < 1e14) || (item < 0 && item > -1e14)) {
                item = item / 1e12;
                return item.toFixed(fixed || 1) + "万亿";
            } else if ((item > 0 && item < 1e16) || (item < 0 && item > -1e16)) {
                item = item / 1e12;
                return item.toFixed(fixed || 0) + "万亿";
            } else {
                return item;
            }
        }
        else {
            return '-';
        }
        //return context.toString();
    }
    if (!Array.prototype.indexOf) {
        // 兼容低版本浏览器扩展indexOf
        Array.prototype.indexOf = function (elt /*, from*/) {
            var len = this.length >>> 0;
            var from = Number(arguments[1]) || 0;
            from = (from < 0) ?
                Math.ceil(from) :
                Math.floor(from);
            if (from < 0)
                from += len;
            for (; from < len; from++) {
                if (from in this &&
                    this[from] === elt)
                    return from;
            }
            return -1;
        };
    }
    Array.prototype.unique = function () {
        var res = [];
        var json = {};
        for (var i = 0; i < this.length; i++) {
            if (!json[this[i]]) {
                res.push(this[i]);
                json[this[i]] = 1;
            }
        }
        return res;
    }
    // 截断字符
    template.helper("cutstr", function (str, len, ellipsis) {
        return common.cutstr(str, len, ellipsis);
    });
    // 日期格式化
    template.helper("formatDate", function (date, fmt) {
        if (typeof date === "string") {
            date = new Date(date.substring(0,19).replace(/-/g, '/').replace('T', ' '))
        }
        return common.formatDate(date, fmt);
    });
    // 获取市场代码
    template.helper("getShortMarket", function (str) {
        switch (str) {
            case "1": return "sh";
            case "2": return "sz";
            default: return "sz";
        }
    });

    // jquery扩展
    $.extend({
        // 定时数据获取扩展
        dataAutoRefresh: function (settings) {
            var _init = false, _intInterval = !window["defaultInterval"] ? 1000 * 20 : window.defaultInterval, _intThread = -1;
            if (!settings["dataType"]) settings["dataType"] = "json";
            return {
                init: _init,
                intInterval: _intInterval,
                intThread: _intThread,
                load: function () {
                    this.init = true;
                    if (typeof (settings) !== "object" || !settings)
                        return false;
                    if (settings.dataType.toLowerCase() === "img") {
                        $.imgLoader(settings);
                    }
                    else {
                        var _timeout = 5000;
                        settings["timeout"] = !settings.timeout ? _timeout : settings["timeout"];
                        if (!!settings.dataType && settings.dataType.toLowerCase() === "jsonp") {
                            settings["type"] = "GET";
                            settings["jsonp"] = !settings.jsonp ? "cb" : settings.jsonp;
                        }
                        $.ajax(settings);
                    }
                },
                start: function () {
                    this.stop();
                    this.load();
                    this.intThread = setInterval(this.load, this.intInterval);
                },
                stop: function () {
                    if (this.intThread !== -1) {
                        clearInterval(this.intThread);
                    }
                    this.intThread = -1;
                }
            }
        },
        //异步动态图片加载
        imgLoader: function (setting) {
            if (typeof (setting) !== "object" || !setting["url"]) return false;
            var fCallback = typeof (setting["success"]) === "function" ? setting["success"] : null;
            var _url = setting["url"];
            if (setting["data"]) {
                var _data = $.param(setting["data"]);
                _url = _url.indexOf("?") > 0 ? _url + "&" + _data : _url + "?" + _data;
            }
            if (!setting["cache"]) {
                _url += _url.indexOf("?") > 0 ? "&_=" + (+new Date()) : "?_=" + (+new Date());
            }
            var _image = document.createElement("img");
            if (typeof (setting["height"]) === "number" && setting["height"] > 0) {
                _image.setAttribute("height", setting["height"] + "px");
            }
            if (typeof (setting["width"]) === "number" && setting["width"] > 0) {
                _image.setAttribute("width", setting["width"] + "px");
            }
            _image.setAttribute('src', _url);
            if (typeof (setting["error"]) === "function")
                $(_image).error(function () { setting["error"](_image); });
            _image.onload = _image.onreadystatechange = function (evt) {
                if (!_image.readyState || /loaded|complete/.test(_image.readyState)) {
                    // Handle memory leak in IE
                    _image.onload = _image.onreadystatechange = null;
                    // Callback if not abort
                    if (fCallback) fCallback(_image);
                }
            };
        }
    });

    $.fn.extend({
        //让文字闪烁起来
        textBlink: function (options) {
            var defaults = {
                color: ["#fff", "#ffe2d1", "#ffc2a1", "#ffa370", "#ff8340", "#ff630f"], //轮番颜色 默认橙色
                blinktime: 60, //每帧时间 毫秒
                circle: 2 //闪烁次数
            }
            var _options = jQuery.extend(defaults, options);
            var loop = 0; var instance = this;
            for (var i = 0; i < _options.color.length * _options.circle; i++) {
                setTimeout(function () {
                    jQuery(instance).css("background-color", _options.color[loop]);
                    loop++;
                    loop = loop % _options.color.length;
                }, _options.blinktime * i);
            }
        }
    });

    module.exports = common
    // return common;
// });



/***/ }),

/***/ "./src/modules/old_b/emchart.js":
/*!**************************************!*\
  !*** ./src/modules/old_b/emchart.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// define(["jQuery", "chartLib"], function () {

    var emChart = {
        initial: function () {
            emChart.bindJs();
            emChart.bindK();
            setInterval(function () {
                emChart.bindJs();
            }, 20 * 1000);
        },
        bindK: function (parameters) {
            var timer,
            kchart = new emcharts3.k2({
                container: "#emchartk",
                width: 585,
                height: 390,
                padding: {
                    top: 0,
                    bottom: 0
                },
                scale: {
                    pillar: 60,
                    min: 10
                },
                popWin: { type: "move" },
                maxin: {
                    //show: true,
                    lineWidth: 30,     // 线长
                    skewx: 0,            // x偏移   
                    skewy: 0            // y偏移
                },
                onComplete: function () {
                },
                onClick: function () {
                    var val = $("#changektab span.cur").attr("value"), type = 'k';
                    switch (val) {
                        case "D":
                            type = "k";
                            break;
                        case "W":
                            type = "wk";
                            break;
                        case "M":
                            type = "mk";
                            break;
                        case "M5":
                            type = "m5k";
                            break;
                        case "M15":
                            type = "m15k";
                            break;
                        case "M30":
                            type = "m30k";
                            break;
                        case "M60":
                            type = "m60k";
                            break;
                        default: break;
                    }
                    window.open(window.location + "#fullScreenChart", "_blank")
                },
                onError: function (e) {
                    console.error(e)
                }
            }),
            params = {
                type: "k",
                authorityType: ""
            };
        function init() {

            events();
            load();
        }

        function load() {
            var fq = $("#beforeBackRight span").text()
            $("#js_box").removeClass("hidefixed");
            $("#js_box").removeClass("hidefixed");
            clearTimeout(timer);
            var _load = function () {
                var params1 = {
                    secid: window.stockEnity.fullcode,
                    ut: 'fa5fd1943c7b386f172d6893dbfba10b',
                    fields1: 'f1,f2,f3,f4,f5',
                    fields2: 'f51,f52,f53,f54,f55,f56,f57,f58',
                    klt: params.type == 'k' ? 101 : params.type == 'wk' ? 102 : params.type == 'mk' ? 103 : params.type == 'm5k' ? 5 : params.type == 'm15k' ? 15 : params.type == 'm30k' ? 30 : 60,
                    fqt: fq == '不复权' ? 0 : fq == '前复权' ? 1 : fq == '后复权' ? 2 : 0,
                    beg: "19900101",
                    end: "20220101"
                }
                $.ajax({
                    url: "http://push2his.eastmoney.com/api/qt/stock/kline/get",
                    dataType: "jsonp",
                    scriptCharset: 'utf-8',
                    data: params1,
                    jsonp: "cb",
                    success: function (resk) {
                        //console.log("kkkk>>", resk)
                        var obj = {
                            "name": resk.data.name,
                            "code": resk.data.code,
                            "info": {
                                "c": "",
                                "h": "",
                                "l": "",
                                "o": "",
                                "a": "",
                                "v": "",
                                "yc": $(".zsj").text(),
                                "time": "",
                                "ticks": "34200|54000|0|34200|41400|46800|54000",
                                "total": resk.data.dktotal,
                                "pricedigit": "0.00",
                                "jys": "2",
                                "Settlement": "-"
                            },
                            data: []
                        }
                        for (var i = 0; i < resk.data.klines.length; i++) {
                            var item = resk.data.klines[i] + '%'
                            obj.data.push(item)
                        }
                        kchart.setData({
                            k: obj
                        });
                        kchart.draw();
                    },
                    error: function (e) {
                        console.error(e);
                    },
                    complate: function () {
                        timer = setTimeout(load, 60 * 1000);
                    }
                });
            };
            _load();
        }

        function events() {
            $("#beforeBackRight dl dd").click(function () {
                $("#beforeBackRight span").html($(this).html());
                var v = $(this).attr("value");
                $("#beforeBackRight").attr("value", v);
                params.authorityType = v === "before" ? "fa" : v === "back" ? "ba" : "";
                load();
                var at = v === "before" ? "1" : v === "back" ? "2" : "0";
                if ($("#js_box").is(":visible")) {
                    $("#select4 dd[value=" + at + "]").click();
                }
            });

            $("#changektab span").click(function () {
                $("#changektab span").removeClass("cur");
                $(this).addClass("cur");
                switch ($(this).attr("value")) {
                    case "D":
                        params.type = "k";
                        break;
                    case "W":
                        params.type = "wk";
                        break;
                    case "M":
                        params.type = "mk";
                        break;
                    case "M5":
                        params.type = "m5k";
                        break;
                    case "M15":
                        params.type = "m15k";
                        break;
                    case "M30":
                        params.type = "m30k";
                        break;
                    case "M60":
                        params.type = "m60k";
                        break;
                }
                load();
            });

            $("#scale-plus").click(function () {
                kchart.shorten(-1, 0.1);
            });

            $("#scale-minus").click(function () {
                kchart.elongate(-1, 0.1);
            });

            $("#beforeBackRight").mouseenter(function () {
                this.getElementsByTagName("dl")[0].style.display = "block";
            });

            $("#beforeBackRight").mouseleave(function () {
                this.getElementsByTagName("dl")[0].style.display = "none";
            });
        }
        init();
    },


        bindJs: function () {
            var fq = $("#beforeBackRight span").text()
            $.ajax({
                url: "http://push2.eastmoney.com/api/qt/stock/trends2/get",
                dataType: "jsonp",
                scriptCharset: 'utf-8',
                data: {
                    secid: window.stockEnity.fullcode,
                    ut: 'fa5fd1943c7b386f172d6893dbfba10b',
                    fields1: 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11',
                    fields2: 'f51,f53,f56,f58',
                    iscr: fq=='不复权'?0:fq=='前复权'?1:fq=='后复权'?2:0,
                    ndays: 1
                },
                jsonp: "cb",
                success: function (res1) {
                    //console.log("分时图数据fenshitu>>",res1)
                    var obj = {
                        name: window.stockEnity.stockName,
                        code: window.stockEnity.stockCode,
                        info: {
                            "mk ":window.stockEnity.stockMarket,
                            "c": "",
                            "h": "",
                            "l": "",
                            "o": "",
                            "a": "",
                            "v": "",
                            "yc": res1.data.preClose, //昨收
                            "time": "",
                            "ticks": "34200|34200|54000|34200|41400|46800|54000",
                            "total": res1.data ? res1.data.trendsTotal : 0, //多少数据
                            "pricedigit": "0.00",
                            "jys": "2",
                            "Settlement": "-"
                        },
                        data: []
                    }
                    var dataList = res1.data ? res1.data.trends : []
                    for (var i = 0; i < dataList.length; i++) {
                        var arr = dataList[i].split(",")
                        var str = arr[0] + ',' + arr[1] + ',' + (arr[2] ) + ',' + arr[3] + ',' + 0
                        obj.data.push(str)
                    }
                    var option = {
                        container: "#emchart-0",
                        width: 565,
                        height: 276,
                        type: 'r',
                        iscr: false,
                        onClick: function () {
                            window.open(window.location + "#fullScreenChart","_blank")
                        }
                    }
                    var timechart = new emcharts3.time(option);
                    timechart.start(false)
                    timechart.setData({
                        time: obj
                    });
                    timechart.redraw();
                    timechart.stop();
                },
                error: function (e) {
                    console.error(e);
                }
            });
        }
    }

    // return emChart;

    module.exports = emChart
    // return emChart;
// });

/***/ }),

/***/ "./src/modules/old_b/template.js":
/*!***************************************!*\
  !*** ./src/modules/old_b/template.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_RESULT__;/*!art-template - Template Engine | http://aui.github.com/artTemplate/*/
!function(){function a(a){return a.replace(t,"").replace(u,",").replace(v,"").replace(w,"").replace(x,"").split(y)}function b(a){return"'"+a.replace(/('|\\)/g,"\\$1").replace(/\r/g,"\\r").replace(/\n/g,"\\n")+"'"}function c(c,d){function e(a){return m+=a.split(/\n/).length-1,k&&(a=a.replace(/\s+/g," ").replace(/<!--[\w\W]*?-->/g,"")),a&&(a=s[1]+b(a)+s[2]+"\n"),a}function f(b){var c=m;if(j?b=j(b,d):g&&(b=b.replace(/\n/g,function(){return m++,"$line="+m+";"})),0===b.indexOf("=")){var e=l&&!/^=[=#]/.test(b);if(b=b.replace(/^=[=#]?|[\s;]*$/g,""),e){var f=b.replace(/\s*\([^\)]+\)/,"");n[f]||/^(include|print)$/.test(f)||(b="$escape("+b+")")}else b="$string("+b+")";b=s[1]+b+s[2]}return g&&(b="$line="+c+";"+b),r(a(b),function(a){if(a&&!p[a]){var b;b="print"===a?u:"include"===a?v:n[a]?"$utils."+a:o[a]?"$helpers."+a:"$data."+a,w+=a+"="+b+",",p[a]=!0}}),b+"\n"}var g=d.debug,h=d.openTag,i=d.closeTag,j=d.parser,k=d.compress,l=d.escape,m=1,p={$data:1,$filename:1,$utils:1,$helpers:1,$out:1,$line:1},q="".trim,s=q?["$out='';","$out+=",";","$out"]:["$out=[];","$out.push(",");","$out.join('')"],t=q?"$out+=text;return $out;":"$out.push(text);",u="function(){var text=''.concat.apply('',arguments);"+t+"}",v="function(filename,data){data=data||$data;var text=$utils.$include(filename,data,$filename);"+t+"}",w="'use strict';var $utils=this,$helpers=$utils.$helpers,"+(g?"$line=0,":""),x=s[0],y="return new String("+s[3]+");";r(c.split(h),function(a){a=a.split(i);var b=a[0],c=a[1];1===a.length?x+=e(b):(x+=f(b),c&&(x+=e(c)))});var z=w+x+y;g&&(z="try{"+z+"}catch(e){throw {filename:$filename,name:'Render Error',message:e.message,line:$line,source:"+b(c)+".split(/\\n/)[$line-1].replace(/^\\s+/,'')};}");try{var A=new Function("$data","$filename",z);return A.prototype=n,A}catch(B){throw B.temp="function anonymous($data,$filename) {"+z+"}",B}}var d=function(a,b){return"string"==typeof b?q(b,{filename:a}):g(a,b)};d.version="3.0.0",d.config=function(a,b){e[a]=b};var e=d.defaults={openTag:"<%",closeTag:"%>",escape:!0,cache:!0,compress:!1,parser:null},f=d.cache={};d.render=function(a,b){return q(a)(b)};var g=d.renderFile=function(a,b){var c=d.get(a)||p({filename:a,name:"Render Error",message:"Template not found"});return b?c(b):c};d.get=function(a){var b;if(f[a])b=f[a];else if("object"==typeof document){var c=document.getElementById(a);if(c){var d=(c.value||c.innerHTML).replace(/^\s*|\s*$/g,"");b=q(d,{filename:a})}}return b};var h=function(a,b){return"string"!=typeof a&&(b=typeof a,"number"===b?a+="":a="function"===b?h(a.call(a)):""),a},i={"<":"&#60;",">":"&#62;",'"':"&#34;","'":"&#39;","&":"&#38;"},j=function(a){return i[a]},k=function(a){return h(a).replace(/&(?![\w#]+;)|[<>"']/g,j)},l=Array.isArray||function(a){return"[object Array]"==={}.toString.call(a)},m=function(a,b){var c,d;if(l(a))for(c=0,d=a.length;d>c;c++)b.call(a,a[c],c,a);else for(c in a)b.call(a,a[c],c)},n=d.utils={$helpers:{},$include:g,$string:h,$escape:k,$each:m};d.helper=function(a,b){o[a]=b};var o=d.helpers=n.$helpers;d.onerror=function(a){var b="Template Error\n\n";for(var c in a)b+="<"+c+">\n"+a[c]+"\n\n";"object"==typeof console&&console.error(b)};var p=function(a){return d.onerror(a),function(){return"{Template Error}"}},q=d.compile=function(a,b){function d(c){try{return new i(c,h)+""}catch(d){return b.debug?p(d)():(b.debug=!0,q(a,b)(c))}}b=b||{};for(var g in e)void 0===b[g]&&(b[g]=e[g]);var h=b.filename;try{var i=c(a,b)}catch(j){return j.filename=h||"anonymous",j.name="Syntax Error",p(j)}return d.prototype=i.prototype,d.toString=function(){return i.toString()},h&&b.cache&&(f[h]=d),d},r=n.$each,s="break,case,catch,continue,debugger,default,delete,do,else,false,finally,for,function,if,in,instanceof,new,null,return,switch,this,throw,true,try,typeof,var,void,while,with,abstract,boolean,byte,char,class,const,double,enum,export,extends,final,float,goto,implements,import,int,interface,long,native,package,private,protected,public,short,static,super,synchronized,throws,transient,volatile,arguments,let,yield,undefined",t=/\/\*[\w\W]*?\*\/|\/\/[^\n]*\n|\/\/[^\n]*$|"(?:[^"\\]|\\[\w\W])*"|'(?:[^'\\]|\\[\w\W])*'|\s*\.\s*[$\w\.]+/g,u=/[^\w$]+/g,v=new RegExp(["\\b"+s.replace(/,/g,"\\b|\\b")+"\\b"].join("|"),"g"),w=/^\d[^,]*|,\d[^,]*/g,x=/^,+|,+$/g,y=/^$|,+/;e.openTag="{{",e.closeTag="}}";var z=function(a,b){var c=b.split(":"),d=c.shift(),e=c.join(":")||"";return e&&(e=", "+e),"$helpers."+d+"("+a+e+")"};e.parser=function(a){a=a.replace(/^\s/,"");var b=a.split(" "),c=b.shift(),e=b.join(" ");switch(c){case"if":a="if("+e+"){";break;case"else":b="if"===b.shift()?" if("+b.join(" ")+")":"",a="}else"+b+"{";break;case"/if":a="}";break;case"each":var f=b[0]||"$data",g=b[1]||"as",h=b[2]||"$value",i=b[3]||"$index",j=h+","+i;"as"!==g&&(f="[]"),a="$each("+f+",function("+j+"){";break;case"/each":a="});";break;case"echo":a="print("+e+");";break;case"print":case"include":a=c+"("+b.join(",")+");";break;default:if(/^\s*\|\s*[\w\$]/.test(e)){var k=!0;0===a.indexOf("#")&&(a=a.substr(1),k=!1);for(var l=0,m=a.split("|"),n=m.length,o=m[l++];n>l;l++)o=z(o,m[l]);a=(k?"=":"=#")+o}else a=d.helpers[c]?"=#"+c+"("+b.join(",")+");":"="+a}return a}, true?!(__WEBPACK_AMD_DEFINE_RESULT__ = (function(){return d}).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)):undefined}();

/***/ }),

/***/ "./src/modules/old_us/basestock.js":
/*!*****************************************!*\
  !*** ./src/modules/old_us/basestock.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// define(["common", "emChart", "template", "suggest"], function (common, emChart, template, suggest2017) {

  var common = __webpack_require__(/*! ../old_b/common */ "./src/modules/old_b/common.js")
  var emChart = __webpack_require__(/*! ../old_b/emchart */ "./src/modules/old_b/emchart.js")
  var template = __webpack_require__(/*! ../old_b/template */ "./src/modules/old_b/template.js")

    function baseStock() {
        if (window.stockEnity) {
            this.baseUrl = 'http://push2.eastmoney.com'
            this.ut = 'bd1d9ddb04089700cf9c27f6f7426281'
            this.code = window.stockEnity.stockCode;
            this.name = window.stockEnity.stockName;
            this.market = window.stockEnity.stockMarket;
            this.stockId = window.stockEnity.stockId;
            this.gubaCode = window.stockEnity.gubaCode;
            this.debug = window.location.host !== "quote.eastmoney.com" || window.stockEnity.released;
        }
        if (window.location.href.indexOf("eastmoney.com") > 0) {
            document.domain = "eastmoney.com";
        }
        if (typeof baseStock.suggest === "undefined") {
            try {
                var suggest = baseStock.suggest = new suggest2017({
                    inputid: "search_box",
                    offset: { left: -91, top: 5 },
                    shownewtips: true,
                    newtipsoffset: { top: -3, left: 0 }
                });
            } catch (e) {
                console.error(e);
            }
        }
    }


    // 快速行情
    baseStock.prototype.loadHqData = function () {
        var loadData = {
            url: "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + this.stockId + "&sty=FDPBPFB&st=z&sr=&p=&ps=&cb=?&js=([[(x)]])&token=7bc05d0d4c3c22ef9fca8c2a912d779c",
            intital: function (fieldList) {
                var self = this;
                self.loadHqData(fieldList);
                setInterval(function () {
                    self.loadHqData(fieldList);
                }, 20000);
            },
            loadHqData: function (fieldList) {
                common.jsonP(this.url, function (json) {
                    console.log(11111, json)
                    if (json && json[0] && json[0][0].stats != false) {
                        var stockData = json[0][0].split(',');
                        var zsjIndex, zdeIndex = 0;
                        //获取最新价和涨跌额的index
                        for (var i = 0; i < fieldList.length; i++) {
                            var item = fieldList[i];
                            if (item.name == "zsj") {
                                zsjIndex = item.num;
                            }
                            if (item.name == "zde") {
                                zdeIndex = item.num;
                            }
                        }

                        for (var i = 0; i < fieldList.length; i++) {
                            var field = fieldList[i];

                            var data = stockData[field.num];
                            //振幅和涨跌幅加百分比
                            if (field.name == "zf" || field.name == "zdf" || field.name == "hsl" || field.name == "wb" || field.name == "roe") {
                                if (data > 10000) data = data.split('.')[0];
                                data = data === "-" ? "-" : data + "%";
                            } else {
                                data = data === "-" ? "-" : data;
                            }

                            //开平
                            if (field.name == "kp") {
                                if (data == -1) {
                                    data = "-";
                                } else if (data == 0) {
                                    data = "双开";
                                } else if (data == 1) {
                                    data = "双平";
                                } else if (data == 2) {
                                    data = "多换";
                                } else if (data == 3) {
                                    data = "多开";
                                } else if (data == 4) {
                                    data = "多平";
                                } else if (data == 5) {
                                    data = "空换";
                                } else if (data == 6) {
                                    data = "空开";
                                } else if (data == 7) {
                                    data = "空平";
                                }
                            }
                            //万百万缩写
                            if (field.NumbericFormat && data) {
                                data = data.NumbericFormat();
                            }
                            $("." + field.name).html(data);

                            if (field.hasColor) {
                                var zsj = stockData[zsjIndex];
                                $("." + field.name).removeClass("red").removeClass("green");
                                if (field.name == "wb" || field.name == "wc" || field.name == "rz" || field.name == "cc") {
                                    $("." + field.name).addClass(common.getColor(data));
                                } else if (field.name != "zxj" && field.name != "zdf" && field.name != "zde") {
                                    if (data > zsj) {
                                        $("." + field.name).addClass("red");
                                    } else if (data < zsj) {
                                        $("." + field.name).addClass("green");
                                    }
                                } else {
                                    var zde = stockData[zdeIndex];
                                    if (zde != 0 && zde != "-") {
                                        if (zde.isPositive()) {
                                            $("." + field.name).addClass("red");
                                            $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");
                                        } else {
                                            $("." + field.name).addClass("green");
                                            $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
                                        }
                                    } else {
                                        $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
                                    }
                                }
                            }
                        }

                        //行情时间
                        $("#stock_time").html("(" + stockData[3] + ")");

                        //涨跌平
                        var zdpList = stockData[25].split("|");

                        if ($(".pjs").length > 0) {
                            $(".zjs").html(zdpList[0]);
                            $(".pjs").html(zdpList[1]);
                            $(".djs").html(zdpList[2]);
                        }

                        //阶段涨跌幅
                        var jdzdfList = stockData[26].split("|");

                        if ($(".5day").length > 0) {
                            $(".5day").html(jdzdfList[0]);
                            jdzdfList[0].isPositive() ? $(".5day").addClass("red") : $(".5day").addClass("green");
                            $(".20day").html(jdzdfList[2]);
                            jdzdfList[2].isPositive() ? $(".20day").addClass("red") : $(".20day").addClass("green");
                            $(".60day").html(jdzdfList[3]);
                            jdzdfList[3].isPositive() ? $(".60day").addClass("red") : $(".60day").addClass("green");
                            $(".tillNow").html(jdzdfList[4]);
                            jdzdfList[4].isPositive() ? $(".tillNow").addClass("red") : $(".tillNow").addClass("green");

                        }
                    }
                });
            }
        }
        return loadData;
    }

    /**
    * 加载排行模板
    * @param  {object} settings
    */
    baseStock.prototype.loadRankTemplate = function (settings) {
        var tpl = '{{each list as val idx}}<tr>'
            + '<td><a href="{{val.link}}" title="{{val.title || val.name}}" target="_blank">{{val.name}}</a></td>'
            + '<td class="{{val.color}}">{{val.close}}</td><td class="{{val.color}}">{{val.changePercent}}</td>'
            + '</tr>{{/each}}';
        var _this = this;
        var _default = {
            interval: 0,
            template: tpl,
            link: "//quote.eastmoney.com/web/r/{{code}}{{market}}",
            ajax: {
                url: "//nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx",
                type: "GET",
                data: {
                    type: "CT",
                    cmd: "",
                    sty: "E1II",
                    st: "(ChangePercent)",
                    sr: -1,
                    js: "([(x)])",
                    ps: 5,
                    token: "4f1862fc3b5e77c150a2b985b12db0fd"
                },
                dataType: "jsonp",
                jsonp: "cb"
            },
            dataResolver: function (json) {
                var context = new Object(),
                    models = [];
                if (json instanceof Array) {
                    for (var i = 0; i < json.length; i++) {
                        if (!isNaN(settings.count) && i >= settings.count) break;
                        var data = json[i];
                        if (typeof data !== "string") continue;
                        var items = data.split(',');
                        var _model = {
                            code: items[0],
                            market: items[1],
                            title: items[2],
                            name: common.cutstr(items[2], 10, "..."),
                            close: items[3],
                            changePercent: items[4],
                            color: items[4] === "0" || items[4] === "-" ? "" : items[4].isPositive() ? "red" : "green"
                        };
                        _model.link = template.render(_settings.link, _model);
                        models.push(_model);
                    }
                    context["list"] = models;
                }
                return context;
            }
        };
        if (settings.ajax) {
            settings.ajax.data = $.extend(_default.ajax.data, settings.ajax.data);
        }
        settings.ajax = $.extend(_default.ajax, settings.ajax);
        if (typeof settings.cmd === "string" && !settings.ajax.data.cmd)
            settings.ajax.data["cmd"] = settings.cmd;
        if (typeof settings.count === "number" && settings.count > 0)
            settings.ajax.data["ps"] = settings.count;
        if (typeof settings.callback === "string")
            settings.ajax["jsonpCallback"] = settings.callback;
        var _settings = $.extend(_default, settings);
        var $dom = $(_settings.dom);
        if ($dom.length === 0 && typeof _settings.dom === "string") {
            var _dom = document.getElementById(_settings.dom);
            if (_dom) $dom = $(_dom);
            else throw "dom not found";
        }
        _settings.ajax.success = function (json) {
            if (typeof settings.callback === "function") { settings.callback(json); }
            if (!json) return;
            var model, html;
            if (typeof _settings.dataResolver === "function") {
                model = _settings.dataResolver(json);
            }
            if (typeof _settings.callback === "function")
                _settings.callback($dom, model, _settings);
            if (typeof _settings.template === "string") {
                html = render(_settings.template, model);
            }
            else if (typeof _settings.template === "function") {
                var temp = _settings.template(context, _settings);
                html = render(temp, model);
            }
            if (html) $dom.html(html);
        };
        var render = function (tpl, model) {
            var _model = model || {};
            if (document.getElementById(tpl))
                return template(tpl, _model);
            else
                return template.render(tpl, _model);
        };
        var auto = $.dataAutoRefresh(_settings.ajax);
        if (_settings.interval > 0) {
            auto.intInterval = _settings.interval;
            auto.start();
        }
        else { auto.load(); }
        return auto;
    }

    /** 
    * 新版快速行情
    * @param {object} settings: 配置
    */
    baseStock.prototype.loadQuoteData = function (settings) {
        var _this = this;
        var _defualt = {
            ajax: {
                url: "//nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx",
                data: {
                    type: "CT",
                    cmd: _this.stockId,
                    sty: "FDPBPFB",
                    st: "z",
                    js: "((x))",
                    token: "4f1862fc3b5e77c150a2b985b12db0fd"
                },
                dataType: "jsonp"
            },
            interval: window.defaultInterval || 20 * 1000,
            fields: []
        };
        if (settings.ajax) {
            if (settings.ajax.data) {
                settings.ajax.data = $.extend(_defualt.ajax.data, settings.ajax.data);
            }
            settings.ajax = $.extend(_defualt.ajax, settings.ajax);
        }
        var _settings = $.extend(_defualt, settings);
        _settings.ajax.success = function (json) {
            if (!json) return;
            var data;
            if (typeof _settings.dataResolver === "function") {
                data = _settings.dataResolver(json);
            }
            else if (typeof (json) === "string") {
                data = json.split(',');
            }
            for (var i = 0; i < _settings.fields.length; i++) {
                var field = _settings.fields[i] ? _settings.fields[i] : {};
                var item = data[field.num || 0] + '',
                     //item = field.fixed?data[field.num || 0].toFixed(data[field.fixed]):item
                    $dom = $("." + field.name),
                    changed = false;
                if (typeof field.handler === 'function') {
                    item = field.handler.apply(_this, [item, field, _settings]);
                }
                if (!item || $dom.length == 0) continue;
                // 是否科学计数
                if (field.NumbericFormat) {
                    item = item.NumbericFormat();
                }
                // 枚举映射
                if (typeof (field.map) === "object" && field.map[item]) {
                    item = field.map[item];
                }
                // 呈现模板
                if (typeof field.template === "string") {
                    var model = new Object();
                    model[field.paramName || "data"] = item;
                    item = template.render(field.template, model);
                }
                changed = $dom.html() != item;
                //if (!changed) continue;
                $dom.html(item);
                // 颜色处理
                if (field.hasColor) {
                    var css = "", blink_model = 0;
                    $dom.removeClass("red").removeClass("green");
                    if (!isNaN(field.comparer)) {
                        css = field.comparer < 0 ? "green" : field.comparer > 0 ? "red" : "";
                        blink_model = field.comparer > 0 ? 1 : field.comparer < 0 ? -1 : 0;
                    }
                    else if (typeof field.comparer === "function") {
                        var c = field.comparer(data);
                        css = c < 0 ? "green" : c > 0 ? "red" : "";
                        blink_model = c > 0 ? 1 : c < 0 ? -1 : 0;
                    }
                    else {
                        css = common.getColor(item);
                        item = typeof item === "string" ? item : item.toString();
                        blink_model = item == "0" || item == "-" ? 0 : item.isPositive() ? 1 : -1;
                    }
                    $dom.addClass(css);
                    // 闪烁效果
                    if (field.blink && changed) {
                        if (blink_model === 1) {
                            $dom.textBlink({ color: ["#FFDDDD", "#FFEEEE", ""], blinktime: 150 });
                        }
                        else if (blink_model === -1) {
                            $dom.textBlink({ color: ["#b4f7af", "#ccffcc", ""], blinktime: 150 });
                        }
                    }
                }
                // 字段呈现回调
                if (typeof (field.render) === "function") {
                    field.render($dom, data[field.num || 0] + '', data, _settings);
                }
            }
        };
        var auto = $.dataAutoRefresh(_settings.ajax);
        auto.intInterval = _settings.interval;
        auto.start();
        return auto;
    }

    /** 
    * 新版个股新闻行情
    * @param {object} settings: 配置
    */
    baseStock.prototype.bindStockNews = function (settings) {
        var tpl = $("#tmp_news").html() || "{{if Status === 0 && Data.length>0}}"
            + "<ul class=\"article_list nlist\">"
            + "{{each Data as val idx}}<li>"
            + "<a href=\"{{val.Art_Url}}\" title=\"{{val.Art_Title}}\" target=\"_blank\" class=\"fl\">{{val.Art_Title | cutstr:42,'...'}}</a>"
            + "<i class=\"fr\">{{val.Art_ShowTime | formatDate:'MM-dd'}}</i>"
            + "</li>{{/each}}"
            + "</ul>{{else}}"
            + "<div class=\"nonslist\">暂无该股新闻</div>"
            + "{{/if}}";
        var _settings;
        var _default = {
            tpl: tpl,
            dom: $("#stocknews"),
            api: {
                url: "//searchapi.eastmoney.com/api/Info/Search?isAssociation20=True&highlights20=null&pageIndex20=1&pageSize20=5&returnFields20=Art_Title|0,Art_Url|0,Art_ShowTime&type=20&token=E5303D4106DC91E17D35009B8830D33D&sort20=Art_ShowTime|0",
                data: { and20: "multimatch/Art_Title,Art_Content/" + encodeURIComponent(stockEnity.stockName) + "/True" },
                dataType: "jsonp",
                jsonp: "cb",
                success: function (json) {
                    if (!json) json = { Status: -1 };
                    $(_settings.dom).html(template.render(_settings.tpl, json));
                }
            }
        };
        if (settings && settings.api) {
            settings.api = $.extend(_default.api, settings.api);
        }
        _settings = $.extend(_default, settings);
        if (settings) {
            if (typeof _settings.dom === "string") {
                var query = _settings.dom;
                _settings.dom = document.getElementById(query);
                if (!ele) _settings.dom = $(query);
            }
            if (typeof settings.callback === "function") {
                _default.api.success = settings.callback;
            }
            if (typeof settings.api.data !== "undefined") {
                $.extend(_default.api.data, settings.api.data);
            }
        }
        return $.ajax(_settings.api);
    }

    // 五档，分时
    baseStock.prototype.loadDetailData = function () {
        common.jsonP("http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + this.stockId + "&sty=FDTHTB&st=z&sr=&p=&ps=&cb=?&js=([(x)])&token=7bc05d0d4c3c22ef9fca8c2a912d779c", function (json) {
            if (json && json[0]) {
                var stockData = json[0].split(',');
                var html_sell = "<tbody>";
                var html_buy = "<tbody>";
                var html_deal = "<tbody>";
                var numList = ["一", "二", "三", "四", "五"];

                var zs = stockData[3];
                var color = "";
                for (var i = 10; i < 15; i++) {
                    if (stockData[24 - i] > zs) {
                        color = "red";
                    } else if (stockData[24 - i] < zs) {
                        color = "green";
                    }
                    html_sell += '<tr><td class="tac">卖' + numList[14 - i] + '</td><td class="' + color + '">' + stockData[24 - i] + '</td><td>' + stockData[34 - i] + '</td></tr>';
                }

                color = "";
                for (var j = 5; j < 10; j++) {
                    if (stockData[j] > zs) {
                        color = "red";
                    } else if (stockData[j] < zs) {
                        color = "green";
                    }
                    html_buy += '<tr><td class="tac">买' + numList[j - 5] + '</td><td class="' + color + '">' + stockData[j] + '</td><td>' + stockData[j + 10] + '</td></tr>';
                }

                var dealEntity = stockData[25];
                if (dealEntity && dealEntity != "-") {
                    var dealList = dealEntity.split("|");

                    var count = dealList.length >= 9 ? dealList.length - 9 : 0;

                    for (var k = dealList.length - 1; k >= count; k--) {
                        var itemList = dealList[k].split("~");
                        var arrow = itemList[3] == "-1" ? "↓" : itemList[3] == "1" ? "↑" : "";
                        var arrowColor = itemList[3] == "-1" ? "green" : itemList[3] == "1" ? "red" : "";
                        var dataColor = "";
                        if (stockData[3] < itemList[1]) {
                            dataColor = "red";
                        } else if (stockData[3] > itemList[1]) {
                            dataColor = "green";
                        }
                        html_deal += '<tr><td>' + itemList[0] + '</td><td class="' + dataColor + '">' + (itemList[1] || "-") + '</td>'
                            + '<td class="chjl ' + arrowColor + '">' + (itemList[2] || "-") + arrow + '</td></tr>';
                    }
                }
                else {
                    html_deal += "<tr><td>暂无数据</td></tr>";
                }

                html_sell += "</tbody>";
                html_buy += "</tbody>";
                html_deal += "</tbody>";

                $("#sell_table").html(html_sell);
                $("#buy_table").html(html_buy);
                $("#deal_table").html(html_deal);
            }
        });
    }

    // 行情图片事件绑定
    baseStock.prototype.bindChartImgEvent = function (options) {
        var self;
        var defualtUrls = {
            "url_r": "//webquotepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da",
            //"url_k": "//webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da"
            "url_k": (window.stockEnity.MktNum == '90' || window.stockEnity.MktNum == '105'|| window.stockEnity.MktNum == '106' || window.stockEnity.MktNum == '107') ? "//webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da" : "//pifm.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx?token=44c9d251add88e27b65ed86506f6e5da"
        };

        var _options = $.extend(defualtUrls, options);
        return {
            unitWidth: -6,
            stockId: this.stockId,
            bindEvent: function () {
                if (!self) self = this;
                $("#pictit span").click(function () {
                    $("#pictit span").removeClass("cur");
                    $(this).addClass("cur");
                    self.changeImg("k");
                });

                $("#zkeya li").click(function () {
                    $("#zkeya li").removeClass("at");
                    $(this).addClass("at");
                    self.changeImg("k");
                });

                $("#zkeyb li").click(function () {
                    $("#zkeyb li").removeClass("at");
                    $("#zkeyc li").removeClass("at");
                    $(this).addClass("at");
                    $("#zkeyc li[type=" + $(this).attr("type") + "]").addClass("at");
                    self.changeImg("k");
                });

                $("#zkeyc li").click(function () {
                    $("#zkeyb li").removeClass("at");
                    $("#zkeyc li").removeClass("at");
                    $(this).addClass("at");
                    $("#zkeyb li[type=\"" + $(this).attr("type") + "\"]").addClass("at");
                    self.changeImg("k");
                });

                $("#picklc").click(function () {
                    if (self.unitWidth <= -8) {
                        return;
                    }
                    self.unitWidth = self.unitWidth - 1;
                    self.changeImg("k");
                });

                $("#picksd").click(function () {
                    if (self.unitWidth >= 0) {
                        return;
                    }
                    self.unitWidth = self.unitWidth + 1;
                    self.changeImg("k");
                });

                //分时
                $("#actTab1 span").click(function () {
                    $("#actTab1 span").removeClass("cur");
                    $(this).addClass("cur");
                    self.changeImg("r");

                });
            },
            changeImg: function (type) {
                if (!self) self = this;
                if (typeof type === "string") {
                    switch (type) {
                        case "r":
                            var rtype = $("#actTab1 .cur").attr("type");

                            var params = {}
                            if (window.stockEnity.MktNum == '90' || window.stockEnity.MktNum == '105' || window.stockEnity.MktNum == '106' || window.stockEnity.MktNum == '107') {
                                params = {
                                    nid: stockEnity.UnifiedID ? stockEnity.UnifiedID : (stockEnity.MktNum + '.' + stockEnity.stockCode),
                                    type: rtype === "M0" ? "" : rtype === "PQ" ? "" : rtype || "r",
                                    imageType: rtype === "PQ" ? "rc" : (rtype === "M0" || !rtype) ? "rf" : "t"
                                }
                            } else {
                                params = {
                                    id: self.stockId,
                                    type: rtype === "M0" ? "" : rtype === "PQ" ? "" : rtype || "r",
                                    imageType: rtype === "PQ" ? "rc" : (rtype === "M0" || !rtype) ? "rf" : "t"
                                }

                            }
                            loadimg("picr", 276, 578, _options.url_r,params, "//hqres.eastmoney.com/EMQuote_Lib/img/picrnotfund.gif");
                            break;
                        case "k":
                            // K图
                            var params2 = {}
                            if (window.stockEnity.MktNum == '90' || window.stockEnity.MktNum == '105' || window.stockEnity.MktNum == '106' || window.stockEnity.MktNum == '107') {
                                params2 = {
                                    nid: stockEnity.UnifiedID ? stockEnity.UnifiedID : (stockEnity.MktNum + '.' + stockEnity.stockCode),
                                    type: $("#pictit .cur").attr("type"),
                                    unitWidth: self.unitWidth,
                                    ef: $("#zkeya .at").attr("type") ? $("#zkeya .at").attr("type") : "",
                                    formula: $("#zkeyb .at").attr("type"),
                                    imageType: "KXL"
                                }
                            } else {
                                params2 = {
                                    id: self.stockId,
                                    type: $("#pictit .cur").attr("type"),
                                    unitWidth: self.unitWidth,
                                    ef: $("#zkeya .at").attr("type") ? $("#zkeya .at").attr("type") : "",
                                    formula: $("#zkeyb .at").attr("type"),
                                    imageType: "KXL"
                                }

                            }
                            loadimg("pick", 365, 520, _options.url_k, params2, "//hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif");
                            break;
                        default: break;
                    }
                }
                else {
                    self.changeImg("r");
                    self.changeImg("k");
                }

                function loadimg(container, height, width, url, data, errurl) {
                    var $container = $("#" + container);
                    if ($container.length === 0) return false;
                    $.imgLoader({
                        url: url,
                        data: data,
                        height: height,
                        width: width,
                        success: function (image) {
                            $container.html(image);
                        },
                        error: function (image) {
                            $container.html($(image).attr("src", errurl || "//hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif"));
                        }
                    });
                }
            }
        };
    }

    // 股市直播
    baseStock.prototype.stockBroadcast = function () {

        var stockBroadcast = {

            init: function () {
                var self = this;
                self.setNews();
                $("#kx_fontsize").click(function () {
                    if ($(".kx_list").hasClass("kx_fz14")) {
                        $(".kx_list").removeClass("kx_fz14");
                        $(this).html("大字+");
                    } else {
                        $(".kx_list").addClass("kx_fz14");
                        $(this).html("小字-");
                    }
                });
                $("#kx_refresh").off()
                $("#kx_refresh").click(function () {
                    self.setNews();
                });
            },
            setNews: function () {
                var url = "http://newsinfo.eastmoney.com/kuaixun/v2/api/list?column=zhiboall&limit=20";
                common.jsonP(url, function (json) {
                    if (json.rc == 1) {
                        //上方的直播
                        var random = parseInt(Math.random() * 20);
                        if (json.news[random]) {
                            var item = json.news[random];
                            $("#ScrollMIIRBox .dt").html(item.showtime);

                            $("#ScrollMIIRBox .t").html('<a href="' + item.url_unique + '" target="_blank">' + item.title + '</a>');
                        }

                        var html = "";
                        for (var i = 0; i < json.news.length; i++) {
                            var itemNews = json.news[i];
                            var time = itemNews.showtime.split(" ")[1];
                            html += '<li><span class="kx_itime">' + time + '</span>' +
                                '<span class="kx_itime_end">|</span>' +
                                '<span class="bd_i_txt">' +
                                '<a href="' + itemNews.url_unique + '" target="_blank">' +
                                itemNews.title + '&nbsp;[点击查看全文]</a></span></li>';
                        }

                        $("#stockBroadcast").html(html);
                    }
                }, null);
            }
        }
        return stockBroadcast;
    }

    // 热门股吧
    baseStock.prototype.setHotGuba = function (length) {
        var base = this
        var url = $("#GetHotGuba").val();
        $.ajax({
            type: "GET",
            url: url,
            data: { count: length },
            dataType: "json",
            success: function (data) {
                if (data.success) {
                    var codeList = data.data.join(",");
                    var arr = []
                    for (var i = 0; i < data.data.length; i++) {
                        var market = data.data[i].slice(6, 7)
                        var code = data.data[i].slice(0, 6)
                        arr.push((market == 1 ? 1 : 0) + '.' + code)
                    }
                    var codestr = arr.join(",")
                    var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
                    base.bindDataTemplatenew(url, "hotGuba", "guba");

                }
            }
        });
    }

    // JS行情图
    baseStock.prototype.setChart = function () {
        var setChart = {
            init: function () {
                this.bindEvent();
                this.set();
            },
            bindEvent: function () {
                $("#image_show").click(function () {
                    $("#h5_show").removeClass("cur");
                    $(this).addClass("cur");
                    $("#img_container").show();
                    $("#h5_container").hide();
                });
                $("#h5_show").click(function () {
                    $("#image_show").removeClass("cur");
                    $(this).addClass("cur");
                    $("#img_container").hide();
                    $("#h5_container").show();
                });
            },
            set: function () {
                emChart.initial();
            }
        }
        return setChart;
    }

    //列表模板
    baseStock.prototype.bindDataTemplate = function (url, containerId, type) {
        var html = "";
        common.jsonP(url, function (json) {
            if (json.length == 0) {
                return;
            }

            if (type.indexOf("NO") >= 0) {
                html += '<tbody>';
            } else {
                html += '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>';
            }

            for (var i = 0; i < json.length; i++) {
                if (!json[i]) continue;
                var itemlist = json[i].split(",");
                var color = common.getColor(itemlist[4]);

                var stockCode = itemlist[1];
                var stockName = itemlist[2];

                if (common.getByteLen(stockName) > 12) {
                    //判断中英文
                    if (stockName.match(/[^\x00-\xff]/ig) != null) {
                        stockName = stockName.substring(0, 6) + "..";
                    } else {
                        stockName = stockName.substring(0, 12) + "..";
                    }
                }

                var stockUrl = "http://quote.eastmoney.com";

                if (type == "global") {
                    if (stockName == "上证指数" || stockName == "深证成指") {
                        stockUrl += "/zs" + stockCode + ".html";
                    } else if (stockName == "恒生指数") {
                        stockUrl += "/hk/zs110000.html";
                    } else {
                        stockUrl += "/gb/zs" + stockCode + ".html";
                    }
                }

                if (type == "AB" || type == "AB_NO") {
                    if (itemlist[1].indexOf("BK") >= 0) {
                        stockUrl += "/web/" + stockCode + "1.html";
                    } else if (itemlist[0] == "1") {
                        stockUrl += "/sh" + stockCode + ".html";
                    } else if (itemlist[0] == "2") {
                        stockUrl += "/sz" + stockCode + ".html";
                    }
                }

                if (type == "guba") {
                    stockUrl = "http://guba.eastmoney.com/list," + stockCode + ".html";
                    stockName += "吧";
                }

                if (type == "globalFuture") {
                    stockUrl += "/globalfuture/" + stockCode + ".html";
                }

                if (type == "forex") {
                    if (stockCode == "DINI") {
                        stockUrl += "/qihuo/dini.html";
                    } else {
                        stockUrl += "/forex/" + stockCode + ".html";
                    }
                }

                if (type == "hk") {
                    stockUrl += "/hk/" + stockCode + ".html";
                }

                if (type == "index" || type == "index_NO") {
                    stockUrl += "/zs" + stockCode + ".html";
                }

                if (type == "us") {
                    stockUrl += "/us/" + stockCode + ".html";
                }

                if (type == "xh") {
                    stockUrl = "";
                    //stockUrl += "/web/" + stockCode + "8.html";
                }

                if (type == "gzqh") {
                    stockUrl += "/gzqh/" + stockCode + ".html";
                }

                if (type == "future") {
                    //判断是否为股指期货
                    if (itemlist[0] == "_ITFFO") {
                        stockUrl += "/gzqh/" + stockCode + ".html";
                    } else {
                        stockUrl += "/qihuo/" + stockCode + ".html";
                    }
                }
                html += '<tr>'
                    + '<td>'
                    + (stockUrl ? ('<a href="' + stockUrl + '" target="_blank" title="' + itemlist[2] + '">' + stockName + '</a>') : stockName)
                    + '</td>'
                    + '<td class="' + color + '">' + itemlist[3] + '</td>'
                    + '<td class="' + color + '">' + itemlist[4] + '</td>'
                    + '</td></tr>';
            }
            html += "</tbody>";
            $("#" + containerId).html(html);
        });

    }

    //列表模板接新行情
    baseStock.prototype.bindDataTemplatenew = function (url, containerId, type) {
        var html = "";
        $.ajax({
            type: "GET",
            url: url,
            data: null,
            dataType: 'jsonp',
            jsonp: 'cb',
            success: function (res) {
                var data = res.data.diff;
                var json = []
                if (type == 'AB' || type == 'guba') {
                    for (var i = 0; i < data.length; i++) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(2) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                } else if (type == 'ZDF') {
                    for (var i in data) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(2) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                }

                var html = '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>';
                for (var i = 0; i < json.length; i++) {
                    var itemlist = json[i].split(",");
                    var color = common.getColor(itemlist[4]);
                    var stockCode = itemlist[1];
                    var stockName = itemlist[2];
                    var stockUrl = "http://quote.eastmoney.com";
                    if (type == "AB") {
                        if (itemlist[1].indexOf("BK") >= 0) {
                            stockUrl += "/web/" + stockCode + "1.html";
                        } else if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    } else if (type == "guba") {
                        stockUrl = "http://guba.eastmoney.com/list," + stockCode + ".html";
                        stockName += "吧";
                    } else if (type == "ZDF") {
                        if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    }
                    html += '<tr>'
                        + '<td>'
                        + (stockUrl ? ('<a href="' + stockUrl + '" target="_blank" title="' + itemlist[2] + '">' + stockName + '</a>') : stockName)
                        + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[3]) + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[4]) + '</td>'
                        + '</td></tr>';
                }

                html += "</tbody>";
                $("#" + containerId).html(html);

            }
        });
    }

    // 获取文章列表
    baseStock.prototype.getArticle = function (articleNum, containerId) {
        var url = $("#GetArticle").val();
        $.ajax({
            type: "GET",
            url: url,
            data: {
                articleNum: articleNum
            },
            dataType: "json",
            success: function (data) {
                if (data && data.success) {
                    if (data.data.length >= 5) {
                        var html = "";
                        for (var i = 0; i < data.data.length; i++) {
                            var item = data.data[i];

                            html += '<li class="clearfix">' +
                                '<a href="' + item.url + '" target="_blank" class="fl">' + item.title + '</a>' +
                                '<i class="fr">' + item.date + '</i></li>';
                        }
                        $("#" + containerId).html(html);
                    }
                }
            }
        });
    }

    //自选股
    baseStock.prototype.getFavouriteStock = function (num) {
        var count = num || 5;
        var base = this;
        var pi = common.getCookie("pi");
        var initlist = "300059,000016,000017,300268,000001,000002,000005,000006,000008";
        var emhq_stock = common.getCookie("emhq_stock");
        if (emhq_stock) {
            initlist = emhq_stock;
        }
        var itemlist = initlist.split(",");
        var stockList = new Array();
        for (var i = 0; i < itemlist.length; i++) {
            stockList.push(itemlist[i] + common.getMarketCode(itemlist[i]));
        }
        if (pi) {
            if (pi.split(';').length >= 3) {
                var name = pi.split(';')[2];
                if (!/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) {
                    $.getScript("https://myfavor.eastmoney.com/mystock?f=gsaandcheck&sc=" + base.code + "|0" + base.market + "|01&c=" + count + "&var=favorStock", function () {
                        var allstocklist = [];
                        if (favorStock.result == "1") {
                            var sl = favorStock.data.list.split(',');
                            for (var i = 0; i < sl.length; i++) {
                                var item = sl[i].split('|');
                                var stockId = item[0] + common.getMarketCode(item[0]);
                                allstocklist.push(stockId);
                            }
                            allstocklist = allstocklist.concat(stockList).unique().slice(0, count);
                            var url = "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + allstocklist.join(',') + "&sty=MPNSBAS&st=z&p=1&ps=" + count + "&cb=?&js=([(x)])&token=7bc05d0d4c3c22ef9fca8c2a912d779c";
                            base.bindDataTemplate(url, "favorTable", "AB");
                        }
                    });
                }
            }
        } else {
            var url = "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + stockList.join(",") + "&sty=MPNSBAS&st=c&sr=-1&p=1&ps=" + count + "&cb=?&js=([(x)])&token=7bc05d0d4c3c22ef9fca8c2a912d779c";
            base.bindDataTemplate(url, "favorTable", "AB");
        }
    }


    //自选股 接新行情 zxw
    baseStock.prototype.getFavouriteStocknew = function (num) {
        var count = num || 5;
        var base = this;
        var pi = common.getCookie("pi");
        var initlist = "0.300059,0.000016,0.000017,0.300268,0.000001,0.000002,0.000005,0.000006,0.000008";
        var emhq_stock = common.getCookie("emhq_stock");
        if (emhq_stock) {
            initlist = emhq_stock;
        }
        var itemlist = initlist.split(",");
        var stockList = new Array();
        for (var i = 0; i < itemlist.length; i++) {
            stockList.push(itemlist[i]);
        }
        if (pi) {
            if (pi.split(';').length >= 3) {
                var name = pi.split(';')[2];
                if (!/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) {
                    $.getScript("https://myfavor.eastmoney.com/mystock?f=gsaandcheck&sc=" + base.code + "|0" + base.market + "|01&c=" + count + "&var=favorStock", function () {
                        var allstocklist = [];
                        if (favorStock.result == "1") {
                            var sl = favorStock.data.list.split(',');
                            for (var i = 0; i < sl.length; i++) {
                                var item = sl[i].split('|');
                                var stockId = (common.getMarketCode(item[0]) == 2 ? 0 : common.getMarketCode(item[0])) + '.' + item[0]
                                allstocklist.push(stockId);
                            }
                            allstocklist = allstocklist.concat(stockList).unique().slice(0, count);
                            var codestr = allstocklist.join(",")
                            var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
                            base.bindDataTemplatenew(url, "favorTable", "AB");

                        }
                    });
                }
            }
        } else {
            var codestr = stockList.slice(0, count).join(",")
            var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
            base.bindDataTemplatenew(url, "favorTable", "AB");
        }
    }

//     return baseStock;
// });

module.exports = baseStock


/***/ }),

/***/ "./src/modules/old_us/us.js":
/*!**********************************!*\
  !*** ./src/modules/old_us/us.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// require(["baseStock", "common", "template"], function (baseStock, common, template) {

var baseStock = __webpack_require__(/*! ./basestock */ "./src/modules/old_us/basestock.js")
var common = __webpack_require__(/*! ../old_b/common */ "./src/modules/old_b/common.js")
var template = __webpack_require__(/*! ../old_b/template */ "./src/modules/old_b/template.js")

    function Usstock() {
        baseStock.call(this);  //第二次调用基类的构造函数
        this.stockZjlType = "";
    }

    Usstock.prototype = new baseStock();
    var instance = new Usstock();

    Usstock.prototype.baseUrl = 'http://push2.eastmoney.com'
    Usstock.prototype.ut = 'bd1d9ddb04089700cf9c27f6f7426281'


    // 热门美股吧
    Usstock.prototype.setHotGubaList = function (len) {
        var _len = len || 15;
        var url = "http://gubawebapi.eastmoney.com/v3/read/Guba/HotGuba.aspx?type=4&deviceid=900150983cd24fb0d6963f7d28e17f72&product=EastMoney&plat=web";
        $.ajax({
            url: url,
            dataType: "jsonp",
            data: { version: 100 },
            jsonpCallback: "this.hotGubaCallback(" + _len + ")"
        });

    }

    // 热门美股吧回调
    window.hotGubaCallback = function (len) {  //zxw
        var _len = len;
        function render(json) {
            var ids = [];
            if (json.rc === 1) {
                for (var i = 0; i < json.re.length; i++) {
                    var code = json.re[i].stockbar_code;
                    if (!code) continue;
                    if (json.re[i].stockbar_market.split(".")[1] == 'nyse') {
                        ids.push(106 + '.' + code.substring(2, code.length));
                    } else {
                        ids.push(105 + '.' + code.substring(2, code.length));
                    }
                }
                var idList = ids.join(",");

                var auto = $.dataAutoRefresh({
                    url: instance.baseUrl + '/api/qt/ulist.np/get?secids=' + idList + "&ut=" + instance.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152',
                    data: null,
                    dataType: 'jsonp',
                    jsonp: 'cb',
                    success: function (json) {
                        var data = json.data.diff
                        var list = [];
                        if (data && data instanceof Array) {
                            for (var i = 0; i < data.length; i++) {
                                if (i >= _len) continue;
                                list.push({
                                    name: common.cutstr(data[i].f14, 8),
                                    title: data[i].f14,
                                    close: data[i].f2 == 0 ? '-' : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                                    changePercent: data[i].f2 == 0 ? '-' : ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(2) + '%'),
                                    link: "//guba.eastmoney.com/list,us" + data[i].f12 + ".html",
                                    color: common.getColor(data[i].f3)
                                });
                            }
                            var html = template("tmp_name_close_cp", { list: list });
                            $("#hotGuba tbody").html(html);
                        }
                    }
                });
                auto.start();
            }
        }
        return render;
    }

    // 美股成交明细 zxw
    Usstock.prototype.bindDealDetail = function () {
        var _url = this.baseUrl + "/api/qt/stock/details/get?secid=" + stockEnity.UnifiedID + "&ut=" + this.ut + "&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55&pos=-13"
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data
                if (!data.details.length || !data.prePrice) return;
                var list = [];
                var details = data.details
                for (var i = 0; i < details.length; i++) {

                    if (i > 0) {
                        var itemslast = details[i - 1].split(",")
                        var items = details[i].split(",");
                        var dir = (items[1] > itemslast[1] ? "↑" : items[1] == itemslast[1] ? " " : "↓")
                        var listitem = {
                            time: items[0],
                            close: items[1],
                            closeCss: common.getColor(items[1] - data.prePrice),
                            volumn: items[2],
                            dir: dir,
                            volumnCss: items[4] == 0 ? lastcolor : (items[4] == 2 ? (items[1] * items[2] > 200000 ? 'purple' : 'red') : (items[1] * items[2] > 200000 ? 'blue' : 'green')),
                            arrowcolor: items[1] > itemslast[1] ? "red" : items[1] == itemslast[1] ? " " : "green"
                        }
                        list.push(listitem);

                        var lastcolor = listitem.volumnCss
                    }
                }
                list = list.reverse()
                var html = template("tmp_deal_detail", { list: list });
                $("#deal_detail tbody").html(html);
            }
        });
    }

    // 中概股行情 zxw
    Usstock.prototype.bindChineseCompanyQuote = function () {
        var _url = this.baseUrl + "/api/qt/clist/get?ut=" + this.ut + "&pi=0&pz=12&po=1&fs=b:MK0201&fid=f3&fields=f1,f2,f3,f12,f14"
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data.diff
                var list = []
                for (var i in data) {
                    list.push({
                        title: data[i].f14,
                        name: common.cutstr(data[i].f14, 8),
                        close: (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                        changePercent: (data[i].f3 / 100).toFixed(2) + '%',
                        color: common.getColor(data[i].f3),
                        link: "//quote.eastmoney.com/us/" + data[i].f12 + ".html"
                    })
                }
                var html = template("tmp_name_close_cp", { list: list });
                $("#zgghq tbody").html(html);
            }
        });
    }

    // 互联网中国行情 zxw
    Usstock.prototype.bindChineseNetworkQuote = function () {
        var _url = this.baseUrl + "/api/qt/clist/get?ut=" + this.ut + "&pi=0&pz=12&po=1&fs=b:MK0202&fid=f3&fields=f1,f2,f3,f12,f14"
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data.diff
                var list = []
                for (var i in data) {
                    list.push({
                        title: data[i].f14,
                        name: common.cutstr(data[i].f14, 8),
                        close: (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                        changePercent: (data[i].f3 / 100).toFixed(2) + '%',
                        color: common.getColor(data[i].f3),
                        link: "//quote.eastmoney.com/us/" + data[i].f12 + ".html"
                    })
                }
                var html = template("tmp_name_close_cp", { list: list });
                $("#hlwzg tbody").html(html);
            }
        });
    }

    // 知名美股行情 zxw
    Usstock.prototype.bindFamoueQuote = function () {
        var _url = this.baseUrl + "/api/qt/clist/get?ut=" + this.ut + "&pi=0&pz=6&po=1&fs=b:MK0001&fid=f3&fields=f1,f2,f3,f12,f14"
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data.diff
                var list = []
                for (var i in data) {
                    list.push({
                        title: data[i].f14,
                        name: common.cutstr(data[i].f14, 8),
                        close: (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                        changePercent: (data[i].f3 / 100).toFixed(2) + '%',
                        color: common.getColor(data[i].f3),
                        link: "//quote.eastmoney.com/us/" + data[i].f12 + ".html"
                    })
                }
                var html = template("tmp_name_close_cp", { list: list });
                $("#famous_quote tbody").html(html);
            }
        });
    }

    //全屏的方法
    Usstock.prototype.fullScreenFun = function () {
        // ie9以下隐藏全屏按钮
        if (document.all && !document.addEventListener) {
            $(".fullScreenBtn").hide();

            //隐藏全屏
            $("#beta-text-link1").hide();
            $("#beta-text-link2").hide();

            //并阻止ie8以下的点击事件问题
            $("#picrbox1 a").attr('disabled', 'true');
            $("#picrbox1 a").attr('href', '#');
            $("#picrbox1 a").css('cursor', 'default');
            $("#picrbox1 img").css('cursor', 'default');
            $("#picrbox2 a").attr('disabled', 'true');
            $("#picrbox2 a").attr('href', '#');
            $("#picrbox2 a").css('cursor', 'default');
            $("#picrbox2 img").css('cursor', 'default');


            window.location.hash = "";
        }
        var type = "";
        var id = stockEnity.UnifiedID
        var url = "//quote.eastmoney.com/basic/full.html?mcid=" + id + "&type=r";
        var $context = $('<div class="fs-wrapper"><div class= "mark-box"></div><div class="full-box"><span class="full-close">×</span><iframe src = "' + url + '" style="height:98%;width:99%;min-height:600px"></iframe></div ></div>');
        $(".fullScreenBtn").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        if (location.href.indexOf("#fullScreenChart") > 0) {
            $(".fullScreenBtn").trigger("click");
        }
    }

    // 事件绑定
    function bindEvent() {
        $(".tabLi").mouseenter(function () {
            $(this).parent().find("li").removeClass("cur");
            $(this).addClass("cur");

            var index = $(this).index();
            if ($(this).parents(".tabExchange").length > 0) {
                $(this).parents(".tabExchange").find(".more").hide();
                $(this).parents(".tabExchange").find(".more").eq(index).show();
                $(this).parents(".tabExchange").find(".info_list").removeClass("active");
                $(this).parents(".tabExchange").find(".info_list").eq(index).addClass("active");
            } else {
                $(this).parents(".side_box").find(".info_list").removeClass("active");
                $(this).parents(".side_box").find(".info_list").eq(index).addClass("active");
            }

        });

        $(".rank_date li").click(function () {
            $(".rank_date li").removeClass("cur");
            $(this).addClass("cur");
            instance.stockZjlType = $(this).attr("value") || "";
            instance.BindStockZjl();
        });
        $("#RefPR").click(function (e) {
            location.reload();
        });
    }
    var imgevt = instance.bindChartImgEvent();
    init();

    setInterval(function () {
        refresh();
    }, 20 * 1000);

    setInterval(function () {
        refreshfscj(); //分时成交每秒刷新
    }, 20 * 1000);

    function refreshfscj() {
        instance.bindDealDetail();
    }

    //我的自选
    instance.getFavouriteStocknew(9);


    function refresh() {
        imgevt.changeImg();
        // instance.getFavouriteStocknew(9);
        instance.bindChineseCompanyQuote();
        instance.bindChineseNetworkQuote();
        instance.bindFamoueQuote();
    }

    //增加数据格式判断
    function myformatNum(num) {
        if (num == 0) {
            return num
        }
        if (num == undefined || num == '' || isNaN(num) || num == '-') {
            return '-';
        }
    
        var hz = '';
        var num2 = '';
        if (num >= 10000000000000) {
            num = num / 1000000000000;
            hz = '万亿';
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 1000000000000  && num < 10000000000000) {
            num = num / 1000000000000;
            hz = '万亿';
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 100000000000 && num < 1000000000000) {
            num = num / 100000000;
            hz = '亿';
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 10000000000 && num < 100000000000) {
            num = num / 100000000;
            hz = '亿';
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 100000000 && num < 10000000000) {
            num = num / 100000000;
            hz = '亿';
            num2 =  parseFloat(num).toFixed(2);
        }
        else if (num >= 10000000 && num < 100000000) {
            num = num / 10000;
            hz = '万';
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 1000000 && num < 10000000) {
            num = num / 10000;
            hz = '万';
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 10000 && num < 1000000) {
            num = num / 10000;
            hz = '万';
            num2 =  parseFloat(num).toFixed(2);
        }
        else if (num >= 1000 && num < 10000) {
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 100 && num < 1000) {
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 1 && num < 100) {
            num2 = parseFloat(num).toFixed(2);
        }
        else if (num >= 0 && num < 1) {
            num2 = parseFloat(num).toFixed(3);
        } 
        else if(num <0) {
            num2 = parseFloat(num).toFixed(2);
        }
        else {
            num2 =  parseFloat(num).toFixed(2);
            // return num;
        }
    
        
    
        // if(parseInt(num) >= 1000){ //整数部分超过4位
        //   num2 = num.toFixed(1);
        // }
    
        return num2.toString() + hz;
    }

    function init() {
        bindEvent();
        instance.bindStockNews({
            api: {
                url: "http://cmsdataapi.eastmoney.com/api/StockNews/QuoteNews?marketType=7&stockCode=" + stockEnity.stockCode + "&stockName=" + encodeURIComponent(stockEnity.stockName) + "&count=5&token=4f1862fc3b5e77c150a2b985b12db0fd",
                data: {}
            }
        });
        instance.stockBroadcast().init();

        function onChangeDataRender($dom, item, settings) {
            if (item != 0 && item != "-") {
                if (item.isPositive()) {
                    $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");
                } else {
                    $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
                }
            } else {
                $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
            }
        }

        //获取基本行情 zxw
        instance.loadQuoteData({
            ajax: {
                url: instance.baseUrl + '/api/qt/stock/get?secid=' + stockEnity.UnifiedID + "&ut=" + instance.ut + "&fields=f43,f169,f170,f46,f60,f84,f116,f44,f45,f171,f126,f47,f48,f168,f164,f49,f161,f55,f92,f59,f152,f167,f50,f86,f71,f172",
                data: {

                },
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get'
            },
            dataResolver: function (json) {
                //判断若是国内登录状态 则刷新
                if(getLoginStatus() && json && json.lt !==2) {
                    // console.log('我的自选刷新')
                    instance.getFavouriteStocknew(9);
                }

                var data = json["data"]
                 //若最新价出现大于 9位数  字大小调整为25px
                 if((data.f43 / Math.pow(10, data.f59)).toFixed(3) >= 100000.000) {
                    $(".quote_brief .brief_left .brief_topP").css("font-size", "25px");
                 }

                // console.log(data.f55.toFixed(2))
                // myformatNum(111);
                // console.log(myformatNum(data.f55.toFixed(2)));

                var shouyi = myformatNum(data.f55.toFixed(2));
                var jingzc = myformatNum(data.f92.toFixed(2));
                var zsz = myformatNum(data.f116);
                var zgb = myformatNum(data.f84);



                var arr = []
                arr.push(data.f43 == 0 ? '-' : (data.f43 / Math.pow(10, data.f59)).toFixed(3))//0最新价
                arr.push(data.f43 == 0 ? '-' : (data.f44 / Math.pow(10, data.f59)).toFixed(3))//1最高价
                arr.push(data.f43 == 0 ? '-' : (data.f45 / Math.pow(10, data.f59)).toFixed(3))//2最低价
                arr.push(data.f43 == 0 ? '-' : (data.f46 / Math.pow(10, data.f59)).toFixed(3))//3开盘价
                arr.push(data.f43 == 0 ? '-' : data.f47)//4成交量
                arr.push(data.f43 == 0 ? '-' : data.f48)//5成交额(f48)
                arr.push(data.f43 == 0 ? '-' : data.f49)//6外盘
                arr.push(shouyi)//7每股收益(f55) 
                arr.push(data.f59)// 8小数位数(f59)
                arr.push((data.f60 / Math.pow(10, data.f59)).toFixed(3))//9昨收价(f60)
                arr.push(zgb)//10总股本(股)(f84)
                arr.push(jingzc)//11每股净资产(f92)
                arr.push(zsz)//12总市值(f116)
                arr.push(data.f126)//13股息率(f126
                arr.push(data.f152)//14小数位数字段(2)
                arr.push(data.f43 == 0 ? '-' : data.f161)//15内盘(f161)
                arr.push(data.f164 / Math.pow(10, data.f152))//16市盈率(TTM)(f164)
                arr.push(data.f168)//17换手率(f168)
                arr.push(data.f43 == 0 ? '-' : (data.f169 / Math.pow(10, data.f59)).toFixed(3))//18涨跌值(f169) 
                arr.push(data.f43 == 0 ? '-' : data.f170)//19涨跌幅(f170) 
                arr.push(data.f43 == 0 ? '-' : data.f171)//20振幅(f171)
                arr.push(data.f43 == 0 ? '-' : data.f167 / Math.pow(10, data.f152))//21市净率(f167)
                arr.push(data.f43 == 0 ? '-' : data.f50 / Math.pow(10, data.f152))//22量比(f50)
                arr.push(common.formatDate(new Date(data.f86 * 1000), 'yyyy-MM-dd HH:mm:ss'))//23行情时间Unix时间戳，单位秒(f86)
                arr.push(data.f43 == 0 ? '-' : (data.f71 / Math.pow(10, data.f59)).toFixed(3))//24均价(f71)
                return arr;
            },
            fields: [
                {
                    name: "jk", num: 3, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[3]) ? 0 : data[3]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                { name: "zs", num: 9, hasColor: false, NumbericFormat: false },
                {
                    name: "zxj", num: 0, hasColor: true, NumbericFormat: false, blink: true,
                    comparer: function (data) { return isNaN(data[18]) ? 0 : data[18]; }
                },
                {
                    name: "zde", num: 18, hasColor: true, NumbericFormat: false, blink: true,
                    render: onChangeDataRender
                },
                { name: "zdf", num: 19, hasColor: true, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2) +'%'}}", blink: true },
                {
                    name: "zgj", num: 1, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[1]) ? 0 : data[1]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                {
                    name: "zdj", num: 2, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[2]) ? 0 : data[2]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                { name: "cjl", num: 4, hasColor: false, NumbericFormat: true },
                { name: "cje", num: 5, hasColor: false, NumbericFormat: true },
                //{
                //    name: "SellPrice1", num: 30, hasColor: true, NumbericFormat: false,
                //    comparer: function (data) { return (isNaN(data[30]) ? 0 : data[30]) - (isNaN(data[9]) ? 0 : data[9]); }
                //},
                //{ name: "SellVolume1", num: 31, hasColor: false, NumbericFormat: false },
                { name: "BuyOrder", num: 6, hasColor: true, NumbericFormat: true, comparer: 1 },
                { name: "SellOrder", num: 15, hasColor: true, NumbericFormat: true, comparer: -1 },
                { name: "zf", num: 20, hasColor: false, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2)+'%'}}" },
                { name: "hsl", num: 17, hasColor: false, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2)+'%'}}" },
                { name: "pe", num: 16, hasColor: false, NumbericFormat: false },
                { name: "sjl", num: 21, hasColor: false, NumbericFormat: false },
                { name: "mgsy", num: 7, hasColor: false, NumbericFormat: false },
                { name: "mgjzc", num: 11, hasColor: false, NumbericFormat: false },
                { name: "roe", num: 20, hasColor: false, NumbericFormat: false },//11111111111111111
                { name: "zgb", num: 10, hasColor: false, NumbericFormat: false },
                { name: "zsz", num: 12, hasColor: false, NumbericFormat: false },
                { name: "gxl", num: 13, hasColor: false, NumbericFormat: false },
                //{
                //    name: "BuyPrice1", num: 23, hasColor: true, NumbericFormat: false,
                //    comparer: function (data) { return (isNaN(data[23]) ? 0 : data[23]) - (isNaN(data[7]) ? 0 : data[7]); }
                //},
                //{ name: "BuyVolume1", num: 24, hasColor: false, NumbericFormat: false },
                { name: "lb", num: 22, hasColor: false, NumbericFormat: false },
                { name: "yl", num: 26, hasColor: false, NumbericFormat: false },//111111111111111
                { name: "tb", num: 27, hasColor: false, NumbericFormat: true },//1111111111111
                { name: "update", num: 23, hasColor: false, NumbericFormat: false, template: "{{data}}" },
                {
                    name: "jj", num: 24, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[24]) ? 0 : data[24]) - (isNaN(data[9]) ? 0 : data[9]); }
                }
                //{ name: "ltgb", num: 32, hasColor: false, NumbericFormat: true },
                //{ name: "ltsz", num: 33, hasColor: false, NumbericFormat: true } //总市值总股本不对，暂时去掉
            ]
        });
        imgevt.bindEvent();
        //guba.init("gubalisttable", Usstock.prototype.gubaCode, { listcount: 12, titlecut: 42 });
        instance.setHotGubaList(15);
        refresh();
        refreshfscj();
        // instance.fullScreenFun();
    }

    
    //新增 加自选的方法
    function fullScreenFun() {
        if (document.all && !document.addEventListener) {
            $(".fullScreenBtn").hide();

            //隐藏全屏
            $("#beta-text-link1").hide();
            $("#beta-text-link2").hide();

            //并阻止ie8以下的点击事件问题
            $("#picrbox1 a").attr('disabled', 'true');
            $("#picrbox1 a").attr('href', '#');
            $("#picrbox1 a").css('cursor', 'default');
            $("#picrbox1 img").css('cursor', 'default');
            $("#picrbox2 a").attr('disabled', 'true');
            $("#picrbox2 a").attr('href', '#');
            $("#picrbox2 a").css('cursor', 'default');
            $("#picrbox2 img").css('cursor', 'default');


            window.location.hash = "";
        }
        // ie9以下隐藏全屏按钮
        if (document.all && !document.addEventListener) {
            $(".fullScreenBtn").hide();
            window.location.hash = "";
        }else {
            $(".fullScreenBtn").show();
       
        
        var id = stockEnity.MktNum + "." + stockEnity.stockCode
        var url = "//quote.eastmoney.com/basic/full.html?mcid=" + id + "&type=r";
        var $context = $('<div class="fs-wrapper"><div class= "mark-box"></div><div class="full-box"><span class="full-close">×</span><iframe src = "' + url + '" style="height:98%;width:99%"></iframe></div ></div>');
        $(".fullScreenBtn").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        if (location.href.indexOf("#fullScreenChart") > 0) {
            $(".fullScreenBtn").trigger("click");
        }

        //增加 点击图片 跳转全屏图
        $("#picr").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });

        //增加点击 k线图 跳转全屏图
        $("#pick").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        $("#beta-text-link1").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        $("#beta-text-link2").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });

    }


    }
    fullScreenFun();

    //新的  加自选
    function newAddzixuan() {
        if(stockEnity.UnifiedID) {
            var mark_code = stockEnity.UnifiedID;
        }

        zixuan_show(mark_code);
        zixuan_add(mark_code);
        zixuan_del(mark_code);
    }
    newAddzixuan();


    function zixuan_show(code) {
        // console.log('自选股 show')
        myShowzixuan(code).then(function (result) {
          // console.info(result)
            // var res = result.data.check;
           
            if(result) {
                $("#addZX1").css("display", "none");
                $("#addZX2").css("display", "false");
            }else {
                $("#addZX1").css("display", "block");
                $("#addZX2").css("display", "none");
            }
        })
        

    }

    function zixuan_add(code) {
        $("#addZX1").click(function() {
            myAddzixuan(code).then(function(res) {

                if(res) {
                    $("#addZX1").css("display", "none");
                    $("#addZX2").css("display", "block");
                }
            })

        })

    }

    function zixuan_del(code) {
        $("#addZX2").click(function() {
            myDelzixuan(code).then(function(res) {
              
                if(res) {
                    $("#addZX1").css("display", "block");
                    $("#addZX2").css("display", "none");
                }
            })
        })

    }


    //加自选
    function myAddzixuan (code) {
        var islogin = getLoginStatus();
        var zxgurl2 = 'http://myfavor1.eastmoney.com/' //f=gsaandcheck
        var zxg2 = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl2 + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp:'cb'
                });
            }
        }

        return zxg2.data({
            f: 'asz',
            sc: code
        }).then(function(list){
            // console.log(list)
           // return list.result
            if (list.result == 1) {
                return true
            }
            else{
                return false
            }
        })

    }

    //删自选
    function myDelzixuan (code) {
        var islogin = getLoginStatus();
        var zxgurl2 = 'http://myfavor1.eastmoney.com/' //f=gsaandcheck
        var zxg2 = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl2 + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp:'cb'
                });
            }
        }

        return zxg2.data({
            f: 'dsz',
            sc: code
        }).then(function(list){
            // console.log(list)
            //return list.result
            if (list.result == 1) {
                return true
            }
            else{
                return false
            }
        })

    }

    //show自选  get自选
    function myShowzixuan (code) {
      // console.info(111)
        var islogin = getLoginStatus();
        var zxgurl2 = 'http://myfavor1.eastmoney.com/' //f=gsaandcheck
        var zxg2 = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl2 + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp:'cb'
                });
            }
        }

        return zxg2.data({
            f: 'gsaandcheck',
            sc: code
        }).then(function(list){
            // console.log(list)
            //return list.result
            //return false;
            if (list.data.check == 'True') {
                return true
            }
            else{
                return false
            }
        })

    }


    function getLoginStatus() {
        if (cookieGet('ut') && cookieGet('ct') && cookieGet('uidal')) {
            
            return true;
        }
        return false; 
    }


    function cookieGet(name) {
		var xarr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
		if (xarr != null)
			return decodeURIComponent(xarr[2]);
		return null;
	}
// });



/***/ })

/******/ });
//# sourceMappingURL=us.js.map