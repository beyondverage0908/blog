/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./jssrc/option.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./jssrc/option.ts":
/*!*************************!*\
  !*** ./jssrc/option.ts ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * 期货 主JS
 */
__webpack_require__(/*! ../src/modules/old_option/stock */ "./src/modules/old_option/stock.js");


/***/ }),

/***/ "./src/modules/old_b/basestock.js":
/*!****************************************!*\
  !*** ./src/modules/old_b/basestock.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// define(["common", "emChart", "template", "suggest"], function (common, emChart, template, suggest2017) {

  var common = __webpack_require__(/*! ./common */ "./src/modules/old_b/common.js")
  var emChart = __webpack_require__(/*! ./emchart */ "./src/modules/old_b/emchart.js")
  var template = __webpack_require__(/*! ./template */ "./src/modules/old_b/template.js")
  // var suggest = suggest2017


    function baseStock() {
        if (window.stockEnity) {
            this.baseUrl = 'http://push2.eastmoney.com'
            //this.baseUrl = 'http://61.152.230.191'
            this.ut = 'bd1d9ddb04089700cf9c27f6f7426281'
            this.code = window.stockEnity.stockCode;
            this.name = window.stockEnity.stockName;
            this.market = window.stockEnity.stockMarket;
            this.newmarket = window.stockEnity.MktNum;
            this.stockId = window.stockEnity.stockId;
            this.gubaCode = window.stockEnity.gubaCode;
            this.debug = window.location.host !== "quote.eastmoney.com" || window.stockEnity.released;
        }
        if (window.location.href.indexOf("eastmoney.com") > 0) {
            document.domain = "eastmoney.com";
        }
        if (typeof baseStock.suggest === "undefined") {
            try {
                var suggest = baseStock.suggest = new suggest2017({
                    inputid: "search_box",
                    offset: { left: -91, top: 5 },
                    shownewtips: true,
                    newtipsoffset: { top: -3, left: 0 }
                });
            } catch (e) {
                console.error(e);
            }
        }
    }

    //新版行情源行情 zxw
    baseStock.prototype.loadnewHqData = function (url, type) {
        var loadData = {
            url: url,
            type: type || '',
            intital: function (fieldList) {
                var self = this;
                self.loadHqData(fieldList);
                setInterval(function () {
                    self.loadHqData(fieldList);
                }, 20000);
            },
            loadHqData: function (fieldList) {
                common.jsonPnew(this.url, function (json) {
                    var data = json.data;
                    var arr = []
                    if (type == 'B') {
                        arr.push(data.f43 == '-' ? '-' : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59))//0最新价
                        arr.push(data.f44 == '-' ? '-' : (data.f44 / Math.pow(10, data.f59)).toFixed(data.f59))//1最高价
                        arr.push(data.f45 == '-' ? '-' : (data.f45 / Math.pow(10, data.f59)).toFixed(data.f59))//2最低价
                        arr.push(data.f46 == '-' ? '-' : (data.f46 / Math.pow(10, data.f59)).toFixed(data.f59))//3开盘价
                        arr.push(data.f47 == '-' ? '-' : data.f47)//4成交量
                        arr.push(data.f48 == '-' ? '-' : data.f48)//5成交额(f48)
                        arr.push(data.f49 == '-' ? '-' : data.f49)//6外盘
                        arr.push(data.f55.toFixed(2))//7每股收益(f55) 
                        arr.push(data.f59)// 8小数位数(f59)
                        arr.push((data.f60 / Math.pow(10, data.f59)).toFixed(data.f59))//9昨收价(f60)
                        arr.push(data.f84)//10总股本(股)(f84)
                        arr.push(data.f92.toFixed(2))//11每股净资产(f92)
                        arr.push(data.f116)//12总市值(f116)
                        arr.push(data.f126)//13股息率(f126
                        arr.push(data.f152)//14小数位数字段(2)
                        arr.push(data.f161 == '-' ? '-' : data.f161)//15内盘(f161)
                        arr.push(data.f164 / Math.pow(10, data.f152))//16市盈率(TTM)(f164)
                        arr.push(data.f168 == '-' ? '-' : (data.f168 / 100))//17换手率(f168)
                        arr.push(data.f169 == '-' ? '-' : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))//18涨跌值(f169) 
                        arr.push(data.f170 == '-' ? '-' : data.f170 / 100)//19涨跌幅(f170) 
                        arr.push(data.f171 == '-' ? '-' : data.f171)//20振幅(f171)
                        arr.push(data.f167 == '-' ? '-' : data.f167 / Math.pow(10, data.f152))//21市净率(f167)
                        arr.push(data.f50 == '-' ? '-' : (data.f50 / Math.pow(10, data.f152)).toFixed(2))//22量比(f50)
                        arr.push(common.formatDate(new Date(data.f86 * 1000), 'yyyy-MM-dd HH:mm:ss'))//23行情时间Unix时间戳，单位秒(f86)
                        arr.push(data.f71 == '-' ? '-' : (data.f71 / Math.pow(10, data.f59)).toFixed(data.f59))//24均价(f71)
                        arr.push(data.f51 == '-' ? '-' : (data.f51 / Math.pow(10, data.f59)).toFixed(data.f59))//25涨停价
                        arr.push(data.f52 == '-' ? '-' : (data.f52 / Math.pow(10, data.f59)).toFixed(data.f59))//26跌停价
                        arr.push(data.f117)//27流通市值(f117)
                        arr.push(data.f191 == '-' ? '-' : (data.f191 / 100))//28委比
                        arr.push(data.f192)//29委差
                        arr.push(data.f162)//30市盈率(动态)
                        arr.push(data.f167)//31市净率

                        //行情时间
                        $("#stock_time").html("(" + common.formatDate(new Date(data.f86 * 1000), 'yyyy-MM-dd HH:mm:ss') + ")");
                    } else if (type == 'qq') {
                        arr.push(data.f43 == '-' ? '-' : (data.f43 / Math.pow(10, data.f59)).toFixed(1))//0最新价
                        arr.push(data.f44 == '-' ? '-' : (data.f44 / Math.pow(10, data.f59)).toFixed(1))//1最高价
                        arr.push(data.f45 == '-' ? '-' : (data.f45 / Math.pow(10, data.f59)).toFixed(1))//2最低价
                        arr.push(data.f46 == '-' ? '-' : (data.f46 / Math.pow(10, data.f59)).toFixed(1))//3开盘价
                        arr.push(data.f47 == '-' ? '-' : data.f47)//4成交量
                        arr.push(data.f48 == '-' ? '-' : data.f48)//5成交额(f48)
                        arr.push(data.f49 == '-' ? '-' : data.f49)//6外盘
                        arr.push(data.f59)// 7小数位数(f59)
                        arr.push((data.f60 / Math.pow(10, data.f59)).toFixed(1))//8昨收价(f60)
                        arr.push(data.f152)//9小数位数字段(2)
                        arr.push(data.f161 == '-' ? '-' : data.f161)//10内盘(f161)
                        arr.push(data.f169 == '-' ? '-' : (data.f169 / Math.pow(10, data.f59)).toFixed(1))//11涨跌值(f169) 
                        arr.push(data.f170 == '-' ? '-' : (data.f170 / 100).toFixed(2))//12涨跌幅(f170) 
                        arr.push(data.f171 == '-' ? '-' : (data.f171 / 100).toFixed(2))//13振幅(f171)
                        arr.push(data.f50 == '-' ? '-' : data.f50 / Math.pow(10, data.f152))//14量比(f50)
                        arr.push(common.formatDate(new Date(data.f86 * 1000), 'yyyy-MM-dd HH:mm:ss'))//15行情时间Unix时间戳，单位秒(f86)
                        arr.push(data.f19 == 0 ? '-' : (data.f19 / Math.pow(10, data.f59)).toFixed(1))//16买入价
                        arr.push(data.f39 == 0 ? '-' : (data.f39 / Math.pow(10, data.f59)).toFixed(1))//17卖出价
                        $("#stock_time").html("(" + common.formatDate(new Date(data.f86 * 1000), 'yyyy-MM-dd HH:mm:ss') + ")");
                    }
                    var stockData = []
                    for (var i = 0; i < arr.length; i++) {
                        stockData.push(arr[i] + '')
                    }
                    var zsjIndex, zdeIndex = 0;
                    //获取最新价和涨跌额的index
                    for (var i = 0; i < fieldList.length; i++) {
                        var item = fieldList[i];
                        if (item.name == "zsj") {
                            zsjIndex = item.num;
                        }
                        if (item.name == "zde") {
                            zdeIndex = item.num;
                        }
                    }
                    for (var i = 0; i < fieldList.length; i++) {
                        var field = fieldList[i];
                        var data = stockData[field.num];
                        //振幅和涨跌幅加百分比
                        if (field.name == "zf" || field.name == "zdf" || field.name == "hsl" || field.name == "wb" || field.name == "roe") {
                            //if (data > 10000) data = data.split('.')[0];
                            data = data === "-" ? "-" : data + "%";
                        } else if (field.name == "syl" || field.name == "sjl") {
                            data = data === "-" ? "-" : data / 100;
                        } else {
                            data = data === "-" ? "-" : data;
                        }
                        //开平
                        if (field.name == "kp") {
                            if (data == -1) {
                                data = "-";
                            } else if (data == 0) {
                                data = "双开";
                            } else if (data == 1) {
                                data = "双平";
                            } else if (data == 2) {
                                data = "多换";
                            } else if (data == 3) {
                                data = "多开";
                            } else if (data == 4) {
                                data = "多平";
                            } else if (data == 5) {
                                data = "空换";
                            } else if (data == 6) {
                                data = "空开";
                            } else if (data == 7) {
                                data = "空平";
                            }
                        }
                        //万百万缩写
                        if (field.NumbericFormat && data) {
                            data = data.NumbericFormat();
                        }
                        $("." + field.name).html(data);

                        if (field.hasColor) {
                            var zsj = stockData[zsjIndex];
                            $("." + field.name).removeClass("red").removeClass("green");
                            if (field.name == "wb" || field.name == "wc" || field.name == "rz" || field.name == "cc") {
                                $("." + field.name).addClass(common.getColor(data));
                            } else if (field.name != "zxj" && field.name != "zdf" && field.name != "zde") {
                                if (data > zsj) {
                                    $("." + field.name).addClass("red");
                                } else if (data < zsj) {
                                    $("." + field.name).addClass("green");
                                }
                            } else {
                                var zde = stockData[zdeIndex];
                                if (zde != 0 && zde != "-") {
                                    if (zde.isPositive()) {
                                        $("." + field.name).addClass("red");
                                        $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");
                                    } else {
                                        $("." + field.name).addClass("green");
                                        $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
                                    }
                                } else {
                                    $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
                                }
                            }
                        }
                    }


                    //涨跌平
                    var zdpList = stockData[25].split("|");
                    if ($(".pjs").length > 0) {
                        $(".zjs").html(zdpList[0]);
                        $(".pjs").html(zdpList[1]);
                        $(".djs").html(zdpList[2]);
                    }
                    //阶段涨跌幅
                    var jdzdfList = stockData[26].split("|");
                    if ($(".5day").length > 0) {
                        $(".5day").html(jdzdfList[0]);
                        jdzdfList[0].isPositive() ? $(".5day").addClass("red") : $(".5day").addClass("green");
                        $(".20day").html(jdzdfList[2]);
                        jdzdfList[2].isPositive() ? $(".20day").addClass("red") : $(".20day").addClass("green");
                        $(".60day").html(jdzdfList[3]);
                        jdzdfList[3].isPositive() ? $(".60day").addClass("red") : $(".60day").addClass("green");
                        $(".tillNow").html(jdzdfList[4]);
                        jdzdfList[4].isPositive() ? $(".tillNow").addClass("red") : $(".tillNow").addClass("green");
                    }
                });
            }
        }
        return loadData;
    }

    // 快速行情
    baseStock.prototype.loadHqData = function () {
        var loadData = {
            url: "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + this.stockId + "&sty=FDPBPFB&st=z&sr=&p=&ps=&cb=?&js=([[(x)]])&token=7bc05d0d4c3c22ef9fca8c2a912d779c",
            intital: function (fieldList) {
                var self = this;
                self.loadHqData(fieldList);
                setInterval(function () {
                    self.loadHqData(fieldList);
                }, 20000);
            },
            loadHqData: function (fieldList) {
                common.jsonP(this.url, function (json) {
                    if (json && json[0] && json[0][0].stats != false) {
                        var stockData = json[0][0].split(',');
                        var zsjIndex, zdeIndex = 0;
                        //获取最新价和涨跌额的index
                        for (var i = 0; i < fieldList.length; i++) {
                            var item = fieldList[i];
                            if (item.name == "zsj") {
                                zsjIndex = item.num;
                            }
                            if (item.name == "zde") {
                                zdeIndex = item.num;
                            }
                        }

                        for (var i = 0; i < fieldList.length; i++) {
                            var field = fieldList[i];

                            var data = stockData[field.num];
                            //振幅和涨跌幅加百分比
                            if (field.name == "zf" || field.name == "zdf" || field.name == "hsl" || field.name == "wb" || field.name == "roe") {
                                if (data > 10000) data = data.split('.')[0];
                                data = data === "-" ? "-" : data + "%";
                            } else {
                                data = data === "-" ? "-" : data;
                            }

                            //开平
                            if (field.name == "kp") {
                                if (data == -1) {
                                    data = "-";
                                } else if (data == 0) {
                                    data = "双开";
                                } else if (data == 1) {
                                    data = "双平";
                                } else if (data == 2) {
                                    data = "多换";
                                } else if (data == 3) {
                                    data = "多开";
                                } else if (data == 4) {
                                    data = "多平";
                                } else if (data == 5) {
                                    data = "空换";
                                } else if (data == 6) {
                                    data = "空开";
                                } else if (data == 7) {
                                    data = "空平";
                                }
                            }
                            //万百万缩写
                            if (field.NumbericFormat && data) {
                                data = data.NumbericFormat();
                            }
                            $("." + field.name).html(data);

                            if (field.hasColor) {
                                var zsj = stockData[zsjIndex];
                                $("." + field.name).removeClass("red").removeClass("green");
                                if (field.name == "wb" || field.name == "wc" || field.name == "rz" || field.name == "cc") {
                                    $("." + field.name).addClass(common.getColor(data));
                                } else if (field.name != "zxj" && field.name != "zdf" && field.name != "zde") {
                                    if (data > zsj) {
                                        $("." + field.name).addClass("red");
                                    } else if (data < zsj) {
                                        $("." + field.name).addClass("green");
                                    }
                                } else {
                                    var zde = stockData[zdeIndex];
                                    if (zde != 0 && zde != "-") {
                                        if (zde.isPositive()) {
                                            $("." + field.name).addClass("red");
                                            $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");
                                        } else {
                                            $("." + field.name).addClass("green");
                                            $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
                                        }
                                    } else {
                                        $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
                                    }
                                }
                            }
                        }

                        //行情时间
                        $("#stock_time").html("(" + stockData[3] + ")");

                        //涨跌平
                        var zdpList = stockData[25].split("|");

                        if ($(".pjs").length > 0) {
                            $(".zjs").html(zdpList[0]);
                            $(".pjs").html(zdpList[1]);
                            $(".djs").html(zdpList[2]);
                        }

                        //阶段涨跌幅
                        var jdzdfList = stockData[26].split("|");

                        if ($(".5day").length > 0) {
                            $(".5day").html(jdzdfList[0]);
                            jdzdfList[0].isPositive() ? $(".5day").addClass("red") : $(".5day").addClass("green");
                            $(".20day").html(jdzdfList[2]);
                            jdzdfList[2].isPositive() ? $(".20day").addClass("red") : $(".20day").addClass("green");
                            $(".60day").html(jdzdfList[3]);
                            jdzdfList[3].isPositive() ? $(".60day").addClass("red") : $(".60day").addClass("green");
                            $(".tillNow").html(jdzdfList[4]);
                            jdzdfList[4].isPositive() ? $(".tillNow").addClass("red") : $(".tillNow").addClass("green");

                        }
                    }
                });
            }
        }
        return loadData;
    }


    //加载排行模板新 zxw
    baseStock.prototype.loadRankTemplatenew = function (setting) {
        var url = setting.url
        var dom = setting.dom
        var link = setting.link
        common.jsonPnew(url, function (json) {
            var htm = "";
            var list = json.data.diff
            if (list instanceof Array) {
                for (var i = 0; i < list.length; i++) {
                    var price = list[i].f2 == '-' ? '-' : (list[i].f2).toFixed(list[i].f1)
                    var percent = list[i].f3 == '-' ? '-' : (list[i].f3.toFixed(2) + '%')
                    var color = list[i].f3 > 0 ? 'red' : list[i].f3 < 0 ? 'green' : ''
                    var link = setting.link.replace("{{code}}", list[i].f12)
                    if (link.indexOf('forex') > -1) {
                        link = link.replace("forex", list[i].f13 == 120 ? 'cnyrate' : 'forex')
                    }

                    var stockCode = list[i].f12;
                    if (stockCode == "399001" || stockCode == "000001" || stockCode == "000300" || stockCode == "399006" || stockCode == "399005") {
                        link = "//quote.eastmoney.com/zs" + stockCode + ".html";
                    }

                    htm += '<tr>'
                        + '<td><a href="' + link + '" title="' + list[i].f14 + '" target="_blank">' + list[i].f14.cutstr(10, "...") + '</a></td>'
                        + '<td class="' + color + '">' + price + '</td><td class="' + color + '">' + percent + '</td>'
                        + '</tr>'
                }
            } else {
                for (var i in list) {
                    var price = (list[i].f2 / Math.pow(10, list[i].f1)).toFixed(list[i].f1)
                    var percent = (list[i].f3 / Math.pow(10, list[i].f152)).toFixed(2) + '%'
                    var color = list[i].f3 > 0 ? "red" : list[i].f3 < 0 ? "green" : ""
                    var link = setting.link.replace("{{code}}", list[i].f12)
                    if (link.indexOf('forex') > -1) {
                        link = link.replace("forex", list[i].f13 == 120 ? 'cnyrate' : 'forex')
                    }

                    var stockCode = list[i].f12;
                    if (stockCode == "399001" || stockCode == "000001" || stockCode == "000300" || stockCode == "399006" || stockCode == "399005") {
                        link = "//quote.eastmoney.com/zs" + stockCode + ".html";
                    }

                    htm += '<tr>'
                        + '<td><a href="' + link + '" title="' + list[i].f14 + '" target="_blank">' + list[i].f14.cutstr(10, "...") + '</a></td>'
                        + '<td class="' + color + '">' + price + '</td><td class="' + color + '">' + percent + '</td>'
                        + '</tr>'
                }
            }
            $(dom).html(htm)

        })
    }

    /**
    * 加载排行模板
    * @param  {object} settings
    */
    baseStock.prototype.loadRankTemplate = function (settings) {
        var tpl = '{{each list as val idx}}<tr>'
            + '<td><a href="{{val.link}}" title="{{val.title || val.name}}" target="_blank">{{val.name}}</a></td>'
            + '<td class="{{val.color}}">{{val.close}}</td><td class="{{val.color}}">{{val.changePercent}}</td>'
            + '</tr>{{/each}}';
        var _this = this;
        var _default = {
            interval: 0,
            template: tpl,
            link: "//quote.eastmoney.com/web/r/{{code}}{{market}}",
            ajax: {
                url: "//nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx",
                type: "GET",
                data: {
                    type: "CT",
                    cmd: "",
                    sty: "E1II",
                    st: "(ChangePercent)",
                    sr: -1,
                    js: "([(x)])",
                    ps: 5,
                    token: "4f1862fc3b5e77c150a2b985b12db0fd"
                },
                dataType: "jsonp",
                jsonp: "cb"
            },
            dataResolver: function (json) {
                var context = new Object(),
                    models = [];
                if (json instanceof Array) {
                    for (var i = 0; i < json.length; i++) {
                        if (!isNaN(settings.count) && i >= settings.count) break;
                        var data = json[i];
                        if (typeof data !== "string") continue;
                        var items = data.split(',');
                        var _model = {
                            code: items[0],
                            market: items[1],
                            title: items[2],
                            name: common.cutstr(items[2], 10, "..."),
                            close: items[3],
                            changePercent: items[4],
                            color: items[4] === "0" || items[4] === "-" ? "" : items[4].isPositive() ? "red" : "green"
                        };
                        _model.link = template.render(_settings.link, _model);
                        models.push(_model);
                    }
                    context["list"] = models;
                }
                return context;
            }
        };
        if (settings.ajax) {
            settings.ajax.data = $.extend(_default.ajax.data, settings.ajax.data);
        }
        settings.ajax = $.extend(_default.ajax, settings.ajax);
        if (typeof settings.cmd === "string" && !settings.ajax.data.cmd)
            settings.ajax.data["cmd"] = settings.cmd;
        if (typeof settings.count === "number" && settings.count > 0)
            settings.ajax.data["ps"] = settings.count;
        if (typeof settings.callback === "string")
            settings.ajax["jsonpCallback"] = settings.callback;
        var _settings = $.extend(_default, settings);
        var $dom = $(_settings.dom);
        if ($dom.length === 0 && typeof _settings.dom === "string") {
            var _dom = document.getElementById(_settings.dom);
            if (_dom) $dom = $(_dom);
            else throw "dom not found";
        }
        _settings.ajax.success = function (json) {
            if (typeof settings.callback === "function") { settings.callback(json); }
            if (!json) return;
            var model, html;
            if (typeof _settings.dataResolver === "function") {
                model = _settings.dataResolver(json);
            }
            if (typeof _settings.callback === "function")
                _settings.callback($dom, model, _settings);
            if (typeof _settings.template === "string") {
                html = render(_settings.template, model);
            }
            else if (typeof _settings.template === "function") {
                var temp = _settings.template(context, _settings);
                html = render(temp, model);
            }
            if (html) $dom.html(html);
        };
        var render = function (tpl, model) {
            var _model = model || {};
            if (document.getElementById(tpl))
                return template(tpl, _model);
            else
                return template.render(tpl, _model);
        };
        var auto = $.dataAutoRefresh(_settings.ajax);
        if (_settings.interval > 0) {
            auto.intInterval = _settings.interval;
            auto.start();
        }
        else { auto.load(); }
        return auto;
    }

    /** 
    * 新版快速行情
    * @param {object} settings: 配置
    */
    baseStock.prototype.loadQuoteData = function (settings) {
        var _this = this;
        var _defualt = {
            ajax: {
                url: "//nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx",
                data: {
                    type: "CT",
                    cmd: _this.stockId,
                    sty: "FDPBPFB",
                    st: "z",
                    js: "((x))",
                    token: "4f1862fc3b5e77c150a2b985b12db0fd"
                },
                dataType: "jsonp"
            },
            interval: window.defaultInterval || 20 * 1000,
            fields: []
        };
        if (settings.ajax) {
            if (settings.ajax.data) {
                settings.ajax.data = $.extend(_defualt.ajax.data, settings.ajax.data);
            }
            settings.ajax = $.extend(_defualt.ajax, settings.ajax);
        }
        var _settings = $.extend(_defualt, settings);
        _settings.ajax.success = function (json) {
            if (!json) return;
            var data;
            if (typeof _settings.dataResolver === "function") {
                data = _settings.dataResolver(json);
            }
            else if (typeof (json) === "string") {
                data = json.split(',');
            }
            for (var i = 0; i < _settings.fields.length; i++) {
                var field = _settings.fields[i] ? _settings.fields[i] : {};
                var item = data[field.num || 0] + '',
                    //item = field.fixed?data[field.num || 0].toFixed(data[field.fixed]):item
                    $dom = $("." + field.name),
                    changed = false;
                if (typeof field.handler === 'function') {
                    item = field.handler.apply(_this, [item, field, _settings]);
                }
                if (!item || $dom.length == 0) continue;
                // 是否科学计数
                if (field.NumbericFormat) {
                    item = item.NumbericFormat();
                }
                // 枚举映射
                if (typeof (field.map) === "object" && field.map[item]) {
                    item = field.map[item];
                }
                // 呈现模板
                if (typeof field.template === "string") {
                    var model = new Object();
                    model[field.paramName || "data"] = item;
                    item = template.render(field.template, model);
                }
                changed = $dom.html() != item;
                //if (!changed) continue;
                $dom.html(item);
                // 颜色处理
                if (field.hasColor) {
                    var css = "", blink_model = 0;
                    $dom.removeClass("red").removeClass("green");
                    if (!isNaN(field.comparer)) {
                        css = field.comparer < 0 ? "green" : field.comparer > 0 ? "red" : "";
                        blink_model = field.comparer > 0 ? 1 : field.comparer < 0 ? -1 : 0;
                    }
                    else if (typeof field.comparer === "function") {
                        var c = field.comparer(data);
                        css = c < 0 ? "green" : c > 0 ? "red" : "";
                        blink_model = c > 0 ? 1 : c < 0 ? -1 : 0;
                    }
                    else {
                        css = common.getColor(item);
                        item = typeof item === "string" ? item : item.toString();
                        blink_model = item == "0" || item == "-" ? 0 : item.isPositive() ? 1 : -1;
                    }
                    $dom.addClass(css);
                    // 闪烁效果
                    if (field.blink && changed) {
                        if (blink_model === 1) {
                            $dom.textBlink({ color: ["#FFDDDD", "#FFEEEE", ""], blinktime: 150 });
                        }
                        else if (blink_model === -1) {
                            $dom.textBlink({ color: ["#b4f7af", "#ccffcc", ""], blinktime: 150 });
                        }
                    }
                }
                // 字段呈现回调
                if (typeof (field.render) === "function") {
                    field.render($dom, data[field.num || 0] + '', data, _settings);
                }
            }
        };
        var auto = $.dataAutoRefresh(_settings.ajax);
        auto.intInterval = _settings.interval;
        auto.start();
        return auto;
    }

    /** 
    * 新版个股新闻行情
    * @param {object} settings: 配置
    */
    baseStock.prototype.bindStockNews = function (settings) {
        var tpl = $("#tmp_news").html() || "{{if Status === 0 && Data.length>0}}"
            + "<ul class=\"article_list nlist\">"
            + "{{each Data as val idx}}<li>"
            + "<a href=\"{{val.Art_Url}}\" title=\"{{val.Art_Title}}\" target=\"_blank\" class=\"fl\">{{val.Art_Title | cutstr:42,'...'}}</a>"
            + "<i class=\"fr\">{{val.Art_ShowTime | formatDate:'MM-dd'}}</i>"
            + "</li>{{/each}}"
            + "</ul>{{else}}"
            + "<div class=\"nonslist\">暂无该股新闻</div>"
            + "{{/if}}";
        var _settings;
        var _default = {
            tpl: tpl,
            dom: $("#stocknews"),
            api: {
                url: "//searchapi.eastmoney.com/api/Info/Search?isAssociation20=True&highlights20=null&pageIndex20=1&pageSize20=5&returnFields20=Art_Title|0,Art_Url|0,Art_ShowTime&type=20&token=E5303D4106DC91E17D35009B8830D33D&sort20=Art_ShowTime|0",
                data: { and20: "multimatch/Art_Title,Art_Content/" + encodeURIComponent(stockEnity.stockName) + "/True" },
                dataType: "jsonp",
                jsonp: "cb",
                success: function (json) {
                    if (!json) json = { Status: -1 };
                    $(_settings.dom).html(template.render(_settings.tpl, json));
                }
            }
        };
        if (settings && settings.api) {
            settings.api = $.extend(_default.api, settings.api);
        }
        _settings = $.extend(_default, settings);
        if (settings) {
            if (typeof _settings.dom === "string") {
                var query = _settings.dom;
                _settings.dom = document.getElementById(query);
                if (!ele) _settings.dom = $(query);
            }
            if (typeof settings.callback === "function") {
                _default.api.success = settings.callback;
            }
            if (typeof settings.api.data !== "undefined") {
                $.extend(_default.api.data, settings.api.data);
            }
        }
        return $.ajax(_settings.api);
    }


    // 新行情五档，分时  zxw
    baseStock.prototype.loadDetailDatanew = function () {
        var base = this
        var url = base.baseUrl + "/api/qt/stock/get?secid=" + window.stockEnity.fullcode + "&ut=" + base.ut + "&fields=f531,f59,f60&invt=2"
        common.jsonPnew(url, function (json) {
            if (!json.data) return
            var data = json.data
            var zs = data.f60
            //$(".wb").text(data.f191 == '-' ? '-' : ((data.f191 / 100).toFixed(2) + '%')).addClass(data.f191 > 0 ? 'red' : data.f191 < 0 ? 'green' : '')
            //$(".wc").text(data.f192).addClass(data.f192 > 0 ? 'red' : data.f192 < 0 ? 'green' : '')
            var sellList = [
                {
                    label: '卖五',
                    price: data.f31,
                    volume: data.f32
                }, {
                    label: '卖四',
                    price: data.f33,
                    volume: data.f34
                }, {
                    label: '卖三',
                    price: data.f35,
                    volume: data.f36
                }, {
                    label: '卖二',
                    price: data.f37,
                    volume: data.f38
                }, {
                    label: '卖一',
                    price: data.f39,
                    volume: data.f40
                }
            ]
            var buyList = [
                {
                    label: '买一',
                    price: data.f19,
                    volume: data.f20
                }, {
                    label: '买二',
                    price: data.f17,
                    volume: data.f18
                }, {
                    label: '买三',
                    price: data.f15,
                    volume: data.f16
                }, {
                    label: '买四',
                    price: data.f13,
                    volume: data.f14
                }, {
                    label: '买五',
                    price: data.f11,
                    volume: data.f12
                }
            ]
            var html_sell = ''
            var html_buy = ''
            for (var i = 0; i < buyList.length; i++) {
                var color = buyList[i].price > zs ? 'red' : buyList[i].price < zs ? 'green' : ''
                var price = buyList[i].price == '-' ? '-' : ((buyList[i].price / Math.pow(10, data.f59)).toFixed(data.f59))
                html_buy += '<tr><td class="tac">' + buyList[i].label + '</td><td class="' + color + '">' + price + '</td><td class="td3">' + buyList[i].volume + '</td></tr>'
            }
            for (var i = 0; i < sellList.length; i++) {
                var color = sellList[i].price > zs ? 'red' : sellList[i].price < zs ? 'green' : ''
                var price = sellList[i].price == '-' ? '-' : ((sellList[i].price / Math.pow(10, data.f59)).toFixed(data.f59))
                html_sell += '<tr><td class="tac">' + sellList[i].label + '</td><td class="' + color + '">' + price + '</td><td class="td3">' + sellList[i].volume + '</td></tr>'
            }
            $("#sell_table tbody").html(html_sell);
            $("#buy_table tbody").html(html_buy);

        });
    }

    // 五档，分时
    baseStock.prototype.loadDetailData = function () {
        common.jsonP("http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + this.stockId + "&sty=FDTHTB&st=z&sr=&p=&ps=&cb=?&js=([(x)])&token=7bc05d0d4c3c22ef9fca8c2a912d779c", function (json) {
            if (json && json[0]) {
                var stockData = json[0].split(',');
                var html_sell = "<tbody>";
                var html_buy = "<tbody>";
                var html_deal = "<tbody>";
                var numList = ["一", "二", "三", "四", "五"];

                var zs = stockData[3];
                var color = "";
                for (var i = 10; i < 15; i++) {
                    if (stockData[24 - i] > zs) {
                        color = "red";
                    } else if (stockData[24 - i] < zs) {
                        color = "green";
                    }
                    html_sell += '<tr><td class="tac">卖' + numList[14 - i] + '</td><td class="' + color + '">' + stockData[24 - i] + '</td><td class="td3">' + stockData[34 - i] + '</td></tr>';
                }

                color = "";
                for (var j = 5; j < 10; j++) {
                    if (stockData[j] > zs) {
                        color = "red";
                    } else if (stockData[j] < zs) {
                        color = "green";
                    }
                    html_buy += '<tr><td class="tac">买' + numList[j - 5] + '</td><td class="' + color + '">' + stockData[j] + '</td><td class="td3">' + stockData[j + 10] + '</td></tr>';
                }

                var dealEntity = stockData[25];
                if (dealEntity && dealEntity != "-") {
                    var dealList = dealEntity.split("|");

                    var count = dealList.length >= 9 ? dealList.length - 9 : 0;

                    for (var k = dealList.length - 1; k >= count; k--) {
                        var itemList = dealList[k].split("~");
                        var arrow = itemList[3] == "-1" ? "↓" : itemList[3] == "1" ? "↑" : "";
                        var arrowColor = itemList[3] == "-1" ? "green" : itemList[3] == "1" ? "red" : "";
                        var dataColor = "";
                        if (stockData[3] < itemList[1]) {
                            dataColor = "red";
                        } else if (stockData[3] > itemList[1]) {
                            dataColor = "green";
                        }
                        html_deal += '<tr><td>' + itemList[0] + '</td><td class="' + dataColor + '">' + (itemList[1] || "-") + '</td>'
                            + '<td class="chjl ' + arrowColor + '">' + (itemList[2] || "-") + arrow + '</td></tr>';
                    }
                }
                else {
                    html_deal += "<tr><td>暂无数据</td></tr>";
                }

                html_sell += "</tbody>";
                html_buy += "</tbody>";
                html_deal += "</tbody>";

                $("#sell_table").html(html_sell);
                $("#buy_table").html(html_buy);
                $("#deal_table").html(html_deal);
            }
        });
    }

    // 行情图片事件绑定
    baseStock.prototype.bindChartImgEvent = function (options) {
        var self;
        var defualtUrls = {
            "url_r": "//webquotepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da",
            "url_k": "//webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da"
            //"url_k": (window.stockEnity.MktNum == '90' || window.stockEnity.MktNum == '105'|| window.stockEnity.MktNum == '106' || window.stockEnity.MktNum == '107') ? "//webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da" : "//pifm.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx?token=44c9d251add88e27b65ed86506f6e5da"
        };

        var _options = $.extend(defualtUrls, options);
        return {
            unitWidth: -6,
            stockId: this.stockId,
            bindEvent: function () {
                if (!self) self = this;
                $("#pictit span").click(function () {
                    $("#pictit span").removeClass("cur");
                    $(this).addClass("cur");
                    self.changeImg("k");
                });

                $("#zkeya li").click(function () {
                    $("#zkeya li").removeClass("at");
                    $(this).addClass("at");
                    self.changeImg("k");
                });

                $("#zkeyb li").click(function () {
                    $("#zkeyb li").removeClass("at");
                    $("#zkeyc li").removeClass("at");
                    $(this).addClass("at");
                    $("#zkeyc li[type=" + $(this).attr("type") + "]").addClass("at");
                    self.changeImg("k");
                });

                $("#zkeyc li").click(function () {
                    $("#zkeyb li").removeClass("at");
                    $("#zkeyc li").removeClass("at");
                    $(this).addClass("at");
                    $("#zkeyb li[type=\"" + $(this).attr("type") + "\"]").addClass("at");
                    self.changeImg("k");
                });

                $("#picklc").click(function () {
                    if (self.unitWidth <= -8) {
                        return;
                    }
                    self.unitWidth = self.unitWidth - 1;
                    self.changeImg("k");
                });

                $("#picksd").click(function () {
                    if (self.unitWidth >= 0) {
                        return;
                    }
                    self.unitWidth = self.unitWidth + 1;
                    self.changeImg("k");
                });

                //分时
                $("#actTab1 span").click(function () {
                    $("#actTab1 span").removeClass("cur");
                    $(this).addClass("cur");
                    self.changeImg("r");

                });
            },
            changeImg: function (type) {
                if (!self) self = this;
                if (typeof type === "string") {
                    switch (type) {
                        case "r":
                            var rtype = $("#actTab1 .cur").attr("type");
                            params = {
                                nid: stockEnity.UnifiedID ? stockEnity.UnifiedID : (stockEnity.MktNum + '.' + stockEnity.stockCode),
                                type: rtype === "M0" ? "" : rtype === "PQ" ? "" : rtype || "r",
                                imageType: rtype === "PQ" ? "rc" : (rtype === "M0" || !rtype) ? "rf" : "t"
                            }
                            //var params = {}
                            //if (window.stockEnity.MktNum == '90' || window.stockEnity.MktNum == '105' || window.stockEnity.MktNum == '106' || window.stockEnity.MktNum == '107') {
                            //    params = {
                            //        nid: stockEnity.UnifiedID ? stockEnity.UnifiedID : (stockEnity.MktNum + '.' + stockEnity.stockCode),
                            //        type: rtype === "M0" ? "" : rtype === "PQ" ? "" : rtype || "r",
                            //        imageType: rtype === "PQ" ? "rc" : (rtype === "M0" || !rtype) ? "rf" : "t"
                            //    }
                            //} else {
                            //    params = {
                            //        id: self.stockId,
                            //        type: rtype === "M0" ? "" : rtype === "PQ" ? "" : rtype || "r",
                            //        imageType: rtype === "PQ" ? "rc" : (rtype === "M0" || !rtype) ? "rf" : "t"
                            //    }

                            //}
                            loadimg("picr", 276, 578, _options.url_r, params, "//hqres.eastmoney.com/EMQuote_Lib/img/picrnotfund.gif");
                            break;
                        case "k":
                            // K图
                            params2 = {
                                nid: stockEnity.UnifiedID ? stockEnity.UnifiedID : (stockEnity.MktNum + '.' + stockEnity.stockCode),
                                type: $("#pictit .cur").attr("type"),
                                unitWidth: self.unitWidth,
                                ef: $("#zkeya .at").attr("type") ? $("#zkeya .at").attr("type") : "",
                                formula: $("#zkeyb .at").attr("type"),
                                imageType: "KXL"
                            }
                            //var params2 = {}
                            //if (window.stockEnity.MktNum == '90' || window.stockEnity.MktNum == '105' || window.stockEnity.MktNum == '106' || window.stockEnity.MktNum == '107') {
                            //    params2 = {
                            //        nid: stockEnity.UnifiedID ? stockEnity.UnifiedID : (stockEnity.MktNum + '.' + stockEnity.stockCode),
                            //        type: $("#pictit .cur").attr("type"),
                            //        unitWidth: self.unitWidth,
                            //        ef: $("#zkeya .at").attr("type") ? $("#zkeya .at").attr("type") : "",
                            //        formula: $("#zkeyb .at").attr("type"),
                            //        imageType: "KXL"
                            //    }
                            //} else {
                            //    params2 = {
                            //        id: self.stockId,
                            //        type: $("#pictit .cur").attr("type"),
                            //        unitWidth: self.unitWidth,
                            //        ef: $("#zkeya .at").attr("type") ? $("#zkeya .at").attr("type") : "",
                            //        formula: $("#zkeyb .at").attr("type"),
                            //        imageType: "KXL"
                            //    }

                            //}
                            loadimg("pick", 365, 520, _options.url_k, params2, "//hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif");
                            break;
                        default: break;
                    }
                }
                else {
                    self.changeImg("r");
                    self.changeImg("k");
                }

                function loadimg(container, height, width, url, data, errurl) {
                    var $container = $("#" + container);
                    if ($container.length === 0) return false;
                    $.imgLoader({
                        url: url,
                        data: data,
                        height: height,
                        width: width,
                        success: function (image) {
                            $container.html(image);
                        },
                        error: function (image) {
                            $container.html($(image).attr("src", errurl || "//hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif"));
                        }
                    });
                }
            }
        };
    }

    // 股市直播
    baseStock.prototype.stockBroadcast = function () {

        var stockBroadcast = {

            init: function () {
                var self = this;
                self.setNews();
                $("#kx_fontsize").click(function () {
                    if ($(".kx_list").hasClass("kx_fz14")) {
                        $(".kx_list").removeClass("kx_fz14");
                        $(this).html("大字+");
                    } else {
                        $(".kx_list").addClass("kx_fz14");
                        $(this).html("小字-");
                    }
                });
                $("#kx_refresh").off()
                $("#kx_refresh").click(function () {
                    self.setNews();
                });
            },
            setNews: function () {
                var url = "http://newsinfo.eastmoney.com/kuaixun/v2/api/list?column=zhiboall&limit=20";
                common.jsonP(url, function (json) {
                    if (json.rc == 1) {
                        //上方的直播
                        var random = parseInt(Math.random() * 20);
                        if (json.news[random]) {
                            var item = json.news[random];
                            $("#ScrollMIIRBox .dt").html(item.showtime);

                            $("#ScrollMIIRBox .t").html('<a href="' + item.url_unique + '" target="_blank">' + item.title + '</a>');
                        }

                        var html = "";
                        for (var i = 0; i < json.news.length; i++) {
                            var itemNews = json.news[i];
                            var time = itemNews.showtime.split(" ")[1];
                            html += '<li><span class="kx_itime">' + time + '</span>' +
                                '<span class="kx_itime_end">|</span>' +
                                '<span class="bd_i_txt">' +
                                '<a href="' + itemNews.url_unique + '" target="_blank">' +
                                itemNews.title + '&nbsp;[点击查看全文]</a></span></li>';
                        }

                        $("#stockBroadcast").html(html);
                    }
                }, null);
            }
        }
        return stockBroadcast;
    }

    // 热门股吧
    baseStock.prototype.setHotGuba = function (length) {
        var base = this
        //var url = $("#GetHotGuba").val();
        // var url = "http://quote.eastmoney.com/web/api/stockapi/GetHotGuba"
        // $.ajax({
        //     type: "GET",
        //     url: url,
        //     data: { count: length },
        //     dataType: "json",
        //     success: function (data) {
        //         if (data.success) {
        //             var codeList = data.data.join(",");
        //             var arr = []
        //             for (var i = 0; i < data.data.length; i++) {
        //                 var market = data.data[i].slice(6, 7)
        //                 var code = data.data[i].slice(0, 6)
        //                 arr.push((market == 1 ? 1 : 0) + '.' + code)
        //             }
        //             var codestr = arr.join(",")
        //             var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
        //             base.bindDataTemplatenew(url, "hotGuba", "guba");

        //         }
        //     }
        // });
        if(hotguba){
          var codeList = hotguba.join(",");
          var arr = []
          for (var i = 0; i < hotguba.length; i++) {
              var market = hotguba[i].slice(6, 7)
              var code = hotguba[i].slice(0, 6)
              arr.push((market == 1 ? 1 : 0) + '.' + code)
          }
          var codestr = arr.join(",")
          var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
          base.bindDataTemplatenew(url, "hotGuba", "guba");
        }
    }

    // JS行情图
    baseStock.prototype.setChart = function () {
        var _this = this
        var setChart = {
            init: function () {
                this.bindEvent();
                //
                if ($('#h5_show').is('.cur')) {
                    this.set();
                    _this.h5hasset = 1
                }
            },
            bindEvent: function () {
                var _that = this
                $("#image_show").click(function () {
                    $("#h5_show").removeClass("cur");
                    $(this).addClass("cur");
                    $("#img_container").show();
                    $("#h5_container").hide();
                });
                $("#h5_show").click(function () {
                    if(_this.h5hasset != 1){
                        
                        _that.set()
                        _this.h5hasset = 1
                    }

                    $("#image_show").removeClass("cur");
                    $(this).addClass("cur");
                    $("#img_container").hide();
                    $("#h5_container").show();
                });
            },
            set: function () {
                emChart.initial();
            }
        }
        return setChart;
    }

    //列表模板
    baseStock.prototype.bindDataTemplate = function (url, containerId, type) {
        var html = "";
        common.jsonPnew(url, function (json) {
            if (json.length == 0) {
                return;
            }

            if (type.indexOf("NO") >= 0) {
                html += '<tbody>';
            } else {
                html += '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>';
            }

            for (var i = 0; i < json.length; i++) {
                if (!json[i]) continue;
                var itemlist = json[i].split(",");
                var color = common.getColor(itemlist[4]);

                var stockCode = itemlist[1];
                var stockName = itemlist[2];

                if (common.getByteLen(stockName) > 12) {
                    //判断中英文
                    if (stockName.match(/[^\x00-\xff]/ig) != null) {
                        stockName = stockName.substring(0, 6) + "..";
                    } else {
                        stockName = stockName.substring(0, 12) + "..";
                    }
                }

                var stockUrl = "http://quote.eastmoney.com";

                if (type == "global") {
                    if (stockName == "上证指数" || stockName == "深证成指") {
                        stockUrl += "/zs" + stockCode + ".html";
                    } else if (stockName == "恒生指数") {
                        stockUrl += "/hk/zs110000.html";
                    } else {
                        stockUrl += "/gb/zs" + stockCode + ".html";
                    }
                }

                if (type == "AB" || type == "AB_NO") {
                    if (itemlist[1].indexOf("BK") >= 0) {
                        stockUrl += "/web/" + stockCode + "1.html";
                    } else if (itemlist[0] == "1") {
                        stockUrl += "/sh" + stockCode + ".html";
                    } else if (itemlist[0] == "2") {
                        stockUrl += "/sz" + stockCode + ".html";
                    }
                }

                if (type == "guba") {
                    stockUrl = "http://guba.eastmoney.com/list," + stockCode + ".html";
                    stockName += "吧";
                }

                if (type == "globalFuture") {
                    stockUrl += "/globalfuture/" + stockCode + ".html";
                }

                if (type == "forex") {
                    if (stockCode == "DINI") {
                        stockUrl += "/qihuo/dini.html";
                    } else {
                        stockUrl += "/forex/" + stockCode + ".html";
                    }
                }

                if (type == "hk") {
                    stockUrl += "/hk/" + stockCode + ".html";
                }

                if (type == "index" || type == "index_NO") {
                    stockUrl += "/zs" + stockCode + ".html";
                }

                if (type == "us") {
                    stockUrl += "/us/" + stockCode + ".html";
                }

                if (type == "xh") {
                    stockUrl = "";
                    //stockUrl += "/web/" + stockCode + "8.html";
                }

                if (type == "gzqh") {
                    stockUrl += "/gzqh/" + stockCode + ".html";
                }

                if (type == "future") {
                    //判断是否为股指期货
                    if (itemlist[0] == "_ITFFO") {
                        stockUrl += "/gzqh/" + stockCode + ".html";
                    } else {
                        stockUrl += "/qihuo/" + stockCode + ".html";
                    }
                }
                html += '<tr>'
                    + '<td>'
                    + (stockUrl ? ('<a href="' + stockUrl + '" target="_blank" title="' + itemlist[2] + '">' + stockName + '</a>') : stockName)
                    + '</td>'
                    + '<td class="' + color + '">' + itemlist[3] + '</td>'
                    + '<td class="' + color + '">' + itemlist[4] + '</td>'
                    + '</td></tr>';
            }
            html += "</tbody>";
            $("#" + containerId).html(html);
        });

    }

    //列表模板接新行情
    baseStock.prototype.bindDataTemplatenew = function (url, containerId, type) {
        var html = "";
        $.ajax({
            type: "GET",
            url: url,
            data: null,
            dataType: 'jsonp',
            jsonp: 'cb',
            success: function (res) {
                // console.info(url)
                // console.info(res)
                var data = res.data.diff;
                var json = []
                if (type == 'AB' || type == 'guba' || type == 'AB_NO' || type == 'future' || type == 'us' || type == 'globalFuture' || type == 'global') {
                    if (data instanceof Array) {
                        for (var i = 0; i < data.length; i++) {
                            var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)) + ',' + (data[i].f3 == '-' ? '-' : ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%'))
                            json.push(stritem)
                        }
                    } else {
                        for (var i in data) {
                            var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)) + ',' + (data[i].f3 == '-' ? '-' : ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%'))
                            json.push(stritem)
                        }
                    }
                } else if (type == 'ZDF') {
                    for (var i in data) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(2) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                } else if (type == 'hk') {
                    for (var i = 0; i < data.length; i++) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + ((data[i].f2 == '-' ? data[i].f2 : data[i].f2.toFixed(3)) + ',' + (data[i].f3 == '-' ? data[i].f3 : (data[i].f3).toFixed(data[i].f152) + '%'))
                        json.push(stritem)
                    }
                } else if (type == 'forex') {
                    for (var i = 0; i < data.length; i++) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                }
                if (type.indexOf("NO") >= 0) {
                    html += '<tbody>';
                } else {
                    html += '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>';
                }
                for (var i = 0; i < json.length; i++) {
                    var itemlist = json[i].split(",");
                    var color = common.getColor(itemlist[4]);
                    var stockCode = itemlist[1];
                    var stockName = itemlist[2];
                    if (common.getByteLen(stockName) > 12) {
                        //判断中英文
                        if (stockName.match(/[^\x00-\xff]/ig) != null) {
                            stockName = stockName.substring(0, 6) + "..";
                        } else {
                            stockName = stockName.substring(0, 12) + "..";
                        }
                    }

                    var stockUrl = "http://quote.eastmoney.com";
                    if (type == "AB" || type == "AB_NO") {
                        if (itemlist[1].indexOf("BK") >= 0) {
                            stockUrl += "/web/" + stockCode + "1.html";
                        } else if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    } else if (type == "guba") {
                        stockUrl = "http://guba.eastmoney.com/list," + stockCode + ".html";
                        stockName += "吧";
                    } else if (type == "ZDF") {
                        if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    } else if (type == "future") {
                        if (itemlist[0] == 8) {
                            var gzname = stockName.replace("连续", "");
                            var gzcode = gzname.replace("当月", "DYLX").replace("下月", "XYLX").replace("当季", "GZDJLX");
                            if (gzname.indexOf('IF') < 0) { gzcode = gzcode.replace("LX", ""); }
                            stockUrl = "http://quote.eastmoney.com/gzqh/" + gzcode + ".html";
                        } else {
                            stockUrl = "http://quote.eastmoney.com/qihuo/" + stockCode + ".html";
                        }
                    } else if (type == "us") {
                        stockUrl = "http://quote.eastmoney.com/us/" + stockCode + ".html";
                    } else if (type == "hk") {
                        stockUrl = "http://quote.eastmoney.com/hk/" + stockCode + ".html";
                    } else if (type == "forex") {
                        if (itemlist[0] == 100) {
                            stockUrl = "http://quote.eastmoney.com/globalfuture/" + stockCode + ".html";
                        } else {
                            stockUrl = "http://quote.eastmoney.com/forex/" + stockCode + ".html";
                        }
                    } else if (type == "globalFuture") {
                        stockUrl = "http://quote.eastmoney.com/globalfuture/" + stockCode + ".html";
                    } else if (type == "global") {
                        if (itemlist[0] == 0 || itemlist[0] == 1) {
                            stockUrl = "http://quote.eastmoney.com/zs" + stockCode + ".html";
                        } else {
                            stockUrl = "http://quote.eastmoney.com/gb/zs" + stockCode + ".html";
                        }
                    }
                    html += '<tr>'
                        + '<td>'
                        + (stockUrl ? ('<a href="' + stockUrl + '" target="_blank" title="' + itemlist[2] + '">' + stockName + '</a>') : stockName)
                        + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[3]) + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[4]) + '</td>'
                        + '</td></tr>';
                }

                html += "</tbody>";
                $("#" + containerId).html(html);

            }
        });
    }

    // 获取文章列表
    baseStock.prototype.getArticle = function (articleNum, containerId) {
        var url = $("#GetArticle").val();
        $.ajax({
            type: "GET",
            url: url,
            data: {
                articleNum: articleNum
            },
            dataType: "json",
            success: function (data) {
                if (data && data.success) {
                    if (data.data.length >= 5) {
                        var html = "";
                        for (var i = 0; i < data.data.length; i++) {
                            var item = data.data[i];
                            html += '<li class="clearfix">' +
                                '<a href="' + item.url + '" target="_blank" class="fl">' + item.title + '</a>' +
                                '<i class="fr">' + item.date + '</i></li>';
                        }
                        $("#" + containerId).html(html);
                    }
                }
            }
        });
    }

    //自选股
    baseStock.prototype.getFavouriteStock = function (num) {
        var count = num || 5;
        var base = this;
        var pi = common.getCookie("pi");
        var initlist = "300059,000016,000017,300268,000001,000002,000005,000006,000008";
        var emhq_stock = common.getCookie("emhq_stock");
        if (emhq_stock) {
            initlist = emhq_stock;
        }
        var itemlist = initlist.split(",");
        var stockList = new Array();
        for (var i = 0; i < itemlist.length; i++) {
            stockList.push(itemlist[i] + common.getMarketCode(itemlist[i]));
        }
        if (pi) {
            if (pi.split(';').length >= 3) {
                var name = pi.split(';')[2];
                if (!/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) {
                    $.getScript("https://myfavor.eastmoney.com/mystock?f=gsaandcheck&sc=" + base.code + "|0" + base.market + "|01&c=" + count + "&var=favorStock", function () {
                        var allstocklist = [];
                        if (favorStock.result == "1") {
                            var sl = favorStock.data.list.split(',');
                            for (var i = 0; i < sl.length; i++) {
                                var item = sl[i].split('|');
                                var stockId = item[0] + common.getMarketCode(item[0]);
                                allstocklist.push(stockId);
                            }
                            allstocklist = allstocklist.concat(stockList).unique().slice(0, count);
                            var url = "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + allstocklist.join(',') + "&sty=MPNSBAS&st=z&p=1&ps=" + count + "&cb=?&js=([(x)])&token=7bc05d0d4c3c22ef9fca8c2a912d779c";
                            base.bindDataTemplate(url, "favorTable", "AB");
                        }
                    });
                }
            }
        } else {
            var url = "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + stockList.join(",") + "&sty=MPNSBAS&st=c&sr=-1&p=1&ps=" + count + "&cb=?&js=([(x)])&token=7bc05d0d4c3c22ef9fca8c2a912d779c";
            base.bindDataTemplate(url, "favorTable", "AB");
        }
    }


    //自选股 接新行情 zxw
    baseStock.prototype.getFavouriteStocknew = function (num) {
        var count = num || 5;
        var base = this;
        var pi = common.getCookie("pi");
        var initlist = "0.300059,0.000016,0.000017,0.300268,0.000001,0.000002,0.000005,0.000006,0.000008";
        var emhq_stock = common.getCookie("emhq_stock");
        if (emhq_stock) {
            initlist = emhq_stock;
        }
        var itemlist = initlist.split(",");
        var stockList = new Array();
        for (var i = 0; i < itemlist.length; i++) {
            stockList.push(itemlist[i]);
        }
        if (pi) {
            if (pi.split(';').length >= 3) {
                var name = pi.split(';')[2];
                if (!/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) {
                    $.getScript("https://myfavor.eastmoney.com/mystock?f=gsaandcheck&sc=" + base.code + "|0" + base.market + "|01&c=" + count + "&var=favorStock", function () {
                        var allstocklist = [];
                        if (favorStock.result == "1") {
                            var sl = favorStock.data.list.split(',');
                            for (var i = 0; i < sl.length; i++) {
                                var item = sl[i].split('|');
                                var stockId = (common.getMarketCode(item[0]) == 2 ? 0 : common.getMarketCode(item[0])) + '.' + item[0]
                                allstocklist.push(stockId);
                            }
                            allstocklist = allstocklist.concat(stockList).unique().slice(0, count);
                            var codestr = allstocklist.join(",")
                            var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
                            base.bindDataTemplatenew(url, "favorTable", "AB");

                        }
                    });
                }
            }
        } else {
            var codestr = stockList.slice(0, count).join(",")
            var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
            base.bindDataTemplatenew(url, "favorTable", "AB");
        }
    }

    module.exports = baseStock
    // return baseStock;
// });



/***/ }),

/***/ "./src/modules/old_b/common.js":
/*!*************************************!*\
  !*** ./src/modules/old_b/common.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// define(["jQuery", "template"], function ($, template) {
  var template = __webpack_require__(/*! ./template */ "./src/modules/old_b/template.js")

    var common = {
        //文字闪动
        setFlash: function (obj, cls1, cls2) {
            setTimeout(function () { common.setClass(obj, cls1) }, 800);
            setTimeout(function () { common.setClass(obj, cls2) }, 1000);
            setTimeout(function () { common.setClass(obj, cls1) }, 1200);
            setTimeout(function () { common.setClass(obj, cls2) }, 1400);
        },
        //获取季度中文
        getJiduByDate: function (date) {
            var jidu = "";
            var m = date.split('-')[1];
            switch (m) {
                case "03":
                    jidu = "(一)";
                    break;
                case "06":
                    jidu = "(二)";
                    break;
                case "09":
                    jidu = "(三)";
                    break;
                case "12":
                    jidu = "(四)";
                    break;
            }
            return jidu;
        },
        //触发element的eventName事件
        trigger: function (element, eventName) {
            if (typeof element == "undefined" || element == null) return;
            if (document.all) {
                element[eventName]();
            } else {
                var evt = document.createEvent("MouseEvents");
                evt.initEvent(eventName, true, true);
                element.dispatchEvent(evt);
            }
        },
        //Cookie Common Class
        getCookie: function (key) {
            var result = document.cookie.match(new RegExp("(^| )" + key + "=([^;]*)"));
            return result != null ? unescape(decodeURI(result[2])) : null;
        },
        //写cookies
        setCookie: function (name, value, hours) {
            var expire = "";
            if (typeof hours === "number") {
                expire = new Date((new Date()).getTime() + hours * 3600000);
                expire = "; expires=" + expire.toGMTString() + ";";
            }
            expire += "; path=/;domain=.eastmoney.com;";
            document.cookie = name + "=" + escape(value) + expire;
        },
        //通过cookie:pi获取uid
        getUid: function () {
            var webPi = common.getCookie("pi");
            if (webPi && webPi.split(';').length >= 3) {
                var uid = webPi.split(';')[0];
                if (uid.length == 16) {
                    return uid;
                }
            }
            return "";
        },
        //根据股票代码获取市场
        getMarketCode: function (sc) {
            var i = sc.substring(0, 1);
            var j = sc.substring(0, 3);
            if (i == "5" || i == "6" || i == "9") {
                return "1"; //上证股票
            } else {
                if (j == "009" || j == "126" || j == "110") {
                    return "1"; //上证股票
                } else {
                    return "2"; //深圳股票
                }
            }
        },
        getStatusDescription: function (stat) {
            switch (stat) {
                case "-2": return "已收盘";
                case "-1": return "停牌";
                case "0": return "交易中";
                case "1": return "已收盘";
                case "2": return "午间休市";
                case "3": return "已休市";
                case "4": return "未开盘";
                case "5": return "已收盘";
                case "6": return "已收盘";
                case "7": return "已收盘";
                case "8": return "暂停交易";
                case "9": return "暂停交易";
                case "10": return "暂停交易";
                case "11": return "暂停交易";
                case "12": return "未上市";
                default: return "";
            }
        },
        jsonP: function (url, successMethod, errorMethod) {
            $.ajax({
                url: url,
                async: true,
                dataType: "jsonp",
                success: successMethod,
                error: errorMethod
            });
        },
        jsonPnew: function (url, successMethod, errorMethod) {
            $.ajax({
                url: url,
                async: true,
                dataType: "jsonp",
                jsonp: 'cb',
                success: successMethod,
                error: errorMethod
            });
        },
        getQueryString: function (name) {
            var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
            var r = window.location.search.substr(1).match(reg);
            if (r != null) {
                return unescape(r[2]);
            }
            return null;
        },
        formatDate: function (date, fmt) {
            // return date
            if (typeof date === "string"){
                //date = new Date(date.replace(/-/g, '/').replace('T', ' ').split('+')[0]);
                date = new Date(date.substring(0,19).replace(/-/g, '/').replace('T', ' '));                
            }

            var o = {
                "M+": date.getMonth() + 1, //月份         
                "d+": date.getDate(), //日         
                "h+": date.getHours() % 12 == 0 ? 12 : date.getHours() % 12, //小时         
                "H+": date.getHours(), //小时         
                "m+": date.getMinutes(), //分         
                "s+": date.getSeconds(), //秒         
                "q+": Math.floor((date.getMonth() + 3) / 3), //季度         
                "S": date.getMilliseconds() //毫秒         
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[date.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        },
        getByteLen: function (str) {
            var len = 0;
            for (var i = 0; i < str.length; i++) {
                var regNum = new RegExp("[^\x00-\xff]");
                if (regNum.test(str[i])) {
                    len += 2;
                } else {
                    len += 1;
                };
            }
            return len;
        },
        getColor: function (str) {
            var context = str.toString();
            context = context.replace("%", "");
            if (context == 0 || isNaN(context)) {
                return "";
            } else if (context > 0) {
                return "red";
            } else {
                return "green";
            }
        },
        cutString: function (str, len) {
            var content = str.toString();
            if (content.length > len) {
                return content.substring(0, len) + "...";
            } else {
                return str;
            }
        },
        /** 
         * js截取字符串，中英文都能用 
         * @param {string} str: 需要截取的字符串 
         * @param {number} len: 需要截取的长度
         * @param {string} ellipsis: 溢出文字
         * @returns {string}
         */
        cutstr: function (str, len, ellipsis) {
            if (typeof ellipsis != "string") ellipsis = "...";
            var str_length = 0;
            var str_len = 0;
            str_cut = new String();
            for (var i = 0; i < str.length; i++) {
                a = str.charAt(i);
                str_length++;
                if (escape(a).length > 4) {
                    //中文字符的长度经编码之后大于4  
                    str_length++;
                }
                //str_cut = str_cut.concat(a);
                if (str_length <= len) {
                    str_len++;
                }
            }
            //如果给定字符串小于指定长度，则返回源字符串；  
            if (str_length <= len) {
                return str.toString();
            }
            else {
                return str.substr(0, str_len).concat(ellipsis);
            }
        },
        /**
         * 秒表计时器模块
         * @param {any} options: 设置
         * @param {number} seconds: 秒针
         */
        timer: function (options, seconds) {
            var _this = this;
            seconds = seconds || 60;
            if (!options || !options.dom) return;
            var default_options = {
                counter: 60,
                interval: 1000
            };
            var _options = $.extend(options, default_options);
            var $dom = _options.dom, _interval = isNaN(_options.interval) ? 1000 : _options.interval;
            if (typeof _options.dom === "string") {
                var dom = _options.dom;
                if ($(dom).length == 0) return;
                $dom = $(dom);
            }
            var timerId = -1, paused = false, counter = seconds;
            function handler() {
                if (!paused) {
                    $dom.html(counter);
                }
                if (--counter > 0) {
                    timerId = setTimeout(handler, _interval);
                }
                else if (typeof options.callback === "function") {
                    _options.callback(_options.args);
                }
            }
            function pause() { paused = true; }
            function resume() { paused = false; }
            function start() {
                handler();
            }
            function stop() {
                if (timerId != -1) clearTimeout(timerId);
                timerId = -1;
                counter = _options.counter;
            }
            return {
                start: start, stop: stop, reset: function () {
                    stop(), start();
                },
                pause: function () { paused = true; },
                resume: function () { paused = false; }
            };
        },
        /** 
         * js分页功能
         * var pagenav = new PageNavigation("container", 6);
	     * pagenav.onchange = function(i){ alert(i) }
	     * pagenav.nav(1)
         * pagenav.render();
         * @param {string} container: 分页容器
         * @param {number} pagecount: 页数
         */
        pageNavigation: function (container, pagecount) {
            var get = function (id) {
                return $("#" + container + " " + id);
            };
            var _this = this;
            _this.container = document.getElementById(container);
            if (!_this.container) throw "Untouchable container";
            _this.nextpage = get("nextpage");
            _this.prepage = get("prepage");
            _this.pagecount = pagecount || 0;
            _this.container.onclick = function (event) {
                event = event || window.event;
                var target = event.target || event.srcElement;
                var page = target.getAttribute("data-page");
                var controlid = target.getAttribute("data-get");
                var property = target.getAttribute("data-property");

                if (controlid && property) {//转到

                    page = get(controlid).attr(property);
                }

                if (page !== null && !isNaN(page)) {
                    _this.change(page);
                }
            };
            //根据UI 设置config
            _this.config = {
                itemscount: 5,
                disable: "<span>{$text}</span>",
                nextpage: " <a class=\"nextpage\" href=\"javascript:void(null)\"  data-page='{$nextpage}'>下一页</a> ",
                prepage: " <a class=\"prepage\" href=\"javascript:void(null)\" data-page='{$prepage}'>上一页</a> ",
                pageitem: " <a href=\"javascript:void(null)\" data-page='{$num}'>{$num}</a> ",
                current: " <span class='current'>{$num}</span> ",
                firstpage: "<a data-page='1'>1</a><span class='page-break'>...</span>",
                lastpage: "<span class='page-break'>...</span><a data-page='{$pagecount}'>{$pagecount}</a>",
                gopage: '转到<input type="text" value="{$num}" name="pageNum" class="pagenum"/>页 ' +
                    '<input type="button" data-get=".pagenum" data-property="value" class="go-btn" value="Go"/>'
            };
            _this.change = function (num) {
                var _this = this;
                if (!isNaN(num)) {
                    _this.listitems = [];
                    _this.nav(parseInt(num));
                    _this.render();
                }
                _this.onchange(num);
                _this.pageChange(num);
            };
            _this.reset = function () {
                this.listitems = [];
                this.prepage = false;
                this.firstpage = false;
                this.nextpage = false;
                this.lastpage = false;
            };
            //回调函数
            _this.onchange = new Function();
            _this.pageChange = new Function();
            //分页逻辑
            _this.nav = function (n) {
                var startpagenum = 1, endpagenum = this.pagecount, length = (this.config.itemscount - 1) / 2;
                this.reset();
                if (isNaN(n)) { n = 1; }
                if (n < 1) n = 1;
                if (n > this.pagecount) n = this.pagecount;
                if (n !== 1) {
                    this.prepage = this.config.prepage;
                    if (n - length > 1) {
                        startpagenum = n - length;
                        this.firstpage = this.config.firstpage;
                        if (n == 4) {
                            this.firstpage = this.firstpage.replace("...", "");
                        }
                    }

                    for (var i = startpagenum; i < n; i++) {
                        this.listitems.push(this.createPageItem(i));
                    }
                }
                this.listitems.push(this.createCurrentItem(n));
                if (n !== this.pagecount) {
                    this.nextpage = this.config.nextpage;
                    length = this.config.itemscount - this.listitems.length;
                    if (n + length < this.pagecount) {
                        endpagenum = n + length;
                        this.lastpage = this.config.lastpage;
                        if (this.pagecount - n == 3) {
                            this.lastpage = this.lastpage.replace("...", "");
                        }
                    }

                    for (var i = n + 1; i <= endpagenum; i++) {
                        this.listitems.push(this.createPageItem(i));
                    }
                }
                this.page = n;
            };
            _this.render = function () {

                var listitems = this.listitems.join("");
                var nextpage = this.nextpage;
                var prepage = this.prepage;
                var gopage = this.config.gopage;

                var html = [];
                if (!prepage) {
                    prepage = this.config.disable.replace(/\{\$text\}/g, "上一页");
                }
                html.push(prepage.replace(/\{\$prepage\}/g, this.page - 1));

                if (this.firstpage) {
                    html.push(this.firstpage);
                }

                html.push(listitems);

                if (this.lastpage) {
                    html.push(this.lastpage.replace(/\{\$pagecount\}/g, this.pagecount));
                }

                if (!nextpage) {
                    nextpage = this.config.disable.replace(/\{\$text\}/g, "下一页");
                }

                html.push(nextpage.replace(/\{\$nextpage\}/g, this.page + 1));

                html.push(gopage.replace(/\{\$num\}/g, this.page));

                if (this.container) {
                    this.container.innerHTML = html.join("");
                }
                return html.join("");

            };
            _this.createPageItem = function (i) {
                return this.config.pageitem.replace(/\{\$num\}/g, i);
            };
            _this.createCurrentItem = function (i) {
                return this.config.current.replace(/\{\$num\}/g, i);
            };
        }
    }

    String.prototype.cutstr = function (len) {
        return common.cutstr(this, len);
    }

    String.prototype.isPositive = function () {
        var context = this;
        if (typeof (context).toLowerCase() === "string") {
            context = context.replace("%", "");
            var regNum = new RegExp("^([\\-\\+]?\\d+(\\.\\d+)?)$");
            if (regNum.test(context)) {
                var reg = new RegExp("^-");
                return !reg.test(context);
            } else return Number.NaN;
        }
    }

    String.prototype.NumbericFormat = function (fixed) {
        var context = this;
        //var fushu = false;
        fixed = typeof fixed === "number" && fixed >= 0 ? fixed : NaN;
        if (!isNaN(context)) {
            var item = parseInt(this);
            if ((item > 0 && item < 1e4) || (item < 0 && item > -1e4)) {
                return item;
            } else if ((item > 0 && item < 1e6) || (item < 0 && item > -1e6)) {
                item = item / 10000;
                return item.toFixed(fixed || 2) + "万";
            } else if ((item > 0 && item < 1e7) || (item < 0 && item > -1e7)) {
                item = item / 10000;
                return item.toFixed(fixed || 1) + "万";
            } else if ((item > 0 && item < 1e8) || (item < 0 && item > -1e8)) {
                item = item / 10000;
                return item.toFixed(fixed || 0) + "万";
            } else if ((item > 0 && item < 1e10) || (item < 0 && item > -1e10)) {
                item = item / 1e8;
                return item.toFixed(fixed || 2) + "亿";
            } else if ((item > 0 && item < 1e11) || (item < 0 && item > -1e11)) {
                item = item / 1e8;
                return item.toFixed(fixed || 1) + "亿";
            } else if ((item > 0 && item < 1e12) || (item < 0 && item > -1e12)) {
                item = item / 1e8;
                return item.toFixed(fixed || 0) + "亿";
            } else if ((item > 0 && item < 1e14) || (item < 0 && item > -1e14)) {
                item = item / 1e12;
                return item.toFixed(fixed || 1) + "万亿";
            } else if ((item > 0 && item < 1e16) || (item < 0 && item > -1e16)) {
                item = item / 1e12;
                return item.toFixed(fixed || 0) + "万亿";
            } else {
                return item;
            }
        }
        else {
            return '-';
        }
        //return context.toString();
    }
    if (!Array.prototype.indexOf) {
        // 兼容低版本浏览器扩展indexOf
        Array.prototype.indexOf = function (elt /*, from*/) {
            var len = this.length >>> 0;
            var from = Number(arguments[1]) || 0;
            from = (from < 0) ?
                Math.ceil(from) :
                Math.floor(from);
            if (from < 0)
                from += len;
            for (; from < len; from++) {
                if (from in this &&
                    this[from] === elt)
                    return from;
            }
            return -1;
        };
    }
    Array.prototype.unique = function () {
        var res = [];
        var json = {};
        for (var i = 0; i < this.length; i++) {
            if (!json[this[i]]) {
                res.push(this[i]);
                json[this[i]] = 1;
            }
        }
        return res;
    }
    // 截断字符
    template.helper("cutstr", function (str, len, ellipsis) {
        return common.cutstr(str, len, ellipsis);
    });
    // 日期格式化
    template.helper("formatDate", function (date, fmt) {
        if (typeof date === "string") {
            date = new Date(date.substring(0,19).replace(/-/g, '/').replace('T', ' '))
        }
        return common.formatDate(date, fmt);
    });
    // 获取市场代码
    template.helper("getShortMarket", function (str) {
        switch (str) {
            case "1": return "sh";
            case "2": return "sz";
            default: return "sz";
        }
    });

    // jquery扩展
    $.extend({
        // 定时数据获取扩展
        dataAutoRefresh: function (settings) {
            var _init = false, _intInterval = !window["defaultInterval"] ? 1000 * 20 : window.defaultInterval, _intThread = -1;
            if (!settings["dataType"]) settings["dataType"] = "json";
            return {
                init: _init,
                intInterval: _intInterval,
                intThread: _intThread,
                load: function () {
                    this.init = true;
                    if (typeof (settings) !== "object" || !settings)
                        return false;
                    if (settings.dataType.toLowerCase() === "img") {
                        $.imgLoader(settings);
                    }
                    else {
                        var _timeout = 5000;
                        settings["timeout"] = !settings.timeout ? _timeout : settings["timeout"];
                        if (!!settings.dataType && settings.dataType.toLowerCase() === "jsonp") {
                            settings["type"] = "GET";
                            settings["jsonp"] = !settings.jsonp ? "cb" : settings.jsonp;
                        }
                        $.ajax(settings);
                    }
                },
                start: function () {
                    this.stop();
                    this.load();
                    this.intThread = setInterval(this.load, this.intInterval);
                },
                stop: function () {
                    if (this.intThread !== -1) {
                        clearInterval(this.intThread);
                    }
                    this.intThread = -1;
                }
            }
        },
        //异步动态图片加载
        imgLoader: function (setting) {
            if (typeof (setting) !== "object" || !setting["url"]) return false;
            var fCallback = typeof (setting["success"]) === "function" ? setting["success"] : null;
            var _url = setting["url"];
            if (setting["data"]) {
                var _data = $.param(setting["data"]);
                _url = _url.indexOf("?") > 0 ? _url + "&" + _data : _url + "?" + _data;
            }
            if (!setting["cache"]) {
                _url += _url.indexOf("?") > 0 ? "&_=" + (+new Date()) : "?_=" + (+new Date());
            }
            var _image = document.createElement("img");
            if (typeof (setting["height"]) === "number" && setting["height"] > 0) {
                _image.setAttribute("height", setting["height"] + "px");
            }
            if (typeof (setting["width"]) === "number" && setting["width"] > 0) {
                _image.setAttribute("width", setting["width"] + "px");
            }
            _image.setAttribute('src', _url);
            if (typeof (setting["error"]) === "function")
                $(_image).error(function () { setting["error"](_image); });
            _image.onload = _image.onreadystatechange = function (evt) {
                if (!_image.readyState || /loaded|complete/.test(_image.readyState)) {
                    // Handle memory leak in IE
                    _image.onload = _image.onreadystatechange = null;
                    // Callback if not abort
                    if (fCallback) fCallback(_image);
                }
            };
        }
    });

    $.fn.extend({
        //让文字闪烁起来
        textBlink: function (options) {
            var defaults = {
                color: ["#fff", "#ffe2d1", "#ffc2a1", "#ffa370", "#ff8340", "#ff630f"], //轮番颜色 默认橙色
                blinktime: 60, //每帧时间 毫秒
                circle: 2 //闪烁次数
            }
            var _options = jQuery.extend(defaults, options);
            var loop = 0; var instance = this;
            for (var i = 0; i < _options.color.length * _options.circle; i++) {
                setTimeout(function () {
                    jQuery(instance).css("background-color", _options.color[loop]);
                    loop++;
                    loop = loop % _options.color.length;
                }, _options.blinktime * i);
            }
        }
    });

    module.exports = common
    // return common;
// });



/***/ }),

/***/ "./src/modules/old_b/emchart.js":
/*!**************************************!*\
  !*** ./src/modules/old_b/emchart.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// define(["jQuery", "chartLib"], function () {

    var emChart = {
        initial: function () {
            emChart.bindJs();
            emChart.bindK();
            setInterval(function () {
                emChart.bindJs();
            }, 20 * 1000);
        },
        bindK: function (parameters) {
            var timer,
            kchart = new emcharts3.k2({
                container: "#emchartk",
                width: 585,
                height: 390,
                padding: {
                    top: 0,
                    bottom: 0
                },
                scale: {
                    pillar: 60,
                    min: 10
                },
                popWin: { type: "move" },
                maxin: {
                    //show: true,
                    lineWidth: 30,     // 线长
                    skewx: 0,            // x偏移   
                    skewy: 0            // y偏移
                },
                onComplete: function () {
                },
                onClick: function () {
                    var val = $("#changektab span.cur").attr("value"), type = 'k';
                    switch (val) {
                        case "D":
                            type = "k";
                            break;
                        case "W":
                            type = "wk";
                            break;
                        case "M":
                            type = "mk";
                            break;
                        case "M5":
                            type = "m5k";
                            break;
                        case "M15":
                            type = "m15k";
                            break;
                        case "M30":
                            type = "m30k";
                            break;
                        case "M60":
                            type = "m60k";
                            break;
                        default: break;
                    }
                    window.open(window.location + "#fullScreenChart", "_blank")
                },
                onError: function (e) {
                    console.error(e)
                }
            }),
            params = {
                type: "k",
                authorityType: ""
            };
        function init() {

            events();
            load();
        }

        function load() {
            var fq = $("#beforeBackRight span").text()
            $("#js_box").removeClass("hidefixed");
            $("#js_box").removeClass("hidefixed");
            clearTimeout(timer);
            var _load = function () {
                var params1 = {
                    secid: window.stockEnity.fullcode,
                    ut: 'fa5fd1943c7b386f172d6893dbfba10b',
                    fields1: 'f1,f2,f3,f4,f5',
                    fields2: 'f51,f52,f53,f54,f55,f56,f57,f58',
                    klt: params.type == 'k' ? 101 : params.type == 'wk' ? 102 : params.type == 'mk' ? 103 : params.type == 'm5k' ? 5 : params.type == 'm15k' ? 15 : params.type == 'm30k' ? 30 : 60,
                    fqt: fq == '不复权' ? 0 : fq == '前复权' ? 1 : fq == '后复权' ? 2 : 0,
                    beg: "19900101",
                    end: "20220101"
                }
                $.ajax({
                    url: "http://push2his.eastmoney.com/api/qt/stock/kline/get",
                    dataType: "jsonp",
                    scriptCharset: 'utf-8',
                    data: params1,
                    jsonp: "cb",
                    success: function (resk) {
                        //console.log("kkkk>>", resk)
                        var obj = {
                            "name": resk.data.name,
                            "code": resk.data.code,
                            "info": {
                                "c": "",
                                "h": "",
                                "l": "",
                                "o": "",
                                "a": "",
                                "v": "",
                                "yc": $(".zsj").text(),
                                "time": "",
                                "ticks": "34200|54000|0|34200|41400|46800|54000",
                                "total": resk.data.dktotal,
                                "pricedigit": "0.00",
                                "jys": "2",
                                "Settlement": "-"
                            },
                            data: []
                        }
                        for (var i = 0; i < resk.data.klines.length; i++) {
                            var item = resk.data.klines[i] + '%'
                            obj.data.push(item)
                        }
                        kchart.setData({
                            k: obj
                        });
                        kchart.draw();
                    },
                    error: function (e) {
                        console.error(e);
                    },
                    complate: function () {
                        timer = setTimeout(load, 60 * 1000);
                    }
                });
            };
            _load();
        }

        function events() {
            $("#beforeBackRight dl dd").click(function () {
                $("#beforeBackRight span").html($(this).html());
                var v = $(this).attr("value");
                $("#beforeBackRight").attr("value", v);
                params.authorityType = v === "before" ? "fa" : v === "back" ? "ba" : "";
                load();
                var at = v === "before" ? "1" : v === "back" ? "2" : "0";
                if ($("#js_box").is(":visible")) {
                    $("#select4 dd[value=" + at + "]").click();
                }
            });

            $("#changektab span").click(function () {
                $("#changektab span").removeClass("cur");
                $(this).addClass("cur");
                switch ($(this).attr("value")) {
                    case "D":
                        params.type = "k";
                        break;
                    case "W":
                        params.type = "wk";
                        break;
                    case "M":
                        params.type = "mk";
                        break;
                    case "M5":
                        params.type = "m5k";
                        break;
                    case "M15":
                        params.type = "m15k";
                        break;
                    case "M30":
                        params.type = "m30k";
                        break;
                    case "M60":
                        params.type = "m60k";
                        break;
                }
                load();
            });

            $("#scale-plus").click(function () {
                kchart.shorten(-1, 0.1);
            });

            $("#scale-minus").click(function () {
                kchart.elongate(-1, 0.1);
            });

            $("#beforeBackRight").mouseenter(function () {
                this.getElementsByTagName("dl")[0].style.display = "block";
            });

            $("#beforeBackRight").mouseleave(function () {
                this.getElementsByTagName("dl")[0].style.display = "none";
            });
        }
        init();
    },


        bindJs: function () {
            var fq = $("#beforeBackRight span").text()
            $.ajax({
                url: "http://push2.eastmoney.com/api/qt/stock/trends2/get",
                dataType: "jsonp",
                scriptCharset: 'utf-8',
                data: {
                    secid: window.stockEnity.fullcode,
                    ut: 'fa5fd1943c7b386f172d6893dbfba10b',
                    fields1: 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11',
                    fields2: 'f51,f53,f56,f58',
                    iscr: fq=='不复权'?0:fq=='前复权'?1:fq=='后复权'?2:0,
                    ndays: 1
                },
                jsonp: "cb",
                success: function (res1) {
                    //console.log("分时图数据fenshitu>>",res1)
                    var obj = {
                        name: window.stockEnity.stockName,
                        code: window.stockEnity.stockCode,
                        info: {
                            "mk ":window.stockEnity.stockMarket,
                            "c": "",
                            "h": "",
                            "l": "",
                            "o": "",
                            "a": "",
                            "v": "",
                            "yc": res1.data.preClose, //昨收
                            "time": "",
                            "ticks": "34200|34200|54000|34200|41400|46800|54000",
                            "total": res1.data ? res1.data.trendsTotal : 0, //多少数据
                            "pricedigit": "0.00",
                            "jys": "2",
                            "Settlement": "-"
                        },
                        data: []
                    }
                    var dataList = res1.data ? res1.data.trends : []
                    for (var i = 0; i < dataList.length; i++) {
                        var arr = dataList[i].split(",")
                        var str = arr[0] + ',' + arr[1] + ',' + (arr[2] ) + ',' + arr[3] + ',' + 0
                        obj.data.push(str)
                    }
                    var option = {
                        container: "#emchart-0",
                        width: 565,
                        height: 276,
                        type: 'r',
                        iscr: false,
                        onClick: function () {
                            window.open(window.location + "#fullScreenChart","_blank")
                        }
                    }
                    var timechart = new emcharts3.time(option);
                    timechart.start(false)
                    timechart.setData({
                        time: obj
                    });
                    timechart.redraw();
                    timechart.stop();
                },
                error: function (e) {
                    console.error(e);
                }
            });
        }
    }

    // return emChart;

    module.exports = emChart
    // return emChart;
// });

/***/ }),

/***/ "./src/modules/old_b/template.js":
/*!***************************************!*\
  !*** ./src/modules/old_b/template.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_RESULT__;/*!art-template - Template Engine | http://aui.github.com/artTemplate/*/
!function(){function a(a){return a.replace(t,"").replace(u,",").replace(v,"").replace(w,"").replace(x,"").split(y)}function b(a){return"'"+a.replace(/('|\\)/g,"\\$1").replace(/\r/g,"\\r").replace(/\n/g,"\\n")+"'"}function c(c,d){function e(a){return m+=a.split(/\n/).length-1,k&&(a=a.replace(/\s+/g," ").replace(/<!--[\w\W]*?-->/g,"")),a&&(a=s[1]+b(a)+s[2]+"\n"),a}function f(b){var c=m;if(j?b=j(b,d):g&&(b=b.replace(/\n/g,function(){return m++,"$line="+m+";"})),0===b.indexOf("=")){var e=l&&!/^=[=#]/.test(b);if(b=b.replace(/^=[=#]?|[\s;]*$/g,""),e){var f=b.replace(/\s*\([^\)]+\)/,"");n[f]||/^(include|print)$/.test(f)||(b="$escape("+b+")")}else b="$string("+b+")";b=s[1]+b+s[2]}return g&&(b="$line="+c+";"+b),r(a(b),function(a){if(a&&!p[a]){var b;b="print"===a?u:"include"===a?v:n[a]?"$utils."+a:o[a]?"$helpers."+a:"$data."+a,w+=a+"="+b+",",p[a]=!0}}),b+"\n"}var g=d.debug,h=d.openTag,i=d.closeTag,j=d.parser,k=d.compress,l=d.escape,m=1,p={$data:1,$filename:1,$utils:1,$helpers:1,$out:1,$line:1},q="".trim,s=q?["$out='';","$out+=",";","$out"]:["$out=[];","$out.push(",");","$out.join('')"],t=q?"$out+=text;return $out;":"$out.push(text);",u="function(){var text=''.concat.apply('',arguments);"+t+"}",v="function(filename,data){data=data||$data;var text=$utils.$include(filename,data,$filename);"+t+"}",w="'use strict';var $utils=this,$helpers=$utils.$helpers,"+(g?"$line=0,":""),x=s[0],y="return new String("+s[3]+");";r(c.split(h),function(a){a=a.split(i);var b=a[0],c=a[1];1===a.length?x+=e(b):(x+=f(b),c&&(x+=e(c)))});var z=w+x+y;g&&(z="try{"+z+"}catch(e){throw {filename:$filename,name:'Render Error',message:e.message,line:$line,source:"+b(c)+".split(/\\n/)[$line-1].replace(/^\\s+/,'')};}");try{var A=new Function("$data","$filename",z);return A.prototype=n,A}catch(B){throw B.temp="function anonymous($data,$filename) {"+z+"}",B}}var d=function(a,b){return"string"==typeof b?q(b,{filename:a}):g(a,b)};d.version="3.0.0",d.config=function(a,b){e[a]=b};var e=d.defaults={openTag:"<%",closeTag:"%>",escape:!0,cache:!0,compress:!1,parser:null},f=d.cache={};d.render=function(a,b){return q(a)(b)};var g=d.renderFile=function(a,b){var c=d.get(a)||p({filename:a,name:"Render Error",message:"Template not found"});return b?c(b):c};d.get=function(a){var b;if(f[a])b=f[a];else if("object"==typeof document){var c=document.getElementById(a);if(c){var d=(c.value||c.innerHTML).replace(/^\s*|\s*$/g,"");b=q(d,{filename:a})}}return b};var h=function(a,b){return"string"!=typeof a&&(b=typeof a,"number"===b?a+="":a="function"===b?h(a.call(a)):""),a},i={"<":"&#60;",">":"&#62;",'"':"&#34;","'":"&#39;","&":"&#38;"},j=function(a){return i[a]},k=function(a){return h(a).replace(/&(?![\w#]+;)|[<>"']/g,j)},l=Array.isArray||function(a){return"[object Array]"==={}.toString.call(a)},m=function(a,b){var c,d;if(l(a))for(c=0,d=a.length;d>c;c++)b.call(a,a[c],c,a);else for(c in a)b.call(a,a[c],c)},n=d.utils={$helpers:{},$include:g,$string:h,$escape:k,$each:m};d.helper=function(a,b){o[a]=b};var o=d.helpers=n.$helpers;d.onerror=function(a){var b="Template Error\n\n";for(var c in a)b+="<"+c+">\n"+a[c]+"\n\n";"object"==typeof console&&console.error(b)};var p=function(a){return d.onerror(a),function(){return"{Template Error}"}},q=d.compile=function(a,b){function d(c){try{return new i(c,h)+""}catch(d){return b.debug?p(d)():(b.debug=!0,q(a,b)(c))}}b=b||{};for(var g in e)void 0===b[g]&&(b[g]=e[g]);var h=b.filename;try{var i=c(a,b)}catch(j){return j.filename=h||"anonymous",j.name="Syntax Error",p(j)}return d.prototype=i.prototype,d.toString=function(){return i.toString()},h&&b.cache&&(f[h]=d),d},r=n.$each,s="break,case,catch,continue,debugger,default,delete,do,else,false,finally,for,function,if,in,instanceof,new,null,return,switch,this,throw,true,try,typeof,var,void,while,with,abstract,boolean,byte,char,class,const,double,enum,export,extends,final,float,goto,implements,import,int,interface,long,native,package,private,protected,public,short,static,super,synchronized,throws,transient,volatile,arguments,let,yield,undefined",t=/\/\*[\w\W]*?\*\/|\/\/[^\n]*\n|\/\/[^\n]*$|"(?:[^"\\]|\\[\w\W])*"|'(?:[^'\\]|\\[\w\W])*'|\s*\.\s*[$\w\.]+/g,u=/[^\w$]+/g,v=new RegExp(["\\b"+s.replace(/,/g,"\\b|\\b")+"\\b"].join("|"),"g"),w=/^\d[^,]*|,\d[^,]*/g,x=/^,+|,+$/g,y=/^$|,+/;e.openTag="{{",e.closeTag="}}";var z=function(a,b){var c=b.split(":"),d=c.shift(),e=c.join(":")||"";return e&&(e=", "+e),"$helpers."+d+"("+a+e+")"};e.parser=function(a){a=a.replace(/^\s/,"");var b=a.split(" "),c=b.shift(),e=b.join(" ");switch(c){case"if":a="if("+e+"){";break;case"else":b="if"===b.shift()?" if("+b.join(" ")+")":"",a="}else"+b+"{";break;case"/if":a="}";break;case"each":var f=b[0]||"$data",g=b[1]||"as",h=b[2]||"$value",i=b[3]||"$index",j=h+","+i;"as"!==g&&(f="[]"),a="$each("+f+",function("+j+"){";break;case"/each":a="});";break;case"echo":a="print("+e+");";break;case"print":case"include":a=c+"("+b.join(",")+");";break;default:if(/^\s*\|\s*[\w\$]/.test(e)){var k=!0;0===a.indexOf("#")&&(a=a.substr(1),k=!1);for(var l=0,m=a.split("|"),n=m.length,o=m[l++];n>l;l++)o=z(o,m[l]);a=(k?"=":"=#")+o}else a=d.helpers[c]?"=#"+c+"("+b.join(",")+");":"="+a}return a}, true?!(__WEBPACK_AMD_DEFINE_RESULT__ = (function(){return d}).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)):undefined}();

/***/ }),

/***/ "./src/modules/old_option/stock.js":
/*!*****************************************!*\
  !*** ./src/modules/old_option/stock.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

//require(["baseStock", "common"], function (baseStock, common) {

var baseStock = __webpack_require__(/*! ../old_b/basestock */ "./src/modules/old_b/basestock.js")
var common = __webpack_require__(/*! ../old_b/common */ "./src/modules/old_b/common.js")

    function Stock() {
        baseStock.call(this);  //第二次调用基类的构造函数
        //this.stockType = "A";
    }

    Stock.prototype = new baseStock();    //第一次调用基类的构造函数

    //沪深涨幅排行 zxw
    Stock.prototype.setStockHS = function () {
        var url = instance.baseUrl + "/api/qt/clist/get?pi=0&pz=6&po=1&ut=" + instance.ut + "&fs=m:0+t:6,m:0+t:13,m:0+t:80,m:1+t:2&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2"
        common.jsonPnew(url, function (json) {
            var data = json.data.diff
            var html = '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th><th>加自选</th></tr>';
            for (var i in data) {
                var color = data[i].f2 > 0 ? "red" : data[i].f2 < 0 ? "green" : ""
                var price = data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)
                var zdf = data[i].f2 == '-' ? '-' : ((data[i].f3 / 100).toFixed(2) + '%')
                var jlr = (data[i].f62 + '').NumbericFormat()
                var stockName = data[i].f14
                var stockID = data[i].f13 == '1' ? ('sh' + data[i].f12) : ('sz' + data[i].f12)
                html += '<tr><td><a href="http://quote.eastmoney.com/' + stockID + '.html" target="_blank">' + stockName + '</a>' +
                    '</td><td class="' + color + '">' + price + '</td>' +
                    '<td class="' + color + '">' + zdf + '</td>' +
                    '<td class="addZix"><a href="http://quote.eastmoney.com/favor/infavor.aspx?code=' + data[i].f12 + '" target="_self"><i></i>自选</a></td></tr>';
            }
            html += "</tbody>";
            $("#stockTable").html(html);
        });
    }

    //沪深资金流向排行  zxw
    Stock.prototype.setStockZjl = function () {
        var url = instance.baseUrl + "/api/qt/clist/get?pi=0&pz=6&po=1&ut=" + instance.ut + "&fs=m:0+t:6,m:0+t:13,m:0+t:80,m:1+t:2&fid=f62&fields=f1,f2,f3,f12,f13,f14,f152,f62&invt=2"
        common.jsonPnew(url, function (json) {
            var data = json.data.diff
            var html = '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th><th>净流入</th></tr>';
            for (var i in data) {
                var jlrcolor = data[i].f62 > 0 ? "red" : data[i].f62 < 0 ? "green" : ""
                var zxjcolor = data[i].f2 > 0 ? "red" : data[i].f2 < 0 ? "green" : ""
                var price = data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)
                var zdf = data[i].f2 == '-' ? '-' : ((data[i].f3 / 100).toFixed(2) + '%')
                var jlr = (data[i].f62 + '').NumbericFormat()
                var stockName = data[i].f14
                var stockID = data[i].f13 == '1' ? ('sh' + data[i].f12) : ('sz' + data[i].f12)
                html += '<tr><td style="text-indent: 0px;"><a href="http://quote.eastmoney.com/' + stockID + '.html" target="_blank">' + stockName + '</a>' +
                    '</td><td style="text-indent: 0px;" class="' + zxjcolor + '">' + price + '</td>' +
                    '<td style="text-indent: 0px;"  class="' + zxjcolor + '">' + zdf + '</td>' +
                    '<td style="text-indent: 0px;"  class="' + jlrcolor + '">' + jlr + '</td></tr>';
            }
            html += "</tbody>";
            $("#zjlTable").html(html);
        });
    }

    var instance = new Stock();

    var fieldList = [
        { "name": "jk", "num": 3, "hasColor": true, "NumbericFormat": false },
        { "name": "zs", "num": 8, "hasColor": false, "NumbericFormat": false },
        { "name": "zxj", "num": 0, "hasColor": true, "NumbericFormat": false },
        { "name": "zde", "num": 11, "hasColor": true, "NumbericFormat": false },
        { "name": "zdf", "num": 12, "hasColor": true, "NumbericFormat": false },
        { "name": "np", "num": 10, "hasColor": false, "NumbericFormat": false },
        { "name": "wp", "num": 6, "hasColor": false, "NumbericFormat": false },
        { "name": "zgj", "num": 1, "hasColor": true, "NumbericFormat": false },
        { "name": "zdj", "num": 2, "hasColor": true, "NumbericFormat": false },
        { "name": "cjl", "num": 4, "hasColor": false, "NumbericFormat": true },
        { "name": "cje", "num": 5, "hasColor": false, "NumbericFormat": true },
        { "name": "mlj", "num": 16, "hasColor": false, "NumbericFormat": false },
        { "name": "mcj", "num": 17, "hasColor": false, "NumbericFormat": false },
        { "name": "zf", "num": 13, "hasColor": false, "NumbericFormat": false },
        { "name": "lb", "num": 14, "hasColor": false, "NumbericFormat": false }
    ];

    //全球市场行情
    var globalUrl = instance.baseUrl + "/api/qt/ulist.np/get?secids=1.000001,0.399001,100.N225,100.HSI,100.DJIA,100.NDX,100.SPX,100.FTSE,100.GDAXI,100.FCHI,100.TOP40&ut=" + instance.ut + "&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2"

    //全球市场行情
    var globalFutureUrl = instance.baseUrl + "/api/qt/ulist.np/get?secids=102.CL00Y,112.BC,101.GC00Y,101.SI00Y,111.JRUC,104.CN00Y,109.LALS,109.LCPS,103.ZS00Y,103.ZC00Y,108.CTC&ut=" + instance.ut + "&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2";

    //外汇行情
    var forexUrl = instance.baseUrl + "/api/qt/ulist.np/get?secids=100.UDI,121.USDCNYI,133.USDCNH,119.EURUSD,119.USDJPY,119.GBPUSD,119.AUDUSD,119.USDHKD,119.USDCHF,119.NZDUSD&ut=" + instance.ut + "&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2"

    //港股涨跌幅
    var hkUrl = instance.baseUrl + "/api/qt/clist/get?pn=1&pz=5&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=m:116+t:3,m:116+t:4&fields=f1,f2,f3,f12,f13,f14,f152"

    //美股涨跌幅
    var usUrl = instance.baseUrl + "/api/qt/clist/get?ut=" + instance.ut + "&pi=0&pz=6&po=1&fs=b:MK0201&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152"

    //国内期货行情报价
    var cnFutureUrl = instance.baseUrl + "/api/qt/ulist.np/get?secids=8.040120,8.060120,8.070120,8.050120,113.cum,113.agm,113.RBM,113.IM,114.MM,114.LM,115.SRM&ut=" + instance.ut + "&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2"

    //instance.loadHqData().intital(fieldList);

    var hqurl = instance.baseUrl + '/api/qt/stock/get?secid=' + window.stockEnity.fullcode + '&ut=' + instance.ut + '&fields=f191,f192,f117,f43,f51,f52,f169,f170,f46,f60,f84,f116,f44,f45,f171,f126,f47,f48,f168,f164,f49,f161,f55,f92,f59,f152,f167,f50,f532,f86&invt=2'
    // instance.loadnewHqData(hqurl, 'qq').intital(fieldList, 'qq'); //zxw

    // instance.loadnewHqData().intital(fieldList);

    // instance.bindChartImgEvent().bindEvent();
    // instance.getArticle(350, "articleDiv1");
    // instance.getArticle(351, "articleDiv2");
    // instance.getArticle(353, "articleDiv3");
    // instance.getArticle(349, "articleDiv4");
    instance.setHotGuba(14);
    //guba.init("gubalisttable", "cjpl", { listcount: 12, titlecut: 42 });
    init();

    //接口地址
    //正式接口地址
    var qihuo_url = "http://futsse.eastmoney.com";
    var fan_qihuo_url = "http://" + Math.floor(Math.random() * 100 + 1) + ".futsse.eastmoney.com";


    //测试接口地址
    if (common.getQueryString("hq-env") === "test") {
        qihuo_url = "http://futssetest.eastmoney.com";
        fan_qihuo_url = "http://futssetest.eastmoney.com";
    }



    //市场和code  暂时写死
    //   var qihuo_market = 'NYMEX',
    //       qihuo_code = 'NG00Y',
    //       qihuo_mktcode = '102_ng',
    //       qihuo_mkt = '102',
    //       qihuo_mktc = '4';
    //  var zuoshou = '';

    var qihuo_market = stockEnity.MktNum;

    var qihuo_code = stockEnity.stockCode.substr(0, 2).toLowerCase() + stockEnity.stockCode.substr(2);

    getHeadData();


    setInterval(function () {
        init();
    }, 20 * 1000);

    function init() {
        instance.stockBroadcast().init();
        instance.setStockHS();
        instance.setStockZjl();
        // instance.bindDataTemplatenew(globalUrl, "globalTable", "global");// zxw
        // // instance.bindDataTemplatenew(globalFutureUrl, "globalFutureTable", "globalFuture");// zxw
        // instance.bindDataTemplatenew(forexUrl, "forexTable", "forex");// zxw
        // instance.bindDataTemplatenew(hkUrl, "hkTable", "hk"); // zxw
        // instance.bindDataTemplatenew(usUrl, "usTable", "us"); // zxw


        mybindDataTemplatenew(globalUrl, "globalTable", "global");
        mybindDataTemplatenew(forexUrl, "forexTable", "forex");
        mybindDataTemplatenew(hkUrl, "hkTable", "hk");
        mybindDataTemplatenew(usUrl, "usTable", "us");
        // instance.bindDataTemplatenew(cnFutureUrl, "futureTable", "future"); // zxw
        // instance.bindChartImgEvent().changeImg();
    }

    function mybindDataTemplatenew(url, containerId, type) {
        var html = "";
        $.ajax({
            type: "GET",
            url: url,
            data: null,
            dataType: 'jsonp',
            jsonp: 'cb',
            success: function (res) {
                var data = res.data.diff;
                var json = []
                if (type == 'AB' || type == 'guba' || type == 'AB_NO' || type == 'future' || type == 'us' || type == 'globalFuture' || type == 'global') {
                    if (data instanceof Array) {
                        for (var i = 0; i < data.length; i++) {
                            var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)) + ',' + (data[i].f3 == '-' ? '-' : ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%'))
                            json.push(stritem)
                        }
                    } else {
                        for (var i in data) {
                            var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)) + ',' + (data[i].f3 == '-' ? '-' : ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%'))
                            json.push(stritem)
                        }
                    }
                } else if (type == 'ZDF') {
                    for (var i in data) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(2) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                } else if (type == 'hk') {
                    for (var i = 0; i < data.length; i++) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + ((data[i].f2 == '-' ? data[i].f2 : data[i].f2.toFixed(3)) + ',' + (data[i].f3 == '-' ? data[i].f3 : (data[i].f3).toFixed(data[i].f152) + '%'))
                        json.push(stritem)
                    }
                } else if (type == 'forex') {
                    for (var i = 0; i < data.length; i++) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                }
                if (type.indexOf("NO") >= 0) {
                    html += '<tbody>';
                } else {
                    html += '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>';
                }
                for (var i = 0; i < json.length; i++) {
                    var itemlist = json[i].split(",");
                    var color = common.getColor(itemlist[4]);
                    var stockCode = itemlist[1];
                    var stockName = itemlist[2];
                    if (common.getByteLen(stockName) > 12) {
                        //判断中英文
                        if (stockName.match(/[^\x00-\xff]/ig) != null) {
                            stockName = stockName.substring(0, 6) + "..";
                        } else {
                            stockName = stockName.substring(0, 12) + "..";
                        }
                    }

                    var stockUrl = "http://quote.eastmoney.com";
                    if (type == "AB" || type == "AB_NO") {
                        if (itemlist[1].indexOf("BK") >= 0) {
                            stockUrl += "/web/" + stockCode + "1.html";
                        } else if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    } else if (type == "guba") {
                        stockUrl = "http://guba.eastmoney.com/list," + stockCode + ".html";
                        stockName += "吧";
                    } else if (type == "ZDF") {
                        if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    } else if (type == "future") {
                        if (itemlist[0] == 8) {
                            var gzname = stockName.replace("连续", "");
                            var gzcode = gzname.replace("当月", "DYLX").replace("下月", "XYLX").replace("当季", "GZDJLX");
                            if (gzname.indexOf('IF') < 0) { gzcode = gzcode.replace("LX", ""); }
                            stockUrl = "http://quote.eastmoney.com/gzqh/" + gzcode + ".html";
                        } else {
                            stockUrl = "http://quote.eastmoney.com/qihuo/" + stockCode + ".html";
                        }
                    } else if (type == "us") {
                        stockUrl = "http://quote.eastmoney.com/us/" + stockCode + ".html";
                    } else if (type == "hk") {
                        stockUrl = "http://quote.eastmoney.com/hk/" + stockCode + ".html";
                    } else if (type == "forex") {
                        if (itemlist[0] == 100) {
                            stockUrl = "http://quote.eastmoney.com/globalfuture/" + stockCode + ".html";
                        } else {
                            stockUrl = "http://quote.eastmoney.com/forex/" + stockCode + ".html";
                        }
                    } else if (type == "globalFuture") {
                        stockUrl = "http://quote.eastmoney.com/globalfuture/" + stockCode + ".html";
                    } else if (type == "global") {
                        if (itemlist[0] == 0 || itemlist[0] == 1) {
                            stockUrl = "http://quote.eastmoney.com/zs" + stockCode + ".html";
                        } else {
                            stockUrl = "http://quote.eastmoney.com/gb/zs" + stockCode + ".html";
                        }
                    }
                    html += '<tr>'
                        + '<td>'
                        + (stockUrl ? ('<a href="' + stockUrl + '" target="_blank" title="' + itemlist[2] + '">' + stockName + '</a>') : stockName)
                        + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[3]) + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[4]) + '</td>'
                        + '</td></tr>';
                }

                html += "</tbody>";
                $("#" + containerId).html(html);

            }
        });
    }


    //期货换源
    function getHeadData() {
        // var secids = stockentry.marketnum +'.' + stockentry.code;
        //正式地址：
        // var url = "http://" + (Math.floor(Math.random() * 99) + 1) +".push2.eastmoney.com/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f152,f288,f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f31,f32,f33,f34,f35,f36,f37,f38,f39,f40,f20,f19,f18,f17,f16,f15,f14,f13,f12,f11,f531&secid=" + secids;

        //测试地址：
        var url = qihuo_url + "/static/" + qihuo_market + "_" + qihuo_code + "_qt?callbackName=aa";

        $.ajax({
            url: url,
            scriptCharset: "utf-8",
            dataType: "jsonp",
            jsonp: "cb",
            jsonpCallback: 'aa',
            success: function (json) {
                // console.log('json');
                // console.log(json);
                if (json.qt) {
                    formatHead(json.qt);

                    //增加判断浏览器是否为ie7及以下
                    if (document.all && !document.querySelector) {
                        setInterval(function () {
                            getHeadData();
                        }, 15 * 1000);

                    } else {
                        sseHeadData();
                    }


                    zuoshou = json.qt.zjsj;

                    //画图
                    if (json.qt.dm && json.qt.sc) {

                        if (json.qt.sc == "221") {
                            json.qt.sc = "11";
                        }

                        stockId = json.qt.sc + '.' + json.qt.dm;

                        var imgevt = instance.bindChartImgEvent()
                        imgevt.bindEvent(stockId);
                        imgevt.changeImg("r", stockId)
                        imgevt.changeImg("k", stockId)

                    }
                }



            }
        });

    }

    //sse
    function sseHeadData() {
        // var secids = stockentry.marketnum +'.' + stockentry.code;

        //测试地址
        var url = fan_qihuo_url + "/sse/" + qihuo_market + "_" + qihuo_code + "_qt";
        //正式地址
        //var url = "http://" + (Math.floor(Math.random() * 99) + 1) +".push2.eastmoney.com/api/qt/stock/sse?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f152,f288,f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f31,f32,f33,f34,f35,f36,f37,f38,f39,f40,f20,f19,f18,f17,f16,f15,f14,f13,f12,f11,f531&secid=" + secids;


        var evtSource = new EventSource(url);
        evtSource.onmessage = function (json) {
            // console.log('head sse 推送')
            var obj = JSON.parse(json.data)
            // console.log(obj)

            if (obj.qt) {
                formatHead(obj.qt);
            }
        }


    }

    //head format
    var headSourceData;
    function formatHead(data) {
        renderHead(data)
    }

    //渲染头部
    function renderHead(items) {
        var list = [
            { "name": "zxj", "item": items.p == "-" ? "-" : cancelZsjd(items.p, items.zsjd), "color": getColor(items.zdf) },
            { "name": "zde", "item": items.zde == "-" ? "-" : cancelZsjd(items.zde, items.zsjd), "color": getColor(items.zdf) },
            { "name": "zdf", "item": items.zdf == "-" ? "-" : (items.zdf).toFixed(2) + '%', "color": getColor(items.zdf) },
            { "name": "jk", "item": items.o == "-" ? "-" : cancelZsjd(items.o, items.zsjd), "color": getColor(items.o - items.qrspj) },
            { "name": "zgj", "item": items.h == "-" ? "-" : cancelZsjd(items.h, items.zsjd), "color": getColor(items.h - items.qrspj) },
            { "name": "cjl", "item": items.vol == "-" ? "-" : NumbericFormat(items.vol) },
            { "name": "mlj", "item": items.mrj == "-" ? "-" : cancelZsjd(items.mrj, items.zsjd), "color": getColor(items.mrj - items.qrspj) },
            { "name": "np", "item": items.np == "-" ? "-" : NumbericFormat(items.np), "color": 'green' },
            { "name": "zs", "item": items.qrspj == "-" ? "-" : cancelZsjd(items.qrspj, items.zsjd) },
            { "name": "zdj", "item": items.l == "-" ? "-" : cancelZsjd(items.l, items.zsjd), "color": getColor(items.l - items.qrspj) },
            { "name": "cje", "item": items.cje == "-" ? "-" : NumbericFormat(items.cje) },
            { "name": "mcj", "item": items.mcj == "-" ? "-" : cancelZsjd(items.mcj, items.zsjd), "color": getColor(items.mcj - items.qrspj) },
            { "name": "wp", "item": items.wp == "-" ? "-" : NumbericFormat(items.wp), "color": 'red' },
            { "name": "quote_title_0", "item": items.name == "-" ? "-" : items.name },
            { "name": "quote_title_1", "item": items.dm == "-" ? "-" : (items.dm).toUpperCase() },


            // { "name": "lb", "item": items.zjsj  == "-" ? "-" : items.zjsj },
            // { "name": "zjs", "item": items.zjsj  == "-" ? "-" : items.zjsj },
            // { "name": "ccl", "item": items.ccl == "-" ? "-" : NumbericFormat(items.ccl) },
            // { "name": "cc", "item": items.cclbh == "-" ? "-" : NumbericFormat(items.cclbh) },
            // { "name": "rz", "item": items.rz  == "-" ? "-" : items.rz, "color": getColor(items.rz) },

        ];
        for (var i = 0; i < list.length; i++) {
            if (list[i]) {


                var name = $("." + list[i].name);
                name.text(list[i].item);
                name.removeClass("red").removeClass("green").addClass(list[i].color);

            }
        }

        //箭头颜色
        onChangeDataRender(items.zdf);

        //时间
        if (items.jyzt == 0) {
            // var jyr = Dealjyr(items.jyr, "-")
            if (items.utime) {
                var jysj = Dealjysj(items.utime, "-");
                $("#stock_time").html('(' + jysj + ')');
            }


        } else {
            // var jyr = Dealjyr(items.jyr, "-")
            if (items.spsj) {
                var spsj = Dealjysj(items.spsj, "-");
                $("#stock_time").html('(' + spsj + ')');
            }


        }

    }


    //处理价格的展示精度
    function cancelZsjd(value, zsjd) {

        if (value !== '-') {
            return value.toFixed(zsjd);
        }


    }


    //处理数据颜色
    function getColor(str) {
        var context = str.toString();
        context = context.replace("%", "");
        if (context == 0 || isNaN(context)) {
            return "";
        } else if (context > 0) {
            return "red";
        } else {
            return "green";
        }
    }

    //处理成交量数据格式
    function NumbericFormat(string) {
        var context = Number(string);
        //var fushu = false;
        if (!isNaN(context)) {
            var item = parseInt(string);
            if ((item > 0 && item < 1e4) || (item < 0 && item > -1e4)) {
                return item;
            } else if ((item > 0 && item < 1e6) || (item < 0 && item > -1e6)) {
                item = item / 10000;
                return item.toFixed(2) + "万";
            } else if ((item > 0 && item < 1e7) || (item < 0 && item > -1e7)) {
                item = item / 10000;
                return item.toFixed(1) + "万";
            } else if ((item > 0 && item < 1e8) || (item < 0 && item > -1e8)) {
                item = item / 10000;
                return item.toFixed(0) + "万";
            } else if ((item > 0 && item < 1e10) || (item < 0 && item > -1e10)) {
                item = item / 1e8;
                return item.toFixed(2) + "亿";
            } else if ((item > 0 && item < 1e11) || (item < 0 && item > -1e11)) {
                item = item / 1e8;
                return item.toFixed(1) + "亿";
            } else if ((item > 0 && item < 1e12) || (item < 0 && item > -1e12)) {
                item = item / 1e8;
                return item.toFixed(0) + "亿";
            } else if ((item > 0 && item < 1e14) || (item < 0 && item > -1e14)) {
                item = item / 1e12;
                return item.toFixed(2) + "万亿";
            } else if ((item > 0 && item < 1e15) || (item < 0 && item > -1e15)) {
                item = item / 1e12;
                return item.toFixed(1) + "万亿";
            } else if ((item > 0 && item < 1e16) || (item < 0 && item > -1e16)) {
                item = item / 1e12;
                return item.toFixed(0) + "万亿";
            } else {
                return item;
            }
        } else
            return '-';
    }


    //处理开平
    function Dealkp(val) {
        if (val == '1') {
            return '多平'
        } else if (val == '2') {
            return '空平'
        } else if (val == '3') {
            return '多开'
        } else if (val == '4') {
            return '空开'
        } else if (val == '5') {
            return '多换'
        } else if (val == '6') {
            return '空换'
        } else if (val == '7') {
            return '双开'
        } else if (val == '8') {
            return '双平'
        } else {
            return '-'
        }

    }


    //箭头颜色变化
    function onChangeDataRender(item) {

        try {
            if(item === "-" || item == undefined){
                $("#arrow-find").hide().removeAttr("class")
            }
            else if(item == 0){
                $("#arrow-find").hide().removeClass("up-arrow").removeClass("down-arrow");
            }
            else{
                $("#arrow-find").addClass("xp2")
                if (parseFloat(item) > 0) {
                    $("#arrow-find").show().removeClass("down-arrow").addClass("up-arrow");
    
                } else if(parseFloat(item) < 0) {
                    $("#arrow-find").show().removeClass("up-arrow").addClass("down-arrow");
                }
            }
        } catch (error) {
            
        }
        // if (item != 0 && item != "-") {
        //     $("#arrow-find").addClass("xp2")
        //     if (item > 0) {
        //         $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");

        //     } else {
        //         $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
        //     }
        // }else{
           
        // }

        // if (item == 0) {
        //     $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
        // }

    }


    /**
    * 处理交易日
    * @param {number} val :值
    * @param {string} fuhao: 拼接符号
    */
    function Dealjyr(val, fuhao) {
        try {
            val = '' + val;
            if (val.length == 5) {
                val = '0' + val;
            }

            var fulltime = val.substr(0, 4) + fuhao + val.substr(4, 2) + fuhao + val.substr(6, 2);
            return fulltime;

        } catch (e) {
            return '-'
        }

    }


    /**
     * 处理交易时间
     * @param {number} val :待处理的值
     * @param {string} fuhao ：拼接符号
     */
    function Dealjysj(val, fuhao) {
        try {
            //     val = '' + val;
            //    if(val.length == 5) {
            //        val = '0' + val;
            //    } else if(val.length == 4) {
            //      val = '00' + val;
            //    } else if(val.length == 3) {
            //      val = '000' + val;
            //    } else if(val.length == 2) {
            //      val = '0000' + val;
            //    } else if(val.length == 2) {
            //      val = '0000' + val;
            //    } else if(val.length == 1) {
            //     val = '00000' + val;
            //    } else if(val == '0'){
            //      val = '000000';
            //    }


            //    var fulltime = val.substr(0,2) + fuhao + val.substr(2,2) + fuhao + val.substr(4,2);
            //    return fulltime;

            var d = new Date(val * 1000);  //("0" + (d.getMonth() + 1)).slice(-2)    d.getMinutes()  d.getMinutes()  d.getSeconds()
            var jysj = d.getFullYear() + fuhao + (("0" + (d.getMonth() + 1)).slice(-2)) + fuhao + (("0" + (d.getDate())).slice(-2)) + ' ' + ("0" + (d.getHours())).slice(-2) + ':' + ("0" + (d.getMinutes())).slice(-2) + ':' + ("0" + (d.getSeconds())).slice(-2);

            return jysj;

        } catch (e) {
            return '-'
        }

    }



    /**
     * 渲染小表格统一方法
     * @param {strig} selector :dom选择器
     * @param {object} data ：数据
     */
    function renderQthybj(selector, data) {

        var content = $(selector)
        var tbody = content.find("tbody");
        tbody.html('<tr><th class="">名称</th><th>最新价</th><th>涨跌幅</th></tr>');

        if (data) {

            var list = data.list;
            for (var i = 0, len = list.length; i < len; i++) {
                var row = list[i];
                // var fs = Math.pow(10, row.f1);

                var tr = $("<tr></tr>");
                var td1 = $("<td></td>");
                var td1a = $("<a target='_blank' style='width: 70px;display: block;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;'></a>").text(row.name).attr("href", "http://quote.eastmoney.com/unify/r/" + row.sc + '.' + row.dm).attr("title", row.name);
                td1.append(td1a);

                var td2 = $("<td></td>").text(row.p !== '-' ? cancelZsjd(row.p, row.zsjd) : '-');
                var td3 = $("<td></td>").text(row.zdf !== '-' ? (row.zdf).toFixed(2) + "%" : '-');

                if (row.zdf < 0) {
                    td2.addClass("green");
                    td3.addClass("green");
                }
                if (row.zdf > 0) {
                    td2.addClass("red");
                    td3.addClass("red");
                }

                tr.append(td1).append(td2).append(td3);
                tbody.append(tr);
            }

        }

    }


    /**
     * 渲染国外表格
     * @param {strig} selector :dom选择器
     * @param {object} data ：数据
     */
    function renderQthybjGw(selector, data) {

        var content = $(selector)
        var tbody = content.find("tbody");
        tbody.html('<tr><th class="">名称</th><th>最新价</th><th>涨跌幅</th></tr>');

        if (data) {

            var list = data.list;
            for (var i = 0, len = list.length; i < len; i++) {
                var row = list[i];
                // var fs = Math.pow(10, row.f1);

                var tr = $("<tr></tr>");
                var td1 = $("<td></td>");
                var td1a = $("<a target='_blank' style='width: 70px;display: block;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;'></a>").text(row.name).attr("href", "http://quote.eastmoney.com/unify/r/" + row.sc + '.' + row.dm).attr("title", row.name);
                td1.append(td1a);

                var td2 = $("<td></td>").text(row.p !== '-' ? cancelZsjd(row.p, row.zsjd) : '-');
                var td3 = $("<td></td>").text(row.zdf !== '-' ? (row.zdf).toFixed(2) + "%" : '-');

                if (row.zdf < 0) {
                    td2.addClass("green");
                    td3.addClass("green");
                }
                if (row.zdf > 0) {
                    td2.addClass("red");
                    td3.addClass("red");
                }

                tr.append(td1).append(td2).append(td3);
                tbody.append(tr);
            }

        }

    }



    //国内期货合约报价
    Gnqhhybj()
    function Gnqhhybj() {
        var url = qihuo_url + '/list/main/113,114,115,142,8?orderBy=zdf&sort=desc&pageSize=11&pageIndex=0&callbackName=h8';

        $.ajax({
            url: url,
            scriptCharset: "utf-8",
            dataType: "jsonp",
            jsonp: "cb",
            jsonpCallback: 'h8',
            success: function (json) {
                // console.log('国内期货合约报价');
                // console.log(json);

                if (json && json.list) {
                    renderQthybj('#futureTable', json)
                }


            }
        });

    }


    //国际期货行情
    Gwqhhq()
    function Gwqhhq() {
        var url = qihuo_url + '/list/101,102,103,104,108,109,110,111,112?orderBy=zdf&sort=desc&pageSize=10&pageIndex=0&callbackName=h9';

        $.ajax({
            url: url,
            scriptCharset: "utf-8",
            dataType: "jsonp",
            jsonp: "cb",
            jsonpCallback: 'h9',
            success: function (json) {
                // console.log('国内期货合约报价');
                // console.log(json);

                if (json && json.list) {
                    renderQthybjGw('#globalFutureTable', json)
                }


            }
        });

    }


    setInterval(function () {
        Gnqhhybj();
        Gwqhhq();

    }, 20 * 1000);




//});




/***/ })

/******/ });
//# sourceMappingURL=option.js.map