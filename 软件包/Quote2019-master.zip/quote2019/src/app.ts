require('source-map-support').install();

if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = 'development'
}

import Koa from 'koa'
import moment from 'moment'
import render from './modules/koaejs'
// const render = require('./modules/koaejs')
import koaBody from 'koa-body'
import reg_route from './modules/reg_route'
import onerror from './modules/onerror'
import catchweb from './modules/catchweb'
import changeurl from "./modules/changeurl";

const app = new Koa()

app.use(async (ctx, next)=>{
  ctx.state.starttime = Date.now()
  await next()
})

app.use(changeurl())

//静态文件
app.use(require('koa-static')('public'))


app.use(onerror())
app.use(koaBody())

render(app, {
  root: 'views',
  layout: 'shared/layout',
  viewExt: 'ejs',
  cache: process.env.NODE_ENV == 'production' ? true : false,
  debug: false 
});

app.use(async (ctx, next)=>{
  ctx.state.footer = await catchweb('http://emres.dfcfw.com/public/footer-1000-html.html', {}, 10 * 60 * 1000)
  ctx.state.thistime = moment().format('yyyy-mm-dd HH:MM:ss')
  ctx.state.machine_num = process.env.SERVER_NUM || 0
  await next()
})

//注册路由
reg_route(app) 

app.use(async(ctx, next) => {
  ctx.status = 404
  if (process.env.NODE_ENV == 'development') {
    ctx.body = '404'
  }
  else{
    await ctx.render('shared/404', {title:'404', layout: false})
  }
  
})

const port = 45666
app.listen(port, function(){
  console.info(`行情2019(ENV：${process.env.NODE_ENV})已启动，监听端口 ${port}`);
});