/**
 * 港股
 */
import { Context } from "koa"
import Router from 'koa-router'
import txt from "../modules/txt"
import encryption from "../modules/encryption"
import hk from "../modules/stockinfo/hk"
import common from "../modules/stockinfo/common"
import pagecache from "../modules/pagecache"

const hk_page_cache = pagecache({
  cachetime: 2 * 60 * 1000,
  file_cachetime: 30 * 60 * 1000
})

let router = new Router();

router.prefix('/hk')

router.get('/:code(\\d{5}).html', hk_page_cache, async (ctx: Context, next: Function) => {

  let code = ctx.params.code
  let stockinfo = await hk.stockinfo(`116.${code}`)

  if (stockinfo == null) {
    await next()
    return
  }
  
  let [
    news,
    announcement,
    headLines,
    hotguba,
    gubaFierceUser,
    toutiao
  ] = await Promise.all([
    hk.news(code, stockinfo.Name),
    hk.announcement(code),
    hk.headLines(),
    hk.hotguba(),
    common.getGuBaActiveUserList('hk' + code, 4),
    hk.toutiao()
  ])
  

  await ctx.render('hk/index', {
    code: code,
    oldmarket: '5',
    oldcode: code + '5',
    newmarket: '116',
    newcode: '116.' + code,
    title: `${stockinfo.Name} (${code})`,
    stockinfo: stockinfo,
    K: 1 / (16 * 20.0),
    txtLeft: txt.txtLeft,
    txtLength: txt.txtLength,
    news: news,
    announcement: announcement,
    headLines: headLines,
    hotguba: hotguba,
    gubaFierceUser: gubaFierceUser,
    base64: encryption.base64,
    toutiao: toutiao
  })
})


module.exports = router