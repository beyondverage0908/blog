/**
 * 期权
 */

import { Context } from "koa"
import Router from 'koa-router'
import b from "../modules/stockinfo/b";
import option from "../modules/stockinfo/option"
import common from "../modules/stockinfo/common"
import pagecache from "../modules/pagecache"

const option_page_cache = pagecache({
  cachetime: 2 * 60 * 1000,
  file_cachetime: 30 * 60 * 1000
})

let router = new Router();

router.get('/option/:code.html', option_page_cache, async (ctx: Context, next: Function) => {
  let code = ctx.params.code

  // 期权：
  // 中金所 	11	_FO
  // 上期所	151	_SHFEOP
  // 大商所 	140	_DCEOP
  // 郑商所 	141	_CZCEOP
  // 香港期教所	139	_HUCOP

  // /xianhuo/122.xau.html
  //122 8 国际贵金属现货
  //123 


  let allowlist = [{
    name:'_FO',
    market: 11
  },{
    name:'_SHFEOP',
    market: 151  
  },{
    name:'_DCEOP',
    market: 140  
  },{
    name:'_CZCEOP',
    market: 141  
  },{
    name:'_HUCOP',
    market: 139  
  }]

  let marketstr = code.substring(code.lastIndexOf('_'))

  if (marketstr == code) { //没有下划线市场
    await next()
    return
  }

  let thismarketobj = allowlist.find(v=> v.name.toLowerCase() == marketstr.toLowerCase())

  if (thismarketobj == undefined) { //没有找到市场
    await next()
    return
  }

  let market = thismarketobj.market
  let codestr = code.substring(0, code.lastIndexOf('_'))

  let baseinfo = await option.stockinfo(market.toString(), codestr)

  if (baseinfo == null) { //没有基本信息
    await next()
    return
  }
  
  let StockName = baseinfo.name
  let StockCode = codestr

  let [
    hotguba,
    gnjj_news, //国内经济
    gjjj_news, //国际经济
    zqjj_news, //证券聚焦
    ssgs_news //上市公司
  ] = await Promise.all([
    b.hotGuba(),
    common.getCMSNewsByColumn('350'),
    common.getCMSNewsByColumn('351'),
    common.getCMSNewsByColumn('353'),
    common.getCMSNewsByColumn('349')
  ])

  await ctx.render('option/option', {
    layout: 'shared/layout_option',
    StockID: code,
    StockCode: baseinfo.code,
    StockName: StockName,
    StockMarket: marketstr,
    MktNum: market,
    NewCode: market + '.' + baseinfo.code,
    Title: StockName + '(' + StockCode + ')',
    hotguba: hotguba,
    gnjj_news: gnjj_news,
    gjjj_news: gjjj_news,
    zqjj_news: zqjj_news,
    ssgs_news: ssgs_news

  })
})

 
module.exports = router