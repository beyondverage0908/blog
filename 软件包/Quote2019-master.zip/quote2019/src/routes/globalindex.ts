/**
 * 全球指数
 */


import { Context } from "koa"
import Router from 'koa-router'
import globalindex from "../modules/stockinfo/globalindex"
import b from "../modules/stockinfo/b"
import txt from "../modules/txt"
import { fn } from "moment";


let router = new Router();



router.get('/gb/zs:code.html', async (ctx: Context, next: Function) => {
  let code:string = ctx.params.code.toUpperCase()

  if (code == 'INDU') {
    ctx.redirect('/gb/zsDJIA.html')
    return
  }

  if (code == 'CCMP') {
    ctx.redirect('/gb/zsNDX.html')
    return
  }

  if (code == '110000') {
    ctx.redirect('/gb/zsHSI.html')
    return
  }

  if (code == '110010') {
    ctx.redirect('/gb/zsHSCEI.html')
    return
  }  

  if (code == '110030') {
    ctx.redirect('/gb/zsHSCCI.html')
    return
  }

  if (code == '110050') {
    ctx.redirect('/gb/zsSPHKG.html')
    return
  }  

  if (code == 'UKX') {
    ctx.redirect('/gb/zsFTSE.html')
    return
  }   


  

  let marketobj = await globalindex.getMarket(code)

  // console.info(marketobj)
  

  if (marketobj == undefined) { //没有命中国际指数市场
    await next()
    return
  }

  let market = marketobj.f13 //市场
  let quotecode = market + '.' + code //市场.代码

  let baseinfo = await globalindex.stockinfo(quotecode)

  if (baseinfo == null) {
    await next()
    return
  }

  let JYS = baseinfo.f112 //JYS
  // console.info(JYS)
  
  let thisArea = globalindex.getAreaByJYS(JYS)  
  let Area = globalindex.Area
  let StockName = baseinfo.f58
  let old_market = '_UI'
  if(thisArea == Area.HK){
    old_market = '5'
  }

  let GubaCode = ''

  //GubaCode 股吧代码逻辑
  if (thisArea == Area.HK && JYS == "HKIN"){
    GubaCode = "zszz" + code.toLowerCase() //中证海外指数
  }
  else if (thisArea == Area.HK && code != "HSI"){
    GubaCode = "zshk" + code.toLowerCase()
  }
  else{
    GubaCode = "zsgj" + code.toLowerCase()
  }


      
  // 其他国际指数
  let otherArea = [Area.AME, Area.AUS, Area.EUR, Area.ASIA]
  otherArea = otherArea.filter(v=>v!=thisArea).slice(0,3)


  // 老代码映射
  let uifo_code_mappings = [
      // 香港国企
      { key: "110010_UIFO", value: "HSCEI5" },
      // 红筹指数
      { key: "110030_UIFO", value: "HSCCI5" },
      // 标普香港创业板指数
      { key: "110050_UIFO", value: "SPHKG5" },
      // 恒生指数
      { key: "110000_UIFO", value: "HSI5" },
      // 纳斯达克
      { key: "NDX_UI", value: "CCMP_UIFO" },
      // 道琼斯工业
      { key: "DJIA_UI", value: "INDU_UIFO" }
  ]

  // 区域描述
  let area_mappings = {
    [Area.AME]:{
      Name: "美洲",
      Cmd: "_UI_MAP_AME",
      MoreLink: "//quote.eastmoney.com/center/america.html#america_3",
      NewsName: "美国市场",
      NewsMoreLink: "http://global.eastmoney.com/news/cmgsc.html"
    },
    [Area.ASIA]:  {
      Name: "亚洲",
      Cmd: "_UI_MAP_ASIA",
      MoreLink: "//quote.eastmoney.com/center/asia.html#asia_3",
      NewsName: "亚太市场",
      NewsMoreLink: "http://global.eastmoney.com/news/cytsc.html"
    },
    [Area.EUR]:  {
      Name: "欧洲",
      Cmd: "_UI_MAP_EUR",
      MoreLink: "//quote.eastmoney.com/center/europe.html#europe_3",
      NewsMoreLink: "http://global.eastmoney.com/news/cozsc.html"
    },
    [Area.AUS]:  {
      Name: "澳洲",
      Cmd: "_UI_MAP_AUS",
      MoreLink: "//quote.eastmoney.com/center/australia.html#australia_3",
      NewsName: "全球导读",
      NewsMoreLink: "http://global.eastmoney.com/news/cqqdd.html"
    },
    [Area.AFI]:  { 
      Name: "非洲",
      Cmd: "_UI_MAP_AME",
      MoreLink: ""
    },
    [Area.HK]:  {
      Name: "香港",
      Cmd: "_HKI",
      MoreLink: "//quote.eastmoney.com/center/list.html#32_1",
      NewsMoreLink: "http://hk.eastmoney.com/news/cggyw.html"
    }
  }

  let link_fmt = '//quote.eastmoney.com/gb/zs{0}.html'
  // 港股主要指数
  let HKMainIndexList = [
      {
          Name:  "恒生指数",
          Cmd:  "HSI5",
          RelatedCmd:  "C.MK0141",
          MoreLink:  "//quote.eastmoney.com/center/list.html#mk0141_1",
          Link:  txt.format(link_fmt, "HSI")
      },
      {
          Name:  "国企指数",
          Cmd:  "HSCEI5",
          RelatedCmd:  "C.__28HSCEIINDEX",
          MoreLink:  "//quote.eastmoney.com/center/list.html#28HSCEIINDEX_1",
          Link:  txt.format(link_fmt, "HSCEI")
      },
        {
          Name:  "红筹指数",
          Cmd:  "HSCCI5",
          RelatedCmd:  "C.__28HSCEIINDEX",
          MoreLink:  "//quote.eastmoney.com/center/list.html#28HSCEIINDEX_1",
          Link:  txt.format(link_fmt, "HSCCI") },
        {
          Name:  "标普香港创业板指数",
          Cmd:  "SPHKG5",
          RelatedCmd:  "C.__28GEM",
          MoreLink:  "//quote.eastmoney.com/center/list.html#28GEM_1",
          Link:  txt.format(link_fmt, "SPHKG")
      }
  ]
  
  // 美洲主要指数
  let USMainIndexList = [
    { Name: "纳斯达克", Cmd: "NDX_UI", Link: txt.format(link_fmt, "NDX") },
    { Name: "道琼斯", Cmd: "DJIA_UI", Link: txt.format(link_fmt, "DJIA") },
    { Name: "标普", Cmd: "SPX_UI", Link: txt.format(link_fmt, "SPX") }
  ]

  let MainIndex = (thisArea == Area.HK ? HKMainIndexList : USMainIndexList)
 

  

  let [
    CurrentStockNews,
    OtherStockNews,
    hotguba
  ] = await Promise.all([
    globalindex.getCurrentStockNews(thisArea),
    globalindex.getOtherStockNews(),
    b.hotGuba()
  ])

  await ctx.render('globalindex/globalindex', {
    layout: 'shared/layout_globalindex',
    StockName: StockName,
    StockID: code + old_market,
    StockCode: code,
    StockMarket: old_market,
    MktNum: market,
    GubaCode: GubaCode,
    thisArea: thisArea,
    Area: globalindex.Area,
    Title: `${StockName}(${code})`,
    MainIndex: MainIndex,
    uifo_code_mappings: uifo_code_mappings,
    area_mappings: area_mappings,
    otherArea: otherArea,
    HKMainIndexList: HKMainIndexList,
    CurrentStockNews: CurrentStockNews,
    OtherStockNews: OtherStockNews,
    txtLeft: txt.txtLeft,
    USMainIndexList: USMainIndexList,
    hotguba: hotguba
  })
})


module.exports = router