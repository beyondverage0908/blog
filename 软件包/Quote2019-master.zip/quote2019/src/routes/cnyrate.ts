/**
 * 外汇 人民币汇率中间价
 */

import { Context } from "koa"
import Router from 'koa-router'
import cnyrate from "../modules/stockinfo/cnyrate"
import common from "../modules/stockinfo/common"
import zs from "../modules/stockinfo/zs"

import forex from "../modules/stockinfo/forex"
import txt from "../modules/txt";
import moment from "moment";
moment.locale('zh-cn')

/**
 * 三位字母外汇代码和中文对照表
 */
let codetable = [
  {Code:"AED",Name:"阿联酋迪拉姆"},
  {Code:"AFN",Name:"阿富汗尼"},
  {Code:"ALL",Name:"阿尔巴尼列克"},
  {Code:"AMD",Name:"亚美尼亚德拉姆"},
  {Code:"ANG",Name:"荷兰盾"},
  {Code:"AOA",Name:"安哥拉宽扎"},
  {Code:"ARS",Name:"阿根廷比索"},
  {Code:"AUD",Name:"澳元"},
  {Code:"AWG",Name:"阿鲁巴弗罗林"},
  {Code:"AZN",Name:"阿塞拜疆马纳特"},
  {Code:"BAM",Name:"波黑可兑换马克"},
  {Code:"BBD",Name:"巴巴多斯元"},
  {Code:"BDT",Name:"孟加拉国塔卡"},
  {Code:"BGN",Name:"保加利亚列弗"},
  {Code:"BHD",Name:"巴林第纳尔"},
  {Code:"BIF",Name:"布隆迪法郎"},
  {Code:"BMD",Name:"百慕大元"},
  {Code:"BND",Name:"文莱元"},
  {Code:"BOB",Name:"玻利维亚诺"},
  {Code:"BRL",Name:"巴西雷亚尔"},
  {Code:"BSD",Name:"巴哈马元"},
  {Code:"BTC",Name:"比特币"},
  {Code:"BTN",Name:"不丹努扎姆"},
  {Code:"BWP",Name:"博茨瓦纳普拉"},
  {Code:"BYR",Name:"白俄罗斯卢布"},
  {Code:"BZD",Name:"伯利兹元"},
  {Code:"CAD",Name:"加元"},
  {Code:"CDF",Name:"刚果法郎"},
  {Code:"CHF",Name:"瑞士法郎"},
  {Code:"CLF",Name:"智利比索(基金)"},
  {Code:"CLP",Name:"智利比索"},
  {Code:"CNH",Name:"中国离岸人民币"},
  {Code:"CNY",Name:"人民币"},
  {Code:"COP",Name:"哥伦比亚比索"},
  {Code:"CRC",Name:"哥斯达黎加科朗"},
  {Code:"CUP",Name:"古巴比索"},
  {Code:"CVE",Name:"佛得角埃斯库多"},
  {Code:"CYP",Name:"塞普路斯镑"},
  {Code:"CZK",Name:"捷克克朗"},
  {Code:"DEM",Name:"德国马克"},
  {Code:"DJF",Name:"吉布提法郎"},
  {Code:"DKK",Name:"丹麦克朗"},
  {Code:"DOP",Name:"多米尼加比索"},
  {Code:"DZD",Name:"阿尔及利亚第纳尔"},
  {Code:"ECS",Name:"厄瓜多尔苏克雷"},
  {Code:"EGP",Name:"埃及镑"},
  {Code:"ERN",Name:"厄立特里亚纳克法"},
  {Code:"ETB",Name:"埃塞俄比亚比尔"},
  {Code:"EUR",Name:"欧元"},
  {Code:"FJD",Name:"斐济元"},
  {Code:"FKP",Name:"福克兰群岛镑"},
  {Code:"FRF",Name:"法国法郎"},
  {Code:"GBP",Name:"英镑"},
  {Code:"GEL",Name:"格鲁吉亚拉里"},
  {Code:"GHS",Name:"加纳塞地"},
  {Code:"GIP",Name:"直布罗陀镑"},
  {Code:"GMD",Name:"冈比亚达拉西"},
  {Code:"GNF",Name:"几内亚法郎"},
  {Code:"GTQ",Name:"危地马拉格查尔"},
  {Code:"GYD",Name:"圭亚那元"},
  {Code:"HKD",Name:"港币"},
  {Code:"HNL",Name:"洪都拉斯伦皮拉"},
  {Code:"HRK",Name:"克罗地亚库纳"},
  {Code:"HTG",Name:"海地古德"},
  {Code:"HUF",Name:"匈牙利福林"},
  {Code:"IDR",Name:"印度尼西亚卢比"},
  {Code:"IEP",Name:"爱尔兰镑"},
  {Code:"ILS",Name:"以色列新谢克尔"},
  {Code:"INR",Name:"印度卢比"},
  {Code:"IQD",Name:"伊拉克第纳尔"},
  {Code:"IRR",Name:"伊朗里亚尔"},
  {Code:"ISK",Name:"冰岛克郎"},
  {Code:"ITL",Name:"意大利里拉"},
  {Code:"JMD",Name:"牙买加元"},
  {Code:"JOD",Name:"约旦第纳尔"},
  {Code:"JPY",Name:"日元"},
  {Code:"KES",Name:"肯尼亚先令"},
  {Code:"KGS",Name:"吉尔吉斯斯坦索姆"},
  {Code:"KHR",Name:"柬埔寨瑞尔"},
  {Code:"KMF",Name:"科摩罗法郎"},
  {Code:"KPW",Name:"朝鲜元"},
  {Code:"KRW",Name:"韩元"},
  {Code:"KWD",Name:"科威特第纳尔"},
  {Code:"KYD",Name:"开曼群岛元"},
  {Code:"KZT",Name:"哈萨克斯坦坚戈"},
  {Code:"LAK",Name:"老挝基普"},
  {Code:"LBP",Name:"黎巴嫩镑"},
  {Code:"LKR",Name:"斯里兰卡卢比"},
  {Code:"LRD",Name:"利比里亚元"},
  {Code:"LSL",Name:"莱索托洛蒂"},
  {Code:"LTL",Name:"立陶宛立特"},
  {Code:"LVL",Name:"拉脱维亚拉特"},
  {Code:"LYD",Name:"利比亚第纳尔"},
  {Code:"MAD",Name:"摩洛哥迪拉姆"},
  {Code:"MDL",Name:"摩尔多瓦列伊"},
  {Code:"MGA",Name:"马达加斯加阿里亚里"},
  {Code:"MKD",Name:"马其顿代纳尔"},
  {Code:"MMK",Name:"缅甸元"},
  {Code:"MNT",Name:"蒙古图格里克"},
  {Code:"MOP",Name:"澳门元"},
  {Code:"MRO",Name:"毛里塔尼亚乌吉亚"},
  {Code:"MUR",Name:"毛里求斯卢比"},
  {Code:"MVR",Name:"马尔代夫拉菲亚"},
  {Code:"MWK",Name:"马拉维克瓦查"},
  {Code:"MXN",Name:"墨西哥比索"},
  {Code:"MXV",Name:"墨西哥(资金)"},
  {Code:"MYR",Name:"林吉特"},
  {Code:"MZN",Name:"莫桑比克新梅蒂卡尔"},
  {Code:"NAD",Name:"纳米比亚元"},
  {Code:"NGN",Name:"尼日利亚奈拉"},
  {Code:"NIO",Name:"尼加拉瓜新科多巴"},
  {Code:"NOK",Name:"挪威克朗"},
  {Code:"NPR",Name:"尼泊尔卢比"},
  {Code:"NZD",Name:"新西兰元"},
  {Code:"OMR",Name:"阿曼里亚尔"},
  {Code:"PAB",Name:"巴拿马巴波亚"},
  {Code:"PEN",Name:"秘鲁新索尔"},
  {Code:"PGK",Name:"巴布亚新几内亚基那"},
  {Code:"PHP",Name:"菲律宾比索"},
  {Code:"PKR",Name:"巴基斯坦卢比"},
  {Code:"PLN",Name:"波兰兹罗提"},
  {Code:"PYG",Name:"巴拉圭瓜拉尼"},
  {Code:"QAR",Name:"卡塔尔里亚尔"},
  {Code:"RON",Name:"罗马尼亚列伊"},
  {Code:"RSD",Name:"塞尔维亚第纳尔"},
  {Code:"RUB",Name:"卢布"},
  {Code:"RWF",Name:"卢旺达法郎"},
  {Code:"SAR",Name:"沙特里亚尔"},
  {Code:"SBD",Name:"所罗门群岛元"},
  {Code:"SCR",Name:"塞舌尔卢比"},
  {Code:"SDG",Name:"苏丹磅"},
  {Code:"SEK",Name:"瑞典克朗"},
  {Code:"SGD",Name:"新加坡元"},
  {Code:"SHP",Name:"圣赫勒拿镑"},
  {Code:"SIT",Name:"斯洛文尼亚托拉尔"},
  {Code:"SLL",Name:"塞拉利昂利昂"},
  {Code:"SOS",Name:"索马里先令"},
  {Code:"SRD",Name:"苏里南元"},
  {Code:"STD",Name:"圣多美多布拉"},
  {Code:"SVC",Name:"萨尔瓦多科朗"},
  {Code:"SYP",Name:"叙利亚镑"},
  {Code:"SZL",Name:"斯威士兰里兰吉尼"},
  {Code:"THB",Name:"泰铢"},
  {Code:"TJS",Name:"塔吉克斯坦索莫尼"},
  {Code:"TMT",Name:"土库曼斯坦马纳特"},
  {Code:"TND",Name:"突尼斯第纳尔"},
  {Code:"TOP",Name:"汤加潘加"},
  {Code:"TRY",Name:"土耳其里拉"},
  {Code:"TTD",Name:"特立尼达多巴哥元"},
  {Code:"TWD",Name:"新台币"},
  {Code:"TZS",Name:"坦桑尼亚先令"},
  {Code:"UAH",Name:"乌克兰格里夫纳"},
  {Code:"UGX",Name:"乌干达先令"},
  {Code:"USD",Name:"美元"},
  {Code:"UYU",Name:"乌拉圭比索"},
  {Code:"UZS",Name:"乌兹别克斯坦苏姆"},
  {Code:"VEF",Name:"委内瑞拉玻利瓦尔"},
  {Code:"VND",Name:"越南盾"},
  {Code:"VUV",Name:"瓦努阿图瓦图"},
  {Code:"WST",Name:"萨摩亚塔拉"},
  {Code:"XAF",Name:"中非法郎"},
  {Code:"XAG",Name:"银价盎司"},
  {Code:"XAU",Name:"金价盎司"},
  {Code:"XCD",Name:"东加勒比元"},
  {Code:"XCP",Name:"铜价盎司"},
  {Code:"XDR",Name:"IMF特别提款权"},
  {Code:"XOF",Name:"西非法郎"},
  {Code:"XPD",Name:"钯价盎司"},
  {Code:"XPF",Name:"太平洋法郎"},
  {Code:"XPT",Name:"珀价盎司"},
  {Code:"YER",Name:"也门里亚尔"},
  {Code:"ZAR",Name:"南非兰特"},
  {Code:"ZMW",Name:"赞比亚克瓦查"},
  {Code:"ZWL",Name:"津巴布韦元"}
]

let router = new Router();

router.get('/cnyrate/:code.html', async (ctx: Context, next: Function) => {
  let code = ctx.params.code.toUpperCase()

  let newmarket = '120'

  let quotecode =  newmarket + '.' + code
  let baseinfo = await cnyrate.getBaseInfo(quotecode)

  if (baseinfo == null) {
    await next()
    return
  }

  let name = baseinfo.f58

  let code1 = code.substring(0, 3)
  let code2 = code.substring(3, 6)
  let notcny = code1 == "CNY" ? code2 : code1

  let stock1 = codetable.find(v=>v.Code == code1)
  let stock2 = codetable.find(v=>v.Code == code2)

  //查询代码是否存在
  if (stock1 == undefined || stock2 == undefined) {
    console.info(111)
    
    await next()
    return
  }  

  let ItemName = stock1.Name + stock2.Name
  let CurrencyTitles = [stock1.Name, stock2.Name]

  let TrendsModuleObject = codetable.find(v=>v.Code == notcny)
  let USDTrendsModuleObject = codetable.find(v=>v.Code == 'USD')
  // console.info(notcny)
  
  // console.info(TrendsModuleObject)
  
  let TrendsModule = { //其他品种
      Title: cnyrate.newsids.hasOwnProperty(notcny) ? (TrendsModuleObject!).Name : (USDTrendsModuleObject!).Name,
      Code: cnyrate.newsids.hasOwnProperty(notcny) ? notcny : "USD"
  }


  let [
    AvgCNYRateMonthly,
    CNYNews, //人民币资讯
    TrendsModuleNews, //其他品种新闻
    DaoduHtml,
    CommentHtml,
    GubaPopUser,
    FinanceCalendar
  ] = await Promise.all([
    cnyrate.getAvgCNYRateMonthly(),
    cnyrate.getNews('CYN'),
    cnyrate.getNews(notcny),
    common.getCMSNewsByColumn('764'),
    common.getCMSNewsByColumn('130'),
    common.getGuBaActiveUserList('waihui', 20),
    forex.getFinanceCalendar()
  ])  
  

  await ctx.render('cnyrate/cnyrate', {
    layout: 'shared/layout_cnyrate',
    CurrencyTitles: CurrencyTitles,
    ItemName: ItemName,
    ItemCode: code,
    name: name,
    Title: name,
    TimeNow: moment().format('YYYY-MM-DD dddd HH:mm'),
    Time: moment().subtract(1, 'months').format('YYYY年MM月'),
    AvgCNYRateMonthly: AvgCNYRateMonthly,
    CNYNews: CNYNews,
    txtLeft: txt.txtLeft,
    TrendsModuleNews: TrendsModuleNews,
    TrendsModule: TrendsModule,
    DaoduHtml: DaoduHtml,
    CommentHtml: CommentHtml,
    GubaPopUser: GubaPopUser,
    FinanceCalendar: FinanceCalendar,
    ForexKVName: TrendsModuleObject!.Name,
    newmarket: newmarket
  })
})


module.exports = router