/**
 * 期货
 */

import { Context } from "koa"
import Router from 'koa-router'
import qihuo from "../modules/stockinfo/qihuo";
import pagecache from "../modules/pagecache"

const qihuo_page_cache = pagecache({
  cachetime: 2 * 60 * 1000,
  file_cachetime: 30 * 60 * 1000
})


let router = new Router();



router.get('/qihuo/:code.html', qihuo_page_cache, async (ctx: Context, next: Function) => {
  let code = ctx.params.code

  let baseinfo = await qihuo.stockinfo(code)

  if(baseinfo == null){
    await next()
    return
  }



  let ExchangeType = 'SHFE'
  let stockMarket = '1'

  switch (baseinfo.market) {
    case 113:
      ExchangeType = 'SHFE'
      stockMarket = '1'
      break;
    case 142:
      ExchangeType = 'INE'
      stockMarket = 'INE'
      break;  
    case 114:
      ExchangeType = 'DCE'
      stockMarket = '3'
      break;
    case 115:
      ExchangeType = 'CECE'
      stockMarket = '4'
      break;        
    default:
      break;
  }

  let StockID = baseinfo.code + stockMarket

  let exchange = "上海期货交易所";
  let exchangeEX = "上期所";
  let exchangeListUrl = "http://quote.eastmoney.com/center/futurelist.html#11_5_0";
  if (ExchangeType == "DCE") {
      exchange = "大连商品交易所";
      exchangeEX = "大商所";
      exchangeListUrl = "http://quote.eastmoney.com/center/futurelist.html#3_5_1";
  }
  else if (ExchangeType == "CZCE") {
      exchange = "郑州商品交易所";
      exchangeEX = "郑商所";
      exchangeListUrl = "http://quote.eastmoney.com/center/futurelist.html#4_5_2";
  }
  else if (ExchangeType == "INE")
  {
      exchange = "上海能源期货交易中心";
      exchangeEX = "上期能源";
      exchangeListUrl = "http://quote.eastmoney.com/center/futurelist.html#ine_5_5";
  }
  let WapUrl = "https://emwap.eastmoney.com/quota/stock/index/" + StockID;


  let [
    News,
    Comment
  ] = await Promise.all([
    qihuo.getCMSNews(baseinfo.market, baseinfo.type, 1),
    qihuo.getCMSNews(baseinfo.market, baseinfo.type,2)
  ])
  

  await ctx.render('qihuo/qihuo', {
    layout: 'shared/layout_qihuo',
    StockName: baseinfo.name,
    MktNum: baseinfo.market,
    StockCode: baseinfo.code,
    StockID: StockID,
    StockMarket: stockMarket,
    GubaCode: 'f' + ExchangeType + baseinfo.code,
    Relate: 'SI00Y0,QI00Y0,JAGC0',
    ExchangeType: ExchangeType,
    TypeCode: 'F_SHFE_AG',
    zl: '',
    HyId: '',
    FutureType: '沪银',
    NewsId: '',
    CommentId: '',
    DataCenterCode: '',
    TypeUS: baseinfo.type,
    Title:  baseinfo.name + "(" + baseinfo.code + ")",
    WapUrl: WapUrl,
    exchange: exchange,
    exchangeEX: exchangeEX,
    exchangeListUrl: exchangeListUrl,
    News:News,
    Comment: Comment
  })
})

 
module.exports = router