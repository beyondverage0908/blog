/**
 * 债券
 */

import { Context } from "koa"
import Router from 'koa-router'
import a from "../modules/stockinfo/a"
import b from "../modules/stockinfo/b"
import bond from "../modules/stockinfo/bond"
import txt from "../modules/txt";
import moment from "moment";
import pagecache from "../modules/pagecache"

const bond_page_cache = pagecache({
  cachetime: 2 * 60 * 1000,
  file_cachetime: 30 * 60 * 1000
})


let router = new Router();



router.get('/bond/:marketstr(sz|sh):code.html', bond_page_cache, async (ctx: Context, next: Function) => {
  let marketstr = ctx.params.marketstr
  let code = ctx.params.code

  let old_market = marketstr == 'sh'? '1': '2'
  let new_market = marketstr == 'sh'? '1': '0'

  let newcode = new_market + '.' + code

  let baseinfo = await a.stockinfo(newcode)

  if (baseinfo == null) {
    await next()
    return
  }

  /**
   * 是否是可转债
   */
  let IsConversionDebt = false

  //判断是不是可转债
  IsConversionDebt = ["110", "113", "123", "127","128"].some(v=>{
    return code.indexOf(v) == 0
  })


  let [
    FocusNews,
    Analysis,
    Notices,
    hotguba
  ] = await Promise.all([
    bond.getFocusNews(),
    bond.getAnalysis(),
    bond.getNotices(IsConversionDebt, old_market),
    b.hotGuba()
  ])

  await ctx.render('bond/bond', {
    layout: 'shared/layout_bond',
    StockID: code + old_market,
    StockCode: code,
    StockType: marketstr,
    StockName: baseinfo.Name,
    StockMarket: old_market,
    GubaCode: code,
    MktNum: new_market,
    Title: baseinfo.Name + "(" + code + ")",
    ServerTime: moment().format('YYYY-MM-DD HH:mm:ss'),
    FocusNews: FocusNews,
    Analysis: Analysis,
    txtLeft: txt.txtLeft,
    Notices: Notices,
    IsConversionDebt: IsConversionDebt,
    hotguba: hotguba
  })
})


module.exports = router