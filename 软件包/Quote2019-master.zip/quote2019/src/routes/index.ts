import { Context } from "koa"
import Router from 'koa-router'
import moment from "moment";
import a from "../modules/stockinfo/a";
import common from "../modules/stockinfo/common";
import b from "../modules/stockinfo/b";
import txt from "../modules/txt";
import lodash from "lodash";
import fund from "../modules/stockinfo/fund";
import pagecache from "../modules/pagecache"



let router = new Router();

//首页
router.get('/', async (ctx:Context, next: Function) => {
  ctx.body = 'hello new quote'
})

const a_page_cache = pagecache({
  cachetime: 2 * 60 * 1000,
  file_cachetime: 30 * 60 * 1000
})

/**
 * A股
 */
router.get('/:marketstr(sz|sh):code(\\d{6}).html', a_page_cache, async (ctx:Context, next: Function) => {
  let marketstr = ctx.params.marketstr
  let market = '0'
  if (marketstr == 'sh') {
    market = '1'
  }
  let code = ctx.params.code

  let newcode = market + '.' + code

  let baseinfo = await a.stockinfo(newcode)

  // console.info(baseinfo)
  

  if (baseinfo == null) {
    await next()
    return
  }



  if (market == '0' && ['6', '13', '80'].indexOf(baseinfo.level2type.toString()) >= 0) { //深圳A股
    await routeA(market, code, baseinfo, ctx, next)
  }
  else if (market == '1' && baseinfo.level2type == '2') { //上海A股
    await routeA(market, code, baseinfo, ctx, next)
  }
  else if ((market == '0' && baseinfo.level2type == '7') || market == '1' && baseinfo.level2type == '3') { //B股
    await routeB(market, code, baseinfo, ctx, next)
  }
  else if ((market == '0' && baseinfo.level2type == '10') || market == '1' && baseinfo.level2type == '9') { //基金
    await routeFund(market, code, baseinfo, ctx, next)
  }
  else if (market == '0' && baseinfo.level2type == '81') { //新三板
    ctx.redirect(`http://xinsanban.eastmoney.com/QuoteCenter/${code}.html`)
  }
  else if (market == '0' && baseinfo.level2type == '5') { //深圳指数
    ctx.redirect(`http://quote.eastmoney.com/zs${code}.html`)
  }  
  else if (market == '1' && baseinfo.level2type == '1') { //上海指数
    ctx.redirect(`http://quote.eastmoney.com/zs${code}.html`)
  } 
  else if (market == '0' && baseinfo.level2type == '8') { //深圳债券
    ctx.redirect(`http://quote.eastmoney.com/bond/sz${code}.html`)
  }   
  else if (market == '1' && baseinfo.level2type == '4') { //上海债券
    ctx.redirect(`http://quote.eastmoney.com/bond/sh${code}.html`)
  }
  else if (market == '1' && baseinfo.level2type == '23') { //上海科创板
    ctx.redirect(`http://quote.eastmoney.com/kcb/${code}.html`)
  }
  else{
    await next()
  }
  
})

/**
 * A股 中小板 创业板
 */
async function routeA(market:string, code:string, baseinfo:any,ctx:Context, next: Function){

    let market_str = 'sz'
    let market_old = '2'
    let market_new = '0'

    if (ctx.path.substring(1,3) == 'sh') {
      market_str = 'sh'
      market_old = '1'
      market_new = '1'
    }

    // let newcode = market_new + '.' + code

    // let baseinfo = await a.stockinfo(newcode)

    // if (baseinfo == null) {
    //   await next()
    //   return
    // }

    // #region 判断是否是指数
    if (market_new == '0' && baseinfo.level2type == 5) {
      ctx.redirect('./zs' + code + '.html')
      return
    }  

    if (market_new == '1' && baseinfo.level2type == 1) {
      ctx.redirect('./zs' + code + '.html')
      return
    }
    // #endregion

    let [
      Calendar,
      GetBulletin266,
      GetBulletin241,
      GgxwList,
      GsggList,
      //YjbgList,
      GbggHtml,
      ZjlxggHtml,
      GuBaActiveUserList,
      Ltgd,
      vote
    ] = await Promise.all([
      a.stockCalendar(code, market_str),
      a.getBulletin('266'),
      a.getBulletin('1071'),
      a.getGgxw(code, 5, 40),
      a.getGonggao(code, 5),
      //a.getStockReport(code, 5, 8, 22),
      a.getPageHtml('http://bulletin.eastmoney.com/html/base/979.html'),
      a.getPageHtml('http://bulletin.eastmoney.com/html/base/704.html'),
      common.getGuBaActiveUserList(code, 20),
      a.getLtgd(code),
      a.getVote(market_str + code)
    ])

    // let HyybList = await a.getHYReport(baseinfo.oldHY, 5, 8, 22)
    
    await ctx.render('a/a', {
      layout: 'shared/layout_a',
      txtLeft: txt.txtLeft,
      Stock: {
        code: code, //300059
        Name: baseinfo.Name, //东方财富
        HyId: baseinfo.oldHY, //447
        market_str: market_str, //sz
        market_old: market_old, //2
        Market_10: market_new,
        Market_12: market_old,
        MarketCode: market_str + code, //sz300059
        market_new: market_new,
        HYName: baseinfo.HYName, //行业名称
        IsAG: 1,
        Lstng: baseinfo.isSH?'1':'0',
        CekTp: "1"
      },
      CompanyCoreData: {
        SSRQ: baseinfo.SSDateFormat,
        isnew: 0      
      },
      Calendar: Calendar,
      moment: moment,
      Company10CirculateShareHolder: {},
      GetBulletin266: GetBulletin266,
      GetBulletin241: GetBulletin241,
      RelatedBkHtml: '',
      GgxwList: GgxwList,
      HyywList: '',
      GsggList: GsggList,
      //YjbgList: YjbgList,
      // HyybList: HyybList,
      GbggHtml: GbggHtml,
      ZjlxggHtml: ZjlxggHtml,
      GuBaInfos: [],
      GuBaActiveUserList: GuBaActiveUserList,
      vote: vote,
      Ltgd: Ltgd,
      _has: lodash.has,
      _get: lodash.get
    })
}

/**
 * B股
 */
async function routeB(market:string, code:string, baseinfo:any,ctx:Context, next: Function){

  let market_str = 'sz'
  let old_market = '2'
  if (market == '1') {
    market_str = 'sh'
    old_market = '1'
  }

  let [
    hotguba,
    stocknotice
  ] = await Promise.all([
    b.hotGuba(),
    b.getStockNotice(code)
  ])

  await ctx.render('b/b', {
    code: code,
    layout: 'shared/layout_b',
    marketSHSZ: market_str,
    market: market,
    old_market: old_market,
    StockID: code + old_market,
    StockName: txt.ToCDBRemoveBlank(baseinfo.Name),
    title: baseinfo.Name + '(' + code + ')',
    hotguba: hotguba,
    stocknotice: stocknotice
  })
}

/**
 * 基金
 */
async function routeFund(market:string, code:string, baseinfo:any,ctx:Context, next: Function){

  let market_str = 'sz'
  let old_market = '2'
  if (market == '1') {
    market_str = 'sh'
    old_market = '1'
  }

  let [
    fundnews,
    fundnotice,
    hotguba
  ] = await Promise.all([
    fund.getFundNews(baseinfo.Name),
    fund.getFundNotice(code),
    b.hotGuba()
  ])

  await ctx.render('fund/fund', {
    code: code,
    layout: 'shared/layout_fund',
    title: baseinfo.Name + '(' + code + ')',
    old_market: old_market,
    StockID: code + old_market,
    StockName: baseinfo.Name,
    market: market,
    GubaCode: 'of' + code,
    market_str: market_str,
    fundnews: fundnews,
    fundnotice: fundnotice,
    txtLeft: txt.txtLeft,
    hotguba: hotguba
  })
}

module.exports = router