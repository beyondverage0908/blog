/**
 * 全屏页面
 */


import { Context } from "koa"
import Router from 'koa-router'
import pagecache from "../modules/pagecache"

const fullscreen_page_cache = pagecache({
  cachetime: 2 * 60 * 1000,
  file_cachetime: 30 * 60 * 1000
})


let router = new Router();



router.get('/fullscreen/full.html', fullscreen_page_cache, async (ctx: Context, next: Function) => {
  
  await ctx.render('fullscreen/full', {
    layout: 'fullscreen/layout_full'
  })
})

router.get('/fullscreen/h5chart.html', fullscreen_page_cache, async (ctx: Context, next: Function) => {
  
  await ctx.render('fullscreen/h5chart', {
    layout: 'fullscreen/layout_h5chart'
  })
})

router.get('/fullscreen/kcbh5chart.html', fullscreen_page_cache, async (ctx: Context, next: Function) => {
  
  await ctx.render('fullscreen/kcbh5chart', {
    layout: 'fullscreen/layout_h5chart'
  })
})

 
module.exports = router