/**
 * 美股
 */

import { Context } from "koa"
import Router from 'koa-router'
import us from "../modules/stockinfo/us";
import txt from "../modules/txt";
import pagecache from "../modules/pagecache"

const us_page_cache = pagecache({
  cachetime: 2 * 60 * 1000,
  file_cachetime: 30 * 60 * 1000
})

let router = new Router();



router.get('/us/:code.html', us_page_cache, async (ctx: Context, next: Function) => {
  let code = ctx.params.code.toUpperCase().replace(/_/g, '.') //BRK.A
  let newcode = code.replace(/\./g, '_') //BRK_A
  
  let marketobj = await us.getMarket(newcode) //106  

  if (marketobj == undefined) { //没有命中美股市场
    await next()
    return
  }

  let market = marketobj.f13
  let quotecode = market + '.' + newcode //106.BRK_A

  let baseinfo = await us.stockinfo(quotecode)

  if (baseinfo == null) {
    await next()
    return
  }

  let [
    StockName
   ] = [
    baseinfo.f58
   ]

  let [
    Notice,
    MarketNews,
    Comment,
    F10Bulletin
  ] = await Promise.all([
    us.getNotice(code),
    us.getMarketNews(),
    us.getComment(),
    us.getF10Bulletin(newcode)
  ])


  await ctx.render('us/us', {
    layout: 'shared/layout_us',
    // WapUrl: `https://emwap.eastmoney.com/quota/stock/index/${code}7`,
    Title: `${StockName}(${code})`,
    StockName: StockName,
    StockCode: code,
    StockMarket: 7,
    StockID: `${code}7`,
    GubaCode: `us${code}`,
    MktNum: market,
    UnifiedID: quotecode,
    Notice: Notice,
    txtLeft: txt.txtLeft,
    MarketNews: MarketNews,
    Comment: Comment,
    F10Bulletin: F10Bulletin
  })
})


module.exports = router