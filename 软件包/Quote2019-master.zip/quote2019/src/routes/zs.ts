/**
 * 指数
 */

import { Context } from "koa"
import Router from 'koa-router'
import zs from "../modules/stockinfo/zs"
import common from "../modules/stockinfo/common";
import txt from "../modules/txt";
import pagecache from "../modules/pagecache"

const zs_page_cache = pagecache({
  cachetime: 2 * 60 * 1000,
  file_cachetime: 30 * 60 * 1000
})


let router = new Router();



router.get('/zs:code(\\d{6}).html', zs_page_cache, async (ctx: Context, next: Function) => {
  let code = ctx.params.code
  
  let baseinfo = await zs.getZSInfo(code)

  if(baseinfo === null){ //没有此指数
    await next()
    return
  }

  let Market_12 = '1'
  if (baseinfo.newmarket == '1') {
    Market_12 = '1'
  }
  else if (baseinfo.newmarket == '0') {
    Market_12 = '2'
  }

  let [
    zqyw,
    dpfx,
    gskx,
    //yjbg,
    bloglist,
    dfsd,
    PicUpBulletin,
    WydcJg,
    GBRqyh,
    RzrqStr,
    cfhArtilce,
    PicDownBulletin,
    WydcDk,
    sczm
  ] = await Promise.all([
    zs.zqyw(),
    zs.dpfx(),
    zs.gskx(),
    //zs.getReport(4),
    zs.getBlog(),
    zs.getDfsd(),
    zs.getTopBulletin('978'),
    zs.getJgdc(),
    common.getGuBaActiveUserList(code, 20),
    zs.getRzrq(),
    zs.getCFH(),
    zs.getPicDownBulletin(),
    zs.getDkdc(),
    zs.sczm()
  ])
  
  
  let zjlName = Market_12 == "1" ? "沪市" : "深市"
  let zjlCode = baseinfo.newmarket == "1" ? "0000011" : "3990012"
  let zjlLink = "http://data.eastmoney.com/zjlx/zs" + (Market_12 == "1" ? "000001" : "399001") + ".html"
  let zdpCode = "IE" + code + Market_12

  if (code == "000001") { zdpCode = "SH" }
  if (code == "399001") { zdpCode = "SZ" }

  if (code == "399005") {
    zjlCode = "3990052"
    zjlName = "指数"
    zjlLink = "http://data.eastmoney.com/zjlx/zs" + code + ".html"
    zdpCode = "SZ.ZXB"
  }

  if (code == "399006") {
    zjlCode = "3990062"
    zjlName = "指数"
    zjlLink = "http://data.eastmoney.com/zjlx/zs" + code + ".html"
    zdpCode = "SZ.CYB"
  }

  await ctx.render('zs/index', {
    layout: 'shared/layout_zs',
    Stock: { 
      Code: code,
      Market_12: Market_12,
      Market_10: baseinfo.newmarket,
      Name: baseinfo.name,
      zjlCode: zjlCode,
      zdpCode: zdpCode,
      gbname: "zs" + (Market_12 == "1" ? "sh" : "sz") + code,
      zjlName: zjlName,
      zjlLink: zjlLink
    },
    Cfg: zs.GetCFGInfo(code, Market_12),
    code: code,
    cfhArtilce: cfhArtilce,
    WydcDk: WydcDk,
    Dfsd: dfsd,
    PicUpBulletin: PicUpBulletin,
    PicDownBulletin: PicDownBulletin,
    BlogList: bloglist,
    //yjbg: yjbg,
    WydcJg: WydcJg,
    GBRqyh: GBRqyh,
    Sczm: sczm,
    RzrqStr: RzrqStr,
    zqyw: zqyw,
    dpfx: dpfx,
    gskx: gskx,
    txtLeft: txt.txtLeft,
    formatNum: txt.formatNum,
    numToFixed: txt.numToFixed
  })
})


module.exports = router