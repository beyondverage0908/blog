/**
 * 科创板
 */

import { Context } from "koa"
import Router from 'koa-router'
import a from "../modules/stockinfo/a";
import pagecache from "../modules/pagecache"

const kcb_page_cache = pagecache({
  cachetime: 2 * 60 * 1000,
  file_cachetime: 30 * 60 * 1000
})


let router = new Router();



router.get('/kcb/:code(\\d{6}).html', kcb_page_cache, async (ctx: Context, next: Function) => {
  let code = ctx.params.code

  let newcode = '1.' + code
  
  let baseinfo = await a.stockinfo(newcode)

  if (baseinfo == null) {
    await next()
    return
  }

  await ctx.render('kcb/kcb', {
    layout: 'shared/layout_kcb',
    Stock: '',
    ID: '',
    UnifiedID: newcode,
    UnifiedCode: code,
    Code: code,
    Name: baseinfo.Name,
    MktNum: '1',
    Title: `${baseinfo.Name}(${code})`,
    GetBulletin241: ''
  })
})

 
module.exports = router