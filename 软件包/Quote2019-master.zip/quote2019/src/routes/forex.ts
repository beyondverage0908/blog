/**
 * 外汇
 */

import { Context } from "koa"
import Router from 'koa-router'
import forex from "../modules/stockinfo/forex"
import common from "../modules/stockinfo/common"
import zs from "../modules/stockinfo/zs"

import bond from "../modules/stockinfo/bond"
import txt from "../modules/txt";
import moment from "moment";


let router = new Router();

/**
 * 处理外汇名称
 * @param name 外汇名称
 */
function dealName(name:string):Array<string> {

  let nameList = ['', '']

  if (name.length == 4){
      nameList[0] = name.substring(0, 2);
      nameList[1] = name.substring(1, 2);
  }
  else if (name.indexOf("人民币") >= 0)
  {
      if (name.indexOf("人民币") == 0)
      {
          nameList[0] = "人民币";
          if (name.indexOf("竞价") >= 0)
          {
              nameList[1] = name.replace("竞价", "").replace("人民币", "");
          }
          if (name.indexOf("询价") >= 0)
          {
              nameList[1] = name.replace("询价", "").replace("人民币", "");
          }
      }
      else
      {
          nameList[1] = "人民币";
          if (name.indexOf("竞价") >= 0)
          {
              nameList[0] = name.replace("竞价", "").replace("人民币", "");
          }
          if (name.indexOf("询价") >= 0)
          {
              nameList[0] = name.replace("询价", "").replace("人民币", "");
          }
          if (name.indexOf("离岸") >= 0)
          {
              nameList[0] = name.replace("离岸", "").replace("人民币", "");
          }
      }
  }
  else
  {
      nameList[0] = name.split('兑')[0];
      nameList[1] = name.split('兑')[1];
  }

  return nameList
}

router.get('/forex/:code.html', async (ctx: Context, next: Function) => {
  let code = ctx.params.code.toUpperCase()

  if (code == 'USDCNY') {
    ctx.redirect('/cnyrate/USDCNYC.html')
    return
  }  

  let baseinfo = await forex.getBaseInfo(code)

  if (baseinfo == null) {
    await next()
    return 
  }

  let newmarket = baseinfo.market
  let newcode = newmarket + '.' + code  

  if (!baseinfo) {
    await next()
    return
  }

  // console.info(baseinfo)

  let CurrencyTitles = dealName(baseinfo.name)

  let [
    Zhibo,
    Daodu,
    Comment,
    Point,
    Trends,
    FinanceCalendar,
    GubaPopUser
  ] = await Promise.all([
    forex.getZhiBo(),
    common.getCMSNewsByColumn('764'),
    common.getCMSNewsByColumn('130'),
    common.getCMSNewsByColumn('837'),
    common.getCMSNewsByColumn('131'),
    forex.getFinanceCalendar(),
    common.getGuBaActiveUserList('waihui', 20)
  ])  

  await ctx.render('forex/forex', {
    layout: 'shared/layout_forex',
    ItemName: baseinfo.name,
    ItemCode: code,
    newmarket: newmarket,
    Zhibo: Zhibo,
    Daodu: Daodu,
    Comment: Comment,
    Point: Point,
    Trends: Trends,
    txtLeft: txt.txtLeft,
    CurrencyTitles: CurrencyTitles,
    ForexName: CurrencyTitles,
    ForexCode: [code.substring(0, 3), code.substring(3, 6)],
    FinanceCalendar: FinanceCalendar,
    GubaPopUser: GubaPopUser
  })
})


module.exports = router