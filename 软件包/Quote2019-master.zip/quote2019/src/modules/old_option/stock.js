//require(["baseStock", "common"], function (baseStock, common) {

var baseStock = require('../old_b/basestock')
var common = require('../old_b/common')

    function Stock() {
        baseStock.call(this);  //第二次调用基类的构造函数
        //this.stockType = "A";
    }

    Stock.prototype = new baseStock();    //第一次调用基类的构造函数

    //沪深涨幅排行 zxw
    Stock.prototype.setStockHS = function () {
        var url = instance.baseUrl + "/api/qt/clist/get?pi=0&pz=6&po=1&ut=" + instance.ut + "&fs=m:0+t:6,m:0+t:13,m:0+t:80,m:1+t:2&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2"
        common.jsonPnew(url, function (json) {
            var data = json.data.diff
            var html = '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th><th>加自选</th></tr>';
            for (var i in data) {
                var color = data[i].f2 > 0 ? "red" : data[i].f2 < 0 ? "green" : ""
                var price = data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)
                var zdf = data[i].f2 == '-' ? '-' : ((data[i].f3 / 100).toFixed(2) + '%')
                var jlr = (data[i].f62 + '').NumbericFormat()
                var stockName = data[i].f14
                var stockID = data[i].f13 == '1' ? ('sh' + data[i].f12) : ('sz' + data[i].f12)
                html += '<tr><td><a href="http://quote.eastmoney.com/' + stockID + '.html" target="_blank">' + stockName + '</a>' +
                    '</td><td class="' + color + '">' + price + '</td>' +
                    '<td class="' + color + '">' + zdf + '</td>' +
                    '<td class="addZix"><a href="http://quote.eastmoney.com/favor/infavor.aspx?code=' + data[i].f12 + '" target="_self"><i></i>自选</a></td></tr>';
            }
            html += "</tbody>";
            $("#stockTable").html(html);
        });
    }

    //沪深资金流向排行  zxw
    Stock.prototype.setStockZjl = function () {
        var url = instance.baseUrl + "/api/qt/clist/get?pi=0&pz=6&po=1&ut=" + instance.ut + "&fs=m:0+t:6,m:0+t:13,m:0+t:80,m:1+t:2&fid=f62&fields=f1,f2,f3,f12,f13,f14,f152,f62&invt=2"
        common.jsonPnew(url, function (json) {
            var data = json.data.diff
            var html = '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th><th>净流入</th></tr>';
            for (var i in data) {
                var jlrcolor = data[i].f62 > 0 ? "red" : data[i].f62 < 0 ? "green" : ""
                var zxjcolor = data[i].f2 > 0 ? "red" : data[i].f2 < 0 ? "green" : ""
                var price = data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)
                var zdf = data[i].f2 == '-' ? '-' : ((data[i].f3 / 100).toFixed(2) + '%')
                var jlr = (data[i].f62 + '').NumbericFormat()
                var stockName = data[i].f14
                var stockID = data[i].f13 == '1' ? ('sh' + data[i].f12) : ('sz' + data[i].f12)
                html += '<tr><td style="text-indent: 0px;"><a href="http://quote.eastmoney.com/' + stockID + '.html" target="_blank">' + stockName + '</a>' +
                    '</td><td style="text-indent: 0px;" class="' + zxjcolor + '">' + price + '</td>' +
                    '<td style="text-indent: 0px;"  class="' + zxjcolor + '">' + zdf + '</td>' +
                    '<td style="text-indent: 0px;"  class="' + jlrcolor + '">' + jlr + '</td></tr>';
            }
            html += "</tbody>";
            $("#zjlTable").html(html);
        });
    }

    var instance = new Stock();

    var fieldList = [
        { "name": "jk", "num": 3, "hasColor": true, "NumbericFormat": false },
        { "name": "zs", "num": 8, "hasColor": false, "NumbericFormat": false },
        { "name": "zxj", "num": 0, "hasColor": true, "NumbericFormat": false },
        { "name": "zde", "num": 11, "hasColor": true, "NumbericFormat": false },
        { "name": "zdf", "num": 12, "hasColor": true, "NumbericFormat": false },
        { "name": "np", "num": 10, "hasColor": false, "NumbericFormat": false },
        { "name": "wp", "num": 6, "hasColor": false, "NumbericFormat": false },
        { "name": "zgj", "num": 1, "hasColor": true, "NumbericFormat": false },
        { "name": "zdj", "num": 2, "hasColor": true, "NumbericFormat": false },
        { "name": "cjl", "num": 4, "hasColor": false, "NumbericFormat": true },
        { "name": "cje", "num": 5, "hasColor": false, "NumbericFormat": true },
        { "name": "mlj", "num": 16, "hasColor": false, "NumbericFormat": false },
        { "name": "mcj", "num": 17, "hasColor": false, "NumbericFormat": false },
        { "name": "zf", "num": 13, "hasColor": false, "NumbericFormat": false },
        { "name": "lb", "num": 14, "hasColor": false, "NumbericFormat": false }
    ];

    //全球市场行情
    var globalUrl = instance.baseUrl + "/api/qt/ulist.np/get?secids=1.000001,0.399001,100.N225,100.HSI,100.DJIA,100.NDX,100.SPX,100.FTSE,100.GDAXI,100.FCHI,100.TOP40&ut=" + instance.ut + "&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2"

    //全球市场行情
    var globalFutureUrl = instance.baseUrl + "/api/qt/ulist.np/get?secids=102.CL00Y,112.BC,101.GC00Y,101.SI00Y,111.JRUC,104.CN00Y,109.LALS,109.LCPS,103.ZS00Y,103.ZC00Y,108.CTC&ut=" + instance.ut + "&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2";

    //外汇行情
    var forexUrl = instance.baseUrl + "/api/qt/ulist.np/get?secids=100.UDI,121.USDCNYI,133.USDCNH,119.EURUSD,119.USDJPY,119.GBPUSD,119.AUDUSD,119.USDHKD,119.USDCHF,119.NZDUSD&ut=" + instance.ut + "&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2"

    //港股涨跌幅
    var hkUrl = instance.baseUrl + "/api/qt/clist/get?pn=1&pz=5&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=m:116+t:3,m:116+t:4&fields=f1,f2,f3,f12,f13,f14,f152"

    //美股涨跌幅
    var usUrl = instance.baseUrl + "/api/qt/clist/get?ut=" + instance.ut + "&pi=0&pz=6&po=1&fs=b:MK0201&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152"

    //国内期货行情报价
    var cnFutureUrl = instance.baseUrl + "/api/qt/ulist.np/get?secids=8.040120,8.060120,8.070120,8.050120,113.cum,113.agm,113.RBM,113.IM,114.MM,114.LM,115.SRM&ut=" + instance.ut + "&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2"

    //instance.loadHqData().intital(fieldList);

    var hqurl = instance.baseUrl + '/api/qt/stock/get?secid=' + window.stockEnity.fullcode + '&ut=' + instance.ut + '&fields=f191,f192,f117,f43,f51,f52,f169,f170,f46,f60,f84,f116,f44,f45,f171,f126,f47,f48,f168,f164,f49,f161,f55,f92,f59,f152,f167,f50,f532,f86&invt=2'
    // instance.loadnewHqData(hqurl, 'qq').intital(fieldList, 'qq'); //zxw

    // instance.loadnewHqData().intital(fieldList);

    // instance.bindChartImgEvent().bindEvent();
    // instance.getArticle(350, "articleDiv1");
    // instance.getArticle(351, "articleDiv2");
    // instance.getArticle(353, "articleDiv3");
    // instance.getArticle(349, "articleDiv4");
    instance.setHotGuba(14);
    //guba.init("gubalisttable", "cjpl", { listcount: 12, titlecut: 42 });
    init();

    //接口地址
    //正式接口地址
    var qihuo_url = "http://futsse.eastmoney.com";
    var fan_qihuo_url = "http://" + Math.floor(Math.random() * 100 + 1) + ".futsse.eastmoney.com";


    //测试接口地址
    if (common.getQueryString("hq-env") === "test") {
        qihuo_url = "http://futssetest.eastmoney.com";
        fan_qihuo_url = "http://futssetest.eastmoney.com";
    }



    //市场和code  暂时写死
    //   var qihuo_market = 'NYMEX',
    //       qihuo_code = 'NG00Y',
    //       qihuo_mktcode = '102_ng',
    //       qihuo_mkt = '102',
    //       qihuo_mktc = '4';
    //  var zuoshou = '';

    var qihuo_market = stockEnity.MktNum;

    var qihuo_code = stockEnity.stockCode.substr(0, 2).toLowerCase() + stockEnity.stockCode.substr(2);

    getHeadData();


    setInterval(function () {
        init();
    }, 20 * 1000);

    function init() {
        instance.stockBroadcast().init();
        instance.setStockHS();
        instance.setStockZjl();
        // instance.bindDataTemplatenew(globalUrl, "globalTable", "global");// zxw
        // // instance.bindDataTemplatenew(globalFutureUrl, "globalFutureTable", "globalFuture");// zxw
        // instance.bindDataTemplatenew(forexUrl, "forexTable", "forex");// zxw
        // instance.bindDataTemplatenew(hkUrl, "hkTable", "hk"); // zxw
        // instance.bindDataTemplatenew(usUrl, "usTable", "us"); // zxw


        mybindDataTemplatenew(globalUrl, "globalTable", "global");
        mybindDataTemplatenew(forexUrl, "forexTable", "forex");
        mybindDataTemplatenew(hkUrl, "hkTable", "hk");
        mybindDataTemplatenew(usUrl, "usTable", "us");
        // instance.bindDataTemplatenew(cnFutureUrl, "futureTable", "future"); // zxw
        // instance.bindChartImgEvent().changeImg();
    }

    function mybindDataTemplatenew(url, containerId, type) {
        var html = "";
        $.ajax({
            type: "GET",
            url: url,
            data: null,
            dataType: 'jsonp',
            jsonp: 'cb',
            success: function (res) {
                var data = res.data.diff;
                var json = []
                if (type == 'AB' || type == 'guba' || type == 'AB_NO' || type == 'future' || type == 'us' || type == 'globalFuture' || type == 'global') {
                    if (data instanceof Array) {
                        for (var i = 0; i < data.length; i++) {
                            var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)) + ',' + (data[i].f3 == '-' ? '-' : ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%'))
                            json.push(stritem)
                        }
                    } else {
                        for (var i in data) {
                            var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 == '-' ? data[i].f2 : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1)) + ',' + (data[i].f3 == '-' ? '-' : ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%'))
                            json.push(stritem)
                        }
                    }
                } else if (type == 'ZDF') {
                    for (var i in data) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(2) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                } else if (type == 'hk') {
                    for (var i = 0; i < data.length; i++) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + ((data[i].f2 == '-' ? data[i].f2 : data[i].f2.toFixed(3)) + ',' + (data[i].f3 == '-' ? data[i].f3 : (data[i].f3).toFixed(data[i].f152) + '%'))
                        json.push(stritem)
                    }
                } else if (type == 'forex') {
                    for (var i = 0; i < data.length; i++) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                }
                if (type.indexOf("NO") >= 0) {
                    html += '<tbody>';
                } else {
                    html += '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>';
                }
                for (var i = 0; i < json.length; i++) {
                    var itemlist = json[i].split(",");
                    var color = common.getColor(itemlist[4]);
                    var stockCode = itemlist[1];
                    var stockName = itemlist[2];
                    if (common.getByteLen(stockName) > 12) {
                        //判断中英文
                        if (stockName.match(/[^\x00-\xff]/ig) != null) {
                            stockName = stockName.substring(0, 6) + "..";
                        } else {
                            stockName = stockName.substring(0, 12) + "..";
                        }
                    }

                    var stockUrl = "http://quote.eastmoney.com";
                    if (type == "AB" || type == "AB_NO") {
                        if (itemlist[1].indexOf("BK") >= 0) {
                            stockUrl += "/web/" + stockCode + "1.html";
                        } else if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    } else if (type == "guba") {
                        stockUrl = "http://guba.eastmoney.com/list," + stockCode + ".html";
                        stockName += "吧";
                    } else if (type == "ZDF") {
                        if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    } else if (type == "future") {
                        if (itemlist[0] == 8) {
                            var gzname = stockName.replace("连续", "");
                            var gzcode = gzname.replace("当月", "DYLX").replace("下月", "XYLX").replace("当季", "GZDJLX");
                            if (gzname.indexOf('IF') < 0) { gzcode = gzcode.replace("LX", ""); }
                            stockUrl = "http://quote.eastmoney.com/gzqh/" + gzcode + ".html";
                        } else {
                            stockUrl = "http://quote.eastmoney.com/qihuo/" + stockCode + ".html";
                        }
                    } else if (type == "us") {
                        stockUrl = "http://quote.eastmoney.com/us/" + stockCode + ".html";
                    } else if (type == "hk") {
                        stockUrl = "http://quote.eastmoney.com/hk/" + stockCode + ".html";
                    } else if (type == "forex") {
                        if (itemlist[0] == 100) {
                            stockUrl = "http://quote.eastmoney.com/globalfuture/" + stockCode + ".html";
                        } else {
                            stockUrl = "http://quote.eastmoney.com/forex/" + stockCode + ".html";
                        }
                    } else if (type == "globalFuture") {
                        stockUrl = "http://quote.eastmoney.com/globalfuture/" + stockCode + ".html";
                    } else if (type == "global") {
                        if (itemlist[0] == 0 || itemlist[0] == 1) {
                            stockUrl = "http://quote.eastmoney.com/zs" + stockCode + ".html";
                        } else {
                            stockUrl = "http://quote.eastmoney.com/gb/zs" + stockCode + ".html";
                        }
                    }
                    html += '<tr>'
                        + '<td>'
                        + (stockUrl ? ('<a href="' + stockUrl + '" target="_blank" title="' + itemlist[2] + '">' + stockName + '</a>') : stockName)
                        + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[3]) + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[4]) + '</td>'
                        + '</td></tr>';
                }

                html += "</tbody>";
                $("#" + containerId).html(html);

            }
        });
    }


    //期货换源
    function getHeadData() {
        // var secids = stockentry.marketnum +'.' + stockentry.code;
        //正式地址：
        // var url = "http://" + (Math.floor(Math.random() * 99) + 1) +".push2.eastmoney.com/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f152,f288,f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f31,f32,f33,f34,f35,f36,f37,f38,f39,f40,f20,f19,f18,f17,f16,f15,f14,f13,f12,f11,f531&secid=" + secids;

        //测试地址：
        var url = qihuo_url + "/static/" + qihuo_market + "_" + qihuo_code + "_qt?callbackName=aa";

        $.ajax({
            url: url,
            scriptCharset: "utf-8",
            dataType: "jsonp",
            jsonp: "cb",
            jsonpCallback: 'aa',
            success: function (json) {
                // console.log('json');
                // console.log(json);
                if (json.qt) {
                    formatHead(json.qt);

                    //增加判断浏览器是否为ie7及以下
                    if (document.all && !document.querySelector) {
                        setInterval(function () {
                            getHeadData();
                        }, 15 * 1000);

                    } else {
                        sseHeadData();
                    }


                    zuoshou = json.qt.zjsj;

                    //画图
                    if (json.qt.dm && json.qt.sc) {

                        if (json.qt.sc == "221") {
                            json.qt.sc = "11";
                        }

                        stockId = json.qt.sc + '.' + json.qt.dm;

                        var imgevt = instance.bindChartImgEvent()
                        imgevt.bindEvent(stockId);
                        imgevt.changeImg("r", stockId)
                        imgevt.changeImg("k", stockId)

                    }
                }



            }
        });

    }

    //sse
    function sseHeadData() {
        // var secids = stockentry.marketnum +'.' + stockentry.code;

        //测试地址
        var url = fan_qihuo_url + "/sse/" + qihuo_market + "_" + qihuo_code + "_qt";
        //正式地址
        //var url = "http://" + (Math.floor(Math.random() * 99) + 1) +".push2.eastmoney.com/api/qt/stock/sse?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f152,f288,f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f31,f32,f33,f34,f35,f36,f37,f38,f39,f40,f20,f19,f18,f17,f16,f15,f14,f13,f12,f11,f531&secid=" + secids;


        var evtSource = new EventSource(url);
        evtSource.onmessage = function (json) {
            // console.log('head sse 推送')
            var obj = JSON.parse(json.data)
            // console.log(obj)

            if (obj.qt) {
                formatHead(obj.qt);
            }
        }


    }

    //head format
    var headSourceData;
    function formatHead(data) {
        renderHead(data)
    }

    //渲染头部
    function renderHead(items) {
        var list = [
            { "name": "zxj", "item": items.p == "-" ? "-" : cancelZsjd(items.p, items.zsjd), "color": getColor(items.zdf) },
            { "name": "zde", "item": items.zde == "-" ? "-" : cancelZsjd(items.zde, items.zsjd), "color": getColor(items.zdf) },
            { "name": "zdf", "item": items.zdf == "-" ? "-" : (items.zdf).toFixed(2) + '%', "color": getColor(items.zdf) },
            { "name": "jk", "item": items.o == "-" ? "-" : cancelZsjd(items.o, items.zsjd), "color": getColor(items.o - items.qrspj) },
            { "name": "zgj", "item": items.h == "-" ? "-" : cancelZsjd(items.h, items.zsjd), "color": getColor(items.h - items.qrspj) },
            { "name": "cjl", "item": items.vol == "-" ? "-" : NumbericFormat(items.vol) },
            { "name": "mlj", "item": items.mrj == "-" ? "-" : cancelZsjd(items.mrj, items.zsjd), "color": getColor(items.mrj - items.qrspj) },
            { "name": "np", "item": items.np == "-" ? "-" : NumbericFormat(items.np), "color": 'green' },
            { "name": "zs", "item": items.qrspj == "-" ? "-" : cancelZsjd(items.qrspj, items.zsjd) },
            { "name": "zdj", "item": items.l == "-" ? "-" : cancelZsjd(items.l, items.zsjd), "color": getColor(items.l - items.qrspj) },
            { "name": "cje", "item": items.cje == "-" ? "-" : NumbericFormat(items.cje) },
            { "name": "mcj", "item": items.mcj == "-" ? "-" : cancelZsjd(items.mcj, items.zsjd), "color": getColor(items.mcj - items.qrspj) },
            { "name": "wp", "item": items.wp == "-" ? "-" : NumbericFormat(items.wp), "color": 'red' },
            { "name": "quote_title_0", "item": items.name == "-" ? "-" : items.name },
            { "name": "quote_title_1", "item": items.dm == "-" ? "-" : (items.dm).toUpperCase() },


            // { "name": "lb", "item": items.zjsj  == "-" ? "-" : items.zjsj },
            // { "name": "zjs", "item": items.zjsj  == "-" ? "-" : items.zjsj },
            // { "name": "ccl", "item": items.ccl == "-" ? "-" : NumbericFormat(items.ccl) },
            // { "name": "cc", "item": items.cclbh == "-" ? "-" : NumbericFormat(items.cclbh) },
            // { "name": "rz", "item": items.rz  == "-" ? "-" : items.rz, "color": getColor(items.rz) },

        ];
        for (var i = 0; i < list.length; i++) {
            if (list[i]) {


                var name = $("." + list[i].name);
                name.text(list[i].item);
                name.removeClass("red").removeClass("green").addClass(list[i].color);

            }
        }

        //箭头颜色
        onChangeDataRender(items.zdf);

        //时间
        if (items.jyzt == 0) {
            // var jyr = Dealjyr(items.jyr, "-")
            if (items.utime) {
                var jysj = Dealjysj(items.utime, "-");
                $("#stock_time").html('(' + jysj + ')');
            }


        } else {
            // var jyr = Dealjyr(items.jyr, "-")
            if (items.spsj) {
                var spsj = Dealjysj(items.spsj, "-");
                $("#stock_time").html('(' + spsj + ')');
            }


        }

    }


    //处理价格的展示精度
    function cancelZsjd(value, zsjd) {

        if (value !== '-') {
            return value.toFixed(zsjd);
        }


    }


    //处理数据颜色
    function getColor(str) {
        var context = str.toString();
        context = context.replace("%", "");
        if (context == 0 || isNaN(context)) {
            return "";
        } else if (context > 0) {
            return "red";
        } else {
            return "green";
        }
    }

    //处理成交量数据格式
    function NumbericFormat(string) {
        var context = Number(string);
        //var fushu = false;
        if (!isNaN(context)) {
            var item = parseInt(string);
            if ((item > 0 && item < 1e4) || (item < 0 && item > -1e4)) {
                return item;
            } else if ((item > 0 && item < 1e6) || (item < 0 && item > -1e6)) {
                item = item / 10000;
                return item.toFixed(2) + "万";
            } else if ((item > 0 && item < 1e7) || (item < 0 && item > -1e7)) {
                item = item / 10000;
                return item.toFixed(1) + "万";
            } else if ((item > 0 && item < 1e8) || (item < 0 && item > -1e8)) {
                item = item / 10000;
                return item.toFixed(0) + "万";
            } else if ((item > 0 && item < 1e10) || (item < 0 && item > -1e10)) {
                item = item / 1e8;
                return item.toFixed(2) + "亿";
            } else if ((item > 0 && item < 1e11) || (item < 0 && item > -1e11)) {
                item = item / 1e8;
                return item.toFixed(1) + "亿";
            } else if ((item > 0 && item < 1e12) || (item < 0 && item > -1e12)) {
                item = item / 1e8;
                return item.toFixed(0) + "亿";
            } else if ((item > 0 && item < 1e14) || (item < 0 && item > -1e14)) {
                item = item / 1e12;
                return item.toFixed(2) + "万亿";
            } else if ((item > 0 && item < 1e15) || (item < 0 && item > -1e15)) {
                item = item / 1e12;
                return item.toFixed(1) + "万亿";
            } else if ((item > 0 && item < 1e16) || (item < 0 && item > -1e16)) {
                item = item / 1e12;
                return item.toFixed(0) + "万亿";
            } else {
                return item;
            }
        } else
            return '-';
    }


    //处理开平
    function Dealkp(val) {
        if (val == '1') {
            return '多平'
        } else if (val == '2') {
            return '空平'
        } else if (val == '3') {
            return '多开'
        } else if (val == '4') {
            return '空开'
        } else if (val == '5') {
            return '多换'
        } else if (val == '6') {
            return '空换'
        } else if (val == '7') {
            return '双开'
        } else if (val == '8') {
            return '双平'
        } else {
            return '-'
        }

    }


    //箭头颜色变化
    function onChangeDataRender(item) {

        try {
            if(item === "-" || item == undefined){
                $("#arrow-find").hide().removeAttr("class")
            }
            else if(item == 0){
                $("#arrow-find").hide().removeClass("up-arrow").removeClass("down-arrow");
            }
            else{
                $("#arrow-find").addClass("xp2")
                if (parseFloat(item) > 0) {
                    $("#arrow-find").show().removeClass("down-arrow").addClass("up-arrow");
    
                } else if(parseFloat(item) < 0) {
                    $("#arrow-find").show().removeClass("up-arrow").addClass("down-arrow");
                }
            }
        } catch (error) {
            
        }
        // if (item != 0 && item != "-") {
        //     $("#arrow-find").addClass("xp2")
        //     if (item > 0) {
        //         $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");

        //     } else {
        //         $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
        //     }
        // }else{
           
        // }

        // if (item == 0) {
        //     $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
        // }

    }


    /**
    * 处理交易日
    * @param {number} val :值
    * @param {string} fuhao: 拼接符号
    */
    function Dealjyr(val, fuhao) {
        try {
            val = '' + val;
            if (val.length == 5) {
                val = '0' + val;
            }

            var fulltime = val.substr(0, 4) + fuhao + val.substr(4, 2) + fuhao + val.substr(6, 2);
            return fulltime;

        } catch (e) {
            return '-'
        }

    }


    /**
     * 处理交易时间
     * @param {number} val :待处理的值
     * @param {string} fuhao ：拼接符号
     */
    function Dealjysj(val, fuhao) {
        try {
            //     val = '' + val;
            //    if(val.length == 5) {
            //        val = '0' + val;
            //    } else if(val.length == 4) {
            //      val = '00' + val;
            //    } else if(val.length == 3) {
            //      val = '000' + val;
            //    } else if(val.length == 2) {
            //      val = '0000' + val;
            //    } else if(val.length == 2) {
            //      val = '0000' + val;
            //    } else if(val.length == 1) {
            //     val = '00000' + val;
            //    } else if(val == '0'){
            //      val = '000000';
            //    }


            //    var fulltime = val.substr(0,2) + fuhao + val.substr(2,2) + fuhao + val.substr(4,2);
            //    return fulltime;

            var d = new Date(val * 1000);  //("0" + (d.getMonth() + 1)).slice(-2)    d.getMinutes()  d.getMinutes()  d.getSeconds()
            var jysj = d.getFullYear() + fuhao + (("0" + (d.getMonth() + 1)).slice(-2)) + fuhao + (("0" + (d.getDate())).slice(-2)) + ' ' + ("0" + (d.getHours())).slice(-2) + ':' + ("0" + (d.getMinutes())).slice(-2) + ':' + ("0" + (d.getSeconds())).slice(-2);

            return jysj;

        } catch (e) {
            return '-'
        }

    }



    /**
     * 渲染小表格统一方法
     * @param {strig} selector :dom选择器
     * @param {object} data ：数据
     */
    function renderQthybj(selector, data) {

        var content = $(selector)
        var tbody = content.find("tbody");
        tbody.html('<tr><th class="">名称</th><th>最新价</th><th>涨跌幅</th></tr>');

        if (data) {

            var list = data.list;
            for (var i = 0, len = list.length; i < len; i++) {
                var row = list[i];
                // var fs = Math.pow(10, row.f1);

                var tr = $("<tr></tr>");
                var td1 = $("<td></td>");
                var td1a = $("<a target='_blank' style='width: 70px;display: block;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;'></a>").text(row.name).attr("href", "http://quote.eastmoney.com/unify/r/" + row.sc + '.' + row.dm).attr("title", row.name);
                td1.append(td1a);

                var td2 = $("<td></td>").text(row.p !== '-' ? cancelZsjd(row.p, row.zsjd) : '-');
                var td3 = $("<td></td>").text(row.zdf !== '-' ? (row.zdf).toFixed(2) + "%" : '-');

                if (row.zdf < 0) {
                    td2.addClass("green");
                    td3.addClass("green");
                }
                if (row.zdf > 0) {
                    td2.addClass("red");
                    td3.addClass("red");
                }

                tr.append(td1).append(td2).append(td3);
                tbody.append(tr);
            }

        }

    }


    /**
     * 渲染国外表格
     * @param {strig} selector :dom选择器
     * @param {object} data ：数据
     */
    function renderQthybjGw(selector, data) {

        var content = $(selector)
        var tbody = content.find("tbody");
        tbody.html('<tr><th class="">名称</th><th>最新价</th><th>涨跌幅</th></tr>');

        if (data) {

            var list = data.list;
            for (var i = 0, len = list.length; i < len; i++) {
                var row = list[i];
                // var fs = Math.pow(10, row.f1);

                var tr = $("<tr></tr>");
                var td1 = $("<td></td>");
                var td1a = $("<a target='_blank' style='width: 70px;display: block;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;'></a>").text(row.name).attr("href", "http://quote.eastmoney.com/unify/r/" + row.sc + '.' + row.dm).attr("title", row.name);
                td1.append(td1a);

                var td2 = $("<td></td>").text(row.p !== '-' ? cancelZsjd(row.p, row.zsjd) : '-');
                var td3 = $("<td></td>").text(row.zdf !== '-' ? (row.zdf).toFixed(2) + "%" : '-');

                if (row.zdf < 0) {
                    td2.addClass("green");
                    td3.addClass("green");
                }
                if (row.zdf > 0) {
                    td2.addClass("red");
                    td3.addClass("red");
                }

                tr.append(td1).append(td2).append(td3);
                tbody.append(tr);
            }

        }

    }



    //国内期货合约报价
    Gnqhhybj()
    function Gnqhhybj() {
        var url = qihuo_url + '/list/main/113,114,115,142,8?orderBy=zdf&sort=desc&pageSize=11&pageIndex=0&callbackName=h8';

        $.ajax({
            url: url,
            scriptCharset: "utf-8",
            dataType: "jsonp",
            jsonp: "cb",
            jsonpCallback: 'h8',
            success: function (json) {
                // console.log('国内期货合约报价');
                // console.log(json);

                if (json && json.list) {
                    renderQthybj('#futureTable', json)
                }


            }
        });

    }


    //国际期货行情
    Gwqhhq()
    function Gwqhhq() {
        var url = qihuo_url + '/list/101,102,103,104,108,109,110,111,112?orderBy=zdf&sort=desc&pageSize=10&pageIndex=0&callbackName=h9';

        $.ajax({
            url: url,
            scriptCharset: "utf-8",
            dataType: "jsonp",
            jsonp: "cb",
            jsonpCallback: 'h9',
            success: function (json) {
                // console.log('国内期货合约报价');
                // console.log(json);

                if (json && json.list) {
                    renderQthybjGw('#globalFutureTable', json)
                }


            }
        });

    }


    setInterval(function () {
        Gnqhhybj();
        Gwqhhq();

    }, 20 * 1000);




//});


