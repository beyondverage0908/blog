// define(['util'], function (util) {
     var util = require('./util');
	/**
	*@description maybe there had some wrong with cross required
    */
    window.baseUrl = 'http://push2.eastmoney.com'
    window.ut = 'bd1d9ddb04089700cf9c27f6f7426281'
    var util = util;
    var brief = {
        fillquote: function () {


            $('.brief_left i, .brief_topP i, .brief_info li i').not('.brief_info li i:eq(3)').removeClass('green red black');
            var url = window.baseUrl + '/api/qt/stock/get?secid=' +  (window.itemCode.indexOf("CNY") > -1?121:window.itemCode.indexOf("USDCNH") > -1?133:119)+'.' + window.itemCode + '&ut=' + window.ut + '&fields=f532,f57,f58,f59,f107,f43,f44,f45,f46,f60,f152,f169,f170,f119,f120,f121,f122&invt=2'
            //57证券代码 58证券名称 107市场号 43最新价 44最高价 45最低价 46开盘价
            //60昨收  59小数 152小数 532 1档买卖盘  19买1价 39卖1价
            //119 5日涨跌幅 120	20日涨跌幅 121 60日涨跌幅 122 年初至今涨跌幅
            var param = {
                type: "GET",
                url: url,
                data: null,
                dataType: "jsonp",
                jsonp: 'cb'
            }
            $.ajax(param).done(function (res) {
                var data = res.data
                if(!data) return 
                var nowprice = data.f43 == '-' ? '-' : ((data.f43 / Math.pow(10, data.f59)).toFixed(data.f59))//最新
                var zsvalue = data.f60 == '-' ? '-' : ((data.f60 / Math.pow(10, data.f59)).toFixed(data.f59))//昨收
                var kpj = data.f46 == '-' ? '-' : ((data.f46 / Math.pow(10, data.f59)).toFixed(data.f59)) // 开盘
                var zdf = data.f170 == '-' ? '-' : ((data.f170 / Math.pow(10, data.f152)).toFixed(data.f152)) + '%'  //涨跌幅
                var zde = data.f169 == '-' ? '-' : ((data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))  //涨跌额
                var zg = data.f44 == '-' ? '-' : ((data.f44 / Math.pow(10, data.f59)).toFixed(data.f59)) //最高
                var zd = data.f45 == '-' ? '-' : ((data.f45 / Math.pow(10, data.f59)).toFixed(data.f59)) // 最低
                var buy1 = data.f19 == '-' ? '-' : ((data.f19 / Math.pow(10, data.f59)).toFixed(data.f59))//买一
                var sell1 = data.f39 == '-' ? '-' : ((data.f39 / Math.pow(10, data.f59)).toFixed(data.f59))//卖一

                var zdf5 = data.f119 == '-' ? '-' : ((data.f119 / Math.pow(10, data.f152)).toFixed(data.f152)) + '%' //5日涨跌幅
                var zdf20 = data.f120 == '-' ? '-' : ((data.f120 / Math.pow(10, data.f152)).toFixed(data.f152)) + '%' //20日涨跌幅
                var zdf60 = data.f121 == '-' ? '-' : ((data.f121 / Math.pow(10, data.f152)).toFixed(data.f152)) + '%' //60日涨跌幅
                var zdfhalfyear = data.f122 == '-' ? '-' : ((data.f122 / Math.pow(10, data.f152)).toFixed(data.f152)) + '%' //半年涨跌幅、

                if (data.f58 && data.f58 != "-") {
                    $(".quote_title_0").html(data.f58)
                }

                 //防止默认填充 -
                var state = !!zde.match(/-[0-9]+/);
                if (state) { //负
                    $(".brief_topP em").attr('style', " ");
                    $(".brief_topP em").css('backgroundPosition', "0px -559px");
                    $(".brief_left i").addClass("green");
                } else if (zde == '-') { // 0 
                    $(".brief_topP em").css('background', "url('')");
                    $(".brief_left i").add(".brief_botP i").addClass("black");
                } else { //正
                    $(".brief_topP em").attr('style', " ");
                    $(".brief_topP em").css('backgroundPosition', "0 -536px");
                    $(".brief_left i").addClass("red");
                }

                /**
                 * 头部行情
                 */
                $(".brief_topP i").text(nowprice); //最新价
                $(".brief_botP i").eq(0).text(zdf); //涨跌幅
                $(".brief_botP i").eq(1).text(zde); //涨跌额
                var $i = $(".brief_info li i");
                $i.eq(0).text( kpj ); //今开
                $i.eq(1).addClass("black").text( zsvalue ); //昨收
                $i.eq(2).text( zg ); //最高
                $i.eq(3).text( zd ); //最低
                $i.eq(4).text( zdf );//涨幅
                $i.eq(5).text( zde );//涨跌
                $i.eq(6).text( buy1 );//买入
                $i.eq(7).text( sell1 );//卖出
                if (kpj < zsvalue) {
                    $i.eq(0).addClass('green');
                }
                if (zdf.match(/-[0-9]+/)) {
                    $i.eq(4).addClass('green');
                }
                if (zde.match(/-[0-9]+/)) {
                    $i.eq(5).addClass('green');
                }
                if (buy1< zsvalue) {
                    $i.eq(6).addClass('green');
                }
                if (sell1 < zsvalue) {
                    $i.eq(7).addClass('green');
                }

                /**
                 * 阶段涨跌幅
                 */
                var $j = $("#phase_increases tbody tr td")
                $j.eq(1).text(zdf5).addClass(data.f119>0?'red':data.f119<0?'green':'')
                $j.eq(3).text(zdf20).addClass(data.f120>0?'red':data.f120<0?'green':'')
                $j.eq(5).text(zdf60).addClass(data.f121>0?'red':data.f121<0?'green':'')
                $j.eq(7).text(zdfhalfyear).addClass(data.f122>0?'red':data.f122<0?'green':'')
            })
        },
        fillrelat:function (select,code) {
            var url = ""
            if(code == "CNY" || code == "CNH"){
                url = window.baseUrl + '/api/qt/clist/get?pn=1&pz=7&po=1&fid=f3&fs=m:121+t:1&invt=2'
            }else{
                url = window.baseUrl + '/api/qt/clist/get?pn=1&pz=7&po=1&fid=f3&fs=m:119+c:' + code +'&invt=2'
            }
            var param = {
                type: "GET",
                url: url,
                data: null,
                dataType: "jsonp",
                jsonp: 'cb'
            }
            $.ajax(param).done(function (res) {
                if(! res.data) return 
                var data = res.data.diff
                var htm = "<tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>"
                for(var i in data){
                    var color = data[i].f3 > 0?'red':data[i].f3 < 0?'green': ''
                    htm += '<tr>'
                                + '<td><a target="_blank" title="'+ data[i].f14+'" href="http://quote.eastmoney.com/forex/'+ data[i].f12+'.html">'+(data[i].f14.length > 8? (data[i].f14.slice(0,8) + '...'):data[i].f14)+'</a></td>'
                                +'<td class="'+color+'">'+ (data[i].f2=='-'?'-':(data[i].f2/10000).toFixed(4))+'</td>'
                                +'<td class="'+color+'">'+ (data[i].f3=='-'?'-':((data[i].f3/100).toFixed(2)) + "%") +'</td>'
                            +'</tr>'
                }
                $(select).html(htm)
            })
        },
        baseForexQuote:function (select) {
            var url = window.baseUrl + '/api/qt/clist/get?pn=1&pz=5&po=1&np=1&ut='+ window.ut +'&fltt=2&invt=2&fid=f3&fs=b:MK0300&fields=f1,f2,f3,f12,f13,f14,f152'
            var param = {
                type: "GET",
                url: url,
                data: null,
                dataType: "jsonp",
                jsonp: 'cb'
            }
            $.ajax(param).done(function (res) {
                if(! res.data) return 
                var data = res.data.diff
                var htm = "<tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>"
                for(var i = 0; i < data.length; i++){
                    var color = data[i].f3 > 0?'red':data[i].f3 < 0?'green': ''
                    htm += '<tr>'
                                + '<td><a target="_blank" title="'+ data[i].f14  +'" href="http://quote.eastmoney.com/forex/'+ data[i].f12+'.html">'+data[i].f14+'</a></td>'
                                +'<td class="'+color+'">'+ (data[i].f2=='-'?'-':(data[i].f2).toFixed(4))+'</td>'
                                +'<td class="'+color+'">'+ (data[i].f3=='-'?'-':((data[i].f3).toFixed(2)) + "%") +'</td>'
                            +'</tr>'
                }
                $(select).html(htm)
            })
        },
        crossForexQuote:function (select) {
            var url = window.baseUrl + '/api/qt/clist/get?pn=1&pz=5&po=1&np=1&ut='+ window.ut +'&fltt=2&invt=2&fid=f3&fs=b:MK0301&fields=f1,f2,f3,f12,f13,f14,f152'
            var param = {
                type: "GET",
                url: url,
                data: null,
                dataType: "jsonp",
                jsonp: 'cb'
            }
            $.ajax(param).done(function (res) {
                if(! res.data) return 
                var data = res.data.diff
                var htm = "<tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>"
                for(var i = 0; i < data.length; i++){
                    var color = data[i].f3 > 0?'red':data[i].f3 < 0?'green': ''
                    htm += '<tr>'
                                + '<td><a target="_blank" title="'+ data[i].f14  +'" href="http://quote.eastmoney.com/forex/'+ data[i].f12+'.html">'+data[i].f14+'</a></td>'
                                +'<td class="'+color+'">'+ (data[i].f2=='-'?'-':(data[i].f2).toFixed(4))+'</td>'
                                +'<td class="'+color+'">'+ (data[i].f3=='-'?'-':((data[i].f3).toFixed(2)) + "%") +'</td>'
                            +'</tr>'
                }
                $(select).html(htm)
            })
        },
        metalrateQuote:function (select) {
            var url = window.baseUrl + '/api/qt/clist/get?pn=1&pz=7&po=1&np=1&ut='+ window.ut +'&fltt=2&invt=2&fid=f3&fs=m:102,m:103,m:108,m:109,m:111,m:112&fields=f1,f2,f3,f12,f13,f14,f152'
            var param = {
                type: "GET",
                url: url,
                data: null,
                dataType: "jsonp",
                jsonp: 'cb'
            }
            $.ajax(param).done(function (res) {
                var data = res.data.diff
                var htm = "<tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>"
                for(var i = 0; i < data.length; i++){
                    var color = data[i].f3 > 0?'red':data[i].f3 < 0?'green': ''
                    htm += '<tr>'
                                + '<td><a target="_blank" title="'+ data[i].f14  +'" href="http://quote.eastmoney.com/globalfuture/'+ data[i].f12+'.html">'+data[i].f14+'</a></td>'
                                +'<td class="'+color+'">'+ (data[i].f2=='-'?'-':(data[i].f2).toFixed(data[i].f1))+'</td>'
                                +'<td class="'+color+'">'+ (data[i].f3=='-'?'-':((data[i].f3).toFixed(data[i].f152)) + "%") +'</td>'
                            +'</tr>'
                }
                $(select).html(htm)
            })
        },
        zjjRMB:function (select) {
            var url =  window.baseUrl +  '/api/qt/ulist.np/get?secids=120.AUDCNYC,120.NZDCNYC,120.CADCNYC,120.GBPCNYC,120.SGDCNYC,120.JPYCNYC,120.EURCNYC,120.HKDCNYC&ut=' + window.ut + '&fid=f3&fields=f1,f2,f3,f4,f12,f13,f14,f152'
            var param = {
                type: "GET",
                url: url,
                data: null,
                dataType: "jsonp",
                jsonp: 'cb'
            }
            $.ajax(param).done(function (res) {
                if(! res.data) return 
                var data = res.data.diff
                var htm = "<tr><th>币种</th><th>中间价</th><th>涨跌(bp)</th></tr>"
                for(var i = 0; i < data.length; i++){
                    var color = data[i].f3 > 0?'red':data[i].f3 < 0?'green': ''
                    htm += '<tr>'
                                + '<td>'+data[i].f14.replace("中间价","").replace("人民币","/人民币")+'</td>'
                                +'<td class="'+color+'">'+ (data[i].f2=='-'?'-':(data[i].f2/10000).toFixed(data[i].f1))+'</td>'
                                +'<td class="'+color+'">'+ (data[i].f4=='-'?'-':(data[i].f4)) +'</td>'
                            +'</tr>'
                }
                $(select).html(htm)
            })

        },
        init: function () {
            this.fillquote()//基本行情

            this.fillrelat("#forex0container tbody",forexCode[0])  //相关汇率
            this.fillrelat("#forex1container tbody",forexCode[1])  //相关汇率
            // if((forexCode[0] == 'GBP' && forexCode[1]=='USD') || (forexCode[0] == 'USD' && forexCode[1]=='CNH')){
            //     this.fillrelat("#forex0container tbody",forexCode[1])  //相关汇率
            //     this.fillrelat("#forex1container tbody",forexCode[0])  //相关汇率
            // }else{
            //     this.fillrelat("#forex0container tbody",forexCode[0])  //相关汇率
            //     this.fillrelat("#forex1container tbody",forexCode[1])  //相关汇率
            // }
            this.baseForexQuote("#base_rate tbody") // 基本汇率行情
            this.crossForexQuote("#cross_rate tbody") // 交叉汇率行情
            this.metalrateQuote("#metal_rate tbody") // 国际期货行情
            this.zjjRMB("#zhongjianjia tbody") // 国际期货行情
        }
    }

    module.exports = brief;
// });