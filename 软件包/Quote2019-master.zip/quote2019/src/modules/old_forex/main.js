var util = require('./util')
var agiotage = require('./agiotage')
var chart = require('./chart')
var fill = require('./fill')
var brief = require('./brief')
// var WdatePicker = require('./wdatepicker')
// !(function () {
    try {
        var suggest = new suggest2017({
            inputid: "search_box",
            offset: { left: -91, top: 5 },
            shownewtips: true,
            newtipsoffset: { top: -3, left: 0 }
        });
    } catch (e) {
        console.error(e);
    }
    /**
    * @description util
    */
    // require(['util'], function (util) {
        // var util = util;

        try {
            document.domain = 'eastmoney.com';
            //
            if (window.stockcode.match(/USDCNH/i)) {
                window.stockcode = 'USDCNH_FOS';
            }
        } catch (e) {

        }

        /**
        * @description 旧代码
        */
        // require(['old'], function () { });
        require('./old')

        ///**
        //* @description 股吧列表数据
        //* @param {Object} gubalist 数据列表
        //*/
        //require(['guba_articlelist'], function (gubalist) {
        //    gubalist.init("gubalisttable", 'waihui',{listcount:18,titlecut:42});

        //    /**
        //    * @description 手动更换链接...
        //    */

        //     var $a = $("#link_guba");
        //     $a.text( window.forexName[0] + '吧' );
        //     $a.attr( 'href', 'http://guba.eastmoney.com/list,' + "forex" + window.itemCode.slice(0,3) + '.html' )
        //     $.each($("a[href^='http://guba.eastmoney.com/list,']"), function(i, v){
        //         var $v = $(v);
        //         var href = $v.attr('href').replace(/list\,[a-z0-9]{3,7}\.html/i, 'list,forex' + window.itemCode.slice(0,3) + '.html');
        //         if(href.match(/CNY/i)){
        //             href = 'http://guba.eastmoney.com/list,usdcnyc.html';
        //         }
        //         $v.attr('href', href);
        //     });
        //});

        ///**
        //* @description 股吧发布框
        //* @param {Object} postbox 发布框
        //*/
        //require(['guba_postbox'], function (postbox) {
        //    postbox.init('sendnew', 'waihui' || util.code);   //TODO  目前看这个接口不支持到外汇某币种(后值) 先发到waihui(前值)
        //});

        ///**
        //* @description logout
        //* @param {Object} guba_user 用户
        //*/
        //require(['guba_user'], function (guba_user) {
        //    if (guba_user.get() != null) {
        //        var thisuser = guba_user.get();
        //        $("#loginstate").html("<span class=\"fr f12\">"+ thisuser.nick + "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"javascript:void(0);\" onclick=\"dcookies()\">退出</a></span>");
        //    }
        //});

        /**
        * @description agiotage
        * @param {Object} agiotage 兑换器构建
        * @param {Object} agiotage_tasks 兑换器重置
        */
        // require(['agiotage', 'agiotage_tasks'], function (agiotage) {
        //     agiotage.init();
        // });

        require('./agiotage_tasks')
        agiotage.init();

        /**
        * @description chart
        * @param {Object} chart 图标构建
        */
        // require(['chart'], function (chart) {
        //     chart.init();
        // });
        chart.init();

        /**
        * @description Fill
        * @example var urlBase = '//...com'; var configBase = {ajax param}
        */
        // require(['fill'], function (fill) {
            var Fill = fill.Fill;
            var temp = fill.temp;

            //@description 其中这里的callback名称必须不同，否则在jq内部作为同一xhr对象处理

            /**
            * @description 基本汇率
            */
            var urlBase = 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=C._FX_USD&sty=E1II&st=(ChangePercent)&sr=-1&p=1&ps=5&cb=callback0&js=&token=049db06d2bc9c947062f56de8b3b5648';
            var configBase = { type: "get", dataType: "jsonp", jsonpCallback: "callback0", url: urlBase };

            /**
            * @description 国际期货
            */

            var urlMetal = 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=C._UF&sty=E1II&st=(ChangePercent)&sr=-1&p=1&ps=7&cb=' + 'callback1' + '&js=&token=049db06d2bc9c947062f56de8b3b5648';
            var configMetal = { type: "get", dataType: "jsonp", jsonpCallback: "callback1", url: urlMetal };
            /**
            * @description 外汇牌价
            */

            var urlForex = 'http://183.136.160.92/EM_UBG_Finance2016TransferExtendInterface/js.ashx?type=ForexPrevailingPrice&cmd=12&js=' + 'callback2' + '&cb=';
            var configForex = { type: "get", dataType: "jsonp", jsonpCallback: "callback2", url: urlForex };

            /**
            * @description 阶段涨幅
            */
            var urlPhase = 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=' + window.stockcode + '&sty=FDPSUD&st=z&sr=&p=&ps=&cb=' + 'callback3' + '&js=&token=049db06d2bc9c947062f56de8b3b5648';
            var configPhase = { type: "get", dataType: "jsonp", jsonpCallback: "callback3", url: urlPhase };

            /**
            * @description 相关币种汇率0
            */
            var urlCountry_0 = 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=C._' + (util.country[0].match(/CNYi|CNH/i) ? 'CNY' : ('FX_' + util.country[0])) + '&sty=E1II&st=(ChangePercent)&sr=-1&p=1&ps=7&cb=' + 'callback4' + '&js=&token=049db06d2bc9c947062f56de8b3b5648';
            var configCountry_0 = { type: "get", dataType: "jsonp", jsonpCallback: "callback4", url: urlCountry_0 };

            /**
            * @description 相关币种汇率1
            */

            var urlCountry_1 = 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=C._FX_' + util.country[1] + '&sty=E1II&st=(ChangePercent)&sr=-1&p=1&ps=7&cb=' + 'callback5' + '&js=&token=049db06d2bc9c947062f56de8b3b5648';
            var configCountry_1 = { type: "get", dataType: "jsonp", jsonpCallback: "callback5", url: urlCountry_1 };

            /**
            * @description 交叉汇率
            */

            var urlCross = 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=C._FX_NOT_USD&sty=E1II&st=d&sr=-1&p=1&ps=5&cb=' + 'callback6' + '&js=&token=049db06d2bc9c947062f56de8b3b5648';
            var configCross = { type: "get", dataType: "jsonp", jsonpCallback: "callback6", url: urlCross };

            /**
            * @description 人民币中间价
            */

            var urlRmb = 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=AUDCNYC0,NZDCNYC0,CADCNYC0,GBPCNYC0,SGDCNYC0,JPYCNYC0,EURCNYC0,HKDCNYC0&sty=DCMFB&st=z&sr=-1&p=1&ps=8&cb=' + 'callback7' + '&js=&token=049db06d2bc9c947062f56de8b3b5648';
            var configRmb = { type: "get", dataType: "jsonp", jsonpCallback: "callback7", url: urlRmb };
            // console.log(util.forexName)
            $("#forex0container").parents(".side_box").find("h2 a").attr("href", 'http://forex.eastmoney.com/news/a' + util.country[0] + '.html').end().find("h2 i").text(util.forexName[0]);
            $("#forex1container").parents(".side_box").find("h2 a").attr("href", 'http://forex.eastmoney.com/news/a' + util.country[1] + '.html').end().find("h2 i").text(util.forexName[1]);

            var isChanged = true;
            function init() {

                //var baseRate = new Fill(temp, configBase, 0).init();
                // var metalRate = new Fill(temp, configMetal, 1).init();
                var forexRate = new Fill(temp, configForex, 2).init();
                // var phase = new Fill(temp, configPhase, 3).init();
                //var country_0 = new Fill(temp, configCountry_0, 4).init();
                // var country_1 = new Fill(temp, configCountry_1, 5).init(isChanged);
                // var crossRate = new Fill(temp, configCross, 6).init();
                // var rmbRate = new Fill(temp, configRmb, 7).init();

                setTimeout(function () {
                    if (isChanged) {
                        $(".report .news").css('marginTop', $("#cross_rate").offset().top - $(".report .news .news_list").eq(0).find('.article_list').offset().top + 3 + 'px');
                        isChanged = false;
                    }
                }, 400);
            };
            init();
            setInterval(init, 20 * 1000);

        // });

        /**
        * @description 顶部摘要
        * @param {Object} brief 顶部构建
        */

        // require(['brief'], function (brief) {
            brief.init(function () {
                // var text = $(".quote_title_1").text();
                // if( text.length > 6 ){
                //     $(".quote_title_1").text(text.slice(0, -1));
                // }

            });

            //TODO


        // });

        $.each($(".calendar_event"), function (i, v, a) {
            var $v = $(v);
            var t = $v.text();
            if (t.length > 15) {
                $v.text(t.slice(0, 14));
            }
        }); 

        /**
        * @description 日历
        */

        // require(['WdatePicker'], function (WdatePicker) {
            //财经日历
            // var $querydate = $("#querydate");
            // var $submitdate = $("#submitdate");
            // $querydate.on('click', function () {

            //     WdatePicker({ dateFmt: 'yyyy-MM-dd' });
            // });
            // $submitdate.on('click', function () {
            //     var date = $querydate.val();

            //     var re = /(\d{4})(\d{2})(\d{2})/;
            //     var matches = re.exec(date);
            //     if (date === "") { return; }
            //     if (matches !== null) {
            //         //window.open('http://forex.eastmoney.com/fc' + matches[1] + '-' + matches[2] + '-' + matches[3] + '.html', '_blank');
            //         window.open('http://forex.eastmoney.com/FC.html?Date=' + date, '_blank');

            //     } else {
            //         //window.open('http://forex.eastmoney.com/fc' + date + '.html', '_blank');
            //         window.open('http://forex.eastmoney.com/FC.html?Date=' + date, '_blank');
            //     }
            // });
        // });
    // });
// })();
