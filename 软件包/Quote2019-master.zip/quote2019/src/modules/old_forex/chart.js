// define(['util'], function (util){
    var util = require('./util');
    /**
    * @description  指标配置
    */
    var pic_url = "//webquotepic.eastmoney.com/GetPic.aspx?id="; //+ imageOpition.ID+ "&imageType=KXL&token=44c9d251add88e27b65ed86506f6e5da&rt=" + formatm();
    var allUri = {
        imageURL:"http://webquoteklinepic.eastmoney.com/GetPic.aspx?ImageType=KXL&"
    };
    var imageOpition = {
        ID:kLine.stockCode + kLine.stockMarket,
        // EF:"", 
        Formula:"RSI",
        unitwidth:-6,
        // FA:"",
        // BA:"", 
        type:"D",
        token: "44c9d251add88e27b65ed86506f6e5da"
    }; 

    if( itemCode.match(/USDCNH/i) ){
        imageOpition.ID = 'USDCNH_FOS';
    }
    $("#zkeyb,#zkeyc").children("li").on("click", function(e){
        var $t = $(this);
        var ind = $t.prevAll("li").length;

        // if($t.parent("ul").attr("id") !== "zkeya"){ 
            $("#zkeyb li").removeClass("at").eq(ind).addClass("at");
            $("#zkeyc li").removeClass("at").eq(ind).addClass("at");
        // }else{
            // $("#zkeya li").removeClass("at").eq(ind).addClass("at");
        // }
        
        //param
        // var ef;
        // $.each($("#zkeya li"), function (i, v, a){
        //     $(v).hasClass("at") ? (ef = $(v)[0].getAttribute("value")) : 0;
        // });

        var formula;
        $.each($("#zkeyb li"), function (i, v, a){
            $(v).hasClass("at") ? (formula = $(v)[0].getAttribute("value")) : 0;
        });

        // imageOpition.EF = ef;
        imageOpition.Formula = formula;

        $("#pick").attr("src",allUri.imageURL + $.param(imageOpition));

    });

    /**
    * @description  k线配置 
    */
    $("#pictit span").on("click", function(e){
        var $t = $(this);
        var val = $t[0].getAttribute("value");

        $t.siblings("span").add($t).removeClass("cur");
        $t.addClass("cur");
        imageOpition.type = val;
        $("#pick").attr("src",allUri.imageURL + $.param(imageOpition));
    });

    $("#picklc, #picksd").on("click", function(e){
        var $t = $(this);
        var ind = $t.prevAll("span").length;
        var num = imageOpition.unitwidth;

        ind === 1 ? num++ : num--;
        if(num > -3 || num < -9){
            return;
        }else{
            imageOpition.unitwidth = ~~num;
        }
      
        $("#pick").attr("src",allUri.imageURL + $.param(imageOpition));
    });
 
    //M暂时未用
    // $("#actTab4 span").on("click", function(e){
    //     var $t = $(this);
    //     var ind = $t.prevAll("span").length;

    //     $t.siblings("span").add($t).removeClass("cur");
    //     $t.addClass("cur");

    //     var e = new Date;
    //     var t = e.getDate()+""+e.getHours()+e.getMinutes();
    //     var arr = ["rc", "r", "M1", "M2", "M3", "M4"];

    //     if(ind > 1){
    //         $("#picr").attr("src",'http://pifm.dfcfw.com/EM_Finance2014PictureInterface/Index.aspx?imagetype=t&type=' + arr[ind] + '&id=' + '0000192' + '&token=beb0a0047196124721f56b0f0ff5a27c&rt=' + t);
        
    //     }else{
    //         $("#picr").attr("src",var pic_url + "0000192" + "&imageType=" +arr[ind] + "&token=44c9d251add88e27b65ed86506f6e5da&rt=" + t);
    //     }
        
    // });
    
    module.exports =  {
        init: function (){ 
            var e = new Date;
            $("#picr").attr("src",pic_url + window.stockcode + "&imageType=" +'RF' + "&token=44c9d251add88e27b65ed86506f6e5da");
            $("#pick").attr("src",allUri.imageURL + $.param(imageOpition));

            $(".to_img0").attr("href",pic_url + window.stockcode + "&imageType=" +'RF' + "&token=44c9d251add88e27b65ed86506f6e5da");
            $(".to_img1").attr("href",allUri.imageURL + $.param(imageOpition));
            setInterval(function (){
                $("#picr").attr("src",pic_url + window.stockcode + "&imageType=" +'RF' + "&token=44c9d251add88e27b65ed86506f6e5da");
                $("#pick").attr("src",allUri.imageURL + $.param(imageOpition));
                $(".to_img0").attr("href",pic_url + window.stockcode + "&imageType=" +'RF' + "&token=44c9d251add88e27b65ed86506f6e5da");
                $(".to_img1").attr("href",allUri.imageURL + $.param(imageOpition));
            }, 10 * 1000);
        }
    }
// })