// define(function (){
    var stockcode = window.stockcode;
    var country = [];
    country[0] = window.itemCode.slice(0, 3);
    country[1] = window.itemCode.slice(3); 

    var forexName = [];
    forexName[0] = window.forexName[0];
    forexName[1] = window.forexName[1];
    var forexMap = ['USD', 'CNY', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD'];

    var code = window.itemCode + '';

    if(code.length < 7 && code.match(/cny/i) ){
        code += 'i';
    }

    // if(country[1].match(/USD/i) || country[1].match(/CNY|CNH/i)){
    //     var exc;
    //     if(!country[0].match('CNY')){
    //         exc = country[0];
    //         country[0] = country[1];
    //         country[1] = exc; 
    //     }
    // }

    // if(forexName[1].match(/人民币/) || forexName[1] === '美元'){
    //     var exc;
    //     if(!forexName[0].match(/人民币/)){ 
    //         exc = forexName[0];
    //         forexName[0] = forexName[1];
    //         forexName[1] = exc;
    //     }
    // }
    

    function hasForex (name){
        for(var i = 0;i<forexMap.length;i++){
            if(forexMap[i] === name)
                return true;
        }
    }

    module.exports =  {
        stockcode: stockcode, 
        kLine: window.kLine, 
        country: country, 
        forexMap: forexMap,
        hasForex: hasForex,
        forexName: forexName,
        code: code
    }
   
// });