// define(['IOScript', 'agiotage_temp'], function(IO, temp){

    var IO = require('./ioscript')
    var temp = require('./agiotage_temp')

    Function.prototype.Bind = function() { 
        var __m = this, object = arguments[0], args = new Array(); 
        for(var i = 1; i < arguments.length; i++){
            args.push(arguments[i]);
        }
        
        return function() {
            return __m.apply(object, args);
        }
    };

    var forex = {
        computeF: function () {
            var bsv = $("#bs").val();
            if (isNaN(bsv)) {
                alert("金额必须为数字.");
                return false;
            }
            $("#res").value = "正在计算..";
            var x = $("#c1")[0][$("#c1")[0].selectedIndex].value;
            var y = $("#c2")[0][$("#c2")[0].selectedIndex].value;
            var url = "http://hq.sinajs.cn/list=" + x + "," + y;
            var scriptLoader = new IO.Script();
            scriptLoader.load(url, forex.deal.Bind(forex, x, y, bsv));

        },
        deal: function (x, y, bsv) {
            var forex1 = forex.dealSpe(x, eval("hq_str_" + x).split(",")[8]);
            var forex2 = forex.dealSpe(y, eval("hq_str_" + y).split(",")[8]);
            var result = (forex2 / forex1) * bsv;
            result = result.toFixed(4);
            $("#res").val(result);
        },

        dealSpe: function (type, val) {
            switch (type) {
                case 'US':
                    return 1;
                    break;
                case 'GBP':
                case 'EUR':
                case 'AUD':
                    return (1 / val).toFixed(4);
                    break;
                default:
                    return val;
                    break;
            }
        },

        addListener: function(){
            var computeF = this.computeF;
            $('#agiotage_btn').on('click',function(){
                computeF();
            })
        },

        temp: function(){
            $('#agiotage').html(temp);
        },

        init: function(){
            this.temp();
            this.addListener();
        }

    }

    module.exports = forex;
// })