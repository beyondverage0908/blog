// define(function (){

	/**
	* @constructor Fill 
	* @description Fill factory
	* @param {Function} temp 模板  
	* @param {Object} config  ajax配置
	* @param {Num} type 0,交叉;1,贵金属;2,人民币
	* @param{Function} callback 回调
	* @return {undefined}   
	*/

	/** 
	*@description  声明模板
	*/   
	var temp;
	var tempPhase;
	var forexUrl = 'http://quote.eastmoney.com/forex/$.html';
	//var metalUrl = [
	//	'http://quote.eastmoney.com/gjqh/OILC.html',
	//	'http://quote.eastmoney.com/gjqh/GLNC.html', 
	//	'http://quote.eastmoney.com/gjqh/LCPS.html',
	//	'http://quote.eastmoney.com/gjqh/RBTC.html',
	//	'http://quote.eastmoney.com/gjqh/CTNZ.html',
	//	'http://quote.eastmoney.com/gjqh/LTNS.html',
	//	'http://quote.eastmoney.com/gjqh/LZNS.html'
	//];

	var tempAD = '<iframe width="200" height="200" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" src="http://same.eastmoney.com/s?z=eastmoney&c=175&op=1" id="ifhqzcad3"></iframe>';

	function Fill (temp, config, type, callback){
		this.ajaxParam = $.extend({
				type : "get",
				contentType: "application/x-www-form-urlencoded;charset=utf-8",
				cache: false
			}, config);
		this.callback = callback;
		this.type = type; 

		this.init = function (isChanged){

			/**
			* @description 当采用人民币老接口时 ajax.fail
			* @example $.ajax(this.ajaxParam).done(temp.bind(this));	//'bind this' will be erroneous in ie6 //shouldnt do this for transmit the param
			*/

			if( type === 4 && itemCode.match(/CNY|CNH/i)){
				var script = document.createElement('script');

				function action(){
					var data = window.fxrc.rank;
					var _html = '';
					var len = $("#forex0container tbody tr").not(":first").length;
					
					_html += '<tr>' + $("#forex0container tbody tr:first").html() + '</tr>';
					for(var i = 0; i < len; i++){
						var _data = data[i].split(',');
						var isUp = !_data[18].match(/-[0-9]+/);
						var isFair = !!_data[18].match(/0.[0]{2,}/);
						var className = (isUp ? isFair ? 'black' : 'red' : 'green');

						_html += '<tr>'
						        +'  <td><a target="_blank" title="' + _data[2] + '" href="' + forexUrl.replace('$', _data[1]) + '">' + _data[2] + '</a></td>'
						        +'  <td class=" ' + className + ' ">' + _data[5] + '</td>'
						        +'  <td class=" ' + className + ' ">' + _data[18] + '</td>'
						        +'</tr>';
					}
					
					$("#forex0container tbody").html(_html);

					callback && callback(this);

					document.getElementsByTagName('head')[0].removeChild(script || document.getElementById('rmb_script'));
				}

				script.src = 'http://hq2gjqh.eastmoney.com/EM_Futures2010NumericApplication/Index.aspx?jsName=fxrc&Type=S&SortType=A&pageSize=20&page=1&style=28RMBRate&_g=' + Math.random(0,1);
				script.id = 'rmb_script';
				document.getElementsByTagName('head')[0].appendChild(script);
				
				if (!!window.ActiveXObject || "ActiveXObject" in window){
					script.onreadystatechange = function(){
						
						if(script.readyState === 'complete' || script.readyState === 'loaded'){
							action();
						}
					}
				}else{
					$(script).on('load', function(){
						action();
					})
				}
				
				return;
			}

			$.ajax(this.ajaxParam).done(temp).fail(function(){
				var $p = $(".toAD");

				if( type === 5 ){
					if(!$p.find('iframe').length && $p.children().length){
						var minus = $p.height() + +$p.css('margin-top').slice(0, -2) - 210;

						$p.html(tempAD).css({'margin-top': minus + 'px', 'margin-bottom': '10px'});
						$p.insertAfter(".quote_calculator");

					}
					
					return ;
				}
			}); 
			callback && callback(this); 
		}
		
		/**
		* @description  因在ajax.done中只能传递句柄，当绑定this时又会导致当前this->xhr失效，所以模板统一在此
		*/
		temp = function (data){ 
		
			var sizzle = ['#base_rate', '#metal_rate', '#forex_rate', '#phase_increases', '#forex0container', '#forex1container', '#cross_rate', '#zhongjianjia'];
			var j = 0; 
			var l = 0;
			var isNull = false;
			
			/**
			* @description  当5中有一个数据少于3时，替换为广告
			*/
			
			if( type === 5 && data.length <= 3 ){

				var $p = $(".toAD");
				
				if(!$p.find('iframe').length){
					var minus = $p.height() + +$p.css('margin-top').slice(0, -2) - 210;
			
					$p.html(tempAD).css({'margin-top': minus + 'px', 'margin-bottom': '10px'});
					$p.insertAfter(".quote_calculator");

				}
				
				return ;
			}

			if( $.isEmptyObject(data) ){
				isNull = true;
				data = ['-,-,-/-,-,-,-,-','-,-,-/-,-,-,-,-','-,-,-/-,-,-,-,-','-,-,-/-,-,-,-,-','-,-,-/-,-,-,-,-','-,-,-/-,-,-,-,-','-,-,-/-,-,-,-,-','-,-,-/-,-,-,-,-'];
			}
			
			if( type === 3 ) 
				var $itemParent = $(sizzle[type] + " tbody tr");
			else
				var $itemParent = $(sizzle[type] + " tbody tr").not(":first")
			
			var len = $itemParent.length;
			var arrForex = ['Name', 'BuyP', 'SellP', 'TaxP'];
			if( type === 2 ){
				var _html = '<tr>' + $(sizzle[type] + " tbody tr:first").html() + '</tr>';

				for( var i = 0; i < len; i++ ){
					var index = 0;
					if(!data[0][i]) return;
					_html += '	  <tr>'
					        +'      <td>' + data[0][i][arrForex[index++]] + '</td>'
					        +'      <td>' + data[0][i][arrForex[index++]] + '</td>'
					        +'      <td>' + data[0][i][arrForex[index++]] + '</td>'
					        +'      <td>' + data[0][i][arrForex[index++]] + '</td>'
					        +'    </tr>';
				}

				$(sizzle[type] + " tbody").html(_html);

				return ;
			}
			if( type === 7 ){
				var _html = '<tr>' + $(sizzle[type] + " tbody tr:first").html() + '</tr>';

				for(var i = 0; i < len; i++){
					var index = 0;
					var _data = data[i].split(',');
					var name = _data[2];
					_data[2] = _data[2].slice(0, -3).replace(/人民币$/, "/人民币").replace(/^人民币/, "人民币/");

					var isUp = !_data[4].match(/-[0-9]+/);
					var isFair = !!_data[4].match(/^0.[0-9]?0$/) || !!_data[4].match(/^0$/);
					var className = (isUp ? isFair ? 'black' : 'red' : 'green');

					_html += '<tr>'
					    // +'        <td><a target="_blank" title="' + name + '" href="' + forexUrl.replace('$', _data[0].slice(0, -1)) + '">' + _data[2] + '</a></td>'
					    +'        <td >'+ _data[2] +'</td>'
					    +'        <td class="' + className + '">' + _data[3] + '</td>'
					    +'        <td class="' + className + '">' + parseInt(_data[4] * 10000, 10) + '</td>'
					    +'    </tr>';
				}

				$(sizzle[type] + " tbody").html(_html);

				return ;
			}

			$.each($itemParent, function(i, v, a){
				
				if(type === 3){
					try{
						var _data = data[0].split(",")[10].split('|');
					}catch(e){
						return ;
					}

					if(data !== undefined && data.stats !== false && +data[0].split(',')[10].length > 1){
						var $v = $($(v).find("td")[1]);
						var val = _data[l++];
						var isUp = !val.match(/-[0-9]+/);
						var isFair = !!val.match(/0.[0]{2,}/);
						var className = (isUp ? isFair ? 'black' : 'red' : 'green');

						$v.addClass(className).text(val);
					}
 					
				}else{
					var k = 0; 
					var _data = data[j++];

					$.each($(v).find("td"), function(j, v, a){
						if(_data !== undefined && _data.stats !== false){
                            var $v = $(v), items = _data.split(',');

							var val = _data.split(",").slice(2)[k++];
							
							if((type === 0 || type === 4 || type === 5 || type === 6) && j === 0){

								if(isNull){
									$v.text(val);
								}else{
									if(_data.split(',')[0].match('IND')){
										$v.html('<a target="_blank" title="' + val + '" href="' + 'http://forex.eastmoney.com' + '">' + val + '</a>');
										return;
									}

									$v.html('<a target="_blank" title="' + val + '" href="' + forexUrl.replace('$', _data.split(',')[0]) + '">' + val + '</a>');
								}

							}else if(type === 1 && j === 0){

								if(isNull){
									$v.text(val);
								}else{
									
                                    $v.html('<a target="_blank" href="//quote.eastmoney.com/globalfuture/' + items[0] + '.html">' + val + '</a>');
								}
							}else{
								$v.text(val);
							}

							if(j === 2 && val.match(/-[0-9]+/)){
								$v.add($v.prev('td')).addClass('green');
 
							}else if(j === 2){
								$v.add($v.prev('td')).addClass('red')
							}
						}

					});

				}

			});
		} 

	}

	module.exports = {
		Fill: Fill,
		temp : temp
	};

// })