// define(function (){
    var win = window;

    //更新图片
    function updateImage(img) {
        var re = /rt=([\d\.]+)(?:&|$)/
             , matchs = re.exec(img.src)
             , rt = Math.random()
             , src = img.src;
        if (matchs) {
            rt = matchs[0].replace(matchs[1], rt);
            img.src = src.replace(re, rt);
        } else {
            rt = "rt=" + rt;
            img.src = src + (src.indexOf("?") !== -1 ? "&" : "?") + rt;
        }
    }

    //图片自刷时间
    var IMG_TIMER_DELAY = 1000 * 60 * 3;
    var DATA_TIMER_DELAY = 1000 * 15;
    var dataUpate = [];

    //最近访问
    function addHistoryItem(container, code, name) {
        var arg = { def: "", set: "k-0-" + code + "-" + name };
        try{
            new HistoryViews(container, arg);
        }catch(e){
            //throw new Error("NOT FIND CONTAINER");
        }
        
    }
    addHistoryItem("historyest", itemCode, itemName);

    //全球时间
    //override _GlobalTime.prototype.show
    _GlobalTime.prototype.show = function() {
        var a = this;
        var f = a.Option;
        var b = f.citys.length;
        var l = [],
            k = [];
        var el = document.getElementById("wordtime").getElementsByTagName("i");
        
        var h = function() {
            var d = a.utils.now() + a.deviation - (3600000 * 8);
            for (var c = 0; c < b; c++) {
                var j = a.utils.formatTime(d, f.citys[c].utc);

                el[c].innerHTML = a.utils.dateFromat(j, f.display);
            }
        };
        h();
        var g = setInterval(h, 1000);
    };
    var globalTime = new _GlobalTime("wordtime");

    //R图
    (function() {
        var picr = document.getElementById("picr");
        if (picr === null) return;
        var src = picr.src;
        var rpic = {
            load: function() {
                updateImage(picr);
            }
        };

        document.getElementById('RefPR').onclick = function() {
            updateImage(picr);
        };

        win.rpic = rpic;

        picr && rpic.load();
    } ());

    function getNowFormatDate() {
        var date = new Date();
        var seperator1 = "-";
        var seperator2 = ":";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;
        return currentdate;
    }

    // 财经日历
    // var querydate = document.getElementById("querydate");
    // var submitdate = document.getElementById("submitdate");

    // querydate.value = getNowFormatDate();
    // querydate.onclick = function() {
    //     new Calendar(1990, new Date().getFullYear()).show(this);
    // };
    // submitdate.onclick = function() {
    //     var date = querydate.value;
    //     var re = /(\d{4})(\d{2})(\d{2})/;
    //     var matches = re.exec(date);
    //     if (date === "") { return; }
    //     if (matches !== null) {
    //         //window.open('http://forex.eastmoney.com/fc' + matches[1] + '-' + matches[2] + '-' + matches[3] + '.html', '_blank');
    //         window.open('http://forex.eastmoney.com/FC.html?Date=' + matches[1] + '-' + matches[2] + '-' + matches[3], '_blank');
            
    //     } else {
    //         //window.open('http://forex.eastmoney.com/fc' + date + '.html', '_blank');
    //         window.open('http://forex.eastmoney.com/FC.html?Date=' + matches[1] + '-' + matches[2] + '-' + matches[3], '_blank');
    //     }
    // };

    //图片自刷
    (function(){
        setInterval(function() {
            rpic.load();
            // pick.load();   //TODO
        }, IMG_TIMER_DELAY);
    })()


    //数据自刷
    setInterval(function() {

        for (var i = 0; i < dataUpate.length; i++) {
            dataUpate[i].load();
        }
    }, DATA_TIMER_DELAY); 

    function formatm(){
        var now=new Date();
        return now.getDate()+""+now.getHours()+""+now.getMinutes()+"";
    }

    var scrollLoad = (function () {
        var getClient=function(){
            var l,t,w,h;
            l=document.documentElement.scrollLeft || document.body.scrollLeft;t=document.documentElement.scrollTop || document.body.scrollTop;w=document.documentElement.clientWidth;h=document.documentElement.clientHeight;
             return {'left':l,'top':t,'width':w,'height':h};
        };
        var getSubClient=function(p){
            var l = 0,t = 0,w,h;
            w = p.offsetWidth ;h = p.offsetHeight;
            while(p.offsetParent){l += p.offsetLeft ;t += p.offsetTop ;p = p.offsetParent;}
            return {'left':l,'top':t,'width':w,'height':h };
        };
        var intens=function(rec1,rec2){
            var lc1,lc2,tc1,tc2,w1,h1;
            lc1 = rec1.left + rec1.width/2;lc2 = rec2.left + rec2.width/2;
            tc1 = rec1.top + rec1.height/2 ; tc2 = rec2.top + rec2.height/2;
            w1 = (rec1.width + rec2.width)/2 ;h1 = (rec1.height + rec2.height)/2;
            return Math.abs(lc1 - lc2) < w1 && Math.abs(tc1 - tc2) < h1 ;
        };
        var jiance=function(prec1,callback){
              var arr = document.getElementsByTagName("del");
                for(var i = arr.length - 1 ; i >= 0 ;i--){
                      if(arr[i]){
                        if(arr[i].children[0].src!=arr[i].children[0].getAttribute("xsrc")){
                            var prec2 =  getSubClient(arr[i].children[0]);
                            if(intens(prec1,prec2)){callback(arr[i].children[0]);}
                          }
                      }
                }
          };
          var jiancev=function(prec1,callback){
              var arr = document.getElementsByTagName("kbd");
                for(var i = arr.length - 1 ; i >= 0 ;i--){
                      if(arr[i]){
                        if(arr[i].children[0].getAttribute("xsrc")=="0"){
                            var prec2 =  getSubClient(arr[i].children[0]);
                            if(intens(prec1,prec2)){callback(arr[i].children[0]);}
                          }
                      }
                }
          };
        var autocheck=function(){
           var prec1 = getClient(); 
           jiance(prec1,function(obj){
            var attrSrc=obj.getAttribute("xsrc");
                    if(attrSrc){var vr=formatm();obj.src = attrSrc+"?r="+vr;obj.setAttribute("xsrc",attrSrc+"?r="+vr);}
           });
           jiancev(prec1,function(obj){
            var attrSrc=obj.getAttribute("xsrc");
                    if(attrSrc=="0"){_this.GetVote("");obj.setAttribute("xsrc","1");}
           })
        };
        window.onscroll = function(){autocheck();};
        window.onresize = function(){autocheck();};
        window.onload = function(){setTimeout(autocheck,200);};
    });
    scrollLoad();
// })