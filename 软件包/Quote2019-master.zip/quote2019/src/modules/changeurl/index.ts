/**
 * 更改url大小写中间件
 */
import { Context } from "koa"


export default function(){
  return async function (ctx: Context, next: Function) {

    ctx.request.url = ctx.request.url.toLowerCase()

    await next()
  }
}