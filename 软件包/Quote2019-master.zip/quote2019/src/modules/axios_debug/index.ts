// /**
//  * 带报错收集的axios
//  * 功能和axios一样
//  */

// import axios from "axios"
// import logger from "../logger";

// async function axios_debug(axios_options:any, recode_time:boolean = false){
//   try {
//     let thistime
//     if (recode_time) {
//       thistime = Date.now()
//     }
//     let back = await axios(axios_options) 
//     if (recode_time && thistime) {
//       logger.info({
//         type: 'time_recode',
//         url: axios_options.url,
//         timespan: Date.now() - thistime
//       })
//     }
//     return back      
//   } catch (error) {
//     logger.error({
//       'error_message': error.message,
//       'stack': error.stack,
//       'url': axios_options.url
//     })
//     throw error;
//   }  
// }

// /**
//  * get 获取axios
//  * url 地址
//  * axios_options axios参数
//  * recode_time 用logger.info记录获取接口的时长 ms 
//  */
// axios_debug.get = async function(url:any, axios_options?:any, recode_time:boolean = false){
//   try {
//     let thistime
//     if (recode_time) {
//       thistime = Date.now()
//     }
//     let back = await axios.get(url, axios_options) 

//     if (recode_time && thistime) {
//       logger.info({
//         type: 'time_recode',
//         url: url,
//         timespan: Date.now() - thistime
//       })
//     }
//     return back      
//   } catch (error) {
//     logger.error({
//       'error_message': error.message,
//       'stack': error.stack,
//       'url': url
//     })
//     throw error;
//   }  
// }


  


// export default axios_debug