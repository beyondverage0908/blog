/**
 * 操作字符串
 */

export default {
  /**
   * 字符串长度 一个汉字算2个
   * 
   * @param {any} txt 
   * @returns 
   */
  txtLength (txt:string) {
    var thislength = 0;
    for (var i = 0; i < txt.length; i++) {
      if (txt.charCodeAt(i) > 255) {
        thislength += 2;
      }
      else {
        thislength++;
      }
    }
    return thislength;
  },
    /**
   * 字符串截取 (一个汉字算2个)
   * 
   * @param {string} txt 输入文本
   * @param {int} n 截取多少个字 一个汉字算2个
   * @param {boolean} needtip 是否需要全文提示
   * @param {string} postfix 自定义截断后缀，默认...
   * @returns 
   */
  txtLeft: function (txt:string, n:number, needtip:boolean = false, postfix:string = '...') {
    if( txt == null || txt == "" ){
      return "";
    }

    var thislength = 0;
    for (var i = 0; i < txt.length; i++) {
      if (txt.charCodeAt(i) > 255) {
        thislength += 2;
      }
      else {
        thislength++;
      }
      if (thislength > n + 3) {
        if(needtip){
          return '<span title="' + txt + '">' + txt.substring(0, i) + postfix + "</span>";
        }
        else{
          return txt.substring(0, i) + postfix;
        }
        break;
      }
    }
    return txt;
  },
  formatNum: function(num:any){
    if(num == 0) {
      return num
    }
    if(num == undefined || num == '' || isNaN(num)){
      return '';
    }

    var hz = '';
    if(num >= 100000000||num <= -100000000){
      num = num / 100000000;
      hz = '亿';
    }
    else if(num >= 10000||num <= -10000){
      num = num / 10000;
      hz = '万';
    }
    else{
      return num;
    }

    var num2 = num.toFixed(2);

    // if(parseInt(num) >= 1000){ //整数部分超过4位
    //   num2 = num.toFixed(1);
    // }

    return num2.toString() + hz;
  },
  numToFixed: function (input:any, fixnum: number) {
    try {
      return input.toFixed(fixnum)
    } catch (error) {
      return input
    }
  },
  /**
   * 全角转半角
   * @param str 
   */
  ToCDB(str:string) { 
    var tmp = ""; 
    for(var i=0;i<str.length;i++){ 
        if (str.charCodeAt(i) == 12288){
            tmp += String.fromCharCode(str.charCodeAt(i)-12256);
            continue;
        }
        if(str.charCodeAt(i) > 65280 && str.charCodeAt(i) < 65375){ 
            tmp += String.fromCharCode(str.charCodeAt(i)-65248); 
        } 
        else{ 
            tmp += String.fromCharCode(str.charCodeAt(i)); 
        } 
    } 
    return tmp 
  },
  /**
   * 全角转半角，并删除空白字符
   * @param str 
   */
  ToCDBRemoveBlank(str:string){
    str = this.ToCDB(str)
    return str.replace(/\s/g, '')
  },
  format(str:string, ...values:string[]):string{
    if (values.length > 0) {

      for (var i = 0; i < values.length; i++) {
          if (values[i] != undefined) {
              var reg= new RegExp("(\\{" + i + "\\})", "g");
              str = str.replace(reg, values[i]);
          }
      }
    }
    return str;
  }
}