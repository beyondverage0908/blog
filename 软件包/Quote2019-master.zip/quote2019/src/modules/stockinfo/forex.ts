/**
 * 获取外汇接口信息
 */


const config = require('../../../config/index.js')
import api_cache from "../api_cache"
import _ from "lodash"
import moment from "moment"



export default {
  
  async getBaseInfo(code:string){

    //尝试从 119 121 市场获取基本信息
    let url = `${config.getEnvParam('quoteapi')}api/qt/ulist.np/get?ut=bd1d9ddb04089700cf9c27f6f7426281&secids=119.${code},121.${code}&fields=f12,f13,f14&fltt=2`

    //美元离岸人民币 特殊处理
    if (code == 'USDCNH') {
      url = `${config.getEnvParam('quoteapi')}api/qt/ulist.np/get?ut=bd1d9ddb04089700cf9c27f6f7426281&secids=133.${code}&fields=f12,f13,f14&fltt=2`
    }

    let back = await api_cache({
      url: url,
      error_replace: {
        data: {
          diff: []
        }
      }
    })

    let baseinfo_array = _.get(back, 'data.diff', [])

    /**
     * 基本信息
     */
    interface BaseInfo{
      /**
       * 代码
       */
      code: string,
      /**
       * 市场
       */
      market: string,
      /**
       * 名称
       */
      name: string
    }

    let baseinfo:BaseInfo|null = null

    if (baseinfo_array.length > 0) { //如果有返回数据，取第一个
      baseinfo = {
        name: baseinfo_array[0].f14,
        market: baseinfo_array[0].f13,
        code: baseinfo_array[0].f12
      }
    }
    return baseinfo
  },
  /**
   * 获取外汇直播
   */
  async getZhiBo(){
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews?channels=1&exclude_cols=743&pageindex=1&pageSize=5&getmore=1`,
      error_replace: {
        Result: []
      }
    })

    back = _.get(back, 'Result', [])

    return back
  },
  /**
   * 获取全球财经日历
   */
  async getFinanceCalendar(){
    let datestr = moment().format('YYYY-MM-DD')
    let back = await api_cache({
      url: `${config.getEnvParam('datainterface')}EM_DataCenter/js.aspx?type=GJZB&sty=RLLB&mkt=&fd=${datestr}&stat=1&p=1&ps=200`,
      keystr: `${config.getEnvParam('datainterface')}EM_DataCenter/js.aspx?type=GJZB&sty=RLLB&mkt=&fd=&stat=1&p=1&ps=200`,
      error_replace: '',
    })

    if (back == '') {
      return []
    }

    try {
      back = JSON.parse(back.replace('([', '[').replace('])', ']'))
    } catch (error) {
      return []
    }

    let CalendarList = back.map((v:string)=>{ 
      let array = v.split(',')
      return {
        date: moment(array[0], "YYYY/M/D H:m:s").format('YYYY-MM-DD HH:mm'),
        country: array[7],
        event: array[8],
        reportdate: moment(array[3], "YYYY/M/D H:m:s").format('YYYY年M月'),
        importance: array[11],
        before: array[12] == '' ? "-" : array[12] + array[6],
        after: array[10] == '' ? "-" : array[10] + array[6],
        pubsh: array[9] == '' ? "-" : array[9] + array[6]
      }
    })

    let countries = ["中国", "德国", "日本", "美国", "欧元区", "英国"]

    CalendarList =  _.chain(CalendarList)
      .orderBy('importance')
      .groupBy('country')
      .filter((v)=>{
        return v[0] != undefined && countries.indexOf(v[0].country) >= 0
      })
      .map(function(v){
        v[0].importance = v[0].importance == "1" ? "高" : v[0].importance == "2" ? "中" : "低"
        v[0].css = v[0].importance == "高" ? "red" : ""
        return v[0]
      })
      .value()
    
    return CalendarList.slice(0, 5)
  },  

  
}

