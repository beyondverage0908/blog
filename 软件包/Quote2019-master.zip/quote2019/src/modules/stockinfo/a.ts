/**
 * 获取a股信息
 */

// import axios from "axios";
// import axios_debug from "../axios_debug"
import moment from "moment";
import cheerio from "cheerio";
import txt from "../txt";
import api_cache from "../api_cache";
import logger from "../logger";
const config = require('../../../config/index.js')

/**
 * 获取个股日历地址
 * @param item 
 */
function setlink(code:string, item:any, market:string){
  var href = "";
  switch (item.sjlxz)
  {
      // 停牌日期
      case "TFP":
          href = "http://data.eastmoney.com/tfpxx/";
          break;
      // 龙虎榜
      case "LHB":
          href = "http://data.eastmoney.com/stock/lhb/" + item.gpdm + ".html";
          break;
      // 大宗交易
      case "DZJY":
          href = "http://data.eastmoney.com/dzjy/detail/" + item.gpdm + ".html";
          break;
      // 公告
      case "GG":
          href = "http://data.eastmoney.com/notices/stock/" + item.gpdm + ".html";
          break;
      // 研报
      case "YB":
          href = "http://data.eastmoney.com/report/" + item.gpdm + ".html";
          break;
      // 机构调研
      case "JGDY":
          href = "http://data.eastmoney.com/jgdy/gsjsdy/" + item.gpdm + ".html";
          break;
      // 股东增减持日
      case "GDZJC":
          href = "http://data.eastmoney.com/executive/gdzjc/" + item.gpdm + ".html";
          break;
      // 限售解禁日
      case "XSJJ":
          href = "http://data.eastmoney.com/dxf/q/" + item.gpdm + ".html";
          break;
      // 高管持股
      case "GGZJC":
          href = "http://data.eastmoney.com/executive/" + item.gpdm + ".html";
          break;
      // 高管关联人持股
      case "GGXGZJC":
          href = "http://data.eastmoney.com/executive/" + item.gpdm + ".html";
          break;
      // 预约披露日
      case "YYPL":
          href = "http://data.eastmoney.com/bbsj/" + item.gpdm + ".html";
          break;
      // 业绩预告
      case "YJYG":
          href = "http://data.eastmoney.com/bbsj/" + item.gpdm + ".html";
          break;
      // 业绩快报
      case "YJKB":
          href = "http://data.eastmoney.com/bbsj/" + code + ".html";
          break;
      // 业绩报表
      case "YJBB":
          href = "http://data.eastmoney.com/bbsj/" + item.gpdm + ".html";
          break;
      // 股本变动
      case "GBBD":
          href = "http://emweb.securities.eastmoney.com/f10_v2/CapitalStockStructure.aspx?type=web&code=" + market + item.gpdm;
          break;
      // 新股
      case "XGSG":
          href = "http://data.eastmoney.com/xg/xg/detail/" + item.gpdm + ".html";
          break;
      // 分红
      case "FHPS":
          href = "http://data.eastmoney.com/yjfp/detail/" + item.gpdm + ".html";
          break;
      // 股东大会
      case "GDDH":
          href = "http://data.eastmoney.com/gddh/list/" + item.gpdm + ".html";
          break;
      // 股东户数
      case "GDHS":
          href = "http://data.eastmoney.com/gdhs/detail/" + item.gpdm + ".html";
          break;

      //股权质押
      case "GQZY":
          href = "http://data.eastmoney.com/gpzy/detail/" + item.gpdm + ".html";
          break;

      //委托理财
      case "WTLC":
          href = "http://data.eastmoney.com/wtlc/detail/" + item.gpdm + ".html";
          break;

      //股票回购
      case "GPHG":
          href = "http://data.eastmoney.com/gphg/" + item.gpdm + ".html";
          break;

      //并购重组
      case "BGCZ":
          href = "http://data.eastmoney.com/bgcz/detail/" + item.gpdm + ".html";
          break;

      //重大合同
      case "ZDHT":
          href = "http://data.eastmoney.com/zdht/detail/" + item.gpdm + ".html";
          break;

      //关联交易
      case "GLJY":
          href = "http://data.eastmoney.com/gljy/detail/" + item.gpdm + ".html";
          break;

      //公司投资
      case "GSTZ":
          href = "http://data.eastmoney.com/gstz/stock/" + item.gpdm + ".html";
          break;
      default: break;
  }
  return href; 
}

export default {
  /**
   * 基本信息
   * @param newcode 
   */
  async stockinfo (newcode:string) {
    let back = await api_cache({
      url: `${config.getEnvParam('quoteapi')}api/qt/stock/get?secid=${newcode}&fields=f57,f58,f107,f78,f127,f189,f198,f199,f111&dpt=wz.hdhy`,
      success_log: true,
      error_replace: {
        data: null
      }
    })

    if (back.data == null) {
      return null
    }

    //转换成老的板块id
    back.data.oldHY = ''
    try {
      if (back.data.f198) {
         back.data.oldHY = parseInt(back.data.f198.replace('BK', '')).toString()
      }      
    } catch (error) {
      
    }

    let SSDateFormat = back.data.f189.toString()
    let isSH = false //是否上市
    
  if (SSDateFormat != '0') {
      try {
        SSDateFormat = SSDateFormat.substring(0,4) + '-' + SSDateFormat.substring(4,6) + '-' + SSDateFormat.substring(6)
        let shdate = moment(back.data.f189, 'YYYYMMDD')
        
        
        if (shdate <= moment()) {
          isSH = true
        }
      } catch (error) {

        
      }
    }

    return {
      Name: back.data.f58,
      Code: back.data.f57,
      State: back.data.f78,
      BK: back.data.f127,
      HYID: back.data.f198,
      HYID2: back.data.f199,
      oldHY: back.data.oldHY,
      HYName: back.data.f127,
      SSDate: back.data.f189,
      SSDateFormat: SSDateFormat,
      isSH: isSH,
      level2type: back.data.f111 //二级类型
    }
  },
  /**
  //  * 额外信息 
  //  * @param newcode 
  //  */
  // async extraInfo (newcode:string) {
  //   let back = await axios.get(`${config.getEnvParam('quoteapi')}api/qt/ulist.np/get?secids=${newcode}&fields=f1,f2,f3,f4,f12,f13,f14,f107,f152,f26,f198&ut=6d2ffaa6a585d612eda28417681d58fb`)

  //   let SSDateFormat = back.data.data.f26

  //   if (SSDateFormat) {
  //     try {
  //       SSDateFormat = SSDateFormat.substring(0,4) + '-' + SSDateFormat.substring(4,6) + '-' + SSDateFormat.substring(6)
  //     } catch (error) {
        
  //     }
  //   }

  //   return {
  //     SSDate: back.data.data.f26,
  //     SSDateFormat: SSDateFormat
  //   }
  // },  
  /**
   * 个股日历
   * @param code 
   */
  async stockCalendar(code:string, market_str:string){
    let begin = moment().add(-6, 'months').format('YYYY-MM-DD')
    let end = moment().add(6, 'months').format('YYYY-MM-DD')

    let back = await api_cache({
      url: `http://dcfm.eastmoney.com/em_mutisvcexpandinterface/api/js?type=GGSJ20_ZDGZ&token=70f12f2f4f091e459a279469fe49eca5&st=rq&sr=-1&p=1&ps=10&filter=(gpdm=%27${code}%27%20and%20rq%3E=^${begin}^%20and%20rq%3C=^${end}^)`,
      error_replace: [],
      cache_time: 2 * 60 * 1000
    })

    back.forEach((v:any)=>{
      v.link = setlink(code, v, market_str)
    })

    return back
  },
  
  /**
   * 获取布告栏
   * @param id 
   */
  async getBulletin(id:string){
    let back = await api_cache({
      url: `http://bulletin.eastmoney.com/html/Base/${id}.html`,
      error_replace: ''
    })

    const $ = cheerio.load(back)
    let backarray:Array<any> = []
    $('a').each((i, elem)=>{
      backarray.push({
        Link: $(elem).attr('href'),
        Class: '',
        Text: $(elem).text()
      })
    })

    if (backarray.length == 0) {
      logger.error(`布告栏${id}格式错误`)
      return [{
        Link: '',
        Text: '',
        Class: ''
      }]
    }
    
    return backarray      
  },

  /**
   * 个股新闻
   * @param code 
   * @param count 
   * @param title_length 
   */
  async getGgxw(code:string, count:number, title_length:number):Promise<string>{
    let backstr:Array<string> = ['<ul>']

    /**
     * 东财特殊逻辑
     */
    if(code == '300059'){
      let bulletin = await this.getBulletin('1032')
      bulletin.forEach((v,i)=>{
        if (i >= count) return
        backstr.push(`<li><a target="_blank" title="${v.Text}" href="${v.Link}">${txt.txtLeft(v.Text, title_length + 6, false)}</a></li>`)
      })

      // console.info(bulletin)
      backstr.push('</ul>')
      return backstr.join('')
    }

    /**
     * 新闻接口
     */

    let news = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/StockNews?marketType=2&stockCode=${code}&stockName=&returnFields=Art_Title,Art_Url,Art_ShowTime`,
      error_replace: []
    })

    news.Data.forEach((v:any,i:number)=>{
      if (i >= count) return
      backstr.push(`<li><span>${v.Art_ShowTime.substring(5,10)}</span><a target="_blank" title="${v.Art_Title}" href="${v.Art_Url}">${txt.txtLeft(v.Art_Title, title_length, false)}</a></li>`)
    })

    backstr.push('</ul>')
    return backstr.join('')
  },

  /**
   * 个股公告
   * @param code 
   * @param count 
   */
  async getGonggao(code:string, count:number):Promise<string>{
    let back = await api_cache({
      url: `${config.getEnvParam('newsnotice')}webapi/api/Notice?Time=&CodeType=1&StockCode=${code}&FirstNodeType=0&SecNodeType=0&PageIndex=1&PageSize=${count}`,
      cache_time: 5 * 60 * 1000,
      error_replace: {
        data: []
      }
    })

    if ( !back.data || back.data.length == 0) {
      return '<span class="nodatalist">暂无数据</span>'
    }

    let backstr:Array<string> = ['<ul>']

    back.data.forEach((v:any)=>{
      backstr.push(`<li><span>${v.NOTICEDATE.substring(5,10)}</span><a target="_blank" title="${v.NOTICETITLE}" href="${v.Url}">${txt.txtLeft(v.NOTICETITLE, 38, false)}</a></li>`)
    })

    backstr.push('</ul>')

    return backstr.join('')
  },

  // /**
  //  * 个股研报
  //  * @param code 
  //  * @param count 
  //  * @param name_length 
  //  * @param title_length 
  //  */
  // async getStockReport(code:string, count:number, name_length:number, title_length:number):Promise<string>{
  //   let back = await api_cache({
  //     url: `http://datainterface.eastmoney.com/EM_DataCenter/js.aspx?type=SR&sty=GGSR&js=[(x)]&ps=${count}&p=1&code=${code}`,
  //     error_replace: []
  //   })

  //   if ( !(back instanceof Array)  || back.length == 0) {
  //     return `<tr><td colspan="3"><span class="nodatalist">暂无数据</span></td></tr>`
  //   }

  //   let backstr:Array<string> = []

  //   back.forEach((v:any)=>{
  //     v.ybdate = v.datetime.substring(0,10).replace(/-/g, '')
  //     backstr.push('<tr>');
  //     backstr.push(`<td align="center"><a target="_blank" href="http://data.eastmoney.com/report/${v.insCode}_0.html" class="lightBlue">${txt.txtLeft(v.insName, name_length, false)}</a></td>`);
  //     backstr.push(`<td align="center"><span>${v.sratingName}</span></td>`);
  //     backstr.push(`<td class="text-indent10"><span class="dt">${v.datetime.substring(5,10)}</span><a target="_blank" href="http://data.eastmoney.com/report/${v.ybdate}/${v.infoCode}.html">${txt.txtLeft(v.title, title_length, false)}</a></td>`);
  //     backstr.push("</tr>");
  //   })

  //   return backstr.join('')
  // },

  // /**
  //  * 行业研报
  //  * @param HYID 
  //  * @param count 
  //  * @param name_length 
  //  * @param title_length 
  //  */
  // async getHYReport(HYID:string, count:number, name_length:number, title_length:number):Promise<string>{
  //   let back = await api_cache({
  //     url: `http://datainterface.eastmoney.com/EM_DataCenter/js.aspx?type=SR&sty=HYSR&mkt=0&stat=0&cmd=4&code=${HYID}&sc=&ps=${count}&p=1&js=[(x)]`,
  //     error_replace: []
  //   })

  //   if (back.length == 0) {
  //     return `<tr><td colspan="3"><span class="nodatalist">暂无数据</span></td></tr>`
  //   }

  //   back = back.map((v:any)=>{
  //     let temp = v.split(',')
  //     let newobj:any = {}
  //     newobj.datetime = temp[1]
  //     newobj.insCode = temp[3]
  //     newobj.insName = temp[4]
  //     newobj.sratingName = temp[7]
  //     newobj.infoCode = temp[2]
  //     newobj.title = temp[9]
  //     return newobj
  //   })

  //   let backstr:Array<string> = []

  //   back.forEach((v:any)=>{
  //     let thisdate = moment(v.datetime, 'YYYY/M/D hh:mm:ss')
  //     let ybdate = thisdate.format('MM-DD')
  //     let ybdate2 = thisdate.format('YYYYMMDD')
  //     //v.ybdate = v.datetime.substring(0,10).replace(/-/g, '')
  //     backstr.push('<tr>');
  //     backstr.push(`<td align="center"><a target="_blank" href="http://data.eastmoney.com/report/${v.insCode}_0.html" class="lightBlue">${txt.txtLeft(v.insName, name_length, false)}</a></td>`);
  //     backstr.push(`<td align="center"><span>${v.sratingName}</span></td>`);
  //     backstr.push(`<td class="text-indent10"><span class="dt">${ybdate}</span><a target="_blank" href="http://data.eastmoney.com/report/${ybdate2}/hy,${v.infoCode}.html">${txt.txtLeft(v.title, title_length, false)}</a></td>`);
  //     backstr.push("</tr>");
  //   })

  //   return backstr.join('')


  // },

  async getPageHtml(url:string):Promise<string>{
    let back = await api_cache({
      url: url,
      error_replace: ''
    })
    if (back == '') {
      return ''
    }

    let backstr = back.trim()

    backstr = backstr.replace(/<ul><li><a/ig, "").replace(/<\/li><\/ul>/ig, "")
    backstr = '<a style="color:#ff4901; font-size:12px;" target="_blank"' + backstr;

    return backstr
  },

  /**
   * 投票数据
   * @param code 
   */
  async getVote(code:string){
    let back = await api_cache({
      url: `${config.getEnvParam('voteapi')}UserData/GetWebTape?callback=aa&code=${code}`,
      error_replace: ''
    })

    let backtxt:string = back
    backtxt = backtxt.substring(
      backtxt.indexOf('aa(') + 3,
      backtxt.length -1
    )

    let backobj:any

    try {
      backobj = JSON.parse(backtxt)
      return {
        kz: backobj.Data.TapeZ != 0 ? backobj.Data.TapeZ:0.5,
        kd: backobj.Data.TapeD != 0 ? backobj.Data.TapeD :0.5,
        date: backobj.Data.Date
      }        
    } catch (error) {
      return {
        kz: 0.0,
        kd: 0.0,
        date: ''
      }      
    }

  },

  /**
   * 十大股东
   * 
   *  */

  async getLtgd(code: string){
    let back = await api_cache({
      url: `${config.getEnvParam('ltgdapi')}quote/api/ltgd/data/${code}`,
      error_replace: {
        result: false
      }
    });
    if (!back.result) {
      return []
    }
    // console.info(back.data)
    
    return back.data
  }


  
}