/**
 * 美股 获取接口数据
 */
const config = require('../../../config/index.js')
import api_cache from "../api_cache"
import _ from "lodash"

export default {
  /**
   * 根据code获取市场号 返回undefined可以认为不是美股
   * @param code 
   */
  async getMarket(code:string){    
    let back = await api_cache({
      url: `${config.getEnvParam('quoteapi')}api/qt/clist/get?pn=1&pz=1000000&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f3&fs=m:105,m:106,m:107&fields=f12,f13`,
      cache_time: 30 * 60 * 1000,
      file_cache_time: 30 * 60 * 1000,
      error_replace: {
        data: {
          diff: []
        }
      }
    })

    let codelist:Array<{f12:string, f13: number, f14:string}> = _.get(back, 'data.diff', [])

    if (codelist.length == 0) {
      return undefined
    }

    return codelist.find(v=>{
      return v.f12.toUpperCase() == code.toUpperCase()
    })
  },

  /**
   * 基本信息
   * @param quotecode 
   */
  async stockinfo (quotecode:string) {
    let back = await api_cache({
      url: `${config.getEnvParam('quoteapi')}api/qt/stock/get?secid=${quotecode}&fields=f57,f58,f107,f78,f127,f189,f198,f199,f111&dpt=wz.hdhy`,
      success_log: true,
      error_replace: {
        data: null
      }
    })

    return _.get(back, 'data', null)
  },

  /**
   * 获取美股公告
   * @param code 
   */
  async getNotice(code:string){
    let back = await api_cache({
      url: `${config.getEnvParam('newsnotice')}webapi/api/Notice?Time=&PageIndex=1&FirstNodeType=0&SecNodeType=0&CodeType=11&StockCode=${code}&PageSize=5`,
      cache_time: 5 * 60 * 1000,
      error_replace: {
        data: []
      }
    })

    return _.get(back, 'data', [])    
  },

  /**
   * 获取美股聚焦
   */
  async getMarketNews(){
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews?columns=436&pageindex=1&pagesize=5`,
      error_replace: {
        Result: []
      }
    })

    return _.get(back, 'Result', [])    
  },  

  /**
   * 获取美股评论
   */
  async getComment(){
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews?columns=582&pageindex=1&pagesize=5`,
      error_replace: {
        Result: []
      }
    })

    return _.get(back, 'Result', [])    
  },

  /**
   * 获取F10布告栏
   * @param newcode BRK_A
   */
  async getF10Bulletin(newcode:string){
    let back = await api_cache({
      url: `${config.getEnvParam('bulletin')}html/Base/461.html`,
      error_replace: ''
    })

    return back.replace(/#code#/ig, newcode).replace(/<a /ig, "<a target=_blank ").replace(/<ul>/ig, "<ul class='F10DA clearfix pl10'>")
  }
}