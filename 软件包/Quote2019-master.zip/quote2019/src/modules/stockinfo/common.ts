/**
 * 通用接口数据
 */
const config = require('../../../config/index.js')
import api_cache from "../api_cache"
import _ from "lodash"

export default {
  /**
   * 根据栏目号获取cmsapi新闻列表
   * @param column_id 栏目号
   * @param pageindex 分页
   * @param pagesize 每页条数
   */
  async getCMSNewsByColumn(column_id:string, pageindex:number=1, pagesize:number=5){
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews/QueryCmsNewsByColumnFile?column=${column_id}&pageindex=${pageindex}&pagesize=${pagesize}`,
      error_replace: {
        Result: []
      }
    })

    return _.get(back, 'Result', [])    
  },
  /**
   * 股吧牛人
   * @param code 股吧代码
   * @param count 获取数量
   */
  async getGuBaActiveUserList(code:string, count:number=20){
    let back = await api_cache({
      url: `${config.getEnvParam('guba_api')}suggest/api/suggest/GubaFierceUserList?code=${code}&ps=${count}&product=EastMoney&plat=web&version=2&Deviceid=1`,
      error_replace: {
        re: []
      },
      check_callback: function (data:any) {
        return data.re instanceof Array
      }
    })
    return _.get(back, 're', [])
  }
}