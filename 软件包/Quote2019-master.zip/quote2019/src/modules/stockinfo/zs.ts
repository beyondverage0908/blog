/**
 * 指数获取接口
 */
const config = require('../../../config/index.js')
import axios from "axios";
import memorycache from "memory-cache";
import txt from "../txt";
import moment = require("moment");
import cheerio from "cheerio";
import api_cache from "../api_cache"
// import axios_debug from "../axios_debug";
import apiCache from "../api_cache";
import logger from "../logger";
import _ from "lodash";

/**
 * 指数基本信息
 */
interface ZSBaseInfo{
  /**
   * 代码
   */
  code:string,
  /**
   * 行情新市场
   */
  newmarket: string,
  /**
   * 名称
   */
  name: string
}

export default {
  /**
   * 指数列表 带内存缓存
   */
  async getZSList():Promise<Array<ZSBaseInfo>>{

    let cachelist = memorycache.get('zslist')
    if (cachelist) {
      return cachelist
    }

    let back = await api_cache({
      url: `${config.getEnvParam('quoteapi')}api/qt/clist/get?fs=m:1+t:1,m:0+t:5&fields=f12,f13,f14&dpt=wz.hdhy&ut=6d2ffaa6a585d612eda28417681d58fb&np=3`,
      error_replace: {
        data: {
          diff: []
        }
      }
    })

    if (back.data.diff.length > 0) {
      let backlist = back.data.diff.map((v: any)=>{
        return {
          code: v.f12,
          newmarket: v.f13.toString(),
          name: v.f14
        }
      })
      memorycache.put('zslist', backlist, 5 * 60 * 1000)
      return backlist
    }

    return []
    
  },
  /**
   * 根据code获取指数基本信息
   */
  async getZSInfo(code:string){
    let list = await this.getZSList()
    
    let back = list.find(v=>{
      return v.code == code
    })

    if (back) {
      return back
    }
    else{
      return null
    }
  },

  /**
   * 成份股列表
   * @param Code 
   * @param Market 
   */
  GetCFGInfo(Code:string, Market:string){
      let res = ["10", "上证A股涨幅", "10"]
      if (Market == "2")
      {
          res[0] = "20"; res[1] = "深证A股涨幅"; res[2] = "20";
      }
      switch (Code)
      {
          case "000300": res[0] = "28003500"; res[1] = "沪深300成分股"; res[2] = "28003500_0_2"; break;
          case "399006": res[0] = "27"; res[1] = "创业板涨幅"; res[2] = "27"; break;
          case "000003": res[0] = "11"; res[1] = "B股涨幅"; res[2] = "11"; break;
          case "399002": res[0] = "2850018"; res[1] = "成分A指成分股"; res[2] = "2850018_0"; break;
          case "399003": res[0] = "2850019"; res[1] = "成分B指成分股"; res[2] = "2850019_0"; break;
          case "000016": res[0] = "2850016"; res[1] = "上证50成分股"; res[2] = "28003611_0_2"; break;
          case "399102": res[0] = "27"; res[1] = "创业板涨幅"; res[2] = "27"; break;
      }
      return res;
  },

  /**
   * 证券要闻
   */
  async zqyw(){
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews/QueryCmsNewsByColumnFile?column=353&pageindex=1&pagesize=5`,
      error_replace: {
        Result: []
      }
    })
    return back.Result
  },

  /**
   * 大盘分析
   */
  async dpfx(){
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews/QueryCmsNewsByColumnFile?column=407&pageindex=1&pagesize=5`,
      error_replace: {
        Result: []
      }
    })
    return back.Result
  }, 
  
  /**
   * 公司快讯
   */
  async gskx(){
    let back = await apiCache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews/QueryCmsNewsByColumnFile?column=349&pageindex=1&pagesize=5`,
      error_replace: {
        Result: []
      }
    })
    return back.Result
  },


  // /**
  //  * 研究报告
  //  * @param count 
  //  */
  // async getReport(count:number){
  //   // let back = await api_cache({
  //   //   url: `http://datainterface.eastmoney.com/EM_DataCenter/js.aspx?type=SR&sty=HYSR&mkt=0&stat=0&cmd=1&code=&sc=&p=1&ps=` + count,
  //   //   error_replace: ''
  //   // })

  //   let back
  //   let backdata = []
  //   let date1 = moment().add(-2,'years').format('YYYY-MM-DD')
  //   let date2 = moment().format('YYYY-MM-DD')

  //   try {
  //     back = await axios(`${config.getEnvParam('report')}report/list?beginTime=${date1}&endTime=${date2}&pageNo=1&pageSize=4&qType=1&industryCode=*&fields=orgCode,orgSName,sRatingName,encodeUrl,title,publishDate`)    
  //     backdata = back.data.data  
  //   } catch (error) {
  //     backdata = []
  //   }




  //   // try {
  //   //   backdata = JSON.parse(back.substring(1, back.length - 1))
  //   // } catch (error) {
  //   //   return []
  //   // }

  //   if (backdata.length == 0) {
  //     return []
  //   }

  //   let backlist = backdata.map((v:any)=>{
  //     // let item = v.split(',')
  //     // let date = moment(item[1], 'YYYY/M/D')
  //     return {
  //       jg: v.orgSName,
  //       jgid: v.orgCode,
  //       pj: v.sRatingName || '-',
  //       title: txt.txtLeft(v.title, 20, false),
  //       link: `http://data.eastmoney.com/report/zw_industry.jshtml?encodeUrl=${v.encodeUrl}`,
  //       date: v.publishDate.substring(5,10)
  //     }
  //   })

  //   return backlist
  // },

  /**
   * 名博论市
   */
  async getBlog(){
    let back = await api_cache({
      url: `${config.getEnvParam('bulletin')}html/base/1077.html`,
      error_replace: ''
    })

    try {
      const $ = cheerio.load(back)

      let html:Array<string|null> = []

      $('a').attr('target', '_blank')

      $('li').each(function(i, elem) {
        if (i > 0 && i < 6) {
          html.push($(elem).html())
        }
      })

      return html
    } catch (error) {
      logger.error(error)
      return []
    }

  },

  /**
   * 东方视点
   */
  async getDfsd(){
    try {
      let back = await api_cache({
        url: `${config.getEnvParam('bulletin')}html/base/1071.html`,
        error_replace: ''
      })

      const $ = cheerio.load(back)

      $('a').attr('target', '_blank')

      return $('li').eq(0).html()
    } catch (error) {
      logger.error(error)
      return ''
    }

  },

  /**
   * 行情图上面的布告栏
   * @param id 
   */
  async getTopBulletin(id:string){
    try {
      let back = await api_cache({
        url: `${config.getEnvParam('bulletin')}html/base/${id}.html`,
        error_replace: ''
      })

      const $ = cheerio.load(back)

      $('a').attr('target', '_blank')
      $('a').attr('class', 'red')

      return $('li').eq(0).html()
    } catch (error) {
      logger.error({
        'error_message': error.message,
        'stack': error.stack,
        'url': `${config.getEnvParam('bulletin')}html/base/${id}.html`
      })
      return ''
    }    
  },

  /**
   * 机构调查
   */
  async getJgdc(){
    try {
      let back = await api_cache({
        url: `http://bgl.eastmoney.com/vote_3.html`,
        error_replace: ''
      })

      const $ = cheerio.load(back)

      let texts:Array<number> = []

      $('td').each(function(i, elem) {
        if (i > 2 && i < 6) {
          let text = $(elem).text().match(/\d+/)
          if (text) {
            texts.push(parseInt(text[0]))
          }
          else{
            texts.push(20)
          }
          
        }
      })
      return texts
    } catch (error) {
      logger.error(error)
      return [20, 20, 20]
    }    
  },

  /**
   * 获取融资融券日期
   */
  async getRzrqDate(){
    let back = await api_cache({
      url: `${config.getEnvParam('datainterface3')}EM_DataCenter_V3/api/RZRQZXRQ/GetRZRQZXRQC?tkn=eastmoney&cfg=rzrqzxrq`,
      error_replace: {
        Data: [
          {
            Data: ['']
          }
        ]
      }
    })
    return back.Data[0].Data[0]
  },

  /**
   * 获取融资融券数据
   */
  async getRzrq(){
    let date = await this.getRzrqDate()
    let back = await api_cache({
      url: `${config.getEnvParam('datainterface3')}EM_DataCenter_V3/api/RZRJHSZSHJDRZZJE/GetRZRJHSZSHJDRZZJE?tkn=eastmoney&cfg=hszshjdrzzje&datetime=${date}`,
      keystr: 'quote_zs_rzrq_data_string',
      error_replace: {}
    })    

    try {
      let fields:Array<string> = back.Data[0].FieldName.split(',')
      let data:Array<string> = back.Data[0].Data[0].split('|')

      let returnobj:any = {
        date: date,
        date2: moment(date, 'YYYY-MM-DD').format('YYYY年MM月DD日')
      }

      fields.forEach((v, i)=>{
        returnobj[v] = data[i]
      })

      return returnobj      
    } catch (error) {
      logger.error(error)
      return {}
    }



  },

  /**
   * 财富号
   */
  async getCFH(){
    try {
      let back = await api_cache({
        method: 'post',
        url: config.getEnvParam('cfh_articles'),
        postdata: {
          columnid: 2,
          pagesize: 10,
          pageindex: 1
        },
        error_replace: []
      })

      return back.map((v:any)=>{
        return {
          ArtCode: v.ArtCode,
          Title: v.Title,
          Showtime: moment(v.Showtime).format('YYYY-MM-DD HH:mm:ss')
        }
      })      
    } catch (error) {
      return ''
    }

  },

  async getPicDownBulletin(){
    return `<ul><li><a href="http://js1.eastmoney.com/tg.aspx?ID=961" target="_blank" class="red">最新基金重仓股</a></li><li><a href="http://js1.eastmoney.com/tg.aspx?ID=468" target="_blank">沪深两市龙虎榜</a></li><li><a href="http://js1.eastmoney.com/tg.aspx?ID=383" target="_blank">高管增减持股明细</a></li><li><a href="https://acttg.eastmoney.com/pub/webtg_hskh_act_hqtxfwzl1_01_01_01_0" target="_blank">万2.5极速开户</a></li><li><a href="https://acttg.eastmoney.com/pub/webtg_hskh_act_hqywzl2_01_01_01_0" target="_blank" class="red">主力异动提前看</a></li><li class="last"><a href="http://js1.eastmoney.com/tg.aspx?ID=967" target="_blank">个股资金流向</a></li></ul>`
  },

  /**
   * 多空调查
   */
  async getDkdc(){
    let back = await api_cache({
      url: `http://vote.eastmoney.com/VoteAPI/Handlers/ViewVoteResultHandler.ashx?VoteOptionID=1`,
      error_replace: {
        VoteOptions: []
      }
    })

    let backarray:Array<any> = ["0", "0", "0", "0", "0", "0"]

    back.VoteOptions.forEach((v:any)=>{
      switch (v.OptionSeqValue){
          case 1:
              backarray[0] = v.OptionCounter.toString()
              backarray[3] = v.OptionRate.replace('%', '')/2
              break;
          case 2:
              backarray[1] = v.OptionCounter.toString()
              backarray[4] = v.OptionRate.replace('%', '')/2
              break;
          case 3:
              backarray[2] = v.OptionCounter.toString()
              backarray[5] = v.OptionRate.replace('%', '')/2
              break;
          
          default: break;
      }
    })

    return backarray
  },
  /**
   * 市场总貌
   */
  async sczm(){
    let back = await api_cache({
      url: `${config.getEnvParam('sczmapi')}getMarketOverview?ut=7eea3edcaed734bea9cbfc24409ed989&dpt=wz.sczm`,
      check_callback: function(data:any) {
        return _.has(data, 'data.overview')
      },
      error_replace: {
        data: {
          ut: '',
          overview: [
            {
              nt: "深市",
              td: '',
              v: '',
              tv: '',
              ts: '',
              ns: '',
              cn: '',
              ttm: ''
            },
            {
              nt: "中小板",
              td: '',
              v: '',
              tv: '',
              ts: '',
              ns: '',
              cn: '',
              ttm: ''
            },
            {
              nt: "创业板",
              td: '',
              v: '',
              tv: '',
              ts: '',
              ns: '',
              cn: '',
              ttm: ''
            },
            {
              nt: "沪市",
              td: '',
              v: '',
              tv: '',
              ts: '',
              ns: '',
              cn: '',
              ttm: ''
            }
          ]
        }
      }
    })
    
    let backdata = back.data.overview

    let returndata = {
      date: '', //更新时间
      ss: null, //深市
      zxb: null, //中小板
      cyb: null, //创业板
      hs: null //沪市
    }

    back.data.ut = back.data.ut.toString()

    returndata.date = back.data.ut != ''?`${back.data.ut.substring(0,4)}年${back.data.ut.substring(4,6)}月${back.data.ut.substring(6,8)}日`:''

    returndata.ss =  backdata.find((v:any)=>{
      return v.nt == '深市'
    })
    returndata.zxb =  backdata.find((v:any)=>{
      return v.nt == '中小板'
    })
    returndata.cyb =  backdata.find((v:any)=>{
      return v.nt == '创业板'
    })
    returndata.hs =  backdata.find((v:any)=>{
      return v.nt == '沪市'
    })    

    return returndata
  }
}