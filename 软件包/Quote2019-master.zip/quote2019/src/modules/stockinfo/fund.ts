/**
 * 获取基金信息
 */


import moment from "moment";
import cheerio from "cheerio";
import txt from "../txt";
import api_cache from "../api_cache";
import logger from "../logger";
const config = require('../../../config/index.js')

export default {
  /**
   * 获取热门股吧
   */
  async hotGuba(){
    let back = await api_cache({
      url: `${config.getEnvParam('gubawebapi')}v3/read/Guba/HotGuba.aspx?type=5&deviceid=900150983cd24fb0d6963f7d28e17f72&version=200&product=EastMoney&plat=web&ps=15`,
      error_replace: {
        re:[]
      },
      cache_time: 2 * 60 * 1000
    })

    let result = back.re.map((v:any)=>{
      return v.stockbar_market.replace('.sh', '1').replace('.sz', '2')
    })

    return result
  },

  /**
   * 获取基金资讯
   * @param name 
   */
  async getFundNews(name:string){
    let back = await api_cache({
      url: `${config.getEnvParam('searchapi')}api/Info/Search?and20=MultiMatch/Art_Title,Art_Content/${encodeURIComponent(name)}^/True&isAssociation20=True&sort20=Art_CreateTime|2&highlights20=null&pageIndex20=1&pageSize20=5&returnFields20=Art_Url,Art_CreateTime,Art_Title|0&type=20&token=32A8A21716361A5A387B0D85259A0037`,
      headers: {'Referer': 'http://so.eastmoney.com'},
      error_replace: {
        Data:[]
      },
      cache_time: 2 * 60 * 1000
    })

    if (back.Data == null) {
      return []
    }

    let result = back.Data.map((v:any)=>{
      return {
        title: v.Art_Title,
        date: v.Art_CreateTime,
        url: v.Art_Url
      }
    })

    return result    
  },

  /**
   * 获取基金公告
   */
  async getFundNotice(code:string){
    let back = await api_cache({
      url: `${config.getEnvParam('fundmobapitest')}FundMEApi/FundNoticeList?FCODE=${code}&pageIndex=1&pageSize=5&deviceid=QuotePage2017&version=1.0&product=Eastmoney&plat=Web`,
      error_replace: {
        Datas:[]
      },
      cache_time: 2 * 60 * 1000
    })

    if (!back.Datas) {
      return []
    }

    return back.Datas    
  },  

  /**
   * 获取公司公告
   * @param code 
   */
  async getStockNotice(code:string){
    let codeType = "6";
    if (code.indexOf("2") == 0)
    {
        codeType = "7";
    }
    let back = await api_cache({
      url: `${config.getEnvParam('newsnotice')}webapi/api/Notice?Time=&CodeType=${codeType}&StockCode=${code}&PageSize=5&PageIndex=1&FirstNodeType=0&SecNodeType=0&Token=WZSJPD161130`,
      error_replace: {
        data:[]
      },
      cache_time: 5 * 60 * 1000
    })

    let result = back.data.map((v:any)=>{
      return {
        title: v.NOTICETITLE,
        date: v.NOTICEDATE.substring(5, 10),
        url: v.Url
      }
    })

    return result
  }    
}

