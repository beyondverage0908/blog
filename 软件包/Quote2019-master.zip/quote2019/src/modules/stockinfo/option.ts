/**
 * 期权获取接口信息
 */

const config = require('../../../config/index.js')
import api_cache from "../api_cache"
import _ from "lodash"
import logger from "../logger"


export default {
  /**
   * 期权基本信息
   * @param quotecode 
   */
  async stockinfo (market:string, quotecode:string) {
    let back = await api_cache({
      url: `${config.getEnvParam('option')}static/${market}_${quotecode}_qt`,
      success_log: true,
      error_replace: {
        data: null
      }
    })

    let backobj = _.get(back, 'qt', null)
    if (backobj == null) {
      return null
    }

    try {
      return {
        name: backobj.name,
        code: backobj.dm
      }
    } catch (error) {
      logger.error('期权基本信息解析错误')
      return null
    }
  }
  
}