/**
 * 债券
 */
const config = require('../../../config/index.js')
import api_cache from "../api_cache"
import _ from "lodash"




export default {
  /**
   * 获取债券聚焦
   */
  async getFocusNews(){
    let back = await api_cache({
      url: `${config.getEnvParam('newsinfo')}kuaixun/v2/api/list/325/0/0/1/5`,
      error_replace: {
        Result: []
      },
      check_callback: function(data:any){
        return data instanceof Array
      }
    })

    return back  
  },
  /**
   * 获取债市分析
   */
  async getAnalysis(){
    let back = await api_cache({
      url: `${config.getEnvParam('newsinfo')}kuaixun/v2/api/list/326/0/0/1/5`,
      error_replace: {
        Result: []
      },
      check_callback: function(data:any){
        return data instanceof Array
      }
    })

    return back  
  },
  /**
   * 获取债券公告
   * @param IsConversionDebt 是否是可转债
   * @param OldStockMarket 市场
   */
  async getNotices(IsConversionDebt:boolean, OldStockMarket:string){
    let noticeType = IsConversionDebt ? "15" : OldStockMarket == "1" ? "13" : "14";
    let back = await api_cache({
      url: `${config.getEnvParam('newsnotice')}webapi/api/Notice?Time=&CodeType=${noticeType}&StockCode=&FirstNodeType=0&SecNodeType=0&PageIndex=1&PageSize=5`,
      cache_time: 5 * 60 * 1000,
      error_replace: {
        data: []
      },
      check_callback: function(data:any){
        return data.data instanceof Array
      }
    })

    return _.get(back, 'data', [])   
  }
  
}