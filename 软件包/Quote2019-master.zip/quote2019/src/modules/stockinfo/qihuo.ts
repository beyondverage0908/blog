/**
 * 获取期货接口信息
 */

const config = require('../../../config/index.js')
import api_cache from "../api_cache"
import _ from "lodash"
import logger from "../logger"


export default {
  /**
   * 期货基本信息
   * @param quotecode 
   */
  async stockinfo (code:string) {
    let back = await api_cache({
      url: `${config.getEnvParam('option')}/list/113,142,114,115?orderBy=zdf&sort=desc&pageSize=1000000&pageIndex=0`,
      error_replace: null
    })

    if (back == null) {
      return null
    }

    let codelist = _.get(back, 'list', [])
    if (codelist instanceof Array && codelist.length > 0) {
      
    }
    else{
      return null
    }
    

    let thiscode = codelist.find(v=>{  
      return v.dm && v.dm.toLowerCase() == code.toLowerCase()
    })

    if (thiscode == undefined) {
      return null
    }

    try {
      return {
        name: thiscode.name,
        code: thiscode.dm,
        market: thiscode.sc,
        type: thiscode.lx
      }
    } catch (error) {
      return null
    }
  },

  async getCMSNews(mktNum:string, segMktNum:string, type:number){

    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews/QueryCmsNewsBySecondary?mktnum=${mktNum}&seg_mktnum=${segMktNum}&type=${type}&count=5`,
      error_replace: {
        Result: {
          TradeVarietyName: '',
          News: []          
        }
      }
    })

    back = back.Result
    

    let backlist = _.get(back, 'News', []) 

    let seg = segMktNum;
    //小麦和强麦是一个资讯和评论
    if (mktNum == "115" && segMktNum == "1"){
        seg = "2";
    }

    //豆二和豆一是一个资讯和评论
    if (mktNum == "114" && segMktNum == "3"){
        seg = "2";
    }

    if (backlist.length > 0){

      backlist.forEach((v:any)=>{
        v.Art_Showtime = v.Art_ShowTime
        v.Art_Url = v.Art_UniqueUrl
      })

      //修改名称
      if (mktNum == "115" && segMktNum == "1")
      {
          back.TradeVarietyName = "强麦";
      }
      if (mktNum == "114" && segMktNum == "3")
      {
          back.TradeVarietyName = "豆二";
      }
      return back;
        
    }
    
    return this.getSupplementCMSNews(type);
  },

  async getSupplementCMSNews(type:number){
    let dataUrl = '';
    if (type == 1){
        dataUrl = `${config.getEnvParam('cmsapi')}api/CmsNews?columns=516&pageindex=1&pagesize=5`;
    }
    else if (type == 2){
        dataUrl = `${config.getEnvParam('cmsapi')}api/CmsNews?columns=513&pageindex=1&pagesize=5`;
    }
    if (dataUrl != ''){
        let back = await api_cache({
          url: dataUrl,
          error_replace: {
            Result: []
          }
        })

        let content = _.get(back, 'Result', [])

        back.News = content
        if (content.length > 0){
          
          back.News.forEach((v:any)=>{
            v.Art_Url = v.Art_UniqueUrl
          })

          //赋值名称
          if (type == 1){
              back.TradeVarietyName = "综合";
              back.Url = "http://futures.eastmoney.com/news/czhzx.html";
          }
          else if (type == 2){
              back.TradeVarietyName = "期市";
              back.Url = "http://futures.eastmoney.com/news/cqspl.html";
          }
          return back;
        }
    }
    return null;
  }
  
}