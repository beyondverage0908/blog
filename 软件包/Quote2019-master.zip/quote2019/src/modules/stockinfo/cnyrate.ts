/**
 * 人民币汇率中间价接口信息
 */


const config = require('../../../config/index.js')
import api_cache from "../api_cache"
import _ from "lodash"
import moment from "moment"

/**
 * 外汇类型和新闻id对应表
 */
let newsids: {[index: string]:number} = {
  USD: 1,
  CNY: 6,
  EUR: 4,
  JPY: 8,
  GBP: 5,
  CHF: 3,
  CAD: 7,
  AUD: 2,
  NZD: 354
}

export default {
  /**
   * 获取基本信息
   * @param quotecode 带市场的代码
   */
  async getBaseInfo(quotecode:string){
    let back = await api_cache({
      url: `${config.getEnvParam('quoteapi')}api/qt/stock/get?secid=${quotecode}&fields=f57,f58,f107,f78,f127,f189,f198,f199,f256,f257,f258,f269,f270,f271,f112&dpt=wz.hdhy`,
      error_replace: {
        data: null
      }
    })

    return _.get(back, 'data', null)
  },
  /**
   * 获取人民币月平均汇率
   */
  async getAvgCNYRateMonthly(){
    let back = await api_cache({
      url: `${config.getEnvParam('nuexd')}EM_UBG_Finance2016TransferExtendInterface/js.ashx?type=CNYRateAVGPriceOneMonth`,
      error_replace: [],
      check_callback: function(data:any){
        return data instanceof Array
      }
    })

    return back
  },
  async getNews(type:string){
    
    let newsid = newsids[type] || 1 //如果没有匹配 就取美元

    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews/QueryCmsNewsByAttrFile?attr_id=${newsid}&pageindex=1&pagesize=5`,
      error_replace: {
        Result: []
      }
    })

    return _.get(back, 'Result', [])   
  },
  newsids: newsids
  
}

