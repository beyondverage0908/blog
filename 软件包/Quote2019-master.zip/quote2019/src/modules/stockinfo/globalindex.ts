/**
 * 全球指数 获取接口数据
 */
const config = require('../../../config/index.js')
import api_cache from "../api_cache"
import _ from "lodash"

/**
 * 地区
 */
enum Area {
  ASIA,
  HK,
  AME,
  EUR,
  AUS,
  AFI
}


export default {
  /**
   * 根据code获取市场号 返回undefined可以认为不是美股
   * @param code 
   */
  async getMarket(code:string){    
    //[ "AF", "AS", "AT", "BDI", "BL", "BZ", "CA", "CRB", "CZ", "DM", "EP", "FH", "FL", "GM", "HL", "HLL", "ID", "IL", "IND", "JP", "KE", "KOR", "LL", "LT", "MA", "MX", "NZ", "PHP", "PK", "PL", "PT", "RS", "SD", "SIN", "SL", "SP", "SW", "TL", "TW", "UK", "US3", "US4", "VN", "HKI", "HKIN", "HS", "UDI", "US1", "US2" ]
    //[309,310,311,349,312,313,343,348,315,316,345,318,319,320,321,322,323,324,325,306,326,307,327,304,329,330,331,332,333,334,344,335,336,303,337,338,339,340,308,341,351,352,342,305,125,124,347,301,302]

    let back = await api_cache({
      url: `${config.getEnvParam('quoteapi')}api/qt/clist/get?pn=1&pz=1000000&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fid=f3&fs=m:309,m:310,m:311,m:349,m:312,m:313,m:343,m:348,m:315,m:316,m:345,m:318,m:319,m:320,m:321,m:322,m:323,m:324,m:325,m:306,m:326,m:307,m:327,m:304,m:329,m:330,m:331,m:332,m:333,m:334,m:344,m:335,m:336,m:303,m:337,m:338,m:339,m:340,m:308,m:341,m:351,m:352,m:342,m:305,m:125,m:124,m:347,m:301,m:302&fields=f12,f13`,
      cache_time: 30 * 60 * 1000,
      file_cache_time: 30 * 60 * 1000,
      error_replace: {
        data: {
          diff: []
        }
      }
    })

    let codelist:Array<{f12:string, f13: number, f14:string}> = _.get(back, 'data.diff', [])

    if (codelist.length == 0) {
      return undefined
    }

    return codelist.find(v=>{
      return v.f12 == code
    })
  },

  /**
   * 基本信息
   * @param quotecode 
   */
  async stockinfo (quotecode:string) {
    let back = await api_cache({
      url: `${config.getEnvParam('quoteapi')}api/qt/stock/get?secid=${quotecode}&fields=f57,f58,f107,f78,f127,f189,f198,f199,f111,f112&dpt=wz.hdhy`,
      success_log: true,
      error_replace: {
        data: null
      }
    })

    return _.get(back, 'data', null)
  },
  Area: Area,
  /**
   * 根据JYS获取指数的地区
   * @param JYS 
   */
  getAreaByJYS: function (JYS:string) {
    if (JYS == "AF"){
      //非洲指数
      return Area.AFI
    }
    else if (JYS == "BZ" || JYS == "CA" || JYS == "CRB" || JYS == "MX" || JYS == "US1" || JYS == "US2" || JYS == "US3" || JYS == "US4" || JYS == "US4" || JYS == "UDI")
    {
      //美洲指数
      return Area.AME
    }
    else if (JYS == "AT" || JYS == "BDI" || JYS == "BL" || JYS == "CZ" || JYS == "DM" || JYS == "EP" || JYS == "FH" || JYS == "FL" || JYS == "GM" || JYS == "HL" || JYS == "HLL" || JYS == "IL" || JYS == "KE" || JYS == "LL" || JYS == "LT" || JYS == "PL" || JYS == "PT" || JYS == "RS" || JYS == "SD" || JYS == "SP" || JYS == "SW" || JYS == "UK") {
      //欧洲指数
      return Area.EUR
    }
    else if (JYS == "ID" || JYS == "IND" || JYS == "JP" || JYS == "KOR" || JYS == "MA" || JYS == "PHP" || JYS == "PK" || JYS == "SIN" || JYS == "SL" || JYS == "TL" || JYS == "TW" || JYS == "VN"){
      //亚太指数
      return Area.ASIA
    }
    else if (JYS == "AS" || JYS == "NZ"){
      //澳洲指数
      return Area.AUS
    }
    else if (JYS == "HKI" || JYS == "HKIN" || JYS == "HS"){
      //香港指数
      return Area.HK
    }    
    return Area.HK
  },
  /**
   * 获取相关市场新闻
   * @param thisArea 当前区域
   */
  async getCurrentStockNews(thisArea:Area){
    let ColumnId = 782
    switch (thisArea) {
      case Area.ASIA:
        ColumnId = 782;
        break;
      case Area.HK:
        ColumnId = 532;
        break;
      case Area.AME:
        ColumnId = 792;
        break;
      case Area.EUR:
        ColumnId = 781;
        break;
      case Area.AUS:
        ColumnId = 790;
        break;
      case Area.AFI:
        ColumnId = 782;
        break;
      default:
        break;
    }
    
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews/QueryCmsNewsByColumnFile?column=${ColumnId}&pageindex=1&pagesize=5`,
      error_replace: {
        Result: []
      }
    }) 

    return _.get(back, 'Result', [])    
  },
  /**
   * 获取其他市场新闻
   */
  async getOtherStockNews(){
    let OtherColumnId = 786
    
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews/QueryCmsNewsByColumnFile?column=${OtherColumnId}&pageindex=1&pagesize=5`,
      error_replace: {
        Result: []
      }
    })

    return _.get(back, 'Result', [])    
  }
  
}