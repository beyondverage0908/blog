/**
 * 获取港股股票信息
 */

// import axios from "axios";
const config = require('../../../config/index.js')
// import logger from "../logger"
import api_cache from "../api_cache"
// import axios_debug from "../axios_debug"

export default {
  /**
   * 获取港股股票信息
   * @param newcode 
   */
  async stockinfo (newcode:string) {
    let back = await api_cache({
      url: `${config.getEnvParam('quoteapi')}api/qt/stock/get?secid=${newcode}&fields=f57,f58,f198,f199&dpt=wz.ggmb&ut=6d2ffaa6a585d612eda28417681d58fb&np=3`,
      success_log: true,
      error_replace: {
        rc: 1,
        data: null
      }
    })

    if (back.rc != 0) {
      return null
    }

    return {
      Name: back.data.f58,
      Code: back.data.f57,
      Market: '5',
      HYID: back.data.f198
    }
  },
  // /**
  //  * F10基本资料
  //  */
  // async getProfile(code:string){
  //   let back = await axios_debug.get(`http://datainterface.eastmoney.com/EM_DataCenter/JS.aspx?type=GJZB&sty=HKF10&code=${code}&js=(x)&rt=4f1862fc3b5e77c150a2b985b12db0fd`, {
  //     timeout: 5000
  //   })
  //   return back.data
  // },

  // /**
  //  * 沪股通列表
  //  */
  // async hgtList(){
  //   let back = await axios.get(`${config.getEnvParam('quoteapi')}api/qt/clist/get?fs=b:MK0144&fields=f12,f13,f14&np=3&dpt=wz.ggmb`, {
  //     timeout: 5000
  //   })

  //   logger.info({
  //     url: back.config.url,
  //     back: back.data
  //   })

  //   return back.data.data.diff
  // },

  /**
   * 获取个股新闻
   */
  async news(code:string, name:string){
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/StockNews?marketType=2&stockCode=${code}&stockName=${encodeURIComponent(name)}&returnFields=Art_Title,Art_Url,Art_ShowTime`,
      error_replace: {
        Data: []
      },
      check_callback: function (data:any) {
        return data.Data instanceof Array
      }
    })
    return back.Data
  },

  /**
   * 港股公告
   */
  async announcement(code:string){
    let back = await api_cache({
      url: `${config.getEnvParam('newsnotice')}webapi/api/Notice?Time=&CodeType=10&StockCode=${code}&FirstNodeType=0&SecNodeType=0&PageIndex=1&PageSize=5`,
      cache_time: 5 * 60 * 1000,
      error_replace: {
        data: []
      },
      check_callback: function (data:any) {
        return data.data instanceof Array
      }
    })
    
    return back.data
  },

  /**
   * 港股要闻
   */
  async headLines(){
    let back = await api_cache({
      url: `${config.getEnvParam('cmsapi')}api/CmsNews/QueryCmsNewsByColumnFile?column=532&pageindex=1&pagesize=5`,
      error_replace: {
        Result: []
      },
      check_callback: function (data:any) {
        return data.Result instanceof Array
      }
    })
    return back.Result
  },


  /**
   * 热门港股吧
   */
  async hotguba(){
    let back = await api_cache({
      url: `${config.getEnvParam('guba_api')}suggest/api/guba/hotgubalist?market=HK&ps=8&p=1&deviceid=1&version=200&product=guba&plat=web`,
      error_replace: {
        re: []
      },
      check_callback: function (data:any) {
        return data.re instanceof Array
      }
    })
    return back.re
  },

  /**
   * 头条布告栏
   */
  async toutiao(){
    let back = await api_cache({
      url: `${config.getEnvParam('bulletin')}html/Base/486.html`,
      error_replace: ''
    })
    return back
  }
  
  
  
}