// require(["baseStock", "common", "template"], function (baseStock, common, template) {
var baseStock = require('../old_b/basestock')
var common = require('../old_b/common')
var template = require('../old_b/template')

    function Fundstock() {

        baseStock.call(this);  //第二次调用基类的构造函数
    }
    Fundstock.prototype = new baseStock();
    var instance = new Fundstock();
    var address = "https://fundwebapi.eastmoney.com"; //正式地址
    //var address = "http://fundmobapitest.eastmoney.com";
    //分时成交
    Fundstock.prototype.bindDealDetail = function (num) {
        var _num = (num | 10) + 1;
        var _url = instance.baseUrl + "/api/qt/stock/details/get?secid=" + window.stockEnity.fullcode + "&ut=" + instance.ut + "&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55&pos=-" + _num
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data
                if (!data.details.length || !data.prePrice) return;
                var list = [];
                var details = data.details
                for (var i = 0; i < details.length; i++) {
                    if (i > 0) {
                        var itemslast = details[i - 1].split(",")
                        var items = details[i].split(",");
                        var dir = (items[1] > itemslast[1] ? "↑" : items[1] == itemslast[1] ? " " : "↓")
                        var listitem = {
                            time: items[0],
                            close: items[1],
                            closeCss: common.getColor(items[1] - data.prePrice),
                            volumn: items[2],
                            dir: dir,
                            volumnCss: items[4] == 0 ? lastcolor : (items[4] == 2 ? (items[1] * items[2] * 100 > 200000 ? 'purple' : 'red') : (items[1] * items[2] * 100 > 200000 ? 'blue' : 'green')),
                            arrowcolor: items[1] > itemslast[1] ? "red" : items[1] == itemslast[1] ? " " : "green"
                        }
                        list.push(listitem);
                        var lastcolor = listitem.volumnCss
                    } else {
                        var items = details[i].split(",");
                        var listitem = {
                            time: items[0],
                            close: items[1],
                            closeCss: common.getColor(items[1] - data.prePrice),
                            volumn: items[2],
                            dir: "",
                            volumnCss:"red",
                            arrowcolor:""
                        }
                        list.push(listitem);
                    }
                }
                list = list.reverse()
                list = list.slice(0,10)
                var html = template("tmp_deal_detail", { list: list });
                $("#deal_detail tbody").html(html);
            }
        });
    };

    //全球直播
    function globalZhb() {
        var tpl = '{{each news as val idx}}<li class="fl" title ="{{val.title}}" >'
            + '{{if val.newstype!=2}}<a href="{{val.url_unique}}" target="_blank">·{{val.title | cutstr: 80,"..."}}</a>'
            + '{{else}}<a href="http://kuaixun.eastmoney.com" target="_blank">·{{val.title | cutstr: 80,"..."}}</a>{{/if}}'
            + '</li>{{/each}}';
        jQuery.ajax({
            url: "//newsinfo.eastmoney.com/kuaixun/v2/api/list?column=zhiboall&limit=1",
            dataType: "jsonp",
            success: function (json) {
                if (json.rc == 1) {
                    //console.log(json)
                    var html = template.render(tpl, json);
                    $(".ScrollMIIRBox").html(html);
                }
            }
        });
    }
    //封基排行
    Fundstock.prototype.fjRank = function () {
        var _url = instance.baseUrl + "/api/qt/clist/get?&pn=1&pz=6&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=m:0+t:10&fields=f1,f2,f3,f4,f5,f10,f12,f13,f14,f15,f11,f152"
        $.ajax({
            url: _url,
            dataType: "jsonp",
            jsonp: "cb",
            success: function (json) {
                //console.log(json.data.diff)
                var list = json.data.diff
                for (var i = 0; i < list.length; i++) {

                    var price = list[i].f2 == '-' ? '-' : (list[i].f2).toFixed(list[i].f1)
                    var percent = list[i].f3 == '-' ? '-' : (list[i].f3.toFixed(2) + '%')
                    var color = list[i].f3 > 0 ? 'red' : list[i].f3 < 0 ? 'green' : ''
                    var mk = list[i].f13 == 1? "sh" : "sz";

                    $(".tdList" + i).find("a").attr("href", "//quote.eastmoney.com/" + mk + list[i].f12 + ".html").text(list[i].f14);
                    $(".tdList" + i).find("span").html("(<em class='" + color + "'>" + price + "</em> <em class='" + color + "'>" + percent + "</em>)")
                }
            }
        });
    }

    init();
    setInterval(refresh, 20 * 1000);

    function refresh() {
        // console.log(instance)
        instance.getFavouriteStocknew();
        instance.bindDealDetail(10);
        instance.loadDetailDatanew() //五档行情
        instance.fjRank();
        globalZhb();
    };

    function init() {      
        function onChangeDataRender($dom, item, settings) {
            if (item != 0 && item != "-") {
                if (item.isPositive()) {
                    $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");
                } else {
                    $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
                }
            } else {
                $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
            }
        }
        instance.loadQuoteData(
            {
                ajax: {
                    url: instance.baseUrl + '/api/qt/stock/get?secid=' + stockEnity.fullcode + "&ut=" + instance.ut + "&fields=f43,f169,f170,f46,f60,f84,f116,f44,f45,f171,f126,f47,f48,f168,f164,f49,f161,f55,f92,f59,f152,f167,f50,f86,f71,f172,f191,f192,f51,f52",
                    data: {
                    
                    },
                    dataType: 'jsonp',
                    jsonp: 'cb',
                    Type: 'get'
                },
                dataResolver: function (json) {
                    var data = json["data"]
                    var arr = []
                    arr.push(data.f43 == 0 ? '-' : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59))//0最新价
                    arr.push(data.f43 == 0 ? '-' : (data.f44 / Math.pow(10, data.f59)).toFixed(data.f59))//1最高价
                    arr.push(data.f43 == 0 ? '-' : (data.f45 / Math.pow(10, data.f59)).toFixed(data.f59))//2最低价
                    arr.push(data.f43 == 0 ? '-' : (data.f46 / Math.pow(10, data.f59)).toFixed(data.f59))//3开盘价
                    arr.push(data.f43 == 0 ? '-' : data.f47)//4成交量
                    arr.push(data.f43 == 0 ? '-' : data.f48)//5成交额(f48)
                    arr.push(data.f43 == 0 ? '-' : data.f49)//6外盘
                    arr.push(data.f55.toFixed(2))//7每股收益(f55) 
                    arr.push(data.f59)// 8小数位数(f59)
                    arr.push((data.f60 / Math.pow(10, data.f59)).toFixed(data.f59))//9昨收价(f60)
                    arr.push(data.f84)//10总股本(股)(f84)
                    arr.push(data.f92.toFixed(2))//11每股净资产(f92)
                    arr.push(data.f116)//12总市值(f116)
                    arr.push(data.f126)//13股息率(f126
                    arr.push(data.f152)//14小数位数字段(2)
                    arr.push(data.f43 == 0 ? '-' : data.f161)//15内盘(f161)
                    arr.push(data.f164 / Math.pow(10, data.f152))//16市盈率(TTM)(f164)
                    arr.push(data.f168)//17换手率(f168)
                    arr.push(data.f43 == 0 ? '-' : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))//18涨跌值(f169) 
                    arr.push(data.f43 == 0 ? '-' : data.f170)//19涨跌幅(f170) 
                    arr.push(data.f43 == 0 ? '-' : data.f171)//20振幅(f171)
                    arr.push(data.f43 == 0 ? '-' : data.f167 / Math.pow(10, data.f152))//21市净率(f167)
                    arr.push(data.f43 == 0 ? '-' : data.f50 / Math.pow(10, data.f152))//22量比(f50)
                    arr.push(common.formatDate(new Date(data.f86 * 1000), 'yyyy-MM-dd HH:mm:ss'))//23行情时间Unix时间戳，单位秒(f86)
                    arr.push(data.f43 == 0 ? '-' : (data.f71 / Math.pow(10, data.f59)).toFixed(data.f59))//24均价(f71)
                    arr.push(data.f191 == 0 ? '-' : data.f191)//25委比
                    arr.push(data.f192 == 0 ? '-' : data.f192)//26委差
                    arr.push(data.f51 == 0 ? '-' : (data.f51 / Math.pow(10, data.f59)).toFixed(data.f59))//27涨停价
                    arr.push(data.f52 == 0 ? '-' : (data.f52 / Math.pow(10, data.f59)).toFixed(data.f59))//28跌停价
                    return arr;
                },
                fields: [
                      {
                          name: "jk", num: 3, hasColor: true, NumbericFormat: false,
                          comparer: function (data) { return (isNaN(data[3]) ? 0 : data[3]) - (isNaN(data[9]) ? 0 : data[9]); }
                      },
                      { name: "zs", num: 9, hasColor: false, NumbericFormat: false },
                      {
                          name: "zxj", num: 0, hasColor: true, NumbericFormat: false, blink: true,
                          comparer: function (data) { return isNaN(data[18]) ? 0 : data[18]; }
                      },
                      {
                          name: "zde", num: 18, hasColor: true, NumbericFormat: false, blink: true,
                          render: onChangeDataRender
                      },
                      { name: "zdf", num: 19, hasColor: true, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2) +'%'}}", blink: true },
                      {
                          name: "zgj", num: 1, hasColor: true, NumbericFormat: false,
                          comparer: function (data) { return (isNaN(data[1]) ? 0 : data[1]) - (isNaN(data[9]) ? 0 : data[9]); }
                      },
                      {
                          name: "zdj", num: 2, hasColor: true, NumbericFormat: false,
                          comparer: function (data) { return (isNaN(data[2]) ? 0 : data[2]) - (isNaN(data[9]) ? 0 : data[9]); }
                      },
                      { name: "cjl", num: 4, hasColor: false, NumbericFormat: true },
                      { name: "cje", num: 5, hasColor: false, NumbericFormat: true },
                      { name: "BuyOrder", num: 6, hasColor: true, NumbericFormat: true, comparer: 1 },
                      { name: "SellOrder", num: 15, hasColor: true, NumbericFormat: true, comparer: -1 },
                      { name: "zf", num: 20, hasColor: false, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2)+'%'}}" },
                      { name: "hs", num: 17, hasColor: false, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2)+'%'}}" },
                      { name: "pe", num: 16, hasColor: false, NumbericFormat: false },
                      { name: "sjl", num: 21, hasColor: false, NumbericFormat: false },
                      { name: "mgsy", num: 7, hasColor: false, NumbericFormat: false },
                      { name: "mgjzc", num: 11, hasColor: false, NumbericFormat: false },
                      { name: "roe", num: 20, hasColor: false, NumbericFormat: false },
                      { name: "zgb", num: 10, hasColor: false, NumbericFormat: true },
                      { name: "zsz", num: 12, hasColor: false, NumbericFormat: true },
                      { name: "lb", num: 22, hasColor: false, NumbericFormat: false },
                      { name: "stock_time", num: 23, hasColor: false, NumbericFormat: false, template: "{{data}}" },
                      {
                          name: "jj", num: 24, hasColor: true, NumbericFormat: false,
                          comparer: function (data) { return (isNaN(data[24]) ? 0 : data[24]) - (isNaN(data[9]) ? 0 : data[9]); }
                      },
                      { name: "np", num: 15, hasColor: true, NumbericFormat: true, comparer: -1 },
                      { name: "wp", num: 6, hasColor: true, NumbericFormat: true, comparer: 1 },
                      {
                           name: "wb", num: 25, hasColor: true, NumbericFormat: false, blink: true,
                           template: "{{data=='-'?'-':(data/100).toFixed(2) +'%'}}"
                      },
                      {
                           name: "wc", num: 26, hasColor: true, NumbericFormat: false, blink: true,
                      },
                      {
                            name: "zt", num: 27, NumbericFormat: false, hasColor: true,
                            comparer: function (data) { return 1 }
                        },
                        {
                            name: "dt", num: 28, NumbericFormat: false, hasColor: true,
                            comparer: function (data) { return -1}
                        },
                ]
            }
    );

        instance.setHotGuba(15);

        instance.bindChartImgEvent().bindEvent();

        $("#RefPR").click(function (e) {
            location.reload();
        });
        gpchcInfo();
        sameJJ();
        sameJJ_2();
        refresh();
    }
    // 股票持仓
    // 参数说明：m=0 固定参数，fcode:基金代码
    // 返回字段说明：ErrCode: 错误编码，当ErrCode=0 时 为正常返回，其它情况为异常返回,ErrMsg:
    // 当ErrCode!=0返回异常信息,Datas：返回的数据结果
    //Name:股票名称
    // Code:股票代码
    // CCZB:持仓占比 【这里是百分比】
    // ShareCodeNew:所在市场 1 上海市场，2 深圳，5 香港，7，美股
    function gpchcInfo() {   
        //正式地址：https://fundwebapi.eastmoney.com
        var _url = address +"/FundMEApi/FundPositionList?deviceid=123&version=4.3.0&product=Eastmoney&plat=Web&FCODE=" + stockEnity.stockCode; 
        $.ajax({
            url: _url,
            data: {},
            dataType: "jsonp",
            success: function (json) {
                // console.log(json)
                if (json.ErrCode == 0) {
                    var data = json.Datas;
                    var list = [];
                    var total_10 = 0;
                    var url = "";
                    var id = [];                   
                    if (!data || data=="") {
                        $("#chcInfo").html("<span class='noneSpan'>暂无数据</span>");
                    } else {
                        for (var i = 0; i < data.length; i++) {
                            if(i<10){
                                if (data[i].ShareCodeNew == "1") {
                                    url = "//quote.eastmoney.com/sh";
                                } else if (data[i].ShareCodeNew == "2") {
                                    url = "//quote.eastmoney.com/sz";
                                } else if (data[i].ShareCodeNew == "5") {
                                    url = "//quote.eastmoney.com/hk/";
                                } else if (data[i].ShareCodeNew == "7") {
                                    url = "//quote.eastmoney.com/us/";
                                }
                                var item = {
                                    "name": common.cutstr(data[i].ShareName, 10),
                                    "title": data[i].ShareName,
                                    "CCZB": isNaN(data[i].ShareProportion) ? "-" : data[i].ShareProportion + "%",
                                    "link": url + data[i].ShareCode + ".html",
                                    "code": data[i].ShareCode.replace(".", "")
                                };
                                list.push(item);
                                total_10 += Number(data[i].ShareProportion);
                                id.push(data[i].NEWTEXCH + '.' + data[i].ShareCode);
                            }
                        }                        
                        var html = template("tmp", { list: list });
                        $("#gpchc tbody").html(html);
                        gpchcRank(id);
                        setInterval(function () { gpchcRank(id); }, 30 * 1000);
                        $(".top10_p span").text(total_10.toFixed(2) + "%");
                    }
                   
                }
            }
        });
    }

    // 同类基金涨幅榜
    // 参数说明：
    //m=1 固定参数，
    //fcode:基金代码
    //pagesize:数量
    // 返回字段说明：
    // ErrCode: 错误编码，当ErrCode=0 时 为正常返回，其它情况为异常返回
    // ErrMsg:当ErrCode!=0返回异常信息
    // Datas：返回的数据结果

    // Name:基金简称
    // Code：基金代码
    // SYL:收益率
    // SYL_Desc:收益率描述
    // Isbuy:是否可购
    // BuyUrl:购买链接地址 
    function sameJJ() {  
         //正式地址：https://fundwebapi.eastmoney.com
        var _url = address +"/FundMEApi/FundSameTypeInfoList?pageIndex=1&pageSize=4&deviceid=123&version=4.3.0&product=Eastmoney&plat=Web&FCODE=" + stockEnity.stockCode ;        
        $.ajax({
            url: _url,
            data: {},
            dataType: "jsonp",         
            success: function (json) {               
                if (json.ErrCode == 0) {
                    var data = json.Datas;                    
                    var list = [];
                    if (!data) {
                        $("#sameFundRank").html("<li class='noneSpan'>暂无数据</li>");
                  
                    } else {                       
                        for (var i = 0; i < data.length; i++) {
                            var item = {
                                "name": common.cutstr(data[i].SHORTNAME, 20),
                                "title": data[i].SHORTNAME,
                                "SYL_Desc": data[i].MAKR,
                                "SYL": isNaN(data[i].SYL) ? "-" : Number(data[i].SYL).toFixed(2) + "%",
                                "isbuy": data[i].BUY == true ? "" : "gray",
                                "BuyUrl":"https://trade.1234567.com.cn/FundtradePage/default2.aspx?amp;spm=pzm&fc="+ data[i].FCODE,
                                "color": isNaN(data[i].SYL) ? "" :(data[i].SYL.replace("%", "")) > 0 ? "red" : (data[i].SYL.replace("%", "")) < 0 ? "green" : "",
                                "link": "http://fund.eastmoney.com/" + data[i].FCODE + ".html"
                            };
                            list.push(item);
                        }
                        var html = template("sameJJtmp", { list: list });
                        $("#sameFundRank .buyBtn").removeClass("gray");
                        $("#sameFundRank").html(html);
                        $("#sameFundRank li").eq(3).css("border", "none");
                    }
                    
                }

            }


        })
    }
    function sameJJ_2() {    
        var _url = address + "/FundMEApi/FundSameCompanyList?deviceid=123&version=4.3.0&pageSize=4&product=Eastmoney&plat=Web&FCODE="+ stockEnity.stockCode; 
        $.ajax({
            url: _url,
            dataType: "jsonp",
            success: function (json) {               
                if (json.ErrCode == 0) {
                    var data = json.Datas;
                    var fundId = json.Expansion;
                    var list = [];
                    for (var i = 0; i < data.length; i++) {
                        if (i < 4) {
                            var item = {
                                "name": common.cutstr(data[i].SHORTNAME, 20),
                                "title": data[i].SHORTNAME,
                                "SYL_Desc": "日涨幅",
                                "SYL": isNaN(data[i].RZDF) ? "-" : Number(data[i].RZDF).toFixed(2) + "%",
                                "isbuy": data[i].BUY == true ? "" : "gray",
                                "BuyUrl": "https://trade.1234567.com.cn/FundtradePage/default2.aspx?fc=" + data[i].FCODE+"&spm=pzm",
                                "color": isNaN(data[i].RZDF.replace("%", "")) ? "" : (data[i].RZDF.replace("%", "")) > 0 ? "red" : (data[i].RZDF.replace("%", "")) < 0 ? "green" : "",
                                "link": "http://fund.eastmoney.com/" + data[i].FCODE + ".html"
                            };                            
                            list.push(item);
                        }
                    }
                    var html = template("sameJJtmp", { list: list });
                    $("#sameFundComp .buyBtn").removeClass("gray");
                    $("#sameFundComp").html(html);
                    $("#sameFundComp li").eq(3).css("border", "none");
                    var fundComUrl = "";
                    if (!isNaN(fundId)) {
                         fundComUrl = "http://fund.eastmoney.com/company/" + fundId + ".html";
                    } else {
                         fundComUrl = "javascript:;";
                    }    
                    $("a.jjComId").attr("href", fundComUrl);

                }
            }
        })
    }

    /**
     * 获取涨跌幅
     */
    function getZDF(itemdata){
      if (itemdata.f3 == '-') {
          return '-'
      }
      var classname = ''
      if (itemdata.f3 > 0) {
          classname = 'red'
      }
      else if(itemdata.f3 < 0){
          classname = 'green'
      }
      return '<span class="' + classname + '">' + (itemdata.f3/Math.pow(10, itemdata.f1)).toFixed(itemdata.f1) + '%' + '</span>'
    }

    // 股票持仓涨跌幅
    function gpchcRank(id) {
        var _url = 'http://push2.eastmoney.com/api/qt/ulist.np/get?secids=' + id + '&invt=2&ut=bd1d9ddb04089700cf9c27f6f7426281&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&cb=?'
        // var list = [];
        $.ajax({
            url: _url,
            //data: { "cmd": id.join(",") },
            jsonp: "cb",
            type: "GET",
            dataType: "jsonp",
            success: function (json) {
                if (json.rc == 0) {
                    for (var i = 0; i < json.data.diff.length; i++) {
                        var item = json.data.diff[i];
                        $("#chP" + item.f12).html(getZDF(item));
                        $("#chP" + item.f12).attr("title", item.f14);
                    }                    
                }                     
            }
        })
    }
// });