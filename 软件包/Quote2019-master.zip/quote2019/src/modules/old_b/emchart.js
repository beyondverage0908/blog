// define(["jQuery", "chartLib"], function () {

    var emChart = {
        initial: function () {
            emChart.bindJs();
            emChart.bindK();
            setInterval(function () {
                emChart.bindJs();
            }, 20 * 1000);
        },
        bindK: function (parameters) {
            var timer,
            kchart = new emcharts3.k2({
                container: "#emchartk",
                width: 585,
                height: 390,
                padding: {
                    top: 0,
                    bottom: 0
                },
                scale: {
                    pillar: 60,
                    min: 10
                },
                popWin: { type: "move" },
                maxin: {
                    //show: true,
                    lineWidth: 30,     // 线长
                    skewx: 0,            // x偏移   
                    skewy: 0            // y偏移
                },
                onComplete: function () {
                },
                onClick: function () {
                    var val = $("#changektab span.cur").attr("value"), type = 'k';
                    switch (val) {
                        case "D":
                            type = "k";
                            break;
                        case "W":
                            type = "wk";
                            break;
                        case "M":
                            type = "mk";
                            break;
                        case "M5":
                            type = "m5k";
                            break;
                        case "M15":
                            type = "m15k";
                            break;
                        case "M30":
                            type = "m30k";
                            break;
                        case "M60":
                            type = "m60k";
                            break;
                        default: break;
                    }
                    window.open(window.location + "#fullScreenChart", "_blank")
                },
                onError: function (e) {
                    console.error(e)
                }
            }),
            params = {
                type: "k",
                authorityType: ""
            };
        function init() {

            events();
            load();
        }

        function load() {
            var fq = $("#beforeBackRight span").text()
            $("#js_box").removeClass("hidefixed");
            $("#js_box").removeClass("hidefixed");
            clearTimeout(timer);
            var _load = function () {
                var params1 = {
                    secid: window.stockEnity.fullcode,
                    ut: 'fa5fd1943c7b386f172d6893dbfba10b',
                    fields1: 'f1,f2,f3,f4,f5',
                    fields2: 'f51,f52,f53,f54,f55,f56,f57,f58',
                    klt: params.type == 'k' ? 101 : params.type == 'wk' ? 102 : params.type == 'mk' ? 103 : params.type == 'm5k' ? 5 : params.type == 'm15k' ? 15 : params.type == 'm30k' ? 30 : 60,
                    fqt: fq == '不复权' ? 0 : fq == '前复权' ? 1 : fq == '后复权' ? 2 : 0,
                    beg: "19900101",
                    end: "20220101"
                }
                $.ajax({
                    url: "http://push2his.eastmoney.com/api/qt/stock/kline/get",
                    dataType: "jsonp",
                    scriptCharset: 'utf-8',
                    data: params1,
                    jsonp: "cb",
                    success: function (resk) {
                        //console.log("kkkk>>", resk)
                        var obj = {
                            "name": resk.data.name,
                            "code": resk.data.code,
                            "info": {
                                "c": "",
                                "h": "",
                                "l": "",
                                "o": "",
                                "a": "",
                                "v": "",
                                "yc": $(".zsj").text(),
                                "time": "",
                                "ticks": "34200|54000|0|34200|41400|46800|54000",
                                "total": resk.data.dktotal,
                                "pricedigit": "0.00",
                                "jys": "2",
                                "Settlement": "-"
                            },
                            data: []
                        }
                        for (var i = 0; i < resk.data.klines.length; i++) {
                            var item = resk.data.klines[i] + '%'
                            obj.data.push(item)
                        }
                        kchart.setData({
                            k: obj
                        });
                        kchart.draw();
                    },
                    error: function (e) {
                        console.error(e);
                    },
                    complate: function () {
                        timer = setTimeout(load, 60 * 1000);
                    }
                });
            };
            _load();
        }

        function events() {
            $("#beforeBackRight dl dd").click(function () {
                $("#beforeBackRight span").html($(this).html());
                var v = $(this).attr("value");
                $("#beforeBackRight").attr("value", v);
                params.authorityType = v === "before" ? "fa" : v === "back" ? "ba" : "";
                load();
                var at = v === "before" ? "1" : v === "back" ? "2" : "0";
                if ($("#js_box").is(":visible")) {
                    $("#select4 dd[value=" + at + "]").click();
                }
            });

            $("#changektab span").click(function () {
                $("#changektab span").removeClass("cur");
                $(this).addClass("cur");
                switch ($(this).attr("value")) {
                    case "D":
                        params.type = "k";
                        break;
                    case "W":
                        params.type = "wk";
                        break;
                    case "M":
                        params.type = "mk";
                        break;
                    case "M5":
                        params.type = "m5k";
                        break;
                    case "M15":
                        params.type = "m15k";
                        break;
                    case "M30":
                        params.type = "m30k";
                        break;
                    case "M60":
                        params.type = "m60k";
                        break;
                }
                load();
            });

            $("#scale-plus").click(function () {
                kchart.shorten(-1, 0.1);
            });

            $("#scale-minus").click(function () {
                kchart.elongate(-1, 0.1);
            });

            $("#beforeBackRight").mouseenter(function () {
                this.getElementsByTagName("dl")[0].style.display = "block";
            });

            $("#beforeBackRight").mouseleave(function () {
                this.getElementsByTagName("dl")[0].style.display = "none";
            });
        }
        init();
    },


        bindJs: function () {
            var fq = $("#beforeBackRight span").text()
            $.ajax({
                url: "http://push2.eastmoney.com/api/qt/stock/trends2/get",
                dataType: "jsonp",
                scriptCharset: 'utf-8',
                data: {
                    secid: window.stockEnity.fullcode,
                    ut: 'fa5fd1943c7b386f172d6893dbfba10b',
                    fields1: 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11',
                    fields2: 'f51,f53,f56,f58',
                    iscr: fq=='不复权'?0:fq=='前复权'?1:fq=='后复权'?2:0,
                    ndays: 1
                },
                jsonp: "cb",
                success: function (res1) {
                    //console.log("分时图数据fenshitu>>",res1)
                    var obj = {
                        name: window.stockEnity.stockName,
                        code: window.stockEnity.stockCode,
                        info: {
                            "mk ":window.stockEnity.stockMarket,
                            "c": "",
                            "h": "",
                            "l": "",
                            "o": "",
                            "a": "",
                            "v": "",
                            "yc": res1.data.preClose, //昨收
                            "time": "",
                            "ticks": "34200|34200|54000|34200|41400|46800|54000",
                            "total": res1.data ? res1.data.trendsTotal : 0, //多少数据
                            "pricedigit": "0.00",
                            "jys": "2",
                            "Settlement": "-"
                        },
                        data: []
                    }
                    var dataList = res1.data ? res1.data.trends : []
                    for (var i = 0; i < dataList.length; i++) {
                        var arr = dataList[i].split(",")
                        var str = arr[0] + ',' + arr[1] + ',' + (arr[2] ) + ',' + arr[3] + ',' + 0
                        obj.data.push(str)
                    }
                    var option = {
                        container: "#emchart-0",
                        width: 565,
                        height: 276,
                        type: 'r',
                        iscr: false,
                        onClick: function () {
                            window.open(window.location + "#fullScreenChart","_blank")
                        }
                    }
                    var timechart = new emcharts3.time(option);
                    timechart.start(false)
                    timechart.setData({
                        time: obj
                    });
                    timechart.redraw();
                    timechart.stop();
                },
                error: function (e) {
                    console.error(e);
                }
            });
        }
    }

    // return emChart;

    module.exports = emChart
    // return emChart;
// });