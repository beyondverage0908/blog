// define(["jQuery", "template"], function ($, template) {
  var template = require('./template')

    var common = {
        //文字闪动
        setFlash: function (obj, cls1, cls2) {
            setTimeout(function () { common.setClass(obj, cls1) }, 800);
            setTimeout(function () { common.setClass(obj, cls2) }, 1000);
            setTimeout(function () { common.setClass(obj, cls1) }, 1200);
            setTimeout(function () { common.setClass(obj, cls2) }, 1400);
        },
        //获取季度中文
        getJiduByDate: function (date) {
            var jidu = "";
            var m = date.split('-')[1];
            switch (m) {
                case "03":
                    jidu = "(一)";
                    break;
                case "06":
                    jidu = "(二)";
                    break;
                case "09":
                    jidu = "(三)";
                    break;
                case "12":
                    jidu = "(四)";
                    break;
            }
            return jidu;
        },
        //触发element的eventName事件
        trigger: function (element, eventName) {
            if (typeof element == "undefined" || element == null) return;
            if (document.all) {
                element[eventName]();
            } else {
                var evt = document.createEvent("MouseEvents");
                evt.initEvent(eventName, true, true);
                element.dispatchEvent(evt);
            }
        },
        //Cookie Common Class
        getCookie: function (key) {
            var result = document.cookie.match(new RegExp("(^| )" + key + "=([^;]*)"));
            return result != null ? unescape(decodeURI(result[2])) : null;
        },
        //写cookies
        setCookie: function (name, value, hours) {
            var expire = "";
            if (typeof hours === "number") {
                expire = new Date((new Date()).getTime() + hours * 3600000);
                expire = "; expires=" + expire.toGMTString() + ";";
            }
            expire += "; path=/;domain=.eastmoney.com;";
            document.cookie = name + "=" + escape(value) + expire;
        },
        //通过cookie:pi获取uid
        getUid: function () {
            var webPi = common.getCookie("pi");
            if (webPi && webPi.split(';').length >= 3) {
                var uid = webPi.split(';')[0];
                if (uid.length == 16) {
                    return uid;
                }
            }
            return "";
        },
        //根据股票代码获取市场
        getMarketCode: function (sc) {
            var i = sc.substring(0, 1);
            var j = sc.substring(0, 3);
            if (i == "5" || i == "6" || i == "9") {
                return "1"; //上证股票
            } else {
                if (j == "009" || j == "126" || j == "110") {
                    return "1"; //上证股票
                } else {
                    return "2"; //深圳股票
                }
            }
        },
        getStatusDescription: function (stat) {
            switch (stat) {
                case "-2": return "已收盘";
                case "-1": return "停牌";
                case "0": return "交易中";
                case "1": return "已收盘";
                case "2": return "午间休市";
                case "3": return "已休市";
                case "4": return "未开盘";
                case "5": return "已收盘";
                case "6": return "已收盘";
                case "7": return "已收盘";
                case "8": return "暂停交易";
                case "9": return "暂停交易";
                case "10": return "暂停交易";
                case "11": return "暂停交易";
                case "12": return "未上市";
                default: return "";
            }
        },
        jsonP: function (url, successMethod, errorMethod) {
            $.ajax({
                url: url,
                async: true,
                dataType: "jsonp",
                success: successMethod,
                error: errorMethod
            });
        },
        jsonPnew: function (url, successMethod, errorMethod) {
            $.ajax({
                url: url,
                async: true,
                dataType: "jsonp",
                jsonp: 'cb',
                success: successMethod,
                error: errorMethod
            });
        },
        getQueryString: function (name) {
            var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
            var r = window.location.search.substr(1).match(reg);
            if (r != null) {
                return unescape(r[2]);
            }
            return null;
        },
        formatDate: function (date, fmt) {
            // return date
            if (typeof date === "string"){
                //date = new Date(date.replace(/-/g, '/').replace('T', ' ').split('+')[0]);
                date = new Date(date.substring(0,19).replace(/-/g, '/').replace('T', ' '));                
            }

            var o = {
                "M+": date.getMonth() + 1, //月份         
                "d+": date.getDate(), //日         
                "h+": date.getHours() % 12 == 0 ? 12 : date.getHours() % 12, //小时         
                "H+": date.getHours(), //小时         
                "m+": date.getMinutes(), //分         
                "s+": date.getSeconds(), //秒         
                "q+": Math.floor((date.getMonth() + 3) / 3), //季度         
                "S": date.getMilliseconds() //毫秒         
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[date.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        },
        getByteLen: function (str) {
            var len = 0;
            for (var i = 0; i < str.length; i++) {
                var regNum = new RegExp("[^\x00-\xff]");
                if (regNum.test(str[i])) {
                    len += 2;
                } else {
                    len += 1;
                };
            }
            return len;
        },
        getColor: function (str) {
            var context = str.toString();
            context = context.replace("%", "");
            if (context == 0 || isNaN(context)) {
                return "";
            } else if (context > 0) {
                return "red";
            } else {
                return "green";
            }
        },
        cutString: function (str, len) {
            var content = str.toString();
            if (content.length > len) {
                return content.substring(0, len) + "...";
            } else {
                return str;
            }
        },
        /** 
         * js截取字符串，中英文都能用 
         * @param {string} str: 需要截取的字符串 
         * @param {number} len: 需要截取的长度
         * @param {string} ellipsis: 溢出文字
         * @returns {string}
         */
        cutstr: function (str, len, ellipsis) {
            if (typeof ellipsis != "string") ellipsis = "...";
            var str_length = 0;
            var str_len = 0;
            str_cut = new String();
            for (var i = 0; i < str.length; i++) {
                a = str.charAt(i);
                str_length++;
                if (escape(a).length > 4) {
                    //中文字符的长度经编码之后大于4  
                    str_length++;
                }
                //str_cut = str_cut.concat(a);
                if (str_length <= len) {
                    str_len++;
                }
            }
            //如果给定字符串小于指定长度，则返回源字符串；  
            if (str_length <= len) {
                return str.toString();
            }
            else {
                return str.substr(0, str_len).concat(ellipsis);
            }
        },
        /**
         * 秒表计时器模块
         * @param {any} options: 设置
         * @param {number} seconds: 秒针
         */
        timer: function (options, seconds) {
            var _this = this;
            seconds = seconds || 60;
            if (!options || !options.dom) return;
            var default_options = {
                counter: 60,
                interval: 1000
            };
            var _options = $.extend(options, default_options);
            var $dom = _options.dom, _interval = isNaN(_options.interval) ? 1000 : _options.interval;
            if (typeof _options.dom === "string") {
                var dom = _options.dom;
                if ($(dom).length == 0) return;
                $dom = $(dom);
            }
            var timerId = -1, paused = false, counter = seconds;
            function handler() {
                if (!paused) {
                    $dom.html(counter);
                }
                if (--counter > 0) {
                    timerId = setTimeout(handler, _interval);
                }
                else if (typeof options.callback === "function") {
                    _options.callback(_options.args);
                }
            }
            function pause() { paused = true; }
            function resume() { paused = false; }
            function start() {
                handler();
            }
            function stop() {
                if (timerId != -1) clearTimeout(timerId);
                timerId = -1;
                counter = _options.counter;
            }
            return {
                start: start, stop: stop, reset: function () {
                    stop(), start();
                },
                pause: function () { paused = true; },
                resume: function () { paused = false; }
            };
        },
        /** 
         * js分页功能
         * var pagenav = new PageNavigation("container", 6);
	     * pagenav.onchange = function(i){ alert(i) }
	     * pagenav.nav(1)
         * pagenav.render();
         * @param {string} container: 分页容器
         * @param {number} pagecount: 页数
         */
        pageNavigation: function (container, pagecount) {
            var get = function (id) {
                return $("#" + container + " " + id);
            };
            var _this = this;
            _this.container = document.getElementById(container);
            if (!_this.container) throw "Untouchable container";
            _this.nextpage = get("nextpage");
            _this.prepage = get("prepage");
            _this.pagecount = pagecount || 0;
            _this.container.onclick = function (event) {
                event = event || window.event;
                var target = event.target || event.srcElement;
                var page = target.getAttribute("data-page");
                var controlid = target.getAttribute("data-get");
                var property = target.getAttribute("data-property");

                if (controlid && property) {//转到

                    page = get(controlid).attr(property);
                }

                if (page !== null && !isNaN(page)) {
                    _this.change(page);
                }
            };
            //根据UI 设置config
            _this.config = {
                itemscount: 5,
                disable: "<span>{$text}</span>",
                nextpage: " <a class=\"nextpage\" href=\"javascript:void(null)\"  data-page='{$nextpage}'>下一页</a> ",
                prepage: " <a class=\"prepage\" href=\"javascript:void(null)\" data-page='{$prepage}'>上一页</a> ",
                pageitem: " <a href=\"javascript:void(null)\" data-page='{$num}'>{$num}</a> ",
                current: " <span class='current'>{$num}</span> ",
                firstpage: "<a data-page='1'>1</a><span class='page-break'>...</span>",
                lastpage: "<span class='page-break'>...</span><a data-page='{$pagecount}'>{$pagecount}</a>",
                gopage: '转到<input type="text" value="{$num}" name="pageNum" class="pagenum"/>页 ' +
                    '<input type="button" data-get=".pagenum" data-property="value" class="go-btn" value="Go"/>'
            };
            _this.change = function (num) {
                var _this = this;
                if (!isNaN(num)) {
                    _this.listitems = [];
                    _this.nav(parseInt(num));
                    _this.render();
                }
                _this.onchange(num);
                _this.pageChange(num);
            };
            _this.reset = function () {
                this.listitems = [];
                this.prepage = false;
                this.firstpage = false;
                this.nextpage = false;
                this.lastpage = false;
            };
            //回调函数
            _this.onchange = new Function();
            _this.pageChange = new Function();
            //分页逻辑
            _this.nav = function (n) {
                var startpagenum = 1, endpagenum = this.pagecount, length = (this.config.itemscount - 1) / 2;
                this.reset();
                if (isNaN(n)) { n = 1; }
                if (n < 1) n = 1;
                if (n > this.pagecount) n = this.pagecount;
                if (n !== 1) {
                    this.prepage = this.config.prepage;
                    if (n - length > 1) {
                        startpagenum = n - length;
                        this.firstpage = this.config.firstpage;
                        if (n == 4) {
                            this.firstpage = this.firstpage.replace("...", "");
                        }
                    }

                    for (var i = startpagenum; i < n; i++) {
                        this.listitems.push(this.createPageItem(i));
                    }
                }
                this.listitems.push(this.createCurrentItem(n));
                if (n !== this.pagecount) {
                    this.nextpage = this.config.nextpage;
                    length = this.config.itemscount - this.listitems.length;
                    if (n + length < this.pagecount) {
                        endpagenum = n + length;
                        this.lastpage = this.config.lastpage;
                        if (this.pagecount - n == 3) {
                            this.lastpage = this.lastpage.replace("...", "");
                        }
                    }

                    for (var i = n + 1; i <= endpagenum; i++) {
                        this.listitems.push(this.createPageItem(i));
                    }
                }
                this.page = n;
            };
            _this.render = function () {

                var listitems = this.listitems.join("");
                var nextpage = this.nextpage;
                var prepage = this.prepage;
                var gopage = this.config.gopage;

                var html = [];
                if (!prepage) {
                    prepage = this.config.disable.replace(/\{\$text\}/g, "上一页");
                }
                html.push(prepage.replace(/\{\$prepage\}/g, this.page - 1));

                if (this.firstpage) {
                    html.push(this.firstpage);
                }

                html.push(listitems);

                if (this.lastpage) {
                    html.push(this.lastpage.replace(/\{\$pagecount\}/g, this.pagecount));
                }

                if (!nextpage) {
                    nextpage = this.config.disable.replace(/\{\$text\}/g, "下一页");
                }

                html.push(nextpage.replace(/\{\$nextpage\}/g, this.page + 1));

                html.push(gopage.replace(/\{\$num\}/g, this.page));

                if (this.container) {
                    this.container.innerHTML = html.join("");
                }
                return html.join("");

            };
            _this.createPageItem = function (i) {
                return this.config.pageitem.replace(/\{\$num\}/g, i);
            };
            _this.createCurrentItem = function (i) {
                return this.config.current.replace(/\{\$num\}/g, i);
            };
        }
    }

    String.prototype.cutstr = function (len) {
        return common.cutstr(this, len);
    }

    String.prototype.isPositive = function () {
        var context = this;
        if (typeof (context).toLowerCase() === "string") {
            context = context.replace("%", "");
            var regNum = new RegExp("^([\\-\\+]?\\d+(\\.\\d+)?)$");
            if (regNum.test(context)) {
                var reg = new RegExp("^-");
                return !reg.test(context);
            } else return Number.NaN;
        }
    }

    String.prototype.NumbericFormat = function (fixed) {
        var context = this;
        //var fushu = false;
        fixed = typeof fixed === "number" && fixed >= 0 ? fixed : NaN;
        if (!isNaN(context)) {
            var item = parseInt(this);
            if ((item > 0 && item < 1e4) || (item < 0 && item > -1e4)) {
                return item;
            } else if ((item > 0 && item < 1e6) || (item < 0 && item > -1e6)) {
                item = item / 10000;
                return item.toFixed(fixed || 2) + "万";
            } else if ((item > 0 && item < 1e7) || (item < 0 && item > -1e7)) {
                item = item / 10000;
                return item.toFixed(fixed || 1) + "万";
            } else if ((item > 0 && item < 1e8) || (item < 0 && item > -1e8)) {
                item = item / 10000;
                return item.toFixed(fixed || 0) + "万";
            } else if ((item > 0 && item < 1e10) || (item < 0 && item > -1e10)) {
                item = item / 1e8;
                return item.toFixed(fixed || 2) + "亿";
            } else if ((item > 0 && item < 1e11) || (item < 0 && item > -1e11)) {
                item = item / 1e8;
                return item.toFixed(fixed || 1) + "亿";
            } else if ((item > 0 && item < 1e12) || (item < 0 && item > -1e12)) {
                item = item / 1e8;
                return item.toFixed(fixed || 0) + "亿";
            } else if ((item > 0 && item < 1e14) || (item < 0 && item > -1e14)) {
                item = item / 1e12;
                return item.toFixed(fixed || 1) + "万亿";
            } else if ((item > 0 && item < 1e16) || (item < 0 && item > -1e16)) {
                item = item / 1e12;
                return item.toFixed(fixed || 0) + "万亿";
            } else {
                return item;
            }
        }
        else {
            return '-';
        }
        //return context.toString();
    }
    if (!Array.prototype.indexOf) {
        // 兼容低版本浏览器扩展indexOf
        Array.prototype.indexOf = function (elt /*, from*/) {
            var len = this.length >>> 0;
            var from = Number(arguments[1]) || 0;
            from = (from < 0) ?
                Math.ceil(from) :
                Math.floor(from);
            if (from < 0)
                from += len;
            for (; from < len; from++) {
                if (from in this &&
                    this[from] === elt)
                    return from;
            }
            return -1;
        };
    }
    Array.prototype.unique = function () {
        var res = [];
        var json = {};
        for (var i = 0; i < this.length; i++) {
            if (!json[this[i]]) {
                res.push(this[i]);
                json[this[i]] = 1;
            }
        }
        return res;
    }
    // 截断字符
    template.helper("cutstr", function (str, len, ellipsis) {
        return common.cutstr(str, len, ellipsis);
    });
    // 日期格式化
    template.helper("formatDate", function (date, fmt) {
        if (typeof date === "string") {
            date = new Date(date.substring(0,19).replace(/-/g, '/').replace('T', ' '))
        }
        return common.formatDate(date, fmt);
    });
    // 获取市场代码
    template.helper("getShortMarket", function (str) {
        switch (str) {
            case "1": return "sh";
            case "2": return "sz";
            default: return "sz";
        }
    });

    // jquery扩展
    $.extend({
        // 定时数据获取扩展
        dataAutoRefresh: function (settings) {
            var _init = false, _intInterval = !window["defaultInterval"] ? 1000 * 20 : window.defaultInterval, _intThread = -1;
            if (!settings["dataType"]) settings["dataType"] = "json";
            return {
                init: _init,
                intInterval: _intInterval,
                intThread: _intThread,
                load: function () {
                    this.init = true;
                    if (typeof (settings) !== "object" || !settings)
                        return false;
                    if (settings.dataType.toLowerCase() === "img") {
                        $.imgLoader(settings);
                    }
                    else {
                        var _timeout = 5000;
                        settings["timeout"] = !settings.timeout ? _timeout : settings["timeout"];
                        if (!!settings.dataType && settings.dataType.toLowerCase() === "jsonp") {
                            settings["type"] = "GET";
                            settings["jsonp"] = !settings.jsonp ? "cb" : settings.jsonp;
                        }
                        $.ajax(settings);
                    }
                },
                start: function () {
                    this.stop();
                    this.load();
                    this.intThread = setInterval(this.load, this.intInterval);
                },
                stop: function () {
                    if (this.intThread !== -1) {
                        clearInterval(this.intThread);
                    }
                    this.intThread = -1;
                }
            }
        },
        //异步动态图片加载
        imgLoader: function (setting) {
            if (typeof (setting) !== "object" || !setting["url"]) return false;
            var fCallback = typeof (setting["success"]) === "function" ? setting["success"] : null;
            var _url = setting["url"];
            if (setting["data"]) {
                var _data = $.param(setting["data"]);
                _url = _url.indexOf("?") > 0 ? _url + "&" + _data : _url + "?" + _data;
            }
            if (!setting["cache"]) {
                _url += _url.indexOf("?") > 0 ? "&_=" + (+new Date()) : "?_=" + (+new Date());
            }
            var _image = document.createElement("img");
            if (typeof (setting["height"]) === "number" && setting["height"] > 0) {
                _image.setAttribute("height", setting["height"] + "px");
            }
            if (typeof (setting["width"]) === "number" && setting["width"] > 0) {
                _image.setAttribute("width", setting["width"] + "px");
            }
            _image.setAttribute('src', _url);
            if (typeof (setting["error"]) === "function")
                $(_image).error(function () { setting["error"](_image); });
            _image.onload = _image.onreadystatechange = function (evt) {
                if (!_image.readyState || /loaded|complete/.test(_image.readyState)) {
                    // Handle memory leak in IE
                    _image.onload = _image.onreadystatechange = null;
                    // Callback if not abort
                    if (fCallback) fCallback(_image);
                }
            };
        }
    });

    $.fn.extend({
        //让文字闪烁起来
        textBlink: function (options) {
            var defaults = {
                color: ["#fff", "#ffe2d1", "#ffc2a1", "#ffa370", "#ff8340", "#ff630f"], //轮番颜色 默认橙色
                blinktime: 60, //每帧时间 毫秒
                circle: 2 //闪烁次数
            }
            var _options = jQuery.extend(defaults, options);
            var loop = 0; var instance = this;
            for (var i = 0; i < _options.color.length * _options.circle; i++) {
                setTimeout(function () {
                    jQuery(instance).css("background-color", _options.color[loop]);
                    loop++;
                    loop = loop % _options.color.length;
                }, _options.blinktime * i);
            }
        }
    });

    module.exports = common
    // return common;
// });

