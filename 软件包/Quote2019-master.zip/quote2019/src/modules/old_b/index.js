// require(["baseStock", "common", "emZjlChart", "vticker", "template", "emcharts3"], function (baseStock, common, emZjlChart, vticker, template) {

  var baseStock = require('./basestock')
  var common = require('./common')
  var emZjlChart = require('./emzjlchart')
  require('./jquery.vticker')
  var template = require('./template')


    function bkStock() {
        baseStock.call(this);  //第二次调用基类的构造函数
        this.stockZjlType = "";
    }

    bkStock.prototype = new baseStock();
    var instance = new bkStock();

    //资金流
    bkStock.prototype.BindZjl = function () {
        var url = instance.baseUrl + '/api/qt/stock/get?secid=' + window.stockEnity.fullcode + "&ut=" + instance.ut + "&fields=f57,f135,f136,f137,f138,f139,f140,f141,f142,f143,f144,f145,f146,f147,f148,f149,f193,f194,f195,f196,f197,f152"
        $.ajax({
            type: "GET",
            url: url,
            data: null,
            //dataType: "json",
            dataType: 'jsonp',
            jsonp: 'cb',
            success: function (res) {
                //console.log("資金流>>>", res.data)

                //饼状图
                //var char3 = new emZjlChart(bkStock.prototype.stockId, "pe_zjl_chart", "");
                //char3.drawPeChart().init(res.data);

                //"f57版块名称,f135主力流入,f136主力流出,f137主力净流入,f138超大单流入,f139超大单流出,f140超大单净流入,f141大单流入,
                //f142大单流出,f143大单净流入,f144中单流入,f145中单流出,f146中单净流入,f147小单流入,f148小单流出,f149小单净流入"
                //f193主力净占比,f194超大单净占比,f195	大单净占比,f196中单净占比,f197小单净占比,f152小數位數
                var data = res.data
                $(".zllr").html(data.f135.toString().NumbericFormat())//主力流入
                $(".zllc").html(data.f136.toString().NumbericFormat());//主力流出
                $(".zljlr").html(data.f137.toString().NumbericFormat()).addClass(common.getColor(data.f137));//主力净流入
                $(".cddlr").html(data.f138.toString().NumbericFormat());//超大单流入
                $(".cddlc").html(data.f139.toString().NumbericFormat());//超大单流出
                $(".ddlr").html(data.f141.toString().NumbericFormat());//大单流入
                $(".ddlc").html(data.f142.toString().NumbericFormat());//大单流出
                $(".zdlr").html(data.f144.toString().NumbericFormat());//中单流入
                $(".zdlc").html(data.f145.toString().NumbericFormat());//中单流出
                $(".xdlr").html(data.f147.toString().NumbericFormat());//小单流入
                $(".xdlc").html(data.f148.toString().NumbericFormat());//小单流出
                $(".cddjlr").html(data.f140.toString().NumbericFormat()).addClass(common.getColor(data.f140));//超大单净流入
                $(".ddjlr").html(data.f143.toString().NumbericFormat()).addClass(common.getColor(data.f143));//大单净流入
                $(".zdjlr").html(data.f146.toString().NumbericFormat()).addClass(common.getColor(data.f146));//中单净流入
                $(".xdjlr").html(data.f149.toString().NumbericFormat()).addClass(common.getColor(data.f149));//小单净流入
                $(".zljb").html((data.f193 / Math.pow(10, data.f152)).toFixed(2) + '%').addClass(common.getColor(data.f193));//主力净占比
                $(".cddjb").html((data.f194 / Math.pow(10, data.f152)).toFixed(2) + '%').addClass(common.getColor(data.f194));//超大单净占比
                $(".ddjb").html((data.f195 / Math.pow(10, data.f152)).toFixed(2) + '%').addClass(common.getColor(data.f195));//大单净占比
                $(".zdjb").html((data.f196 / Math.pow(10, data.f152)).toFixed(2) + '%').addClass(common.getColor(data.f196));//中单净占比
                $(".xdjb").html((data.f197 / Math.pow(10, data.f152)).toFixed(2) + '%').addClass(common.getColor(data.f197));//小单净占比
                var arr = []
                arr.push(Math.abs(data.f140))
                arr.push(Math.abs(data.f143))
                arr.push(Math.abs(data.f146))
                arr.push(Math.abs(data.f149))

                var max = Math.max.apply(Math, arr)
                var totalHeight = $("#chartContainer .up_div").height() - 20;
                //资金流柱状图
                for (var i = 0; i < 4; i++) {
                    var jlr = i == 0 ? data.f140 : i == 1 ? data.f143 : i == 2 ? data.f146 : data.f149
                    //if (!jlr) continue
                    var height = jlr ? Math.abs(totalHeight) * (Math.abs(jlr) / max) : 0;
                    if (jlr > 0) {
                        $(".canvas_pic .up_ul li").eq(i).css("height", height).attr('title', jlr.toString().NumbericFormat());
                        $(".canvas_pic .down_ul li").eq(i).html((jlr/10000).toFixed(0)).attr('title', jlr.toString().NumbericFormat());
                        $(".canvas_pic .down_ul li").eq(i).css("background-color", "#fff");
                        $(".canvas_pic .down_ul li").eq(i).addClass("red");
                    } else {
                        $(".canvas_pic .down_ul li").eq(i).css("height", height).attr('title', jlr.toString().NumbericFormat());
                        $(".canvas_pic .up_ul li").eq(i).html((jlr / 10000).toFixed(0)).attr('title', jlr.toString().NumbericFormat());
                        $(".canvas_pic .up_ul li").eq(i).css("background-color", "#fff");
                        $(".canvas_pic .up_ul li").eq(i).addClass("green");
                    }
                    $(".canvas_pic .up_ul li").eq(i).css("position", "absolute");
                    $(".canvas_pic .up_ul li").eq(i).css("bottom", "0");
                    $(".canvas_pic .up_ul li").eq(i).css("left", 24 * i + "%");
                    $(".canvas_pic .down_ul li").eq(i).css("left", 24 * i + "%");

                }
            }
        });
    }


    //新闻
    //bkStock.prototype.BindNews = function () {
    //    var url = "/web/api/StockApi/GetStockNews";
    //    $.ajax({
    //        type: "GET",
    //        url: url,
    //        data: { code: bkStock.prototype.code, name: bkStock.prototype.name, length: 5 },
    //        dataType: "json",
    //        success: function (data) {
    //            if (data.success && data.data.length > 0) {

    //                var html = "";
    //                for (var i = 0; i < data.data.length; i++) {
    //                    var item = data.data[i];

    //                    html += '<li class="clearfix">' +
    //                        '<a href="' + item.url + '" target="_blank" class="fl">' + item.title + '</a>' +
    //                        '<i class="fr">' + item.date + '</i></li>';
    //                }

    //                $("#stocknews_table").html(html);

    //            }
    //        }
    //    });
    //}

    //公告
    bkStock.prototype.BindNotice = function () {
        // //var url = "/api/stockapi/GetStockNotice"; //本地
        // var url = "http://quote.eastmoney.com/web/api/stockapi/GetStockNotice"; //测试线上
        // $.ajax({
        //     type: "GET",
        //     url: url,
        //     data: { code: bkStock.prototype.code, name: bkStock.prototype.name, length: 5 },
        //     dataType: "json",
        //     success: function (data) {
        //         if (data.success) {

        //             var html = "";
        //             for (var i = 0; i < data.data.length; i++) {
        //                 var item = data.data[i];

        //                 html += '<li class="clearfix">' +
        //                     '<a href="' + item.url + '" target="_blank" class="fl">' + item.title + '</a>' +
        //                     '<i class="fr">' + item.date + '</i></li>';
        //             }

        //             $("#stocknotice_table").html(html);

        //         }
        //     }
        // });

        if(window['stocknotice']){
          var html = "";
          for (var i = 0; i < stocknotice.length; i++) {
              var item = stocknotice[i];

              html += '<li class="clearfix">' +
                  '<a href="' + item.url + '" target="_blank" class="fl">' + item.title + '</a>' +
                  '<i class="fr">' + item.date + '</i></li>';
          }

          $("#stocknotice_table").html(html);          
        }
    }

    //公司深度分析
    bkStock.prototype.CompanyCore = function () {
        var base = this;
        var url = base.baseUrl + "/api/qt/stock/get?secid=" + window.stockEnity.fullcode + "&ut=" + base.ut + "&fields=f55,f57,f152,f62,f162,f92,f167,f183,f184,f105,f185,f186,f187,f173,f188,f84,f85,f116,f117,f190,f189,f269,f270,f271,f272,f273,f274,f275&invt=2"
        //55每股收益 57证券代码 62财报季度   162市盈率(动态) 92净资产 167市净率 183营收 184营收同比 105净利润 185净利润同比
        // 186毛利率 187净利率  173ROE 188负债率 84总股本 85流通股本  116总市值  117流通市值 190每股未分配利润 189上市日期
        //269 B股对应A股代码  270B股对应A股市场号 271B股对应A股名称 272B股对应A股小数位数 273B股对应的A股昨收价
        //274B股对应的A股的最新价 275B股对应的A股的涨跌幅
        common.jsonPnew(url, function (json) {
            var data = json.data
            var html = "";
            var html_finance = "";
            var season = data.f62 == 1 ? '一' : data.f62 == 2 ? '二' : data.f62 == 3 ? '三' : '四';
            var sstime = data.f189 + ''
            html += '<tbody><tr><td><a href="http://data.eastmoney.com/bbsj/' + base.code + '.html" target="_blank">收益(' + season + '):</a><span>' + data.f55.toFixed(3) + '</span></td><td><span>PE(动):</span><span class="PEBox">' + (data.f162 / Math.pow(10, data.f152)).toFixed(data.f152) + '</span></td></tr>' +
                   '<tr><td><a href="http://data.eastmoney.com/bbsj/' + base.code + '.html" target="_blank">净资产:</a><span>' + data.f92.toFixed(4) + '</span></td><td><span>市净率:</span><span class="sjlBox">' + (data.f167 / Math.pow(10, data.f152)).toFixed(data.f152) + '</span></td></tr>' +
                   '<tr><td><span>营收:</span><span>' + (data.f183 + '').NumbericFormat() + '</span></td><td><a href="http://data.eastmoney.com/bbsj/' + base.code + '.html" target="_blank">同比:</a><span>' + data.f184.toFixed(2) + '%</span></td></tr>' +
                   '<tr><td><span>净利润:</span><span>' + (data.f105 + '').NumbericFormat() + '</span></td><td><span>同比:</span><span>' + data.f185.toFixed(2) + '%</span></td></tr>' +
                   '<tr><td><a href="http://data.eastmoney.com/bbsj/' + base.code + '.html" target="_blank">毛利率:</a><span>' + data.f186.toFixed(2) + '%</span></td><td><span>净利率:</span><span>' + data.f187.toFixed(2) + '%</span></td></tr>' +
                   '<tr><td><a href="http://data.eastmoney.com/bbsj/' + base.code + '.html" target="_blank">ROE<b class="roeIcon" title="净资产收益率"></b>:</a><span>' + data.f173.toFixed(2) + '%</span></td><td><span>负债率:</span><span>' + data.f188.toFixed(2) + '%</span></td></tr>' +
                   '<tr><td><span>总股本:</span><span>' + (data.f84 + '').NumbericFormat() + '</span></td><td><span>总值:</span><span>' + (data.f116 + '').NumbericFormat() + '</span></td></tr>' +
                   '<tr><td><span>流通股:</span><span>' + (data.f85 + '').NumbericFormat() + '</span></td><td><span>流值:</span><span>' + (data.f117 + '').NumbericFormat() + '</span></td></tr>' +
                   '<tr><td colspan="2"><span>每股未分配利润:</span><span>' + data.f190.toFixed(4) + '元</span></td></tr>' +
                   '<tr><td colspan="2"><span>上市时间:</span><span>' + sstime.slice(0, 4) + '-' + sstime.slice(4, 6) + '-' + sstime.slice(6) + '</span></td></tr></tbody>';

            html_finance += '<tbody><tr><td>净资产：<span>' + data.f92.toFixed(4) + '</span></td>' +
                    '<td>ROE: <span>' + data.f173.toFixed(2) + '%</span></td></tr><tr><td>收益(' + season + '): <span>' + data.f55.toFixed(3) + '</span></td>' +
                    '<td>PE(动): <span class="PEBox">' + (data.f162 / Math.pow(10, data.f152)).toFixed(data.f152) + '</span></td></tr><tr><td>总股本: <span>' + (data.f84 + '').NumbericFormat() + '</span></td>' +
                    '<td>总值: <span>' + (data.f116 + '').NumbericFormat() + '</span></td></tr><tr><td>流通股: <span>' + (data.f85 + '').NumbericFormat() + '</span></td>' +
                    '<td>流值: <span>' + (data.f117 + '').NumbericFormat() + '</span></td></tr></tbody>';

            $("#fanince_table").html(html_finance);
            $("#company_table").html(html);

            //AB股关联
            var ahtml = "";
            if (data.f269 != "-") {
                var market = data.f270 == "1" ? "sh" : "sz";
                var zdf = data.f275 == "-" ? "-" : (data.f275 / 100).toFixed(2) + "%";
                var color = data.f275 > 0 ? "red" : data.f275 < 0 ? "green" : '';
                ahtml += '<a href="http://quote.eastmoney.com/' + market + data.f269 + '.html" target="_blank" class="AB_a"><strong>' + data.f271 + ' A股行情</strong></a><span class="n2 ' + color + '">' +(data.f274=='-'?'-':(data.f274 / Math.pow(10, data.f272)).toFixed(data.f272)) + '</span><span class="n3 ' + color + '">' + zdf + '</span>';
            } else {
                ahtml += '<a href="http://acttg.eastmoney.com/pub/web_app_bghqy_ycwzl_01_01_01_1" target="_blank" class="n1">手机看B股实时行情</a>';
                ahtml += '<a href="http://acttg.eastmoney.com/pub/web_app_bghqy_ycwzl_01_02_01_1" target="_blank" class="n2">顶尖高手交易全曝光</a>';
            }

            $("#astock_table").html(ahtml);
        })
    }



    //AB股比价
    bkStock.prototype.ABStock = function (type) {
        var base = this;
        var url = base.baseUrl + "/api/qt/clist/get?pn=1&pz=6&po=1&np=1&ut=" + base.ut + "&fltt=2&invt=2&fid=f3&fs=" + (type == 1 ? 'm:1+t:3+s:1024' : 'm:0+t:7+s:1024') + "&fields=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f12,f13,f14,f15,f16,f17,f18,f20,f21,f23,f24,f25,f22,f11,f62,f128,f136,f115,f152,f201,f202,f203,f196,f197,f199,f195,f200,f251"
        common.jsonPnew(url, function (json) {
            if (!json.data) return
            var data = json.data.diff;
            var htm = '';
            for (var i = 0; i < data.length; i++) {
                var bijia = data[i].f199 == '-'?'-':data[i].f199.toFixed(2)
                var AClosePrice = data[i].f196 == '-' ? '-' : (data[i].f196).toFixed(data[i].f200)
                var ApercentChange = data[i].f197 == '-'?'-': data[i].f197.toFixed(2) + '%'
                var AColor = data[i].f197 > 0 ? 'red' : data[i].f197 < 0 ? 'green' : ''
                var ACode = data[i].f201
                var AMarket = data[i].f202 == 1 ? "sh" : "sz";
                var AName = data[i].f203.replace('Ｂ', 'B')

                var BClosePrice = data[i].f2 == '-' ? '-' : (data[i].f2).toFixed(data[i].f1)
                var BpercentChange = data[i].f3 == '-' ? '-' : data[i].f3.toFixed(2) + '%'
                var BColor = data[i].f3 > 0 ? 'red' : data[i].f3 < 0 ? 'green' : ''
                var BCode = data[i].f12
                var BMarket = data[i].f13 == 1 ? "sh" : "sz";
                var BName = data[i].f14

                var zxj = data[i].f251

                var AUrl = ACode == "-" ? "javascript:;" : "http://quote.eastmoney.com/" + AMarket + ACode + ".html";
                htm += '<tr><td>' + (i + 1) + '</td><td><a href="http://quote.eastmoney.com/' + BMarket + BCode + '.html" target="_blank">' + BCode + '</a></td>' +
                    '<td><a href="http://quote.eastmoney.com/' + BMarket + BCode + '.html" target="_blank">' + BName + '</a></td>' +
                    '<td><a href="http://guba.eastmoney.com/list,' + BCode + '.html" target="_blank" class="guba_a">股吧</a><a href="http://data.eastmoney.com/zjlx/' + BCode + '.html" target="_blank">资金流</a></td>' +

                '<td class=' + BColor + '><b>' + BClosePrice + '</b></td><td class=' + BColor + '><b>' + zxj + '</b></td><td class=' + BColor + '><b>' + BpercentChange + '</b></td>' +
                    '<td><a href="' + AUrl + '" target="_blank">' + ACode + '</a></td>' +
                    '<td><a href="' + AUrl + '" target="_blank">' + AName + '</a></td>' +
                    '<td class=' + AColor + '><b>' + AClosePrice + '</b></td><td class=' + AColor + '><b>' + ApercentChange + '</b></td><td><b>' + bijia + '</b></td></tr>';
            }
            if (type == 1) {
                $("#AB_SH_table").html(htm);
            } else {
                $("#AB_SZ_table").html(htm);
            }
        });
    }

    bkStock.prototype.CheckFavorite = function () {
        var code = this.code;
        var market = this.market;
        var newmarket = this.newmarket
        var _url = "http://myfavor1.eastmoney.com/mystock_web?f=gsaandcheck&sc=" + newmarket + "." + code
        common.jsonPnew(_url, function (json) {
            var fag = json.data.check
            if (fag == 'True') {
                $("#addZX1_a").html("-删自选")
                $("#addZX1").css("background", "rgb(153, 153, 153)")
            } else {
                $("#addZX1_a").html("+加自选")
                $("#addZX1").css("background", "rgb(255, 74, 3)")
            }
        })
    }


    bkStock.prototype.AddFavorite = function () {
        var code = this.code;
        var market = this.market;
        // console.info(this)
        $('#addZX1_a').click(function(){
          return true;
        })

        $("#addZX1").click(function () {
            var ut = common.getCookie("ut");
            if (ut) {
                var _html=$("#addZX1_a").html()
                var f = "azx"
                if (_html == "+加自选") {
                    f = "asz"
                } else {
                    f = "dsz"
                }
                $.getScript("http://myfavor1.eastmoney.com/mystock?f="+ f +"&sc=" + code + "|0" + market + "|01&var=opfavres", function () {
                    //alert("添加自选股成功");
                    
                    if (_html == "+加自选") {
                        window.open("http://quote.eastmoney.com/zixuan/?from=zixuanmini")
                        $("#addZX1_a").html("-删自选")
                        $("#addZX1").css("background", "rgb(153, 153, 153)")
                    } else {
                        $("#addZX1_a").html("+加自选")
                        $("#addZX1").css("background", "rgb(255, 74, 3)")
                    }

                });
            } else {
                window.open("https://passport2.eastmoney.com/pub/login?backurl=" + encodeURIComponent(location.href));
            }
            return false
        });
    }
    //分时成交
    bkStock.prototype.fscjFun = function (num) {
        var _num = (num | 10) + 1;
        var _url = instance.baseUrl + "/api/qt/stock/details/get?secid=" + window.stockEnity.fullcode + "&ut=" + instance.ut + "&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55&pos=-" + _num
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            beforeSend: function () {
                $("#fblist tbody").html('<td colspan="3" style="height: 231px; text-align: center;" class="waiting ">加载中...</td>');
            },
            success: function (json) {
                var data = json.data
                if (!data.details.length || !data.prePrice) {
                    var height = " 230px";
                    $("#fblist tbody").html("<tr><td colspan=3 style='height: " + height + "px;text-align:center'>暂无数据</td></tr>");
                    return;
                };
                var list = [];
                var details = data.details
                for (var i = 0; i < details.length; i++) {
                    if (i > 0) {
                        var itemslast = details[i - 1].split(",")
                        var items = details[i].split(",");
                        var dir = (items[1] > itemslast[1] ? "↑" : items[1] == itemslast[1] ? " " : "↓")
                        var listitem = {
                            time: items[0],
                            close: items[1],
                            closeCss: common.getColor(items[1] - data.prePrice),
                            volumn: items[2],
                            dir: dir,
                            volumnCss: items[4] == 0 ? lastcolor : (items[4] == 2 ? (items[1] * items[2] > 200000 ? 'purple' : 'red') : (items[1] * items[2] > 200000 ? 'blue' : 'green')),
                            arrowcolor: items[1] > itemslast[1] ? "red" : items[1] == itemslast[1] ? " " : "green"
                        }
                        list.push(listitem);
                        var lastcolor = listitem.volumnCss
                    }
                }
                list = list.reverse()
                var html = template("tmp_deal_detail", { list: list });
                $("#fblist tbody").html(html);
            }
        });
    }
    //个股日历
    bkStock.prototype.ggrlFun = function () {
        //console.log(_Market)
        var code = this.code;
        var _Market = this.market;
        //$.getScript("http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=3000592&sty=HC&st=z&sr=&p=&ps=&cb=&js=var%20bjTime=(x)&token=7bc05d0d4c3c22ef9fca8c2a912d779c", function () {
        //    var dt = new Date((window.bjTime).replace(/-/g, '/')).getTime();
            var dt = new Date().getTime();
            var futureTime = new Date(dt + 6 * 30 * 24 * 3600000); //15552000000 = 6个月*30天*24小时*60分钟*60秒*1000毫秒
            var future = common.formatDate(futureTime, "yyyy-MM-dd");
            var pastTime = new Date(dt - 6 * 30 * 24 * 3600000), past = common.formatDate(pastTime, "yyyy-MM-dd");
            var url = "http://dcfm.eastmoney.com/em_mutisvcexpandinterface/api/js/get?type=GGSJ20_ZDGZ&token=70f12f2f4f091e459a279469fe49eca5&&st=rq&sr=-1&p=1&ps=10&filter=(gpdm='" + code + "' and rq>=^" + past + "^ and rq < ^" + future + "^)";
            $.ajax({
                url: url,
                dataType: "jsonp",
                success: function (json) {
                    //console.log(json,"数据")
                    if (!json || json.length < 0) { return; }
                    var Li = "";
                    for (var i = 0; i < json.length; i++) {
                        var _href = hrefFun(json[i]["sjlxz"], json[i]["gpdm"], _Market);
                        var str = json[i]["sjlx"] + '：' + json[i]["sjms"];
                        Li += '<li tracker-eventcode="calendar1"><a href="' + _href + '" target="_blank">' + common.cutstr(str, 70) + '</a></li>';
                    }
                    $(".scroll-ul").html(Li);
                    $(".scrollBox").vTicker({
                        showItems: 1,
                        height: 26
                    });
                }
            });
        //})
    }//个股日历
    function hrefFun(str, gpdm, market) {
        var href = "";
        switch (str) {
            case "TFP":
                href = "http://data.eastmoney.com/tfpxx/";
                break;
                // 停牌日期
            case "LHB":
                href = "http://data.eastmoney.com/stock/lhb/" + gpdm + ".html";
                break;
                // 龙虎榜
            case "DZJY":
                href = "http://data.eastmoney.com/dzjy/detail/" + gpdm + ".html";
                break;
                // 大宗交易
            case "GG":
                href = "http://data.eastmoney.com/notices/stock/" + gpdm + ".html";
                break;
                // 公告
            case "YB":
                href = "http://data.eastmoney.com/report/" + gpdm + ".html";
                break;
                // 研报
            case "JGDY":
                href = "http://data.eastmoney.com/jgdy/gsjsdy/" + gpdm + ".html";
                break;
                // 机构调研
            case "GDZJC":
                href = "http://data.eastmoney.com/executive/gdzjc/" + gpdm + ".html";
                break;
                // 股东增减持日
            case "XSJJ":
                href = "http://data.eastmoney.com/dxf/q/" + gpdm + ".html";
                break;
                // 限售解禁日
            case "GGZJC":
                href = "http://data.eastmoney.com/executive/" + gpdm + ".html";
                break;
                // 高管持股
            case "GGXGZJC":
                href = "http://data.eastmoney.com/executive/" + gpdm + ".html";
                break;
                // 高管关联人持股
            case "YYPL":
                href = "http://data.eastmoney.com/bbsj/" + gpdm + ".html";
                break;
                // 预约披露日
            case "YJYG":
                href = "http://data.eastmoney.com/bbsj/" + gpdm + ".html";
                break;
                // 业绩预告
            case "YJKB":
                href = "http://data.eastmoney.com/bbsj/" + gpdm + ".html";
                break;
                // 业绩快报
            case "YJBB":
                href = "http://data.eastmoney.com/bbsj/" + gpdm + ".html";
                break;
                // 业绩报表
            case "GBBD":
                href = "http://emweb.securities.eastmoney.com/f10_v2/CapitalStockStructure.aspx?type=web&code=" + market == "1" ? "sh" + gpdm : "sz" + gpdm;
                break;
                // 股本变动
            case "XGSG":
                href = "http://data.eastmoney.com/xg/xg/detail/" + gpdm + ".html";
                break;
                // 新股
            case "FHPS":
                href = "http://data.eastmoney.com/yjfp/detail/" + gpdm + ".html";
                break;
                // 分红
            case "GDDH":
                href = "http://data.eastmoney.com/gddh/list/" + gpdm + ".html";
                break;
                // 股东大会
            case "GDHS":
                href = "http://data.eastmoney.com/gdhs/detail/" + gpdm + ".html";
                break;
                // 股东户数
        }
        return href;
    }//个股日历列表跳转链接

    var fieldList = [
        { "name": "jkj", "num": 3, "hasColor": true, "NumbericFormat": false },
        { "name": "zsj", "num": 9, "hasColor": false, "NumbericFormat": false },
        { "name": "zxj", "num": 0, "hasColor": true, "NumbericFormat": false },
        { "name": "zde", "num": 18, "hasColor": true, "NumbericFormat": false },
        { "name": "zdf", "num": 19, "hasColor": true, "NumbericFormat": false },
        { "name": "zgj", "num": 1, "hasColor": true, "NumbericFormat": false },
        { "name": "zdj", "num": 2, "hasColor": true, "NumbericFormat": false },
        { "name": "ztj", "num": 25, "hasColor": false, "NumbericFormat": false },
        { "name": "dtj", "num": 26, "hasColor": false, "NumbericFormat": false },
        { "name": "lb", "num": 22, "hasColor": false, "NumbericFormat": false },
        { "name": "hsl", "num": 17, "hasColor": false, "NumbericFormat": false },
        { "name": "cjl", "num": 4, "hasColor": false, "NumbericFormat": true },
        { "name": "cje", "num": 5, "hasColor": false, "NumbericFormat": true },
        { "name": "zsz", "num": 12, "hasColor": false, "NumbericFormat": true },
        { "name": "ltsz", "num": 27, "hasColor": false, "NumbericFormat": true },
        { "name": "np", "num": 6, "hasColor": false, "NumbericFormat": false },
        { "name": "wp", "num": 15, "hasColor": false, "NumbericFormat": false },
        { "name": "jj", "num": 24, "hasColor": true, "NumbericFormat": false },
        { "name": "wb", "num": 28, "hasColor": true, "NumbericFormat": false },
        { "name": "wc", "num": 29, "hasColor": true, "NumbericFormat": false },
        { "name": "syl", "num": 30, "hasColor": false, "NumbericFormat": false },
        { "name": "sjl", "num": 31, "hasColor": false, "NumbericFormat": false }
    ];

    function bindEvent() {
        $(".tabLi").mouseenter(function () {
            $(this).parent().find("li").removeClass("cur");
            $(this).addClass("cur");

            var index = $(this).index();
            if ($(this).parents(".tabExchangeCon").length > 0) {
                $(this).parents(".tabExchangeCon").find(".info_list").removeClass("active");
                $(this).parents(".tabExchangeCon").find(".info_list").eq(index).addClass("active");

                $(this).parents(".tabExchangeCon").find(".more").hide();
                $(this).parents(".tabExchangeCon").find(".more").eq(index).show();

            } else {
                $(this).parents(".side_box").find(".info_list").removeClass("active");
                $(this).parents(".side_box").find(".info_list").eq(index).addClass("active");
            }

        });

        $(".rank_date li").click(function () {
            $(".rank_date li").removeClass("cur");
            $(this).addClass("cur");
            instance.stockZjlType = $(this).attr("value") || "";
            //instance.BindStockZjl();
        });

        //二维码
        $(".mobile-container, .mobile-icon").mouseenter(function () {
            $(this).find("img").attr("src", "http://pifm3.eastmoney.com/EM_Finance2014PictureInterface/RC.ashx?url=http://m2.quote.eastmoney.com/h5stock/" + bkStock.prototype.stockId + ".html");
            $(".QRcode-div").show();
        });

        $(".mobile-container").mouseout(function () {
            $(".QRcode-div").hide();
        });
    }

    var noth5 = !+'\v1';
    if (noth5) {
        $("#zjl_div").hide();
        $("#chartimg_select").hide();
    } else {
        // var char1 = new emZjlChart(bkStock.prototype.stockId, "pq_zjl_chart", "panqian");
        // char1.drawChart().init();

        // var char2 = new emZjlChart(bkStock.prototype.stockId, "ph_zjl_chart", "panhou");
        // setTimeout(function() {
        //     char2.drawChart().init();
        // },1000)
        //char2.drawChart().init();

        // var char3 = new emZjlChart(bkStock.prototype.stockId, "pe_zjl_chart", "");
        // char3.drawPeChart().init(instance.baseUrl, instance.ut);

        instance.setChart().init();
    }


    bindEvent();
    //zxw 基本行情
    var hqurl = instance.baseUrl + '/api/qt/stock/get?secid=' + window.stockEnity.fullcode + '&ut=' + instance.ut + '&fields=f191,f192,f117,f43,f51,f52,f169,f170,f46,f60,f84,f116,f44,f45,f171,f126,f47,f48,f168,f164,f49,f161,f55,f92,f59,f152,f167,f50,f86,f71,f172,f162,f167&invt=2'
    instance.loadnewHqData(hqurl, 'B').intital(fieldList, 'B'); //zxw
    //instance.loadHqData().intital(fieldList);
    var pic = instance.bindChartImgEvent();
    pic.bindEvent();
    instance.CompanyCore();
    //instance.BindNews();
    instance.BindNotice();
    //guba.init("gubalisttable", bkStock.prototype.code, { listcount: 12, titlecut: 42 });
    instance.setHotGuba(15);
    instance.ABStock(0);
    instance.ABStock(1);
    instance.AddFavorite();
    instance.CheckFavorite();
    init();

    instance.ggrlFun();
    setInterval(function () {
        init();
    }, 20 * 1000);

    function init() {
        instance.bindDataTemplatenew(instance.baseUrl + "/api/qt/ulist.np/get?secids=0.399003,90.bk0636&ut=" + instance.ut + "&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152", "cfg_table", "AB_NO");

        instance.bindDataTemplatenew(instance.baseUrl + "/api/qt/clist/get?pi=0&pz=7&po=1&ut=" + instance.ut + "&fs=b:BK0636&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152", "bgn_table", "AB");
        instance.stockBroadcast().init();
        //instance.loadDetailData();
        instance.loadDetailDatanew(); // 新五档行情
        instance.fscjFun(10);//新分时成交
        instance.getFavouriteStocknew(6);
        instance.BindZjl();
        //instance.BindStockZjl();
        pic.changeImg();
        instance.bindStockNews();
    }

// });

