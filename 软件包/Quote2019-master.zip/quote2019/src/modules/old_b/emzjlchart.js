// define(["jQuery", "chartLib"], function () {
    function opChart(stockId, container, chartStatus) {
        this.stockId = stockId;
        this.container = container;
        this.chartStatus = chartStatus;
    }

    opChart.prototype.drawChart = function () {
        var drawChart = {
            container: this.container,
            stockId: this.stockId,
            width: 620,
            height: 200,
            chartStatus: this.chartStatus,
            draw: function (obj) {
                var _this = this;
                var chart = new EmchartsWebLine({
                    container: _this.container,
                    width: _this.width,
                    height: _this.height, 
                    showflag: true,
                    sepeNum: 6,
                    font: {
                        fontFamily: 'Microsoft Yahei',
                        fontSize: "12",
                        color: "#000"
                    },
                    xaxis: obj.xaxis,
                    series: obj.series
                });
                //调用绘图方法
                chart.draw();
            },
            dataTransfer: function (obj) {
                var _this = this;
                var value = {
                    xaxis: [],
                    series: []
                }
                var main = {
                    name: "主力净流入",
                    color: "#FE3EE1",
                    data: [],
                    suffix: "万元"
                };
                var large = {
                    name: "超大单净流入",
                    color: "#650000",
                    data: [],
                    suffix: "万元"
                };
                var big = {
                    name: "大单净流入",
                    color: "#FF1117",
                    data: [],
                    suffix: "万元"
                };
                var middle = {
                    name: "中单净流入",
                    color: "#FFB83D",
                    data: [],
                    suffix: "万元"
                };
                var small = {
                    name: "小单净流入",
                    color: "#94C4EE",
                    data: [],
                    suffix: "万元"
                };

                var xArr = obj.xa.split(",");

                for (var i = 0; i < xArr.length; i++) {
                    var time = xArr[i];
                    if (time != "") {
                        var isShow = false;
                        if (time == "09:31" || time == "10:30" || time == "11:30" || time == "14:00" || time == "15:00") {
                            isShow = true;
                        }
                        value.xaxis.push({
                            value: time,
                            showline: isShow,
                            show: isShow
                        });
                    }
                }
                var yArr = obj.ya;

                if (obj.ya[0] == ",,,,") {

                    $("#" + _this.container).html('<img src="http://hqcdn.quote.eastmoney.com/zaopan.jpg" border="0">');
                    return;
                }

                //console.log(yArr)
                for (var i = 0; i < yArr.length; i++) {
                    var subArray = yArr[i].split(',');
                    main.data.push(subArray[0]);
                    large.data.push(subArray[1]);
                    big.data.push(subArray[2]);
                    middle.data.push(subArray[3]);
                    small.data.push(subArray[4]);
                }

                value.series.push(main);
                value.series.push(large);
                value.series.push(big);
                value.series.push(middle);
                value.series.push(small);
                var _this = this;
                _this.draw(value);
            },
            dataTransfer_panhou: function (obj) {
                var _this = this;
                var value = {
                    xaxis: [],
                    series: []
                }
                var main = {
                    name: "主力净流入",
                    color: "#FE3EE1",
                    data: [],
                    suffix: "万元"
                };
                var large = {
                    name: "超大单净流入",
                    color: "#650000",
                    data: [],
                    suffix: "万元"
                };
                var big = {
                    name: "大单净流入",
                    color: "#FF1117",
                    data: [],
                    suffix: "万元"
                };
                var middle = {
                    name: "中单净流入",
                    color: "#FFB83D",
                    data: [],
                    suffix: "万元"
                };
                var small = {
                    name: "小单净流入",
                    color: "#94C4EE",
                    data: [],
                    suffix: "万元"
                };

                var len = obj.length;
                var xpoint = 4;
                var jg = parseInt(len / xpoint);
                for (var i = 0; i < len; i++) {
                    var subArray = obj[i].split(',');
                    var nowtime = new Date();
                    var time = subArray[0].replace(subArray[0].split("-")[0] + "-", "");
                    var isShow = false;
                    if (len < xpoint || i % jg == 0 || (i % jg > xpoint && i == len - 1)) {
                        isShow = true;
                    }
                    value.xaxis.push({
                        value: time,
                        showline: isShow,
                        show: isShow
                    });
                    main.data.push(subArray[1]);
                    large.data.push(subArray[2]);
                    big.data.push(subArray[3]);
                    middle.data.push(subArray[4]);
                    small.data.push(subArray[5]);
                }


                if (obj[0] == ",,,,") {
                    $("#" + _this.container).html('<img src="http://hqcdn.quote.eastmoney.com/zaopan.jpg" border="0">');
                    return;
                }

                value.series.push(main);
                value.series.push(large);
                value.series.push(big);
                value.series.push(middle);
                value.series.push(small);
                var _this = this;
                _this.draw(value);
            },
            init: function () {
                var _this = this;
                var url = "";
                if (this.chartStatus == "panhou") {
                    url = "http://ff.eastmoney.com/EM_CapitalFlowInterface/api/js?id=" + _this.stockId + "&type=hff&rtntype=2&cb=var%20aff_data=&js=(x)&check=TMLBMS&acces_token=4f1862fc3b5e77c150a2b985b12db0fd";
                } else {
                    url = "http://ff.eastmoney.com/EM_CapitalFlowInterface/api/js?id=" + _this.stockId + "&type=ff&check=MLBMS&cb=var%20aff_data=&js={(x)}&rtntype=3&acces_token=4f1862fc3b5e77c150a2b985b12db0fd";
                }
                $.ajax({
                    type: "get",
                    url: url,
                    dataType: "script",
                    scriptCharset: "utf-8",
                    success: function () {
                        if (_this.chartStatus == "panhou") {
                            _this.dataTransfer_panhou(aff_data);
                        } else {
                            _this.dataTransfer(aff_data);
                        }
                    }
                });

            }
        }
        return drawChart;
    }

    opChart.prototype.drawPeChart = function () {
        var drawPeChart = {
            container: this.container,
            stockId: this.stockId,
            draw: function (obj) {
                var _this = this;
                var chart = new EmchartsPie({
                    container: _this.container,
                    width: 325,
                    height: 250,
                    startOffset: Math.PI / 2,
                    onPie: false,
                    data: obj,
                    point: {
                        x: 165,
                        y: 125 + 15
                    },
                    radius: 90
                });
                //调用绘图方法
                chart.draw();

            },
            dataTransfer: function (obj) {
                var _this = this;
                var value = [];
                if (!obj || obj == undefined) {
                    return;
                }
                if (obj.f145 == 0 && obj.f148 == 0) { //小单流出 中单流出
                    $("#" + _this.container).html('<img src="http://hqcdn.quote.eastmoney.com/pe_default.jpg" border="0">');
                    return;
                }
                value.push({
                    name: "小单流出",
                    color: "#77e97a",
                    value: obj.f148,
                    showInfo: true
                });
                value.push({
                    name: "中单流出",
                    color: "#27b729",
                    value: obj.f145,
                    showInfo: true
                });
                value.push({
                    name: "大单流出",
                    color: "#0a820a",
                    value: obj.f142,
                    showInfo: true
                });
                value.push({
                    name: "超大单流出",
                    color: "#004800",
                    value: obj.f139,
                    show: true,
                    showInfo: true
                });
                value.push({
                    name: "超大单流入",
                    color: "#650000",
                    value: obj.f138,
                    showInfo: true
                });
                value.push({
                    name: "大单流入",
                    color: "#ae0000",
                    value: obj.f141,
                    showInfo: true
                });
                value.push({
                    name: "中单流入",
                    color: "#f83434",
                    value: obj.f144,
                    showInfo: true
                });
                value.push({
                    name: "小单流入",
                    color: "#ff8080",
                    value: obj.f147,
                    showInfo: true
                });
                this.draw(value);
            },
            init: function (baseUrl, ut) {
                var _this = this;
                var url = baseUrl + '/api/qt/stock/get?secid=' + stockEnity.MktNum + "." + stockEnity.stockCode + "&ut=" + ut + "&fields=f57,f135,f136,f137,f138,f139,f140,f141,f142,f143,f144,f145,f146,f147,f148,f149,f193,f194,f195,f196,f197,f152"
                $.ajax({
                    type: "GET",
                    url: url,
                    data: null,
                    dataType: 'jsonp',
                    jsonp: 'cb',
                    success: function (res) {
                        _this.dataTransfer(res.data);

                    }
                })
            }
        }
        return drawPeChart;
    }

module.exports = opChart
    // return opChart;
// });