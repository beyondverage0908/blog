// define(["common", "emChart", "template", "suggest"], function (common, emChart, template, suggest2017) {

  var common = require('../old_b/common')
  var emChart = require('../old_b/emchart')
  var template = require('../old_b/template')

    function baseStock() {
        if (window.stockEnity) {
            this.baseUrl = 'http://push2.eastmoney.com'
            this.ut = 'bd1d9ddb04089700cf9c27f6f7426281'
            this.code = window.stockEnity.stockCode;
            this.name = window.stockEnity.stockName;
            this.market = window.stockEnity.stockMarket;
            this.stockId = window.stockEnity.stockId;
            this.gubaCode = window.stockEnity.gubaCode;
            this.debug = window.location.host !== "quote.eastmoney.com" || window.stockEnity.released;
        }
        if (window.location.href.indexOf("eastmoney.com") > 0) {
            document.domain = "eastmoney.com";
        }
        if (typeof baseStock.suggest === "undefined") {
            try {
                var suggest = baseStock.suggest = new suggest2017({
                    inputid: "search_box",
                    offset: { left: -91, top: 5 },
                    shownewtips: true,
                    newtipsoffset: { top: -3, left: 0 }
                });
            } catch (e) {
                console.error(e);
            }
        }
    }


    // 快速行情
    baseStock.prototype.loadHqData = function () {
        var loadData = {
            url: "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + this.stockId + "&sty=FDPBPFB&st=z&sr=&p=&ps=&cb=?&js=([[(x)]])&token=7bc05d0d4c3c22ef9fca8c2a912d779c",
            intital: function (fieldList) {
                var self = this;
                self.loadHqData(fieldList);
                setInterval(function () {
                    self.loadHqData(fieldList);
                }, 20000);
            },
            loadHqData: function (fieldList) {
                common.jsonP(this.url, function (json) {
                    console.log(11111, json)
                    if (json && json[0] && json[0][0].stats != false) {
                        var stockData = json[0][0].split(',');
                        var zsjIndex, zdeIndex = 0;
                        //获取最新价和涨跌额的index
                        for (var i = 0; i < fieldList.length; i++) {
                            var item = fieldList[i];
                            if (item.name == "zsj") {
                                zsjIndex = item.num;
                            }
                            if (item.name == "zde") {
                                zdeIndex = item.num;
                            }
                        }

                        for (var i = 0; i < fieldList.length; i++) {
                            var field = fieldList[i];

                            var data = stockData[field.num];
                            //振幅和涨跌幅加百分比
                            if (field.name == "zf" || field.name == "zdf" || field.name == "hsl" || field.name == "wb" || field.name == "roe") {
                                if (data > 10000) data = data.split('.')[0];
                                data = data === "-" ? "-" : data + "%";
                            } else {
                                data = data === "-" ? "-" : data;
                            }

                            //开平
                            if (field.name == "kp") {
                                if (data == -1) {
                                    data = "-";
                                } else if (data == 0) {
                                    data = "双开";
                                } else if (data == 1) {
                                    data = "双平";
                                } else if (data == 2) {
                                    data = "多换";
                                } else if (data == 3) {
                                    data = "多开";
                                } else if (data == 4) {
                                    data = "多平";
                                } else if (data == 5) {
                                    data = "空换";
                                } else if (data == 6) {
                                    data = "空开";
                                } else if (data == 7) {
                                    data = "空平";
                                }
                            }
                            //万百万缩写
                            if (field.NumbericFormat && data) {
                                data = data.NumbericFormat();
                            }
                            $("." + field.name).html(data);

                            if (field.hasColor) {
                                var zsj = stockData[zsjIndex];
                                $("." + field.name).removeClass("red").removeClass("green");
                                if (field.name == "wb" || field.name == "wc" || field.name == "rz" || field.name == "cc") {
                                    $("." + field.name).addClass(common.getColor(data));
                                } else if (field.name != "zxj" && field.name != "zdf" && field.name != "zde") {
                                    if (data > zsj) {
                                        $("." + field.name).addClass("red");
                                    } else if (data < zsj) {
                                        $("." + field.name).addClass("green");
                                    }
                                } else {
                                    var zde = stockData[zdeIndex];
                                    if (zde != 0 && zde != "-") {
                                        if (zde.isPositive()) {
                                            $("." + field.name).addClass("red");
                                            $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");
                                        } else {
                                            $("." + field.name).addClass("green");
                                            $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
                                        }
                                    } else {
                                        $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
                                    }
                                }
                            }
                        }

                        //行情时间
                        $("#stock_time").html("(" + stockData[3] + ")");

                        //涨跌平
                        var zdpList = stockData[25].split("|");

                        if ($(".pjs").length > 0) {
                            $(".zjs").html(zdpList[0]);
                            $(".pjs").html(zdpList[1]);
                            $(".djs").html(zdpList[2]);
                        }

                        //阶段涨跌幅
                        var jdzdfList = stockData[26].split("|");

                        if ($(".5day").length > 0) {
                            $(".5day").html(jdzdfList[0]);
                            jdzdfList[0].isPositive() ? $(".5day").addClass("red") : $(".5day").addClass("green");
                            $(".20day").html(jdzdfList[2]);
                            jdzdfList[2].isPositive() ? $(".20day").addClass("red") : $(".20day").addClass("green");
                            $(".60day").html(jdzdfList[3]);
                            jdzdfList[3].isPositive() ? $(".60day").addClass("red") : $(".60day").addClass("green");
                            $(".tillNow").html(jdzdfList[4]);
                            jdzdfList[4].isPositive() ? $(".tillNow").addClass("red") : $(".tillNow").addClass("green");

                        }
                    }
                });
            }
        }
        return loadData;
    }

    /**
    * 加载排行模板
    * @param  {object} settings
    */
    baseStock.prototype.loadRankTemplate = function (settings) {
        var tpl = '{{each list as val idx}}<tr>'
            + '<td><a href="{{val.link}}" title="{{val.title || val.name}}" target="_blank">{{val.name}}</a></td>'
            + '<td class="{{val.color}}">{{val.close}}</td><td class="{{val.color}}">{{val.changePercent}}</td>'
            + '</tr>{{/each}}';
        var _this = this;
        var _default = {
            interval: 0,
            template: tpl,
            link: "//quote.eastmoney.com/web/r/{{code}}{{market}}",
            ajax: {
                url: "//nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx",
                type: "GET",
                data: {
                    type: "CT",
                    cmd: "",
                    sty: "E1II",
                    st: "(ChangePercent)",
                    sr: -1,
                    js: "([(x)])",
                    ps: 5,
                    token: "4f1862fc3b5e77c150a2b985b12db0fd"
                },
                dataType: "jsonp",
                jsonp: "cb"
            },
            dataResolver: function (json) {
                var context = new Object(),
                    models = [];
                if (json instanceof Array) {
                    for (var i = 0; i < json.length; i++) {
                        if (!isNaN(settings.count) && i >= settings.count) break;
                        var data = json[i];
                        if (typeof data !== "string") continue;
                        var items = data.split(',');
                        var _model = {
                            code: items[0],
                            market: items[1],
                            title: items[2],
                            name: common.cutstr(items[2], 10, "..."),
                            close: items[3],
                            changePercent: items[4],
                            color: items[4] === "0" || items[4] === "-" ? "" : items[4].isPositive() ? "red" : "green"
                        };
                        _model.link = template.render(_settings.link, _model);
                        models.push(_model);
                    }
                    context["list"] = models;
                }
                return context;
            }
        };
        if (settings.ajax) {
            settings.ajax.data = $.extend(_default.ajax.data, settings.ajax.data);
        }
        settings.ajax = $.extend(_default.ajax, settings.ajax);
        if (typeof settings.cmd === "string" && !settings.ajax.data.cmd)
            settings.ajax.data["cmd"] = settings.cmd;
        if (typeof settings.count === "number" && settings.count > 0)
            settings.ajax.data["ps"] = settings.count;
        if (typeof settings.callback === "string")
            settings.ajax["jsonpCallback"] = settings.callback;
        var _settings = $.extend(_default, settings);
        var $dom = $(_settings.dom);
        if ($dom.length === 0 && typeof _settings.dom === "string") {
            var _dom = document.getElementById(_settings.dom);
            if (_dom) $dom = $(_dom);
            else throw "dom not found";
        }
        _settings.ajax.success = function (json) {
            if (typeof settings.callback === "function") { settings.callback(json); }
            if (!json) return;
            var model, html;
            if (typeof _settings.dataResolver === "function") {
                model = _settings.dataResolver(json);
            }
            if (typeof _settings.callback === "function")
                _settings.callback($dom, model, _settings);
            if (typeof _settings.template === "string") {
                html = render(_settings.template, model);
            }
            else if (typeof _settings.template === "function") {
                var temp = _settings.template(context, _settings);
                html = render(temp, model);
            }
            if (html) $dom.html(html);
        };
        var render = function (tpl, model) {
            var _model = model || {};
            if (document.getElementById(tpl))
                return template(tpl, _model);
            else
                return template.render(tpl, _model);
        };
        var auto = $.dataAutoRefresh(_settings.ajax);
        if (_settings.interval > 0) {
            auto.intInterval = _settings.interval;
            auto.start();
        }
        else { auto.load(); }
        return auto;
    }

    /** 
    * 新版快速行情
    * @param {object} settings: 配置
    */
    baseStock.prototype.loadQuoteData = function (settings) {
        var _this = this;
        var _defualt = {
            ajax: {
                url: "//nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx",
                data: {
                    type: "CT",
                    cmd: _this.stockId,
                    sty: "FDPBPFB",
                    st: "z",
                    js: "((x))",
                    token: "4f1862fc3b5e77c150a2b985b12db0fd"
                },
                dataType: "jsonp"
            },
            interval: window.defaultInterval || 20 * 1000,
            fields: []
        };
        if (settings.ajax) {
            if (settings.ajax.data) {
                settings.ajax.data = $.extend(_defualt.ajax.data, settings.ajax.data);
            }
            settings.ajax = $.extend(_defualt.ajax, settings.ajax);
        }
        var _settings = $.extend(_defualt, settings);
        _settings.ajax.success = function (json) {
            if (!json) return;
            var data;
            if (typeof _settings.dataResolver === "function") {
                data = _settings.dataResolver(json);
            }
            else if (typeof (json) === "string") {
                data = json.split(',');
            }
            for (var i = 0; i < _settings.fields.length; i++) {
                var field = _settings.fields[i] ? _settings.fields[i] : {};
                var item = data[field.num || 0] + '',
                     //item = field.fixed?data[field.num || 0].toFixed(data[field.fixed]):item
                    $dom = $("." + field.name),
                    changed = false;
                if (typeof field.handler === 'function') {
                    item = field.handler.apply(_this, [item, field, _settings]);
                }
                if (!item || $dom.length == 0) continue;
                // 是否科学计数
                if (field.NumbericFormat) {
                    item = item.NumbericFormat();
                }
                // 枚举映射
                if (typeof (field.map) === "object" && field.map[item]) {
                    item = field.map[item];
                }
                // 呈现模板
                if (typeof field.template === "string") {
                    var model = new Object();
                    model[field.paramName || "data"] = item;
                    item = template.render(field.template, model);
                }
                changed = $dom.html() != item;
                //if (!changed) continue;
                $dom.html(item);
                // 颜色处理
                if (field.hasColor) {
                    var css = "", blink_model = 0;
                    $dom.removeClass("red").removeClass("green");
                    if (!isNaN(field.comparer)) {
                        css = field.comparer < 0 ? "green" : field.comparer > 0 ? "red" : "";
                        blink_model = field.comparer > 0 ? 1 : field.comparer < 0 ? -1 : 0;
                    }
                    else if (typeof field.comparer === "function") {
                        var c = field.comparer(data);
                        css = c < 0 ? "green" : c > 0 ? "red" : "";
                        blink_model = c > 0 ? 1 : c < 0 ? -1 : 0;
                    }
                    else {
                        css = common.getColor(item);
                        item = typeof item === "string" ? item : item.toString();
                        blink_model = item == "0" || item == "-" ? 0 : item.isPositive() ? 1 : -1;
                    }
                    $dom.addClass(css);
                    // 闪烁效果
                    if (field.blink && changed) {
                        if (blink_model === 1) {
                            $dom.textBlink({ color: ["#FFDDDD", "#FFEEEE", ""], blinktime: 150 });
                        }
                        else if (blink_model === -1) {
                            $dom.textBlink({ color: ["#b4f7af", "#ccffcc", ""], blinktime: 150 });
                        }
                    }
                }
                // 字段呈现回调
                if (typeof (field.render) === "function") {
                    field.render($dom, data[field.num || 0] + '', data, _settings);
                }
            }
        };
        var auto = $.dataAutoRefresh(_settings.ajax);
        auto.intInterval = _settings.interval;
        auto.start();
        return auto;
    }

    /** 
    * 新版个股新闻行情
    * @param {object} settings: 配置
    */
    baseStock.prototype.bindStockNews = function (settings) {
        var tpl = $("#tmp_news").html() || "{{if Status === 0 && Data.length>0}}"
            + "<ul class=\"article_list nlist\">"
            + "{{each Data as val idx}}<li>"
            + "<a href=\"{{val.Art_Url}}\" title=\"{{val.Art_Title}}\" target=\"_blank\" class=\"fl\">{{val.Art_Title | cutstr:42,'...'}}</a>"
            + "<i class=\"fr\">{{val.Art_ShowTime | formatDate:'MM-dd'}}</i>"
            + "</li>{{/each}}"
            + "</ul>{{else}}"
            + "<div class=\"nonslist\">暂无该股新闻</div>"
            + "{{/if}}";
        var _settings;
        var _default = {
            tpl: tpl,
            dom: $("#stocknews"),
            api: {
                url: "//searchapi.eastmoney.com/api/Info/Search?isAssociation20=True&highlights20=null&pageIndex20=1&pageSize20=5&returnFields20=Art_Title|0,Art_Url|0,Art_ShowTime&type=20&token=E5303D4106DC91E17D35009B8830D33D&sort20=Art_ShowTime|0",
                data: { and20: "multimatch/Art_Title,Art_Content/" + encodeURIComponent(stockEnity.stockName) + "/True" },
                dataType: "jsonp",
                jsonp: "cb",
                success: function (json) {
                    if (!json) json = { Status: -1 };
                    $(_settings.dom).html(template.render(_settings.tpl, json));
                }
            }
        };
        if (settings && settings.api) {
            settings.api = $.extend(_default.api, settings.api);
        }
        _settings = $.extend(_default, settings);
        if (settings) {
            if (typeof _settings.dom === "string") {
                var query = _settings.dom;
                _settings.dom = document.getElementById(query);
                if (!ele) _settings.dom = $(query);
            }
            if (typeof settings.callback === "function") {
                _default.api.success = settings.callback;
            }
            if (typeof settings.api.data !== "undefined") {
                $.extend(_default.api.data, settings.api.data);
            }
        }
        return $.ajax(_settings.api);
    }

    // 五档，分时
    baseStock.prototype.loadDetailData = function () {
        common.jsonP("http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + this.stockId + "&sty=FDTHTB&st=z&sr=&p=&ps=&cb=?&js=([(x)])&token=7bc05d0d4c3c22ef9fca8c2a912d779c", function (json) {
            if (json && json[0]) {
                var stockData = json[0].split(',');
                var html_sell = "<tbody>";
                var html_buy = "<tbody>";
                var html_deal = "<tbody>";
                var numList = ["一", "二", "三", "四", "五"];

                var zs = stockData[3];
                var color = "";
                for (var i = 10; i < 15; i++) {
                    if (stockData[24 - i] > zs) {
                        color = "red";
                    } else if (stockData[24 - i] < zs) {
                        color = "green";
                    }
                    html_sell += '<tr><td class="tac">卖' + numList[14 - i] + '</td><td class="' + color + '">' + stockData[24 - i] + '</td><td>' + stockData[34 - i] + '</td></tr>';
                }

                color = "";
                for (var j = 5; j < 10; j++) {
                    if (stockData[j] > zs) {
                        color = "red";
                    } else if (stockData[j] < zs) {
                        color = "green";
                    }
                    html_buy += '<tr><td class="tac">买' + numList[j - 5] + '</td><td class="' + color + '">' + stockData[j] + '</td><td>' + stockData[j + 10] + '</td></tr>';
                }

                var dealEntity = stockData[25];
                if (dealEntity && dealEntity != "-") {
                    var dealList = dealEntity.split("|");

                    var count = dealList.length >= 9 ? dealList.length - 9 : 0;

                    for (var k = dealList.length - 1; k >= count; k--) {
                        var itemList = dealList[k].split("~");
                        var arrow = itemList[3] == "-1" ? "↓" : itemList[3] == "1" ? "↑" : "";
                        var arrowColor = itemList[3] == "-1" ? "green" : itemList[3] == "1" ? "red" : "";
                        var dataColor = "";
                        if (stockData[3] < itemList[1]) {
                            dataColor = "red";
                        } else if (stockData[3] > itemList[1]) {
                            dataColor = "green";
                        }
                        html_deal += '<tr><td>' + itemList[0] + '</td><td class="' + dataColor + '">' + (itemList[1] || "-") + '</td>'
                            + '<td class="chjl ' + arrowColor + '">' + (itemList[2] || "-") + arrow + '</td></tr>';
                    }
                }
                else {
                    html_deal += "<tr><td>暂无数据</td></tr>";
                }

                html_sell += "</tbody>";
                html_buy += "</tbody>";
                html_deal += "</tbody>";

                $("#sell_table").html(html_sell);
                $("#buy_table").html(html_buy);
                $("#deal_table").html(html_deal);
            }
        });
    }

    // 行情图片事件绑定
    baseStock.prototype.bindChartImgEvent = function (options) {
        var self;
        var defualtUrls = {
            "url_r": "//webquotepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da",
            //"url_k": "//webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da"
            "url_k": (window.stockEnity.MktNum == '90' || window.stockEnity.MktNum == '105'|| window.stockEnity.MktNum == '106' || window.stockEnity.MktNum == '107') ? "//webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da" : "//pifm.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx?token=44c9d251add88e27b65ed86506f6e5da"
        };

        var _options = $.extend(defualtUrls, options);
        return {
            unitWidth: -6,
            stockId: this.stockId,
            bindEvent: function () {
                if (!self) self = this;
                $("#pictit span").click(function () {
                    $("#pictit span").removeClass("cur");
                    $(this).addClass("cur");
                    self.changeImg("k");
                });

                $("#zkeya li").click(function () {
                    $("#zkeya li").removeClass("at");
                    $(this).addClass("at");
                    self.changeImg("k");
                });

                $("#zkeyb li").click(function () {
                    $("#zkeyb li").removeClass("at");
                    $("#zkeyc li").removeClass("at");
                    $(this).addClass("at");
                    $("#zkeyc li[type=" + $(this).attr("type") + "]").addClass("at");
                    self.changeImg("k");
                });

                $("#zkeyc li").click(function () {
                    $("#zkeyb li").removeClass("at");
                    $("#zkeyc li").removeClass("at");
                    $(this).addClass("at");
                    $("#zkeyb li[type=\"" + $(this).attr("type") + "\"]").addClass("at");
                    self.changeImg("k");
                });

                $("#picklc").click(function () {
                    if (self.unitWidth <= -8) {
                        return;
                    }
                    self.unitWidth = self.unitWidth - 1;
                    self.changeImg("k");
                });

                $("#picksd").click(function () {
                    if (self.unitWidth >= 0) {
                        return;
                    }
                    self.unitWidth = self.unitWidth + 1;
                    self.changeImg("k");
                });

                //分时
                $("#actTab1 span").click(function () {
                    $("#actTab1 span").removeClass("cur");
                    $(this).addClass("cur");
                    self.changeImg("r");

                });
            },
            changeImg: function (type) {
                if (!self) self = this;
                if (typeof type === "string") {
                    switch (type) {
                        case "r":
                            var rtype = $("#actTab1 .cur").attr("type");

                            var params = {}
                            if (window.stockEnity.MktNum == '90' || window.stockEnity.MktNum == '105' || window.stockEnity.MktNum == '106' || window.stockEnity.MktNum == '107') {
                                params = {
                                    nid: stockEnity.UnifiedID ? stockEnity.UnifiedID : (stockEnity.MktNum + '.' + stockEnity.stockCode),
                                    type: rtype === "M0" ? "" : rtype === "PQ" ? "" : rtype || "r",
                                    imageType: rtype === "PQ" ? "rc" : (rtype === "M0" || !rtype) ? "rf" : "t"
                                }
                            } else {
                                params = {
                                    id: self.stockId,
                                    type: rtype === "M0" ? "" : rtype === "PQ" ? "" : rtype || "r",
                                    imageType: rtype === "PQ" ? "rc" : (rtype === "M0" || !rtype) ? "rf" : "t"
                                }

                            }
                            loadimg("picr", 276, 578, _options.url_r,params, "//hqres.eastmoney.com/EMQuote_Lib/img/picrnotfund.gif");
                            break;
                        case "k":
                            // K图
                            var params2 = {}
                            if (window.stockEnity.MktNum == '90' || window.stockEnity.MktNum == '105' || window.stockEnity.MktNum == '106' || window.stockEnity.MktNum == '107') {
                                params2 = {
                                    nid: stockEnity.UnifiedID ? stockEnity.UnifiedID : (stockEnity.MktNum + '.' + stockEnity.stockCode),
                                    type: $("#pictit .cur").attr("type"),
                                    unitWidth: self.unitWidth,
                                    ef: $("#zkeya .at").attr("type") ? $("#zkeya .at").attr("type") : "",
                                    formula: $("#zkeyb .at").attr("type"),
                                    imageType: "KXL"
                                }
                            } else {
                                params2 = {
                                    id: self.stockId,
                                    type: $("#pictit .cur").attr("type"),
                                    unitWidth: self.unitWidth,
                                    ef: $("#zkeya .at").attr("type") ? $("#zkeya .at").attr("type") : "",
                                    formula: $("#zkeyb .at").attr("type"),
                                    imageType: "KXL"
                                }

                            }
                            loadimg("pick", 365, 520, _options.url_k, params2, "//hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif");
                            break;
                        default: break;
                    }
                }
                else {
                    self.changeImg("r");
                    self.changeImg("k");
                }

                function loadimg(container, height, width, url, data, errurl) {
                    var $container = $("#" + container);
                    if ($container.length === 0) return false;
                    $.imgLoader({
                        url: url,
                        data: data,
                        height: height,
                        width: width,
                        success: function (image) {
                            $container.html(image);
                        },
                        error: function (image) {
                            $container.html($(image).attr("src", errurl || "//hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif"));
                        }
                    });
                }
            }
        };
    }

    // 股市直播
    baseStock.prototype.stockBroadcast = function () {

        var stockBroadcast = {

            init: function () {
                var self = this;
                self.setNews();
                $("#kx_fontsize").click(function () {
                    if ($(".kx_list").hasClass("kx_fz14")) {
                        $(".kx_list").removeClass("kx_fz14");
                        $(this).html("大字+");
                    } else {
                        $(".kx_list").addClass("kx_fz14");
                        $(this).html("小字-");
                    }
                });
                $("#kx_refresh").off()
                $("#kx_refresh").click(function () {
                    self.setNews();
                });
            },
            setNews: function () {
                var url = "http://newsinfo.eastmoney.com/kuaixun/v2/api/list?column=zhiboall&limit=20";
                common.jsonP(url, function (json) {
                    if (json.rc == 1) {
                        //上方的直播
                        var random = parseInt(Math.random() * 20);
                        if (json.news[random]) {
                            var item = json.news[random];
                            $("#ScrollMIIRBox .dt").html(item.showtime);

                            $("#ScrollMIIRBox .t").html('<a href="' + item.url_unique + '" target="_blank">' + item.title + '</a>');
                        }

                        var html = "";
                        for (var i = 0; i < json.news.length; i++) {
                            var itemNews = json.news[i];
                            var time = itemNews.showtime.split(" ")[1];
                            html += '<li><span class="kx_itime">' + time + '</span>' +
                                '<span class="kx_itime_end">|</span>' +
                                '<span class="bd_i_txt">' +
                                '<a href="' + itemNews.url_unique + '" target="_blank">' +
                                itemNews.title + '&nbsp;[点击查看全文]</a></span></li>';
                        }

                        $("#stockBroadcast").html(html);
                    }
                }, null);
            }
        }
        return stockBroadcast;
    }

    // 热门股吧
    baseStock.prototype.setHotGuba = function (length) {
        var base = this
        var url = $("#GetHotGuba").val();
        $.ajax({
            type: "GET",
            url: url,
            data: { count: length },
            dataType: "json",
            success: function (data) {
                if (data.success) {
                    var codeList = data.data.join(",");
                    var arr = []
                    for (var i = 0; i < data.data.length; i++) {
                        var market = data.data[i].slice(6, 7)
                        var code = data.data[i].slice(0, 6)
                        arr.push((market == 1 ? 1 : 0) + '.' + code)
                    }
                    var codestr = arr.join(",")
                    var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
                    base.bindDataTemplatenew(url, "hotGuba", "guba");

                }
            }
        });
    }

    // JS行情图
    baseStock.prototype.setChart = function () {
        var setChart = {
            init: function () {
                this.bindEvent();
                this.set();
            },
            bindEvent: function () {
                $("#image_show").click(function () {
                    $("#h5_show").removeClass("cur");
                    $(this).addClass("cur");
                    $("#img_container").show();
                    $("#h5_container").hide();
                });
                $("#h5_show").click(function () {
                    $("#image_show").removeClass("cur");
                    $(this).addClass("cur");
                    $("#img_container").hide();
                    $("#h5_container").show();
                });
            },
            set: function () {
                emChart.initial();
            }
        }
        return setChart;
    }

    //列表模板
    baseStock.prototype.bindDataTemplate = function (url, containerId, type) {
        var html = "";
        common.jsonP(url, function (json) {
            if (json.length == 0) {
                return;
            }

            if (type.indexOf("NO") >= 0) {
                html += '<tbody>';
            } else {
                html += '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>';
            }

            for (var i = 0; i < json.length; i++) {
                if (!json[i]) continue;
                var itemlist = json[i].split(",");
                var color = common.getColor(itemlist[4]);

                var stockCode = itemlist[1];
                var stockName = itemlist[2];

                if (common.getByteLen(stockName) > 12) {
                    //判断中英文
                    if (stockName.match(/[^\x00-\xff]/ig) != null) {
                        stockName = stockName.substring(0, 6) + "..";
                    } else {
                        stockName = stockName.substring(0, 12) + "..";
                    }
                }

                var stockUrl = "http://quote.eastmoney.com";

                if (type == "global") {
                    if (stockName == "上证指数" || stockName == "深证成指") {
                        stockUrl += "/zs" + stockCode + ".html";
                    } else if (stockName == "恒生指数") {
                        stockUrl += "/hk/zs110000.html";
                    } else {
                        stockUrl += "/gb/zs" + stockCode + ".html";
                    }
                }

                if (type == "AB" || type == "AB_NO") {
                    if (itemlist[1].indexOf("BK") >= 0) {
                        stockUrl += "/web/" + stockCode + "1.html";
                    } else if (itemlist[0] == "1") {
                        stockUrl += "/sh" + stockCode + ".html";
                    } else if (itemlist[0] == "2") {
                        stockUrl += "/sz" + stockCode + ".html";
                    }
                }

                if (type == "guba") {
                    stockUrl = "http://guba.eastmoney.com/list," + stockCode + ".html";
                    stockName += "吧";
                }

                if (type == "globalFuture") {
                    stockUrl += "/globalfuture/" + stockCode + ".html";
                }

                if (type == "forex") {
                    if (stockCode == "DINI") {
                        stockUrl += "/qihuo/dini.html";
                    } else {
                        stockUrl += "/forex/" + stockCode + ".html";
                    }
                }

                if (type == "hk") {
                    stockUrl += "/hk/" + stockCode + ".html";
                }

                if (type == "index" || type == "index_NO") {
                    stockUrl += "/zs" + stockCode + ".html";
                }

                if (type == "us") {
                    stockUrl += "/us/" + stockCode + ".html";
                }

                if (type == "xh") {
                    stockUrl = "";
                    //stockUrl += "/web/" + stockCode + "8.html";
                }

                if (type == "gzqh") {
                    stockUrl += "/gzqh/" + stockCode + ".html";
                }

                if (type == "future") {
                    //判断是否为股指期货
                    if (itemlist[0] == "_ITFFO") {
                        stockUrl += "/gzqh/" + stockCode + ".html";
                    } else {
                        stockUrl += "/qihuo/" + stockCode + ".html";
                    }
                }
                html += '<tr>'
                    + '<td>'
                    + (stockUrl ? ('<a href="' + stockUrl + '" target="_blank" title="' + itemlist[2] + '">' + stockName + '</a>') : stockName)
                    + '</td>'
                    + '<td class="' + color + '">' + itemlist[3] + '</td>'
                    + '<td class="' + color + '">' + itemlist[4] + '</td>'
                    + '</td></tr>';
            }
            html += "</tbody>";
            $("#" + containerId).html(html);
        });

    }

    //列表模板接新行情
    baseStock.prototype.bindDataTemplatenew = function (url, containerId, type) {
        var html = "";
        $.ajax({
            type: "GET",
            url: url,
            data: null,
            dataType: 'jsonp',
            jsonp: 'cb',
            success: function (res) {
                var data = res.data.diff;
                var json = []
                if (type == 'AB' || type == 'guba') {
                    for (var i = 0; i < data.length; i++) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(2) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                } else if (type == 'ZDF') {
                    for (var i in data) {
                        var stritem = data[i].f13 + ',' + data[i].f12 + ',' + data[i].f14 + ',' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(2) + ',' + ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(data[i].f152) + '%')
                        json.push(stritem)
                    }
                }

                var html = '<tbody><tr><th>名称</th><th>最新价</th><th>涨跌幅</th></tr>';
                for (var i = 0; i < json.length; i++) {
                    var itemlist = json[i].split(",");
                    var color = common.getColor(itemlist[4]);
                    var stockCode = itemlist[1];
                    var stockName = itemlist[2];
                    var stockUrl = "http://quote.eastmoney.com";
                    if (type == "AB") {
                        if (itemlist[1].indexOf("BK") >= 0) {
                            stockUrl += "/web/" + stockCode + "1.html";
                        } else if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    } else if (type == "guba") {
                        stockUrl = "http://guba.eastmoney.com/list," + stockCode + ".html";
                        stockName += "吧";
                    } else if (type == "ZDF") {
                        if (itemlist[0] == "1") {
                            stockUrl += "/sh" + stockCode + ".html";
                        } else if (itemlist[0] == "0") {
                            stockUrl += "/sz" + stockCode + ".html";
                        }
                    }
                    html += '<tr>'
                        + '<td>'
                        + (stockUrl ? ('<a href="' + stockUrl + '" target="_blank" title="' + itemlist[2] + '">' + stockName + '</a>') : stockName)
                        + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[3]) + '</td>'
                        + '<td class="' + color + '">' + (itemlist[3] == 0 ? '-' : itemlist[4]) + '</td>'
                        + '</td></tr>';
                }

                html += "</tbody>";
                $("#" + containerId).html(html);

            }
        });
    }

    // 获取文章列表
    baseStock.prototype.getArticle = function (articleNum, containerId) {
        var url = $("#GetArticle").val();
        $.ajax({
            type: "GET",
            url: url,
            data: {
                articleNum: articleNum
            },
            dataType: "json",
            success: function (data) {
                if (data && data.success) {
                    if (data.data.length >= 5) {
                        var html = "";
                        for (var i = 0; i < data.data.length; i++) {
                            var item = data.data[i];

                            html += '<li class="clearfix">' +
                                '<a href="' + item.url + '" target="_blank" class="fl">' + item.title + '</a>' +
                                '<i class="fr">' + item.date + '</i></li>';
                        }
                        $("#" + containerId).html(html);
                    }
                }
            }
        });
    }

    //自选股
    baseStock.prototype.getFavouriteStock = function (num) {
        var count = num || 5;
        var base = this;
        var pi = common.getCookie("pi");
        var initlist = "300059,000016,000017,300268,000001,000002,000005,000006,000008";
        var emhq_stock = common.getCookie("emhq_stock");
        if (emhq_stock) {
            initlist = emhq_stock;
        }
        var itemlist = initlist.split(",");
        var stockList = new Array();
        for (var i = 0; i < itemlist.length; i++) {
            stockList.push(itemlist[i] + common.getMarketCode(itemlist[i]));
        }
        if (pi) {
            if (pi.split(';').length >= 3) {
                var name = pi.split(';')[2];
                if (!/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) {
                    $.getScript("https://myfavor.eastmoney.com/mystock?f=gsaandcheck&sc=" + base.code + "|0" + base.market + "|01&c=" + count + "&var=favorStock", function () {
                        var allstocklist = [];
                        if (favorStock.result == "1") {
                            var sl = favorStock.data.list.split(',');
                            for (var i = 0; i < sl.length; i++) {
                                var item = sl[i].split('|');
                                var stockId = item[0] + common.getMarketCode(item[0]);
                                allstocklist.push(stockId);
                            }
                            allstocklist = allstocklist.concat(stockList).unique().slice(0, count);
                            var url = "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + allstocklist.join(',') + "&sty=MPNSBAS&st=z&p=1&ps=" + count + "&cb=?&js=([(x)])&token=7bc05d0d4c3c22ef9fca8c2a912d779c";
                            base.bindDataTemplate(url, "favorTable", "AB");
                        }
                    });
                }
            }
        } else {
            var url = "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=" + stockList.join(",") + "&sty=MPNSBAS&st=c&sr=-1&p=1&ps=" + count + "&cb=?&js=([(x)])&token=7bc05d0d4c3c22ef9fca8c2a912d779c";
            base.bindDataTemplate(url, "favorTable", "AB");
        }
    }


    //自选股 接新行情 zxw
    baseStock.prototype.getFavouriteStocknew = function (num) {
        var count = num || 5;
        var base = this;
        var pi = common.getCookie("pi");
        var initlist = "0.300059,0.000016,0.000017,0.300268,0.000001,0.000002,0.000005,0.000006,0.000008";
        var emhq_stock = common.getCookie("emhq_stock");
        if (emhq_stock) {
            initlist = emhq_stock;
        }
        var itemlist = initlist.split(",");
        var stockList = new Array();
        for (var i = 0; i < itemlist.length; i++) {
            stockList.push(itemlist[i]);
        }
        if (pi) {
            if (pi.split(';').length >= 3) {
                var name = pi.split(';')[2];
                if (!/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) {
                    $.getScript("https://myfavor.eastmoney.com/mystock?f=gsaandcheck&sc=" + base.code + "|0" + base.market + "|01&c=" + count + "&var=favorStock", function () {
                        var allstocklist = [];
                        if (favorStock.result == "1") {
                            var sl = favorStock.data.list.split(',');
                            for (var i = 0; i < sl.length; i++) {
                                var item = sl[i].split('|');
                                var stockId = (common.getMarketCode(item[0]) == 2 ? 0 : common.getMarketCode(item[0])) + '.' + item[0]
                                allstocklist.push(stockId);
                            }
                            allstocklist = allstocklist.concat(stockList).unique().slice(0, count);
                            var codestr = allstocklist.join(",")
                            var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
                            base.bindDataTemplatenew(url, "favorTable", "AB");

                        }
                    });
                }
            }
        } else {
            var codestr = stockList.slice(0, count).join(",")
            var url = base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
            base.bindDataTemplatenew(url, "favorTable", "AB");
        }
    }

//     return baseStock;
// });

module.exports = baseStock
