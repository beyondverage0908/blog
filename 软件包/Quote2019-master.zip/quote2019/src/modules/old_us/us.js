// require(["baseStock", "common", "template"], function (baseStock, common, template) {

var baseStock = require('./basestock')
var common = require('../old_b/common')
var template = require('../old_b/template')

    function Usstock() {
        baseStock.call(this);  //第二次调用基类的构造函数
        this.stockZjlType = "";
    }

    Usstock.prototype = new baseStock();
    var instance = new Usstock();

    Usstock.prototype.baseUrl = 'http://push2.eastmoney.com'
    Usstock.prototype.ut = 'bd1d9ddb04089700cf9c27f6f7426281'


    // 热门美股吧
    Usstock.prototype.setHotGubaList = function (len) {
        var _len = len || 15;
        var url = "http://gubawebapi.eastmoney.com/v3/read/Guba/HotGuba.aspx?type=4&deviceid=900150983cd24fb0d6963f7d28e17f72&product=EastMoney&plat=web";
        $.ajax({
            url: url,
            dataType: "jsonp",
            data: { version: 100 },
            jsonpCallback: "this.hotGubaCallback(" + _len + ")"
        });

    }

    // 热门美股吧回调
    window.hotGubaCallback = function (len) {  //zxw
        var _len = len;
        function render(json) {
            var ids = [];
            if (json.rc === 1) {
                for (var i = 0; i < json.re.length; i++) {
                    var code = json.re[i].stockbar_code;
                    if (!code) continue;
                    if (json.re[i].stockbar_market.split(".")[1] == 'nyse') {
                        ids.push(106 + '.' + code.substring(2, code.length));
                    } else {
                        ids.push(105 + '.' + code.substring(2, code.length));
                    }
                }
                var idList = ids.join(",");

                var auto = $.dataAutoRefresh({
                    url: instance.baseUrl + '/api/qt/ulist.np/get?secids=' + idList + "&ut=" + instance.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152',
                    data: null,
                    dataType: 'jsonp',
                    jsonp: 'cb',
                    success: function (json) {
                        var data = json.data.diff
                        var list = [];
                        if (data && data instanceof Array) {
                            for (var i = 0; i < data.length; i++) {
                                if (i >= _len) continue;
                                list.push({
                                    name: common.cutstr(data[i].f14, 8),
                                    title: data[i].f14,
                                    close: data[i].f2 == 0 ? '-' : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                                    changePercent: data[i].f2 == 0 ? '-' : ((data[i].f3 / Math.pow(10, data[i].f152)).toFixed(2) + '%'),
                                    link: "//guba.eastmoney.com/list,us" + data[i].f12 + ".html",
                                    color: common.getColor(data[i].f3)
                                });
                            }
                            var html = template("tmp_name_close_cp", { list: list });
                            $("#hotGuba tbody").html(html);
                        }
                    }
                });
                auto.start();
            }
        }
        return render;
    }

    // 美股成交明细 zxw
    Usstock.prototype.bindDealDetail = function () {
        var _url = this.baseUrl + "/api/qt/stock/details/get?secid=" + stockEnity.UnifiedID + "&ut=" + this.ut + "&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55&pos=-13"
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data
                if (!data.details.length || !data.prePrice) return;
                var list = [];
                var details = data.details
                for (var i = 0; i < details.length; i++) {

                    if (i > 0) {
                        var itemslast = details[i - 1].split(",")
                        var items = details[i].split(",");
                        var dir = (items[1] > itemslast[1] ? "↑" : items[1] == itemslast[1] ? " " : "↓")
                        var listitem = {
                            time: items[0],
                            close: items[1],
                            closeCss: common.getColor(items[1] - data.prePrice),
                            volumn: items[2],
                            dir: dir,
                            volumnCss: items[4] == 0 ? lastcolor : (items[4] == 2 ? (items[1] * items[2] > 200000 ? 'purple' : 'red') : (items[1] * items[2] > 200000 ? 'blue' : 'green')),
                            arrowcolor: items[1] > itemslast[1] ? "red" : items[1] == itemslast[1] ? " " : "green"
                        }
                        list.push(listitem);

                        var lastcolor = listitem.volumnCss
                    }
                }
                list = list.reverse()
                var html = template("tmp_deal_detail", { list: list });
                $("#deal_detail tbody").html(html);
            }
        });
    }

    // 中概股行情 zxw
    Usstock.prototype.bindChineseCompanyQuote = function () {
        var _url = this.baseUrl + "/api/qt/clist/get?ut=" + this.ut + "&pi=0&pz=12&po=1&fs=b:MK0201&fid=f3&fields=f1,f2,f3,f12,f14"
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data.diff
                var list = []
                for (var i in data) {
                    list.push({
                        title: data[i].f14,
                        name: common.cutstr(data[i].f14, 8),
                        close: (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                        changePercent: (data[i].f3 / 100).toFixed(2) + '%',
                        color: common.getColor(data[i].f3),
                        link: "//quote.eastmoney.com/us/" + data[i].f12 + ".html"
                    })
                }
                var html = template("tmp_name_close_cp", { list: list });
                $("#zgghq tbody").html(html);
            }
        });
    }

    // 互联网中国行情 zxw
    Usstock.prototype.bindChineseNetworkQuote = function () {
        var _url = this.baseUrl + "/api/qt/clist/get?ut=" + this.ut + "&pi=0&pz=12&po=1&fs=b:MK0202&fid=f3&fields=f1,f2,f3,f12,f14"
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data.diff
                var list = []
                for (var i in data) {
                    list.push({
                        title: data[i].f14,
                        name: common.cutstr(data[i].f14, 8),
                        close: (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                        changePercent: (data[i].f3 / 100).toFixed(2) + '%',
                        color: common.getColor(data[i].f3),
                        link: "//quote.eastmoney.com/us/" + data[i].f12 + ".html"
                    })
                }
                var html = template("tmp_name_close_cp", { list: list });
                $("#hlwzg tbody").html(html);
            }
        });
    }

    // 知名美股行情 zxw
    Usstock.prototype.bindFamoueQuote = function () {
        var _url = this.baseUrl + "/api/qt/clist/get?ut=" + this.ut + "&pi=0&pz=6&po=1&fs=b:MK0001&fid=f3&fields=f1,f2,f3,f12,f14"
        $.ajax({
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data.diff
                var list = []
                for (var i in data) {
                    list.push({
                        title: data[i].f14,
                        name: common.cutstr(data[i].f14, 8),
                        close: (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                        changePercent: (data[i].f3 / 100).toFixed(2) + '%',
                        color: common.getColor(data[i].f3),
                        link: "//quote.eastmoney.com/us/" + data[i].f12 + ".html"
                    })
                }
                var html = template("tmp_name_close_cp", { list: list });
                $("#famous_quote tbody").html(html);
            }
        });
    }

    //全屏的方法
    Usstock.prototype.fullScreenFun = function () {
        // ie9以下隐藏全屏按钮
        if (document.all && !document.addEventListener) {
            $(".fullScreenBtn").hide();

            //隐藏全屏
            $("#beta-text-link1").hide();
            $("#beta-text-link2").hide();

            //并阻止ie8以下的点击事件问题
            $("#picrbox1 a").attr('disabled', 'true');
            $("#picrbox1 a").attr('href', '#');
            $("#picrbox1 a").css('cursor', 'default');
            $("#picrbox1 img").css('cursor', 'default');
            $("#picrbox2 a").attr('disabled', 'true');
            $("#picrbox2 a").attr('href', '#');
            $("#picrbox2 a").css('cursor', 'default');
            $("#picrbox2 img").css('cursor', 'default');


            window.location.hash = "";
        }
        var type = "";
        var id = stockEnity.UnifiedID
        var url = "//quote.eastmoney.com/basic/full.html?mcid=" + id + "&type=r";
        var $context = $('<div class="fs-wrapper"><div class= "mark-box"></div><div class="full-box"><span class="full-close">×</span><iframe src = "' + url + '" style="height:98%;width:99%;min-height:600px"></iframe></div ></div>');
        $(".fullScreenBtn").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        if (location.href.indexOf("#fullScreenChart") > 0) {
            $(".fullScreenBtn").trigger("click");
        }
    }

    // 事件绑定
    function bindEvent() {
        $(".tabLi").mouseenter(function () {
            $(this).parent().find("li").removeClass("cur");
            $(this).addClass("cur");

            var index = $(this).index();
            if ($(this).parents(".tabExchange").length > 0) {
                $(this).parents(".tabExchange").find(".more").hide();
                $(this).parents(".tabExchange").find(".more").eq(index).show();
                $(this).parents(".tabExchange").find(".info_list").removeClass("active");
                $(this).parents(".tabExchange").find(".info_list").eq(index).addClass("active");
            } else {
                $(this).parents(".side_box").find(".info_list").removeClass("active");
                $(this).parents(".side_box").find(".info_list").eq(index).addClass("active");
            }

        });

        $(".rank_date li").click(function () {
            $(".rank_date li").removeClass("cur");
            $(this).addClass("cur");
            instance.stockZjlType = $(this).attr("value") || "";
            instance.BindStockZjl();
        });
        $("#RefPR").click(function (e) {
            location.reload();
        });
    }
    var imgevt = instance.bindChartImgEvent();
    init();

    setInterval(function () {
        refresh();
    }, 20 * 1000);

    setInterval(function () {
        refreshfscj(); //分时成交每秒刷新
    }, 20 * 1000);

    function refreshfscj() {
        instance.bindDealDetail();
    }

    //我的自选
    instance.getFavouriteStocknew(9);


    function refresh() {
        imgevt.changeImg();
        // instance.getFavouriteStocknew(9);
        instance.bindChineseCompanyQuote();
        instance.bindChineseNetworkQuote();
        instance.bindFamoueQuote();
    }

    //增加数据格式判断
    function myformatNum(num) {
        if (num == 0) {
            return num
        }
        if (num == undefined || num == '' || isNaN(num) || num == '-') {
            return '-';
        }
    
        var hz = '';
        var num2 = '';
        if (num >= 10000000000000) {
            num = num / 1000000000000;
            hz = '万亿';
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 1000000000000  && num < 10000000000000) {
            num = num / 1000000000000;
            hz = '万亿';
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 100000000000 && num < 1000000000000) {
            num = num / 100000000;
            hz = '亿';
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 10000000000 && num < 100000000000) {
            num = num / 100000000;
            hz = '亿';
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 100000000 && num < 10000000000) {
            num = num / 100000000;
            hz = '亿';
            num2 =  parseFloat(num).toFixed(2);
        }
        else if (num >= 10000000 && num < 100000000) {
            num = num / 10000;
            hz = '万';
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 1000000 && num < 10000000) {
            num = num / 10000;
            hz = '万';
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 10000 && num < 1000000) {
            num = num / 10000;
            hz = '万';
            num2 =  parseFloat(num).toFixed(2);
        }
        else if (num >= 1000 && num < 10000) {
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 100 && num < 1000) {
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 1 && num < 100) {
            num2 = parseFloat(num).toFixed(2);
        }
        else if (num >= 0 && num < 1) {
            num2 = parseFloat(num).toFixed(3);
        } 
        else if(num <0) {
            num2 = parseFloat(num).toFixed(2);
        }
        else {
            num2 =  parseFloat(num).toFixed(2);
            // return num;
        }
    
        
    
        // if(parseInt(num) >= 1000){ //整数部分超过4位
        //   num2 = num.toFixed(1);
        // }
    
        return num2.toString() + hz;
    }

    function init() {
        bindEvent();
        instance.bindStockNews({
            api: {
                url: "http://cmsdataapi.eastmoney.com/api/StockNews/QuoteNews?marketType=7&stockCode=" + stockEnity.stockCode + "&stockName=" + encodeURIComponent(stockEnity.stockName) + "&count=5&token=4f1862fc3b5e77c150a2b985b12db0fd",
                data: {}
            }
        });
        instance.stockBroadcast().init();

        function onChangeDataRender($dom, item, settings) {
            if (item != 0 && item != "-") {
                if (item.isPositive()) {
                    $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");
                } else {
                    $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
                }
            } else {
                $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
            }
        }

        //获取基本行情 zxw
        instance.loadQuoteData({
            ajax: {
                url: instance.baseUrl + '/api/qt/stock/get?secid=' + stockEnity.UnifiedID + "&ut=" + instance.ut + "&fields=f43,f169,f170,f46,f60,f84,f116,f44,f45,f171,f126,f47,f48,f168,f164,f49,f161,f55,f92,f59,f152,f167,f50,f86,f71,f172",
                data: {

                },
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get'
            },
            dataResolver: function (json) {
                //判断若是国内登录状态 则刷新
                if(getLoginStatus() && json && json.lt !==2) {
                    // console.log('我的自选刷新')
                    instance.getFavouriteStocknew(9);
                }

                var data = json["data"]
                 //若最新价出现大于 9位数  字大小调整为25px
                 if((data.f43 / Math.pow(10, data.f59)).toFixed(3) >= 100000.000) {
                    $(".quote_brief .brief_left .brief_topP").css("font-size", "25px");
                 }

                // console.log(data.f55.toFixed(2))
                // myformatNum(111);
                // console.log(myformatNum(data.f55.toFixed(2)));

                var shouyi = myformatNum(data.f55.toFixed(2));
                var jingzc = myformatNum(data.f92.toFixed(2));
                var zsz = myformatNum(data.f116);
                var zgb = myformatNum(data.f84);



                var arr = []
                arr.push(data.f43 == 0 ? '-' : (data.f43 / Math.pow(10, data.f59)).toFixed(3))//0最新价
                arr.push(data.f43 == 0 ? '-' : (data.f44 / Math.pow(10, data.f59)).toFixed(3))//1最高价
                arr.push(data.f43 == 0 ? '-' : (data.f45 / Math.pow(10, data.f59)).toFixed(3))//2最低价
                arr.push(data.f43 == 0 ? '-' : (data.f46 / Math.pow(10, data.f59)).toFixed(3))//3开盘价
                arr.push(data.f43 == 0 ? '-' : data.f47)//4成交量
                arr.push(data.f43 == 0 ? '-' : data.f48)//5成交额(f48)
                arr.push(data.f43 == 0 ? '-' : data.f49)//6外盘
                arr.push(shouyi)//7每股收益(f55) 
                arr.push(data.f59)// 8小数位数(f59)
                arr.push((data.f60 / Math.pow(10, data.f59)).toFixed(3))//9昨收价(f60)
                arr.push(zgb)//10总股本(股)(f84)
                arr.push(jingzc)//11每股净资产(f92)
                arr.push(zsz)//12总市值(f116)
                arr.push(data.f126)//13股息率(f126
                arr.push(data.f152)//14小数位数字段(2)
                arr.push(data.f43 == 0 ? '-' : data.f161)//15内盘(f161)
                arr.push(data.f164 / Math.pow(10, data.f152))//16市盈率(TTM)(f164)
                arr.push(data.f168)//17换手率(f168)
                arr.push(data.f43 == 0 ? '-' : (data.f169 / Math.pow(10, data.f59)).toFixed(3))//18涨跌值(f169) 
                arr.push(data.f43 == 0 ? '-' : data.f170)//19涨跌幅(f170) 
                arr.push(data.f43 == 0 ? '-' : data.f171)//20振幅(f171)
                arr.push(data.f43 == 0 ? '-' : data.f167 / Math.pow(10, data.f152))//21市净率(f167)
                arr.push(data.f43 == 0 ? '-' : data.f50 / Math.pow(10, data.f152))//22量比(f50)
                arr.push(common.formatDate(new Date(data.f86 * 1000), 'yyyy-MM-dd HH:mm:ss'))//23行情时间Unix时间戳，单位秒(f86)
                arr.push(data.f43 == 0 ? '-' : (data.f71 / Math.pow(10, data.f59)).toFixed(3))//24均价(f71)
                return arr;
            },
            fields: [
                {
                    name: "jk", num: 3, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[3]) ? 0 : data[3]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                { name: "zs", num: 9, hasColor: false, NumbericFormat: false },
                {
                    name: "zxj", num: 0, hasColor: true, NumbericFormat: false, blink: true,
                    comparer: function (data) { return isNaN(data[18]) ? 0 : data[18]; }
                },
                {
                    name: "zde", num: 18, hasColor: true, NumbericFormat: false, blink: true,
                    render: onChangeDataRender
                },
                { name: "zdf", num: 19, hasColor: true, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2) +'%'}}", blink: true },
                {
                    name: "zgj", num: 1, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[1]) ? 0 : data[1]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                {
                    name: "zdj", num: 2, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[2]) ? 0 : data[2]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                { name: "cjl", num: 4, hasColor: false, NumbericFormat: true },
                { name: "cje", num: 5, hasColor: false, NumbericFormat: true },
                //{
                //    name: "SellPrice1", num: 30, hasColor: true, NumbericFormat: false,
                //    comparer: function (data) { return (isNaN(data[30]) ? 0 : data[30]) - (isNaN(data[9]) ? 0 : data[9]); }
                //},
                //{ name: "SellVolume1", num: 31, hasColor: false, NumbericFormat: false },
                { name: "BuyOrder", num: 6, hasColor: true, NumbericFormat: true, comparer: 1 },
                { name: "SellOrder", num: 15, hasColor: true, NumbericFormat: true, comparer: -1 },
                { name: "zf", num: 20, hasColor: false, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2)+'%'}}" },
                { name: "hsl", num: 17, hasColor: false, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2)+'%'}}" },
                { name: "pe", num: 16, hasColor: false, NumbericFormat: false },
                { name: "sjl", num: 21, hasColor: false, NumbericFormat: false },
                { name: "mgsy", num: 7, hasColor: false, NumbericFormat: false },
                { name: "mgjzc", num: 11, hasColor: false, NumbericFormat: false },
                { name: "roe", num: 20, hasColor: false, NumbericFormat: false },//11111111111111111
                { name: "zgb", num: 10, hasColor: false, NumbericFormat: false },
                { name: "zsz", num: 12, hasColor: false, NumbericFormat: false },
                { name: "gxl", num: 13, hasColor: false, NumbericFormat: false },
                //{
                //    name: "BuyPrice1", num: 23, hasColor: true, NumbericFormat: false,
                //    comparer: function (data) { return (isNaN(data[23]) ? 0 : data[23]) - (isNaN(data[7]) ? 0 : data[7]); }
                //},
                //{ name: "BuyVolume1", num: 24, hasColor: false, NumbericFormat: false },
                { name: "lb", num: 22, hasColor: false, NumbericFormat: false },
                { name: "yl", num: 26, hasColor: false, NumbericFormat: false },//111111111111111
                { name: "tb", num: 27, hasColor: false, NumbericFormat: true },//1111111111111
                { name: "update", num: 23, hasColor: false, NumbericFormat: false, template: "{{data}}" },
                {
                    name: "jj", num: 24, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[24]) ? 0 : data[24]) - (isNaN(data[9]) ? 0 : data[9]); }
                }
                //{ name: "ltgb", num: 32, hasColor: false, NumbericFormat: true },
                //{ name: "ltsz", num: 33, hasColor: false, NumbericFormat: true } //总市值总股本不对，暂时去掉
            ]
        });
        imgevt.bindEvent();
        //guba.init("gubalisttable", Usstock.prototype.gubaCode, { listcount: 12, titlecut: 42 });
        instance.setHotGubaList(15);
        refresh();
        refreshfscj();
        // instance.fullScreenFun();
    }

    
    //新增 加自选的方法
    function fullScreenFun() {
        if (document.all && !document.addEventListener) {
            $(".fullScreenBtn").hide();

            //隐藏全屏
            $("#beta-text-link1").hide();
            $("#beta-text-link2").hide();

            //并阻止ie8以下的点击事件问题
            $("#picrbox1 a").attr('disabled', 'true');
            $("#picrbox1 a").attr('href', '#');
            $("#picrbox1 a").css('cursor', 'default');
            $("#picrbox1 img").css('cursor', 'default');
            $("#picrbox2 a").attr('disabled', 'true');
            $("#picrbox2 a").attr('href', '#');
            $("#picrbox2 a").css('cursor', 'default');
            $("#picrbox2 img").css('cursor', 'default');


            window.location.hash = "";
        }
        // ie9以下隐藏全屏按钮
        if (document.all && !document.addEventListener) {
            $(".fullScreenBtn").hide();
            window.location.hash = "";
        }else {
            $(".fullScreenBtn").show();
       
        
        var id = stockEnity.MktNum + "." + stockEnity.stockCode
        var url = "//quote.eastmoney.com/basic/full.html?mcid=" + id + "&type=r";
        var $context = $('<div class="fs-wrapper"><div class= "mark-box"></div><div class="full-box"><span class="full-close">×</span><iframe src = "' + url + '" style="height:98%;width:99%"></iframe></div ></div>');
        $(".fullScreenBtn").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        if (location.href.indexOf("#fullScreenChart") > 0) {
            $(".fullScreenBtn").trigger("click");
        }

        //增加 点击图片 跳转全屏图
        $("#picr").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });

        //增加点击 k线图 跳转全屏图
        $("#pick").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        $("#beta-text-link1").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        $("#beta-text-link2").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });

    }


    }
    fullScreenFun();

    //新的  加自选
    function newAddzixuan() {
        if(stockEnity.UnifiedID) {
            var mark_code = stockEnity.UnifiedID;
        }

        zixuan_show(mark_code);
        zixuan_add(mark_code);
        zixuan_del(mark_code);
    }
    newAddzixuan();


    function zixuan_show(code) {
        // console.log('自选股 show')
        myShowzixuan(code).then(function (result) {
          // console.info(result)
            // var res = result.data.check;
           
            if(result) {
                $("#addZX1").css("display", "none");
                $("#addZX2").css("display", "false");
            }else {
                $("#addZX1").css("display", "block");
                $("#addZX2").css("display", "none");
            }
        })
        

    }

    function zixuan_add(code) {
        $("#addZX1").click(function() {
            myAddzixuan(code).then(function(res) {

                if(res) {
                    $("#addZX1").css("display", "none");
                    $("#addZX2").css("display", "block");
                }
            })

        })

    }

    function zixuan_del(code) {
        $("#addZX2").click(function() {
            myDelzixuan(code).then(function(res) {
              
                if(res) {
                    $("#addZX1").css("display", "block");
                    $("#addZX2").css("display", "none");
                }
            })
        })

    }


    //加自选
    function myAddzixuan (code) {
        var islogin = getLoginStatus();
        var zxgurl2 = 'http://myfavor1.eastmoney.com/' //f=gsaandcheck
        var zxg2 = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl2 + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp:'cb'
                });
            }
        }

        return zxg2.data({
            f: 'asz',
            sc: code
        }).then(function(list){
            // console.log(list)
           // return list.result
            if (list.result == 1) {
                return true
            }
            else{
                return false
            }
        })

    }

    //删自选
    function myDelzixuan (code) {
        var islogin = getLoginStatus();
        var zxgurl2 = 'http://myfavor1.eastmoney.com/' //f=gsaandcheck
        var zxg2 = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl2 + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp:'cb'
                });
            }
        }

        return zxg2.data({
            f: 'dsz',
            sc: code
        }).then(function(list){
            // console.log(list)
            //return list.result
            if (list.result == 1) {
                return true
            }
            else{
                return false
            }
        })

    }

    //show自选  get自选
    function myShowzixuan (code) {
      // console.info(111)
        var islogin = getLoginStatus();
        var zxgurl2 = 'http://myfavor1.eastmoney.com/' //f=gsaandcheck
        var zxg2 = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl2 + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp:'cb'
                });
            }
        }

        return zxg2.data({
            f: 'gsaandcheck',
            sc: code
        }).then(function(list){
            // console.log(list)
            //return list.result
            //return false;
            if (list.data.check == 'True') {
                return true
            }
            else{
                return false
            }
        })

    }


    function getLoginStatus() {
        if (cookieGet('ut') && cookieGet('ct') && cookieGet('uidal')) {
            
            return true;
        }
        return false; 
    }


    function cookieGet(name) {
		var xarr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
		if (xarr != null)
			return decodeURIComponent(xarr[2]);
		return null;
	}
// });

