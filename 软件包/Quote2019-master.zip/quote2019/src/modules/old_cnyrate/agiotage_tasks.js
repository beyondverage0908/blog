// define(function(){
    var $l =  $("#tab_wyzgzgp li");
    $l.on("click", function(){
        var $t = $(this);
        var ind = $t.prevAll("li").length;
        $l.removeClass("cur");
        $t.addClass("cur");
    
        var $tb = $t.parents(".wyzgzgp").next().find("tbody");
        $tb.hide().eq(ind).show();
    });
    $("#select3").hover(function(e){
        $(this).children("dl").css("display","block");
    },function(e){
        $(this).children("dl").css("display","none");
    });
    $("#RefPR").on("click", function(){
         window.location.reload();
    });
    
    

    /**
    * @description get cookie with param(cookie.name)
    * @param {string} name
    * @return {string|null} .val
    */
    function getCookie(t) {
        var i = document.cookie;
        t += "=";
        for (var e = 0; e < i.length; ) {
            var s = e + t.length;
            if (i.substring(e, s) == t) {
                var n = i.indexOf(";", s);
                return -1 == n && (n = i.length),
                unescape(i.substring(s, n))
            }
            if (e = i.indexOf(" ", e) + 1,0 === e){
                break;
            }
                
        }
        return null 
    }

    //@description  refresh 
    function GetRandomNum(e, t) {
        var s = t - e;
        var a = Math.random();
        return e + Math.round(a * s);
    }
    $("#refgbauls").on("click", function (){for(var e=$("#gbauls")[0].getElementsByTagName("dl"),t=GetRandomNum(0,e.length-1),s=0;s<e.length;s++)if(s==t){if(e[s].hasChildNodes())for(var a=e[s].childNodes,i=0;i<a.length;i++)if(a[i].hasChildNodes()){var n=a[i].childNodes[0].getElementsByTagName("img")[0];n&&!n.getAttribute("src")&&n.setAttribute("src",n.getAttribute("data-value"))}e[s].style.display=""}else e[s].style.display="none"});
    
    window.hotpersonafp = function hotpersonafp(e, t, s) {
        var a = !1;
        if (getCookie("pi")) {
            var i = getCookie("pi");
            if (i.split(";").length >= 3) {
               
                var n = i.split(";")[2];

                if (/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(n))
                    a = !0; 
                else { 
                    var r = "http://iguba.eastmoney.com/action.aspx?callback=&action=oaddfollowperson&uid2=" + e;
                    var now=new Date();

                    var script = document.createElement('script');
                    script.src = r + "&v=" + now.getDate()+""+now.getHours()+""+now.getMinutes()+"";
                    script.id = 'hotpersonafp';
                    document.getElementsByTagName('head')[0].appendChild(script);

                    function action(t){
                        t.className = "allow",
                        t.innerHTML = "",
                        t.onclick = null;
                        document.getElementsByTagName('head')[0].removeChild(script || document.getElementById('rmb_script'));
                    }

                    if (!!window.ActiveXObject || "ActiveXObject" in window){
                        script.onreadystatechange = function(){
                            
                            if(script.readyState === 'complete' || script.readyState === 'loaded'){
                                action(t)
                            }
                        }
                    }else{
                        $(script).on('load', function(){
                            action(t)
                        })
                    }
                }
            }else{
                
                a = !0;
            }
                
        }else{
            
            a = !0;
        }
        // TODO
        t.className = "allow",
        t.innerHTML = "",
        t.onclick = null;   
        // a && (location.href = "http://guba.eastmoney.com/login.aspx?url=http://quote.eastmoney.com/" + s + ".html");
    }

    //@description  vote
    // var date = new Date();
    // var _date = date.getUTCFullYear() +''+ (date.getUTCMonth() < 9 ? ( 0 + ''+ (date.getUTCMonth() + 1)) : date.getUTCMonth() + 1) + date.getUTCDate();
  
    // var url_vote = 'http://iguba.eastmoney.com/gubaapi/v3/read/Guba/GubaInfo.aspx?code='+ window.stockcode +'&pi=&deviceid=21163A425F7727789381D8356B6068E2&version=180&product=Eastmoney&plat=web&rt=' + _date;
    // $.ajax({type: "get", dataType: "jsonp", jsonpCallback: "callback", url: url_vote}).done(function (data){
    //     var countAgree,countOppose;
 
    //     var sum = parseInt(data.stockbar_look_high_count + data.stockbar_look_low_count, 10);
    //     countAgree = 100 * data.stockbar_look_high_count/sum;
    //     countOppose = 100 - countAgree;
    
    //     $("#ivap").text(countAgree + '%');
    //     $("#ivbp").text(countOppose + '%');
    //     $("#ivra").css("width", countAgree);
    //     $("#ivrb").css("width", countOppose);

    // });
    // window.smivckNew = function smivckNew(e, t, s) {
    //     var a = "";
    //     var i = $('input:radio[name="hqvote"]:checked').val();
    //     if (!i)
    //         return alert("请先选择投票方向！");
    //     getCookie("pi") && (a = getCookie("pi"));
    //     var n = "http://hqstat.eastmoney.com/vote/QuoteGuBaLookUpOrDown.aspx?code=" + e + "&islow=" + i + "&pi=" + a + "&cb=var%20res=[{0}]&&num=1&rt=" + formatm();

    //     //

    // }

    /**
    * @description  logout
    */
    window.dcookies = function dcookies(sName) {
        var date = new Date();
        document.cookie = "dcusername=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserinfo=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcusermingchen=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserpass=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserpubinfo=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserpubs=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuserkeys=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_name=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_info=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_mingchen=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_pass=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_pubinfo=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_pubs=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "dcuser_keys=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "puser_pname=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "puser_pinfo=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "pi=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        window.location.reload();
    } 
// });