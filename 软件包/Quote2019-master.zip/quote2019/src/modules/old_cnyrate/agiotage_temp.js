// define(function(){
	module.exports =  '<div class="exchange clear">' +
            '     <label>所持有货币：</label><p>' +
            '         <select id="c1" name="c1">' +
            '             <option value="US">美元</option>' +
            '             <option value="EUR">欧元</option>' +
            '             <option value="GBP">英镑</option>' +
            '             <option value="AUD">澳元</option>' +
            '             <option value="JPY">日元</option>' +
            '             <option value="CHF">瑞郎</option>' +
            '             <option value="CAD">加元</option>' +
            '             <option value="HKD">港币</option>' +
            '             <option value="USDCNY">人民币</option>' +
            '         </select>' +
            '     </p>' +
            '     <label>兑换的货币：</label><p>' +
            '         <select id="c2" name="c2">' +
            '             <option value="US">美元</option>' +
            '             <option value="EUR">欧元</option>' +
            '             <option value="GBP">英镑</option>' +
            '             <option value="AUD">澳元</option>' +
            '             <option value="JPY">日元</option>' +
            '             <option value="CHF">瑞郎</option>' +
            '             <option value="CAD">加元</option>' +
            '             <option value="HKD">港币</option>' +
            '             <option value="USDCNY">人民币</option>' +
            '         </select>' +
            '     </p>' +
            '     <label>资金额：</label><p><input name="bs" type="text" id="bs" value="100" size="8"></p>' +
            '     <label>兑换后金额：</label><p><input name="res" type="text" id="res" value="100" size="14" readonly="readonly"></p>' +
            ' </div>' +
            ' <div class="btnCalc" ><b id="agiotage_btn">计 算</b></div>'
    ;
// })