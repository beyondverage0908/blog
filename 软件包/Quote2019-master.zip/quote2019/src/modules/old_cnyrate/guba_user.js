// define(['guba_cookie'],function(cookie) {

var cookie = require('./guba_cookie')

	var user = {
		get : function (){
			var cVal = cookie.get("pi");
			if (cVal && cVal != null && cVal != "") {
				var cVals = cVal.split(";");
				return {
					id: cVals[0],
					name: cVals[1],
					nick: cVals[2],
					photo: "http://mp.dfcfw.com/" + cVals[0] + "/48/0"
				};
			} else {
				return null;
			}
		}
	}
// 	return user;
// });

module.exports = user