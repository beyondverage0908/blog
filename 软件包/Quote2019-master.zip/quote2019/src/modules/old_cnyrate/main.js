
    // var _baseurl = document.getElementById("main_script").getAttribute("data-baseurl");
    // require.config({
    //     baseUrl: _baseurl ? _baseurl : "/Scripts",
    //     paths: {
    //         jquery: "http://www.eastmoney.com/js/jquery.min",
    //         agiotage: 'build/agiotage',
    //         agiotage_tasks: 'build/agiotage_tasks',
    //         IOScript: 'build/IOScript',
    //         agiotage_temp: 'build/agiotage_temp',
    //         guba_postbox: 'build/guba_postbox',
    //         guba_user: 'build/guba_user',
    //         guba_text: 'build/guba_text',
    //         guba_cookie: 'build/guba_cookie',
    //         globaltime: "globaltime.min",
    //         template: 'template',
    //         page: 'em.forex.cnyc.min',
    //         suggest: '//emcharts.dfcfw.com/suggest/stocksuggest2017.min'
    //     },
    //     shim: {
    //         'jquery': {
    //             exports: '$'
    //         },
    //         "suggest": {
    //             deps: ["jquery"]
    //         }
    //     }
    // });

    // require(['page', "suggest", 'globaltime'], function (page, suggest2017) {


var _GlobalTime = require('./globaltime.min')
var page = require('./em.forex.cnyc.min')
var agiotage = require('./agiotage')
require('./agiotage_tasks')
var postbox = require('./guba_postbox')
var guba_user = require('./guba_user')

var template = require('./template')

window.template = template

        try {
            var suggest = new suggest2017({
                inputid: "search_box",
                offset: { left: -91, top: 5 },
                shownewtips: true,
                newtipsoffset: { top: -3, left: 0 }
            });
        } catch (e) {
            console.error(e);
        }
        $(document).ready(function () {
            var globalTime = new _GlobalTime("worldtime");
            _GlobalTime.prototype.show = function () {
                var a = this;
                var f = a.Option;
                var b = f.citys.length;
                var l = [], k = [];
                var el = document.getElementById("worldtime").getElementsByTagName("i");
                var date = "";
                var h = function () {
                    var d = a.utils.now() + a.deviation - (3600000 * 8);
                    for (var c = 0; c < b; c++) {
                        var j = a.utils.formatTime(d, f.citys[c].utc);
                        el[c].innerHTML = a.utils.dateFromat(j, f.display);
                    }
                    var bj = a.utils.formatTime(d, f.citys[0].utc);
                    $("#querydate").html("(" + bj.pattern("yyyy-MM-dd EEE HH:mm") + ")");
                    date = j.pattern("yyyy-MM-dd");
                };
                h();
                var g = setInterval(h, 1000);
                document.getElementById("querydate").value = date;
            };

            new page(stockcode).pageInit();
            // require(['agiotage', 'agiotage_tasks'], function (agiotage) {
                agiotage.init();
            // });

            /**
             * @description 股吧发布框
             * @param {Object} postbox 发布框
             */
            // require(['guba_postbox'], function (postbox) {
                postbox.init('sendnew', "waihui");
            // });

            /**
             * @description logout
             * @param {Object} guba_user 用户
             */
            // require(['guba_user'], function (guba_user) {
                if (guba_user.get() !== null) {
                    var thisuser = guba_user.get();
                    $("#loginstate").html("<span class=\"fr f12\">" + thisuser.nick + "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"javascript:void(0);\" onclick=\"dcookies()\">退出</a></span>");
                }
            // });
        });
    // });