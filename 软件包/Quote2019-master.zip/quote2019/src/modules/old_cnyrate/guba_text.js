// define(function() {
	
var text = {
	titleclean : function (txt){
		if( $.trim(txt) == "" ){
			return "";
		}
		var re = /[☆★●◎◆■▲〓◢█◣▌◥◤▓※⊙☂▆【】✪▉▊▋▌︻▏▎▍☀▅]/g;
		return txt.replace(re,"");		
	},
	TxtLeft: function (txt, n) {
		if( txt == null || txt == "" ){
			return "";
		}
		var thislength = 0;
		for (var i = 0; i < txt.length; i++) {
			if (txt.charCodeAt(i) > 255) {
				thislength += 2;
			}
			else {
				thislength++;
			}
			//console.info(thislength);
			if (thislength > n) {
				return txt.substring(0, i) + "...";
				break;
			}
		}
		return txt;
	},
	TxtLeftNoDot: function (txt, n) {
		if( txt == null || txt == "" ){
			return "";
		}
		var thislength = 0;
		for (var i = 0; i < txt.length; i++) {
			if (txt.charCodeAt(i) > 255) {
				thislength += 2;
			}
			else {
				thislength++;
			}
			//console.info(thislength);
			if (thislength > n) {
				return txt.substring(0, i);
				break;
			}
		}
		return txt;
	},
	TxtLeftta: function (txt, n) { 
		var thislength = 0;
		for (var i = 0; i < txt.length; i++) {
			if (txt.charCodeAt(i) > 255) {
				thislength += 2;
			}
			else {
				thislength++;
			}
			//console.info(thislength);
			if (thislength > n) {
				return txt.substring(0, i) + "..";
				break;
			}
		}
		return txt;
	},
	TxtLength: function (txt) {
		var thislength = 0;
		for (var i = 0; i < txt.length; i++) {
			if (txt.charCodeAt(i) > 255) {
				thislength += 2;
			}
			else {
				thislength++;
			}
		}
		return thislength;
	},
	numshow: function (num) {
		if (num == 0) return "";
		return "(" + num.toString() + ")";
	},
	smallimg : function (url){
		if( url == null || url == "" ){
			return ""
		}
		if( url.match(/\d{8}/) == null ){
			return "";
		}
		var position = url.match(/\d{8}/).index;
		return url.substring(0,position + 8) + "/size100" + url.substring(position + 8,url.length);
	},
	atlength : function (text){ //有多少个@某人
		var temp = text.match(/@\S+(\s|$)/g);
		if( temp == null ){
			return 0;
		}
		return temp.length;
	},
	isstock:function (code){ //简单判断是否是股票号码
		if( /\d{6}/.test(code)){
			code = code.toString();
			if( code.substring(0,1) == "4" ){ //三板
				return false;
			}
			else if ("100,101,108,109,111,112,115,119,125,126,129,131,010,019,020,130,110,113,104,105,106,107,201,202,203,204".indexOf(code.substring(0, 3)) > -1 || "75,12".indexOf(code.substring(0, 2)) > -1){ //债券
				return false;
			}
			else{
				return true;
			}
		}
		else{
			return false;
		}
	},
	clearhtml :function (text){
		return text.replace(/<[^>]*?>/ig, '');
	},
	gettime :function (){ //获得当前时间 例子 2021-04-03 23:12:52
		var temptime = new Date();
		var month = (temptime.getMonth() + 1).toString();
		month = month.length == 1?"0" + month:month;
		var day = temptime.getDate().toString();
		day = day.length == 1?"0" + day:day;
		return temptime.getFullYear() + '-' + month + '-' + day + ' ' + temptime.getHours() + ':' + temptime.getMinutes() + ":" + temptime.getMinutes();
	},
	getshorttime :function (){ //获得当前时间 例子 2021-04-03
		var temptime = new Date();
		var month = (temptime.getMonth() + 1).toString();
		month = month.length == 1?"0" + month:month;
		var day = temptime.getDate().toString();
		day = day.length == 1?"0" + day:day;
		return temptime.getFullYear() + '-' + month + '-' + day;
	},
	replyadd : function (text){ //回复数字加1
		var num = 0;
		var linktext = "";
		if( text.indexOf("(") > 0 ){
			linktext = text.substring(0,text.indexOf("("));
			num = parseInt(text.substring(text.indexOf("(") + 1,text.indexOf(")")));
			num ++
			return linktext + "(" + num.toString() + ")";
		}
		else{
			return text + "(1)";
		}
	},
	cleartext : function (text){
		text = text.replace(/<br>/g," ");
		return text;
	},
	clearquot : function (text){ //转换引号
		text = text.replace(/\'/g,"\\\'");
		text = text.replace(/\"/g,"\\\"");
		return text;
	},
	arraychaos : function (arr){ //数组乱序
		if( arr.length == 0 ){
			return arr;
		}
		arr.sort(function(a,b){ return Math.random()>.5 ? -1 : 1;});
		return arr;
	},
	getmarketcode: function ( code ) {
		var sh_or_sz = "1";
		var i = code.substring(0, 1);
		var j = code.substring(0, 3);
		if (i == "5" || i == "6" || i == "9"){
			//上证股票
		}
		else{
			if (code == "000003" || code == "000300"){
				//上证股票
			}
			if (j == "009" || j == "126" || j == "110"){
				//上证股票
			}
			else{
				sh_or_sz = "2";//深圳股票
			}
		}
		return code + sh_or_sz;
	},
	gecodetmarket: function ( code ) {
		var sh_or_sz = "1";
		var i = code.substring(0, 1);
		var j = code.substring(0, 3);
		if (i == "5" || i == "6" || i == "9"){
			//上证股票
		}
		else{
			if (code == "000003" || code == "000300"){
				//上证股票
			}
			if (j == "009" || j == "126" || j == "110"){
				//上证股票
			}
			else{
				sh_or_sz = "2";//深圳股票
			}
		}
		return sh_or_sz;
	}

}

module.exports = text
// return text;

// });