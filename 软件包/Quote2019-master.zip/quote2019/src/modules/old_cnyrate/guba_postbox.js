﻿// define(['jquery','guba_text'], function($, text) {

var text = require('./guba_text')

	$.fn.gredit = function (options) { //textarea编辑器 参数 bindface:插入表情
		var defaults = {
			openface: function (){
			return false;
			},
			closeface: function (){
			return false;
			}
		};
		var options = $.extend(defaults, options);
		this.each(function () {
			var thisedit = $(this);
			//if (options.bindface) { //插入表情
			//options.bindface.live("click",function () {
			//inserttext("[" + $(this).attr("title") + "]")
			//});
			//}
			if( options.bindface ){ //绑定表情
				options.bindface.click(function(){
					//greditmethod.insertface($(this),nowedit);
					var thislink = $(this);
					var temphtml = '<div class="shadowbox" id="insertfacediv">';
					if( options.facearrow == "bottom" ){
						temphtml += '<div class="shadowboxbottomarrow"></div>';
					}
					else{
						temphtml += '<div class="shadowboxtoparrow"></div>';
					}
					temphtml += '<table class="shadowboxt" cellspacing="0" cellpadding="0"><tr><td class="l7"></td><td class="l8"></td><td class="l9"></td></tr><tr><td class="l4">&nbsp;</td><td class="l5"><div class="shadowboxbody"><div id="facediv"><ul id="facelist"><li title="微笑"><img title="微笑" src="http://gbres.dfcfw.com/face/emot/emot01.png" alt="微笑"></li><li title="大笑"><img title="大笑" src="http://gbres.dfcfw.com/face/emot/emot02.png" alt="大笑"></li><li title="鼓掌"><img title="鼓掌" src="http://gbres.dfcfw.com/face/emot/emot03.png" alt="鼓掌"></li><li title="不说了"><img title="不说了" src="http://gbres.dfcfw.com/face/emot/emot04.png" alt="不说了"></li><li title="为什么"><img title="为什么" src="http://gbres.dfcfw.com/face/emot/emot05.png" alt="为什么"></li><li title="哭"><img title="哭" src="http://gbres.dfcfw.com/face/emot/emot06.png" alt="哭"></li><li title="不屑"><img title="不屑" src="http://gbres.dfcfw.com/face/emot/emot07.png" alt="不屑"></li><li title="怒"><img title="怒" src="http://gbres.dfcfw.com/face/emot/emot08.png" alt="怒"></li><li title="滴汗"><img title="滴汗" src="http://gbres.dfcfw.com/face/emot/emot09.png" alt="滴汗"></li><li title="拜神"><img title="拜神" src="http://gbres.dfcfw.com/face/emot/emot10.png" alt="拜神"></li><li title="胜利"><img title="胜利" src="http://gbres.dfcfw.com/face/emot/emot11.png" alt="胜利"></li><li title="亏大了"><img title="亏大了" src="http://gbres.dfcfw.com/face/emot/emot12.png" alt="亏大了"></li><li title="赚大了"><img title="赚大了" src="http://gbres.dfcfw.com/face/emot/emot13.png" alt="赚大了"></li><li title="牛"><img title="牛" src="http://gbres.dfcfw.com/face/emot/emot14.png" alt="牛"></li><li title="俏皮"><img title="俏皮" src="http://gbres.dfcfw.com/face/emot/emot15.png" alt="俏皮"></li><li title="傲"><img title="傲" src="http://gbres.dfcfw.com/face/emot/emot16.png" alt="傲"></li><li title="好困惑"><img title="好困惑" src="http://gbres.dfcfw.com/face/emot/emot17.png" alt="好困惑"></li><li title="兴奋"><img title="兴奋" src="http://gbres.dfcfw.com/face/emot/emot18.png" alt="兴奋"></li><li title="赞"><img title="赞" src="http://gbres.dfcfw.com/face/emot/emot19.png" alt="赞"></li><li title="不赞"><img title="不赞" src="http://gbres.dfcfw.com/face/emot/emot20.png" alt="不赞"></li><li title="摊手"><img title="摊手" src="http://gbres.dfcfw.com/face/emot/emot21.png" alt="摊手"></li><li title="好逊"><img title="好逊" src="http://gbres.dfcfw.com/face/emot/emot22.png" alt="好逊"></li><li title="失望"><img title="失望" src="http://gbres.dfcfw.com/face/emot/emot23.png" alt="失望"></li><li title="加油"><img title="加油" src="http://gbres.dfcfw.com/face/emot/emot24.png" alt="加油"></li><li title="困顿"><img title="困顿" src="http://gbres.dfcfw.com/face/emot/emot25.png" alt="困顿"></li><li title="想一下"><img title="想一下" src="http://gbres.dfcfw.com/face/emot/emot26.png" alt="想一下"></li><li title="围观"><img title="围观" src="http://gbres.dfcfw.com/face/emot/emot27.png" alt="围观"></li><li title="献花"><img title="献花" src="http://gbres.dfcfw.com/face/emot/emot28.png" alt="献花"></li><li title="大便"><img title="大便" src="http://gbres.dfcfw.com/face/emot/emot29.png" alt="大便"></li><li title="爱心"><img title="爱心" src="http://gbres.dfcfw.com/face/emot/emot30.png" alt="爱心"></li><li title="心碎"><img title="心碎" src="http://gbres.dfcfw.com/face/emot/emot31.png" alt="心碎"></li><li title="毛估估"><img title="毛估估" src="http://gbres.dfcfw.com/face/emot/emot32.png" alt="毛估估"></li><li title="成交"><img title="成交" src="http://gbres.dfcfw.com/face/emot/emot33.png" alt="成交"></li><li title="财力"><img title="财力" src="http://gbres.dfcfw.com/face/emot/emot34.png" alt="财力"></li><li title="护城河"><img title="护城河" src="http://gbres.dfcfw.com/face/emot/emot35.png" alt="护城河"></li><li title="复盘"><img title="复盘" src="http://gbres.dfcfw.com/face/emot/emot36.png" alt="复盘"></li><li title="买入"><img title="买入" src="http://gbres.dfcfw.com/face/emot/emot37.png" alt="买入"></li><li title="卖出"><img title="卖出" src="http://gbres.dfcfw.com/face/emot/emot38.png" alt="卖出"></li><li title="满仓"><img title="满仓" src="http://gbres.dfcfw.com/face/emot/emot39.png" alt="满仓"></li><li title="空仓"><img title="空仓" src="http://gbres.dfcfw.com/face/emot/emot40.png" alt="空仓"></li><li title="抄底"><img title="抄底" src="http://gbres.dfcfw.com/face/emot/emot41.png" alt="抄底"></li><li title="看多"><img title="看多" src="http://gbres.dfcfw.com/face/emot/emot42.png" alt="看多"></li><li title="看空"><img title="看空" src="http://gbres.dfcfw.com/face/emot/emot43.png" alt="看空"></li><li title="加仓"><img title="加仓" src="http://gbres.dfcfw.com/face/emot/emot44.png" alt="加仓"></li><li title="减仓"><img title="减仓" src="http://gbres.dfcfw.com/face/emot/emot45.png" alt="减仓"></li></ul><div class="clear"></div></div></div></td><td class="l6"></td></tr><tr><td class="l1"></td><td class="l2"></td><td class="l3"></td></tr></table></div>';
					if( $("#insertfacediv").length > 0 ){
						$("#insertfacediv").remove();
						options.closeface();
						return false;
					}
					else{
						thislink.after(temphtml);
						options.openface();
						if( options.facearrow == "bottom" ){
							$("#insertfacediv").css({left:thislink.position().left ,top:thislink.position().top - $("#insertfacediv").height() - 7});
						}
						else{
							$("#insertfacediv").css({left:thislink.position().left ,top:thislink.position().top + 20});
						}
						
						if( $("#sendpicurl").val() == "" ){
							if( $("#insertimgdiv").data("load") == "1" ){ //正在上传
								
							}
							else{
								$("#insertimgdiv").remove();
							}
						}
					}
					$("#insertfacediv li").click(function(){
						inserttext("[" + $(this).attr("title") + "]");
						$("#insertfacediv").remove();
						options.closeface();
					});
				});
			}


			var inserttext = function (text) { //插入文字
				if(thisedit[0]){
					if( thisedit.val() == '文明上网，理性发言' ){
						thisedit.val(text).css('color','#000').focus();
						return false;
					}
				}
				
				if (document.selection) {
					thisedit.get(0).focus();
					var sel = document.selection.createRange();
					sel.text = text;
				} else {
					var prefix, main, suffix;
					prefix = thisedit.get(0).value.substring(0, thisedit.get(0).selectionStart);
					main = thisedit.get(0).value.substring(thisedit.get(0).selectionStart, thisedit.get(0).selectionEnd);
					suffix = thisedit.get(0).value.substring(thisedit.get(0).selectionEnd);
					if (main == "") {
						thisedit.get(0).value = prefix + text + suffix;
					}
					else {
						thisedit.get(0).value = prefix + text + suffix;
					}
				}
			}
		});
	};

	/*
	 * textBlink 0.2
	 * Date: 2013-03-29
	 * 让文字闪烁起来
	 */
	(function($){
		$.fn.textBlink = function(options){
			var defaults = {
				color:["#fff","#ffe2d1","#ffc2a1","#ffa370","#ff8340","#ff630f"], //轮番颜色 默认橙色
				blinktime:60, //每帧时间 毫秒
				circle:2 //闪烁次数
			}
			var options = $.extend(defaults, options);
			var loop = 0;
			this.each(function(){
				var thisobj = $(this);
				for (var i = 0; i < options.color.length * options.circle; i ++ ){
					setTimeout(function (){
						thisobj.css('background-color',options.color[loop]);
						loop ++;
						loop = loop % options.color.length;
					},options.blinktime * i);
				}
			});
		};
	})($);

	window.titleistesu = function(text){ //判断标题特殊字符  不允许连续超过3个特殊字符 不允许累计超过5个 ？和！除外
		var re1 = /[^ \u4E00-\uFA29\uE7C7-\uE7F3\w\?\!]/g;
		var re2 = /[^ \u4E00-\uFA29\uE7C7-\uE7F3\w\?\!]{4}/;
		if( text.match(re1) == null ) return false;
		if( text.match(re1).length > 5 ) return true;
		return text.match(re2) != null;
	}

	window.gbpopbox = { //股吧默认弹框样式
		show:function (title,html){ //弹出
			var temphtml = '<div class="gbpopbox"><div class="gbpopboxclose" onclick="gbpopbox.close(this)" title="关闭">X</div><div class="gbpopboxtitle">使用该功能请先登录</div><div class="gbpopboxbody"></div></div>';
			if( $("#talkcont").length > 0 ){
				$("body").prepend(temphtml);
				$("body").prepend('<div class="gbmask"></div>');
				$(".gbmask").show();
			}
			else{
				$(".gbpopbox").remove();
				if( $(".gbpopbox").length == 0 ){
					$("body").prepend(temphtml);
				}
				else{
					$(".gbpopbox").show();
				}
				if( $(".gbmask").length == 0 ){
					$("body").prepend('<div class="gbmask"></div>');
				}
				else{
					$(".gbmask").show();
				}
			}

			//<div class="gbmask"></div>
			//if( $(".gbmask").length == 0 ){
				//$("body").prepend('<div class="gbmask"></div>');
			//}
			//else{
				//$(".gbmask").show();
			//}
			$(".gbmask").height($(document).height());

			if( $(".gbpopbox").length > 0 ){
				//$("body").prepend('<div class="gbmask"></div>');
				$(".gbmask:first").css("z-index",$(".gbpopbox").eq(1).css("z-index") + 1);
				$(".gbpopbox:first").css("z-index",$(".gbpopbox").eq(1).css("z-index") + 2);
			}
			
			
			$(".gbpopbox:first .gbpopboxtitle").html(title);
			$(".gbpopbox:first .gbpopboxbody").html(html);
			//alert($(window).height()/2);
			//alert($(".gbpopbox").height()/2 );
			//alert($(window).scrollTop());
			$(".gbpopbox:first").css({left:$(document).width()/2 - $(".gbpopbox").width()/2,top:$(window).height()/2 - $(".gbpopbox").height()/2  + $(window).scrollTop()});
		},
		close: function (thislink){ //关闭
			//alert($(thislink).parents(".gbpopbox").index(".gbpopbox"));
			if( $("#talkcont").length > 0 ){
				$(thislink).parents(".gbpopbox").prev(".gbmask").remove();		
				$(thislink).parents(".gbpopbox").remove();
			}
			else{
				$(".gbpopbox").remove();
				$(".gbmask").remove();			
			}
			


			//$(".gbmask").eq($(thislink).parents(".gbpopbox").index(".gbpopbox")).remove();
		},
		reposition : function (){
			$(".gbpopbox").css({left:$(document).width()/2 - $(".gbpopbox").width()/2,top:$(window).height()/2 - $(".gbpopbox").height()/2  + $(window).scrollTop()});
		}
	}

	window.clickone = true;
	var postbox = {
		init : function (container, code){
			container = $("#" + container);
			this.inserthtmlcss(container);
			$("#gbtainput").gredit({ bindface: $("#gbtainpubtn4") });
			//$("#gbtainput").gredit({ bindface: $("#gbtainpubtn4"), bindimg: $("#gbtainpubtn5") });
			$("#gbsform").submit(function () {
				postbox.submit(code);
				return false;
			});
			$('<script type="text/javascript" src="http://hqres.eastmoney.com/emag14/js/tvcode.js?v=1.1"></script>').appendTo($("head")); //验证码js

			$(document).click(function (e) { //绑定点击其他地方让其框消失
				var target = $(e.target);
				//console.info(target);
				if( $("#insertfacediv").length > 0 ){
					if( target.is("#insertfacediv") || target.parents().is("#insertfacediv") || target.is("#gbtainpubtn4") || target.parents().is("#gbtainpubtn4")) {
						
					}
					else{
						$("#insertfacediv").remove();
						if( typeof textareafacelose != "undefined" ){
							textareafacelose();
						}
					}
				}
			});

		},
		inserthtmlcss : function (container){
		    var css = '.gbsform { display: block; background-color: #EAF2FF; margin: 0px; padding: 13px 0 0 0; float: left; width: 100%; font-family: simsun; font-size:12px; }.gbsform button, .gbsform input, .gbsform textarea { font-family: simsun; }.gbsform label.l { width: 55px; text-align: right; float: left;  }.gbsform .gbsformi1 { width: 705px; border: 1px solid #D9E3F5;  padding: 8px 4px; *vertical-align: middle; float: left; outline:none;}.gbsform .gbsformt1 { width: 705px; /*height: auto;  max-height:500px;*/ height: 80px; border: 1px solid #D9E3F5; line-height: 130%; padding: 4px 4px; vertical-align: top; resize:none; background-color: #fff; float: left; outline:0; overflow: auto; word-wrap : break-word;   }.gbsform .gbsformt1 em { font-style:italic; }.gbsform .mtj1 { margin-top: -2px; clear: both;  }.gbsform .mtj2 { padding-left: 53px; clear: both;  }.gbsform .mtj2 .mtjchbox { vertical-align: middle; }.gbsform .tzla { padding-top: 6px; }.gbsform .editorfuns { padding-top: 13px; padding-bottom: 13px; float: left; }.gbsform .editorfuns a { color: #333333; margin-right: 10px; _margin-right: 5px; }.gbsform .editorfuns a:link, .gbsform .editorfuns a:visited { text-decoration: none;  }.gbsform .editorfuns a:hover { text-decoration: underline; }.gbsform .gbsformbtns { float: right; padding-right: 20px; padding-top: 5px;  }.gbsform .gbsformi3 { width: 121px; height: 31px; border: 0; color: #fff; cursor: pointer;background-color:#FF8400; vertical-align: middle; font-size: 14px; font-weight: bold;}.gbsform .gbsformi3:hover { background-color:#FF4800; }.gbsform .gbsformi3:disabled {background-color: #8A8B8E; cursor: default; }.gbsform .gbsformi4:disabled {background-color: #8A8B8E; cursor: default; }.gbsform .gbsformi3send {background: url(http://guba.eastmoney.com/images/bgg.jpg) no-repeat 0px -420px;}.gbsform .gbsformi3gd { width: 121px; height: 31px; border: 0; color: #fff; cursor: pointer;background-color: #FF3333; vertical-align: middle; font-size: 14px; font-weight: bold;}.gbsform .gbsformi3gd:hover { background-color: #F30909; }.gbsform .gbsformi4 { width: 61px; height: 31px; background-color: #B5B6BA; border: 0; color: #fff; cursor: pointer; margin-left: 3px; vertical-align: middle; font-size: 14px; font-weight: bold;}.gbsform .gbsformi4:hover { background-color: #8A8B8E; }.iconface { display: inline-block; width: 16px; height: 16px; background: url(http://hqres.eastmoney.com/emag14/images/gbbg.png?v=7) no-repeat -90px -180px; vertical-align: -3px; margin-right: 3px; }.iconimg { display: inline-block; width: 16px; height: 14px; background: url(http://hqres.eastmoney.com/emag14/images/gbbg.png?v=7) no-repeat -120px -180px; vertical-align: -2px; margin-right: 3px; }.shadowbox { position: absolute; z-index: 1001; }.shadowboxt td { overflow: hidden; font-size: 1px; text-overflow:ellipsis;}.shadowboxt .l1,.shadowboxt .l2,.shadowboxt .l3,.shadowboxt .l4,.shadowboxt .l6,.shadowboxt .l7,.shadowboxt .l8,.shadowboxt .l9 { background: url(http://hqres.eastmoney.com/emag14/images/gbshadowbg.png?v=2); _background: url(http://guba.eastmoney.com/images/shadowbgie6.gif?v=2) no-repeat 0 0; font-size: 1px; }.shadowboxt .l7,.shadowboxt .l9,.shadowboxt .l1,.shadowboxt .l3{ height: 4px; width: 4px; }.shadowboxt .l5 { background-color: #fff; padding: 1px; border:1px solid #B7B7B7; font-size: 12px; }.shadowboxt .l7 { background-position:0 0; }.shadowboxt .l8 { background-position:0 -14px; }.shadowboxt .l9 { background-position:-4px 0; }.shadowboxt .l4 { background-position:0 -14px; background-color: transparent; }.shadowboxt .l6 { background-position:0 -14px; width: 4px; overflow: hidden; }.shadowboxt .l1 { background-position:0 -4px; }.shadowboxt .l2 { background-position:0 -14px; }.shadowboxt .l3 { background-position:-4px -4px; }.shadowbox .shadowboxtoparrow { position: absolute; left: 20px; top: -7px; width: 14px; height: 12px; background: url(http://hqres.eastmoney.com/emag14/images/gbshadowbg.png?v=2) no-repeat -18px 0px; }.shadowbox .shadowboxrightarrow { position: absolute; right: -7px; top: 20px; width: 12px; height: 14px; background: url(http://hqres.eastmoney.com/emag14/images/gbshadowbg.png?v=2) no-repeat -102px 0px; _background: url(http://guba.eastmoney.com/images/shadowbgie6.gif?v=2) no-repeat -102px 0px; }.shadowbox .shadowboxbottomarrow { position: absolute; left: 20px; bottom: -9px; width: 12px; height: 14px; background: url(http://hqres.eastmoney.com/emag14/images/gbshadowbg.png?v=2) no-repeat -57px 0px; _background: url(http://guba.eastmoney.com/images/shadowbgie6.gif?v=2) no-repeat -57px 0px; _bottom:-10px; }#facediv { padding-bottom: 4px; }#facelist { list-style: none; margin: 0px; padding: 0px 0 0 4px; width: 310px;  }#facelist li { float: left; width: 28px; height: 28px; border: 1px solid #DADADA; margin-top: 4px; margin-right: 4px; text-align: center; padding-top: 3px; cursor: pointer; }#facelist li img { width: 28px; height: 28px; }#facelist li:hover { border: 1px solid #5FABDF; } #interested .pername { padding-bottom: 5px; }#uploadimgtips { text-align: center; width: 300px; padding: 20px 0; }#uploadimgtips #selectimglink { font-size: 14px;  height: 40px; width: 140px; margin: 0px auto;  cursor: pointer; background-color: #F0F0F0; line-height: 40px; border: 1px solid #A0A0A0; display: inline-block; margin-bottom: 10px;  }.editorinsertimgubtn {  font-size: 14px;  height: 40px; width: 140px; margin: 0px auto;  cursor: pointer; background-color: #F0F0F0; line-height: 40px; border: 1px solid #A0A0A0; }#uploadpreviewdiv { padding: 10px 20px; text-align: center; }#uploadpreviewdiv img { margin-top: 5px; }#uploadpreviewdiv ul li { float: left; width: 120px; }#uploadpreviewdiv #contupload { font-size: 14px;  height: 40px; width: 100px; margin: 0px auto;  cursor: pointer; background-color: #F0F0F0; line-height: 40px; border: 1px solid #A0A0A0; margin-top: 35px; }#uploadpreviewdiv .uploadmoreing { display: none; margin-top: 35px; }#uploadpreviewdiv .uploadmoreing img { vertical-align: -3px; }a#newstip { background-color: #FEFDED; border: 1px solid #F9F2A7; height: 24px; line-height: 24px; cursor:pointer; text-align:center; color:#F48C12; margin-top:4px; display:none; }a#newstip:hover { background-color: #FCF8C2; border:1px solid #EFE467; }/*文字验证码*/#tvcode {  background-color: #fff;  width: 360px; font-size: 12px; }#tvcode .b { padding: 20px 30px 30px 30px; }#tvcode .in { font-size: 14px; }#tvcode .tes { border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; vertical-align: middle; display: inline-block; height: 40px; }#tvcode .tes #t3 { display: none; }#tvcode .tes #t4 { display: none; }#tvcode .te { display: inline-block; width: 46px; height: 40px; border-left: 1px solid #ccc; cursor: default; }#tvcode #back { display: inline-block; width: 46px; height: 40px; border-left: 1px solid #ccc; cursor: pointer; border-right: 1px solid #ccc; background: url(http://hqres.eastmoney.com/emag14/images/gbtvcodeback.png?v=2) 3px 0 #CDCDCD; }#tvcode .ans { padding: 8px 0 8px 56px; }#tvcode #ansi { width: 150px; height: 36px; display: inline-block; vertical-align: middle; cursor: pointer;  }#tvcode .st { padding-left: 56px; }#tvcode #answul { width: 183px; padding-top: 4px; }#tvcode #answul li { width: 54px; height: 40px; border: 1px solid #ccc; float: left; margin: 0 5px 5px 0;   background-repeat:no-repeat; cursor: pointer; display: none; border-collapse: #fff;}#tvcode #answul li:hover { border: 1px solid #5a6fb4; }#tvcode .tvt { font-size: 14px; font-weight: bold; text-align: center; padding-bottom: 10px; }.gbpopbox { position: absolute; z-index: 1001; border: 1px solid #B1D1E6; background-color: #fff;  }.gbpopbox .gbpopboxtitle {  font-size: 14px; font-weight: bold; color: #fff;  background-color: #466B98; padding: 8px 0 8px 12px;  }.gbpopbox .gbpopboxclose {  position: absolute; right: 15px; top: 8px; width: 9px; height: 9px; cursor: pointer; color: #fff; font-size: 18px; font-family: Arial;  }.gbpopbox .gbpopboxclose:hover { text-decoration: underline; }.gbmask { position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; z-index: 1000; background: url(http://hqres.eastmoney.com/emag14/images/gbmask.png); _background:none; _filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled=true, sizingMethod=scale, src="http://hqres.eastmoney.com/emag14/images/gbmask.png"); }';
			$('<style type="text/css">' + css + '</style>').appendTo($("head"))
			var html = '<form method="post" action="" target="_self" id="gbsform" class="gbsform"><div class="cls"><label for="gbtaintitle" class="l tzla">标题：</label><input type="text" name="" class="gbsformi1" id="gbtaintitle" maxlength="80" /></div><div class="mtj1 cls" id="yzmp"><label for="gbtainput" class="l tzla">内容：</label><textarea class="gbsformt1" id="gbtainput"></textarea> </div><div class="mtj2 cls"><div class="editorfuns" id="editorfuns"><a href="javascript:;" id="gbtainpubtn4" data-fun="face" target="_self"><em class="iconface"></em>表情</a>  </div><div class="gbsformbtns"><span id="gdregbtn"></span>&nbsp;<button type="submit" class="gbsformi3">发 布</button><input type="reset" id="gbsformreset" class="gbsformi4" value="清 除" /></div><input type="hidden" id="sendpicurl" /></div></form>';
			container.html(html);
		},
		submit : function (code, para){
			var defaultpara = { isgudong: false }; //默认参数 
			var options = $.extend(defaultpara, para); 
			var swtitle = $.trim($("#gbtaintitle").val());
			if( swtitle == "" ){
				$("#gbtaintitle").textBlink({color:["#FFDDDD","#FFEEEE","#fff"],blinktime:150});
			}
			var swcontent = $.trim($("#gbtainput").val());
			if( swcontent == "" ){
				$("#gbtainput").textBlink({color:["#FFDDDD","#FFEEEE","#fff"],blinktime:150});
				return false;
			}
			if( swtitle == "" || swcontent == "" ){
				return false;
			}
			if( titleistesu(swtitle) ){
				$("#gbtaintitle").textBlink({color:["#FFDDDD","#FFEEEE","#fff"],blinktime:150});
				alert("您输入的标题符号过多，请修改后再发！");
				return false;
			}

			var quanxian = 0;
			var gudongstemp = 0;
			if( $("#gdsubmitlimit").length > 0 ){
				if( $("#gdsubmitlimit").is(":checked") ){
					quanxian = 2;
					gudongstemp = 10;
				}
				gudongstemp = 11;
			}

			if (!clickone) {
				return false;
			}
			clickone = false;

			$(".gbsformi3").text("发布中...");
//			if( gudongstemp > 0 ){
//				gudong.stat(gudongstemp);
//			}
			//alert(quanxian);
			$.ajax({
				type: "GET",
				url: "http://igubacs.eastmoney.com/action.aspx",
				dataType: "jsonp",
				data:{action:"osendwz",yuan_id:0,title:text.titleclean($.trim($("#gbtaintitle").val())),text:swcontent,code:code.toLowerCase(),pdf:"",pic:$("#sendpicurl").val(),postvalid:1,yzmid:tvcode.cbid,yzm:tvcode.value, quanxian:quanxian},
				success: function (json) {
					
					clickone = true;
					//股东发帖统计

	//				if( options.isgudong ){
	//					$(".gbsformi3gd").removeClass("gbsformi3gdsend");
	//				}
	//				else{
	//					$(".gbsformi3").removeClass("gbsformi3send");
	//				}
					//$(".gbsformi3").removeClass("gbsformi3send");
					$(".gbsformi3").text("发  布");
					if (json.result) {
						//gubalist.clearremember();
						//guba.sendok('list,' + code + '.html');
						$("#gbtainput").val('');
						$("#gbtaintitle").val('');
						//stat(1);
						tvcode.checktrue();
						
						//guba.sendok('list,' + code + '.html');
						alert("发布成功！");
					}
					else {    				
						if (json.error == "出验证码") {
							tvcode.init(function (){
								$("#gbsform").submit();
							});
						}
						else if(json.error == "验证码输入错误！"){
							tvcode.checkfalse();
						}
						else if(json.error == "请修改昵称"){
							gbpopbox.close();
							//guba.sendok3();
						}
						else{
							gbpopbox.close();
							//alert(json.error);
						}
					}
				},
				error: function (XMLHttpRequest, textStatus, errorThrown) {
					clickone = true;
					//$(".gbsformi3").removeClass("gbsformi3send");
					$(".gbsformi3").text("发  布");
					alert("系统忙，请稍后再试！");
					try{
						console.error("XMLHttpRequest="+XMLHttpRequest.responseText+"\ntextStatus="+textStatus+"\nerrorThrown="+errorThrown);
					}
					catch (e){}
				}
			});
			return false;
		}
	}
	module.exports = postbox
	// return postbox;
// });