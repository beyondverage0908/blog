// require(["baseStock", "common", "template"], function (baseStock, common, template) {

var baseStock = require('../old_globalindex/basestock')
var common = require('../old_b/common')
var template = require('../old_b/template')

    function Bondstock() {

        baseStock.call(this);  //第二次调用基类的构造函数
    }
    Bondstock.prototype = new baseStock();
    var instance = new Bondstock();
    var noRefresh = 0;
    // 债券成交明细
    Bondstock.prototype.bindDealDetail = function () {

        var _num = 15;
        var _url = instance.baseUrl + "/api/qt/stock/details/get?secid=" + window.stockEnity.fullcode + "&ut=" + instance.ut + "&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55&pos=-" + _num
        $.ajax({ 
            url: _url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            beforeSend: function () {
                $("#deal_detail tbody").html('<td colspan="3" style="height: 249px; text-align: center;" class="waiting ">加载中...</td>');
            },
            success: function (json) {
                var data = json.data
                if (!data.details.length || !data.prePrice) return;
                var list = [];
                var details = data.details
                for (var i = 0; i < details.length; i++) {
                    if (i > 0) {
                        var itemslast = details[i - 1].split(",")
                        var items = details[i].split(",");
                        var dir = (items[1] > itemslast[1] ? "↑" : items[1] == itemslast[1] ? " " : "↓")
                        var listitem = {
                            time: items[0],
                            close: items[1],
                            closeCss: common.getColor(items[1] - data.prePrice),
                            volumn: items[2],
                            dir: dir,
                            volumnCss: items[4] == 0 ? lastcolor : (items[4] == 2 ? (items[1] * items[2] * 100 > 200000 ? 'purple' : 'red') : (items[1] * items[2] * 100 > 200000 ? 'blue' : 'green')),
                            arrowcolor: items[1] > itemslast[1] ? "red" : items[1] == itemslast[1] ? " " : "green"
                        }
                        list.push(listitem);
                        var lastcolor = listitem.volumnCss
                    } else {
                        var items = details[i].split(",");
                        var listitem = {
                            time: items[0],
                            close: items[1],
                            closeCss: common.getColor(items[1] - data.prePrice),
                            volumn: items[2],
                            dir: "",
                            volumnCss: "red",
                            arrowcolor: ""
                        }
                        list.push(listitem);
                    }
                }
                list = list.reverse()
                list = list.slice(0, 10)
                var html = template("tmp_deal_detail", { list: list });
                $("#deal_detail tbody").html(html);
            }
        });
    };

    function bindPageEvent() {
        $(".listData").mouseover(function (e) {
            e.stopPropagation();
            $(".imglist li").removeClass("active");
            $(this).parent("li").addClass("active");
            $(this).hide();
            $(".imgDiv").hide();
            $(this).siblings(".imgDiv").stop().slideDown();
            $(this).parent("li").siblings("li").find(".listData").show();
        });

        $(".tabLi").mouseenter(function () {
            $(this).parent().find("li").removeClass("cur");
            $(this).addClass("cur");

            var index = $(this).index();
            if ($(this).parents(".tabExchangeCon").length > 0) {
                $(this).parents(".tabExchangeCon").find(".info_list").removeClass("active");
                $(this).parents(".tabExchangeCon").find(".info_list").eq(index).addClass("active");

                $(this).parents(".tabExchangeCon").find(".more").hide();
                $(this).parents(".tabExchangeCon").find(".more").eq(index).show();

            } else {
                $(this).parents(".side_box").find(".info_list").removeClass("active");
                $(this).parents(".side_box").find(".info_list").eq(index).addClass("active");
            }

        });
    }

    //基本资料
    function baseMsg() {

        var result = false;
        var startId = stockEnity.stockId.substring(0, 3);
        if (!(startId == "110" || startId == "113" || startId == "123" || startId == "127" || startId == "128")) {
            result = true;
        }

        var market = stockEnity.stockMarket === "1" ? "SH" : "SZ";
        var _url = "//dcfm.eastmoney.com/EM_MutiSvcExpandInterface/api/js?type=ZQ_JBXX&token=70f12f2f4f091e459a279469fe49eca5";
        $.ajax({
            url: _url,
            data: {
                filter: "(BONDCODE='" + stockEnity.stockCode + "')(TEXCH='CNSE" + market + "')"
            },
            dataType: "jsonp",
            success: function (json) {
                if (!json || json.length == 0) return;
                $(".FNAME").attr("title", json[0]["FNAME"])
                $(".FNAME").text(common.cutstr(json[0]["FNAME"], 26)); //债券全称
                $(".SNAME").text(json[0]["SNAME"]);//债券简称
                $(".BONDCODE").text(json[0]["BONDCODE"]);//债券代码

                $(".ISSUEVOL").text(json[0]["ISSUEVOL"] + "亿元");//发行量
                $(".ISSUEPRICE").text(json[0]["ISSUEPRICE"] + "元");//发行价
                $(".COUPONTYPE").text(json[0]["COUPONTYPE"]);//发行方式 

                $(".BONDPERIOD").text(json[0]["BONDPERIOD"] + "年");//期限
                $(".COUPONRATE").text(json[0]["COUPONRATE"] == "-" ? "-" : json[0]["COUPONRATE"] + "%");//发行票面利率
                $(".TEXCH").text(json[0]["TEXCH"].toLowerCase() == "CNSESH".toLowerCase() ? "上海证券交易所" : "深圳证券交易所");//交易市场

                $(".FRSTVALUEDATE").text(dateFun(json[0]["FRSTVALUEDATE"]));//起息日期
                $(".MRTYDATE").text(dateFun(json[0]["MRTYDATE"]));//到期日期
                $(".ISSUEDATE").text(dateFun(json[0]["ISSUEDATE"]));//发行起始日

                $(".LISTDATE").text(dateFun(json[0]["LISTDATE"]));//上市日期
                $(".ISSUERNAME").attr("title", json[0]["ISSUERNAME"])
                $(".ISSUERNAME").text(common.cutstr(json[0]["ISSUERNAME"], 20));//发行单位
                $(".PAYTYPE").text(json[0]["PAYTYPE"]);//付息方式

                $(".CURRENCY").text(json[0]["CURRENCY"]);//币种
                $(".SYQX").text(json[0]["SYQX"] + "天");//剩余期限               

                $(".PAYDAY").text(json[0]["PAYDAY"]);//每年付息日

                //if (stockEnity.stockCode === "123006") {
                //    // $(".SYQX").text('-');//剩余期限
                //    var $html = '<tr class="tr_bg"><td class="border0"><strong>最新赎回执行日</strong></td><td class="red">2019-05-13</td><td><strong>赎回价格</strong></td><td class="red">100.16元/张</td><td><strong>赎回登记日</strong></td><td class="red">2019-05-10</td><td><strong>停止交易和转股日</strong></td><td class="red">2019-05-13</td><tr>';
                //    $('.jbzl_table tbody').append($html)
                //}

                //若当前时间是上市日期的第二天 显示可转债数据 模块
                var companyTime = dateFun(json[0]["LISTDATE"])
                tempTime = companyTime.split('-');
                companyTime = Date.UTC(parseInt(tempTime[0]), parseInt(tempTime[1]), parseInt(tempTime[2]));

                var nowDate = new Date();
                var nowYear = nowDate.getFullYear();
                var nowMonth = (nowDate.getMonth() + 1);
                var nowDay = nowDate.getDate();
                nowTime = Date.UTC(nowYear, nowMonth, nowDay);
                if (!result) {
                    if (nowTime > companyTime) {
                        $("#conversion-draw").show();
                    }
                }
            }
        });
        return result;
    }

    function dateFun(str, format) {
        if (!str || str === "-") return str;
        var _format = format ? format : "yyyy-MM-dd";
        var text = str == "-" ? "-" : str.replace(/-/g, "/").replace("T", " ");
        var date = common.formatDate(new Date(text), _format);
        return date;
    }

    /**
     * 显示新版行情数字行情
     */
    function showNewQuoteNumber(number1, fixed, suffix){
        if (number1 == '-' || number1 == undefined || number1 == '' || isNaN(number1)) {
            return '-'
        }
        if (suffix == undefined){
            suffix = ''
        }
        try{
            return (number1 / (Math.pow(10, fixed))).toFixed(fixed) + suffix
        }
        catch(error){
            return '-'
        }
    } 
    //计算涨跌额
    function showNewQuoteNumber2(number1, number2, fixed){
        if (number1 == '-' || number1 == undefined || number1 == '' || isNaN(number1) || number2 == '-' || number2 == undefined || number2 == '' || isNaN(number2)) {
            return '-'
        }

        try{
            return ((number1 - number2) / (Math.pow(10, fixed))).toFixed(fixed)
        }
        catch(error){
            return '-'
        }
    }      

    function numbertodata(num) {
        try{
            num = num.toString()
            return num.substring(0,4) + '-' + num.substring(4,6) + '-' + num.substring(6,8)
        }
        catch(error){
            return ''
        }
    }

    //可转债基本资料
    function kzzBaseMsg() {
        //var _url = "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?&type=CT&cmd=" + stockEnity.stockId + "&sty=FC20CD&st=z&js=((x))&token=4f1862fc3b5e77c150a2b985b12db0fd"
        var _url = 'http://push2.eastmoney.com/api/qt/stock/get?secid=' + stockEnity.fullcode + '&invt=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fields=f58,f152,f154,f426,f432,f424,f433,f427,f428,f431,f430,f263,f262,f264,f265,f266,f267,f268&cb=?'
        $.ajax({
            url: _url,
            dataType: "jsonp",
            success: function (json) {
                
                //if (!json || json.length == 0) return;
                if(json.rc != 0 || json.data == undefined) return;
                //var item = json.split(",");
                var link = "";
                link = json.data.f263 == "-" ? "javascript:;" : json.data.f263 == 1 ? "http://quote.eastmoney.com/sh" + json.data.f262 + ".html" : "http://quote.eastmoney.com/sz" + json.data.f262 + ".html";
                $(".zgmc").html('<a href=' + link + ' target="_blank">' + json.data.f264 + '</a>');
                $(".zgxj").html(showNewQuoteNumber(json.data.f267, json.data.f265, '元'));
                $(".kszgrq").html(numbertodata(json.data.f433));
                $(".zhguj").html(showNewQuoteNumber(json.data.f426, json.data.f265, '元'));
                $(".zgjz").html(showNewQuoteNumber(json.data.f427, json.data.f154));
                $(".yjl").html(showNewQuoteNumber(json.data.f428, json.data.f152, '%'));
                $(".hscfj").html(showNewQuoteNumber(json.data.f430, json.data.f265, '元'));
                $(".qscfj").html(showNewQuoteNumber(json.data.f431, json.data.f265, '元'));
                $(".dqchj").html(showNewQuoteNumber(json.data.f432, json.data.f265, '元'));
                $(".czjg").html(showNewQuoteNumber(json.data.f424, json.data.f154, '元'));
                $(".data-right").show();
                $(".zhguZde").html(showNewQuoteNumber2(json.data.f267, json.data.f266, json.data.f265));
                $(".zhguZdf").html(showNewQuoteNumber(json.data.f268, json.data.f152, '%'));
                $(".data-right  .zgxj").html(showNewQuoteNumber(json.data.f267, json.data.f265));
                var zhguName = json.data.f264 == "-" ? "-" : json.data.f264 + "行情"
                $(".data-right  .zgmc").html('<a href=' + link + ' target="_blank">' + zhguName + '</a>');
                if (json.data.f268 != "-" && json.data.f268 > 0) {
                    $(".data-right  .zgxj").addClass("red").removeClass("green");
                    $(".zhguZde").addClass("red").removeClass("green");
                    $(".zhguZdf").addClass("red").removeClass("green");
                } else if (json.data.f268 != "-" && json.data.f268 < 0) {
                    $(".data-right  .zgxj").addClass("green").removeClass("red");
                    $(".zhguZde").addClass("green").removeClass("red");
                    $(".zhguZdf").addClass("green").removeClass("red");
                } else {
                    $(".data-right  .zgxj").removeClass("red green")
                    $(".zhguZde").removeClass("red green");
                    $(".zhguZdf").removeClass("red green");
                }

                // if (json.data.f262 != '-' && json.data.f263) {
                //     $.ajax({
                //       url: 'http://push2.eastmoney.com/api/qt/stock/get?secid=' + json.data.f263 + '.' + json.data.f262 + '&invt=1&ut=bd1d9ddb04089700cf9c27f6f7426281&fields=f59,f169&cb=?',
                //       type: 'GET',
                //       dataType: 'jsonp'
                //     })
                //     .done(function(json2) {   
                //       if (json2.rc == 0) {
                //         $(".zhguZde").html(showNewQuoteNumber(json2.data.f169, json2.data.f59));
                //       }
                //     })
                // }
                
            }
        });
    }
    function format(time) {
        return (
            new Date(time).getFullYear() +
            "-" +
            bl(new Date(time).getMonth() + 1) +
            "-" +
            bl(new Date(time).getDate()) +
            " " +
            bl(new Date(time).getHours()) +
            ":" +
            bl(new Date(time).getMinutes()) +
            ":" +
            bl(new Date(time).getSeconds())
        );
    }
    function bl(num) {
        if (num < 10) {
            return "0" + num + "";
        } else {
            return num;
        }
    }

    // 可转债基本资料添加字段
    function kzzBaseMsgAddData() {
        var _serverTime = '';
        if (!serverTime) {
            format(new Date().getTime())
            //_serverTime = new Date().format('yyyy/MM/dd');
        } else {
            _serverTime = serverTime
        }
        var _url = "http://dcfm.eastmoney.com/em_mutisvcexpandinterface/api/js/get?type=KZZ_LB&token=70f12f2f4f091e459a279469fe49eca5&filter=(BONDCODE=" + stockEnity.stockCode + ")";
        $.ajax({
            url: _url,
            dataType: "jsonp",
            success: function (json) {

                if (json && json.length > 0) {
                    var item = json[0];
                    var price_sh = parseFloat(item.PRICE_SH) ? item.PRICE_SH + "元/张" : item.PRICE_SH;
                    var startdate_sh = '';
                    item.STARTDATE_SH !== '-' ? startdate_sh = dateFun(item.STARTDATE_SH) : startdate_sh = '-';

                    var $html = '<tr class="tr_bg">' +
                        '<td class="border0" ><strong>最新赎回执行日</strong></td ><td class="addCcolor" > ' + startdate_sh + '</td >' +
                        '<td><strong>赎回价格</strong></td> <td class="addCcolor" >' + price_sh + '</td >' +
                        '<td><strong>最新回售执行日</strong></td><td class="addCcolor" >' + dateFun(item.STARTDATE_HS) + '</td >' +
                        '<td><strong>回售价格</strong></td><td class="addCcolor">' + item.PRICE_HS + '</td>' +
                        '<tr>';

                    $('#kzz_jbzl tbody').append($html);


                    //赎回执行日在前10天后20天的时间展示温馨提示
                    var SH_time_before10 = new Date(dateFun(item.STARTDATE_SH, "yyyy/MM/dd")).getTime() - 24 * 10 * 60 * 60 * 1000;
                    var SH_time_after20 = new Date(dateFun(item.STARTDATE_SH, "yyyy/MM/dd")).getTime() + 24 * 20 * 60 * 60 * 1000;
                    var time = new Date(dateFun(_serverTime, "yyyy/MM/dd")).getTime();
                    //  console.log(SH_time_before10, SH_time_after20, time,"时间戳")
                    if (time && SH_time_before10 < time && time < SH_time_after20 && startdate_sh !== "-") {

                        // 赎回原因 EXECREASON_SH                      

                        // 赎回类型 CALLSTYPE_SH
                        var obj = gettipFun(item);

                        var _text = "<span class='dcColor'>温馨提示：</span>" +
                            "<div>" + stockEnity.stockName + "（" + stockEnity.stockCode + "）已触发赎回条款，赎回原因：" + obj.shyy + "，赎回类型：" + obj.shll + "。赎回价格" + price_sh + "，赎回登记日" + dateFun(item.RECORDATE_SH) + "，赎回执行日" + dateFun(item.STARTDATE_SH) + "。</div>" +
                            "<div>敬请投资者仔细阅读相关公告，注意投资风险。<a class='toolFootLik' href='http://data.eastmoney.com/notices/stock/" + item.SWAPSCODE + ".html' target='_blank'>查看最新公告>></a></div>"

                        var tableFoot = "<tfoot><tr><td colspan='8' class='toolFoot border0'>" + _text + "</td></tr></tfoot>";

                        $('#kzz_jbzl').append(tableFoot);

                        for (var i = 0; i < $(".addCcolor").length; i++) {
                            var $dom = $(".addCcolor").eq(i);
                            $dom.html() !== "-" ? $dom.addClass("dcColor") : $dom.removeClass("dcColor");
                        }
                    } else {
                        $(".addCcolor").removeClass("dcColor")
                    }


                }
            }
        })

    }
    function gettipFun(data) {
        var shyy = "-";
        switch (data["EXECREASON_SH"] / 1) {
            case 1: shyy = "满足回售条款"; break;
            case 2: shyy = "满足赎回条件"; break;
            case 3: shyy = "满足附加回售条款"; break;
            case 4: shyy = "强制赎回"; break;
            case 5: shyy = "到期赎回"; break;
        }
        var shll = "";
        switch (data["CALLSTYPE_SH"] / 1) {
            case 1: shll = "部分赎回"; break;
            case 2: shll = "全部赎回"; break;
        }

        return { "shyy": shyy, "shll": shll }


    }
    //东财转债的重要通知
    function dcNoticeFun(arr) {
        var $_text = "东财转债（123006）于2018年6月26日起进入转股期，公司股票自2019年2月18日至2019年3月29日连续30个交易日中至少15个交易日的收盘价格不低于当期转股价格（11.36元 / 股）的130%，已触发赎回条款。";

        $(".msg-content-box").html($_text).attr("title", $_text);

        $(".scoll_news").click(function (e) {
            e.stopPropagation()
            $('.dialog').show();
        })
        $(".closeBtn").click(function () {
            $('.dialog').hide();
        })
        $(".sureBtn").click(function () {
            $(".closeBtn").trigger("click")
        })
        //$('document').click(function (e) {  
        //    e.stopPropagation()
        //    $(".closeBtn").trigger("click")
        //})

    }
    //可转债数据 time  + 跳转链接
    function kzzTime() {
        var that = this;

        $("#conversion-draw .kezhuan").attr('href', 'http://data.eastmoney.com/kzz/detail/' + stockEnity.stockCode + '.html');
        //可转债资料 链接
        $("#conversion-info .kezhuan_ziliao").attr('href', 'http://data.eastmoney.com/kzz/detail/' + stockEnity.stockCode + '.html');

        $("#conversion-draw .kezhuan_ziliao").attr('href', 'http://data.eastmoney.com/kzz/detail/' + stockEnity.stockCode + '.html');

    }


    //相关品种
    Bondstock.prototype.aboutType = function (type) {


        var _url = instance.baseUrl + "/api/qt/clist/get?&pn=1&pz=6&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=" + type + "&fields=f1,f2,f3,f4,f5,f10,f12,f13,f14,f15,f11,f152"
        $.ajax({
            url: _url,
            dataType: "jsonp",
            jsonp: "cb",
            success: function (json) {
                //console.log(json.data.diff)
                var list = json.data.diff
                for (var i = 0; i < list.length; i++) {

                    var price = list[i].f2 == '-' ? '-' : (list[i].f2).toFixed(list[i].f1)
                    var percent = list[i].f3 == '-' ? '-' : (list[i].f3.toFixed(2) + '%')
                    var color = list[i].f3 > 0 ? 'red' : list[i].f3 < 0 ? 'green' : ''
                    var mk = list[i].f13 == 1 ? "sh" : "sz";

                    $(".tdList" + i).find("a").attr("href", "//quote.eastmoney.com/bond/" + mk + list[i].f12 + ".html").text(list[i].f14);
                    $(".tdList" + i).find("span").html("(<em class='" + color + "'>" + price + "</em> <em class='" + color + "'>" + percent + "</em>)")
                }
            }
        });


        //var link_tmp = "//quote.eastmoney.com/{{market | getShortMarket}}{{code}}.html";
        //var _url = "//nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&sty=E1II&st=(ChangePercent)&sr=-1&p=1&ps=6&js=([(x)])&token=4f1862fc3b5e77c150a2b985b12db0fd&cmd=" + cmd;
        //$.ajax({
        //    url: _url,
        //    dataType: "jsonp",
        //    jsonp: "cb",
        //    success: function (json) {
        //        if (!json || typeof json == "string") return;
        //        var list = [];
        //        for (var i = 0; i < json.length; i++) {
        //            var items = json[i].split(",");
        //            var mk = items[1] == "1" ? "sh" : "sz";
        //            $(".tdList" + i).find("a").attr("href", "//quote.eastmoney.com/bond/" + mk + items[0] + ".html").text(items[2]);
        //            $(".tdList" + i).find("span").html("(<em class='" + common.getColor(items[4]) + "'>" + items[3] + "</em> <em class='" + common.getColor(items[4]) + "'>" + items[4] + "</em>)")
        //        }
        //    }
        //});

    }

    //债券滚动
    function globalZhb() {
        var sjs = Math.random().toString().replace('.', '');
        jQuery.ajax({
            url: "//newsinfo.eastmoney.com/kuaixun/v2/api/list?column=108&limit=1",
            dataType: "jsonp",
            scriptCharset: "utf-8",
            jsonpCallback: "callback" + sjs,
            success: function (json) {
                if (json.rc == 1) {
                    var info = json.news;
                    var html = "";
                    html = '<li class="fl"><a href="http://kuaixun.eastmoney.com/zq.html" target="_blank" title ="' + info[0].title + '" >·' + common.cutstr(info[0].title, 80) + '</a></li> ';
                    $(".ScrollMIIRBox").html(html);
                }
            }
        });
    }

    //主要债券指数
    Bondstock.prototype.mainBondIndex = function () {
        var base = this
        var arr = ["1.000013", "0.399481", "1.000061", "1.000022", "1.000012"];
        var randomNum = +new Date();
        var src = "//webquotepic.eastmoney.com/GetPic.aspx?imageType=BKSR&token=44c9d251add88e27b65ed86506f6e5da&_=" + randomNum + "&nid=";
        var codestr = arr.join(",")
        var _url = this.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2'
        $.ajax({
            url: _url,
            dataType: "jsonp",
            jsonp: "cb",
            success: function (json) {
                var data = json.data.diff
                for (var i = 0; i < data.length; i++) {
                    var li = $(".listData" + i);
                    li.find(".closeSpan ").text(data[i].f2 == '-' ? '-' : ((data[i].f2) / 100).toFixed(2)).addClass(common.getColor((data[i].f3 == "-" ? 0 : data[i].f3) + ''));
                    li.find(".chpSpan ").text(data[i].f3 == '-' ? '-' : (((data[i].f3) / 100).toFixed(2) + '%')).addClass(common.getColor((data[i].f3 == "-" ? 0 : data[i].f3) + ''));
                    li.find("img").attr("src", src + arr[i]);
                }
            }
        });
    }

    Bondstock.prototype.loadRankTemplatenew = function (obj) {
        var base = this
        var pz = obj.pz || 5
        var _url = this.baseUrl + '/api/qt/clist/get?pn=1&pz=' + pz + '&po=1&np=1&ut=' + this.ut + '&fltt=2&invt=2&fid=f3&fs=' + obj.type + '&fields=f1,f2,f3,f12,f13,f14,f152'
        $.ajax({
            url: _url,
            dataType: "jsonp",
            jsonp: "cb",
            success: function (json) {
                var data = json.data.diff
                var htm = ''
                if (data instanceof Array) {
                    for (var i = 0; i < data.length; i++) {
                        var price = data[i].f2 == '-' ? '-' : (data[i].f2).toFixed(2)
                        var percent = data[i].f3 == '-' ? '-' : (data[i].f3.toFixed(2) + '%')
                        var color = data[i].f3 > 0 ? 'red' : data[i].f3 < 0 ? 'green' : ''
                        var link = obj.link ? obj.link.replace("{{code}}", data[i].f12) : ("http://quote.eastmoney.com/" + (data[i].f13 == 1 ? 'sh' : 'sz') + data[i].f12 + '.html')
                        htm += '<tr>'
                            + '<td><a href="' + link + '" title="' + data[i].f14 + '" target="_blank">' + data[i].f14 + '</a></td>'
                            + '<td class="' + color + '">' + price + '</td><td class="' + color + '">' + percent + '</td>'
                            + '</tr>'
                    }
                } else {
                    for (var i in data) {
                        var price = data[i].f2 == '-' ? '-' : (data[i].f2).toFixed(2)
                        var percent = data[i].f3 == '-' ? '-' : (data[i].f3.toFixed(2) + '%')
                        var color = data[i].f3 > 0 ? 'red' : data[i].f3 < 0 ? 'green' : ''
                        var link = obj.link ? obj.link.replace("{{code}}", data[i].f12) : ("http://quote.eastmoney.com/" + (data[i].f13 == 1 ? 'sh' : 'sz') + data[i].f12 + '.html')
                        htm += '<tr>'
                            + '<td><a href="' + link + '" title="' + data[i].f14 + '" target="_blank">' + data[i].f14 + '</a></td>'
                            + '<td class="' + color + '">' + price + '</td><td class="' + color + '">' + percent + '</td>'
                            + '</tr>'
                    }
                }

                $(obj.dom).html(htm)
            }
        });


    }

    var imgevt = instance.bindChartImgEvent();
    function refresh() {
        imgevt.changeImg();
        instance.bindDealDetail();
        var _link = "//quote.eastmoney.com/{{market | getShortMarket}}{{code}}.html";

        instance.loadRankTemplatenew({ type: "m:1+b:MK0353", dom: "#sh_enterprise_rank tbody" });
        instance.loadRankTemplatenew({ type: "m:0+b:MK0353", dom: "#sz_enterprise_rank tbody" });
        instance.loadRankTemplatenew({ type: "m:1+b:MK0351", dom: "#national_debt_rank tbody" });


        instance.mainBondIndex();
        //instance.quotePrice();
        instance.loadDetailDatanew()      //行情报价new
        globalZhb();



    }

    function init() {
        function onChangeDataRender($dom, item, settings) {
            if (item != 0 && item != "-") {
                if (item.isPositive()) {
                    $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");
                } else {
                    $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
                }
            } else {
                $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
            }
        }


        var loadQuoteDataOption = {
            ajax: {
                url: instance.baseUrl + '/api/qt/stock/get?secid=' + stockEnity.fullcode + "&ut=" + instance.ut + "&fields=f43,f169,f170,f46,f60,f84,f116,f44,f45,f171,f126,f47,f48,f168,f164,f49,f161,f55,f92,f59,f152,f167,f50,f86,f71,f172,f182,f191,f192,f532",
                data: {

                },
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get'
            },
            dataResolver: function (json) {
                var data = json["data"]
                var arr = []
                arr.push(data.f43 == 0 ? '-' : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59))//0最新价
                arr.push(data.f43 == 0 ? '-' : (data.f44 / Math.pow(10, data.f59)).toFixed(data.f59))//1最高价
                arr.push(data.f43 == 0 ? '-' : (data.f45 / Math.pow(10, data.f59)).toFixed(data.f59))//2最低价
                arr.push(data.f43 == 0 ? '-' : (data.f46 / Math.pow(10, data.f59)).toFixed(data.f59))//3开盘价
                arr.push(data.f43 == 0 ? '-' : data.f47)//4成交量
                arr.push(data.f43 == 0 ? '-' : data.f48)//5成交额(f48)
                arr.push(data.f43 == 0 ? '-' : data.f49)//6外盘
                arr.push(data.f55.toFixed(2))//7每股收益(f55) 
                arr.push(data.f59)// 8小数位数(f59)
                arr.push((data.f60 / Math.pow(10, data.f59)).toFixed(data.f59))//9昨收价(f60)
                arr.push(data.f84)//10总股本(股)(f84)
                arr.push(data.f92.toFixed(2))//11每股净资产(f92)
                arr.push(data.f116)//12总市值(f116)
                arr.push(data.f126)//13股息率(f126
                arr.push(data.f152)//14小数位数字段(2)
                arr.push(data.f43 == 0 ? '-' : data.f161)//15内盘(f161)
                arr.push(data.f164 / Math.pow(10, data.f152))//16市盈率(TTM)(f164)
                arr.push(data.f168)//17换手率(f168)
                arr.push(data.f43 == 0 ? '-' : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))//18涨跌值(f169) 
                arr.push(data.f43 == 0 ? '-' : data.f170)//19涨跌幅(f170) 
                arr.push(data.f43 == 0 ? '-' : data.f171)//20振幅(f171)
                arr.push(data.f43 == 0 ? '-' : data.f167 / Math.pow(10, data.f152))//21市净率(f167)
                arr.push(data.f43 == 0 ? '-' : data.f50 / Math.pow(10, data.f152))//22量比(f50)
                arr.push(common.formatDate(new Date(data.f86 * 1000), 'yyyy-MM-dd HH:mm:ss'))//23行情时间Unix时间戳，单位秒(f86)
                arr.push(data.f43 == 0 ? '-' : (data.f71 / Math.pow(10, data.f59)).toFixed(data.f59))//24均价(f71)
                arr.push(data.f19 == 0 ? '-' : (data.f19 / Math.pow(10, data.f59)).toFixed(data.f59))//25买入价
                arr.push(data.f39 == 0 ? '-' : (data.f39 / Math.pow(10, data.f59)).toFixed(data.f59))//26卖出价
                arr.push(data.f191 == 0 ? '-' : data.f191)//27卖出价
                arr.push(data.f192 == 0 ? '-' : data.f192)//28卖出价
                arr.push(data.f182)//29 判断国债企债可转债
                return arr;
            },
            fields: [
                {
                    name: "jk", num: 3, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[3]) ? 0 : data[3]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                { name: "zs", num: 9, hasColor: false, NumbericFormat: false },
                {
                    name: "zxj", num: 0, hasColor: true, NumbericFormat: false, blink: true,
                    comparer: function (data) { return isNaN(data[18]) ? 0 : data[18]; }
                },
                {
                    name: "zde", num: 18, hasColor: true, NumbericFormat: false, blink: true,
                    render: onChangeDataRender
                },
                { name: "zdf", num: 19, hasColor: true, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2) +'%'}}", blink: true },
                {
                    name: "zgj", num: 1, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[1]) ? 0 : data[1]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                {
                    name: "zdj", num: 2, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[2]) ? 0 : data[2]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                { name: "cjl", num: 4, hasColor: false, NumbericFormat: true },
                { name: "cje", num: 5, hasColor: false, NumbericFormat: true },
                { name: "BuyOrder", num: 6, hasColor: true, NumbericFormat: true, comparer: 1 },
                { name: "SellOrder", num: 15, hasColor: true, NumbericFormat: true, comparer: -1 },
                { name: "zf", num: 20, hasColor: false, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2)+'%'}}" },
                { name: "hsl", num: 17, hasColor: false, NumbericFormat: false, template: "{{data=='-'?'-':(data/100).toFixed(2)+'%'}}" },
                { name: "pe", num: 16, hasColor: false, NumbericFormat: false },
                { name: "sjl", num: 21, hasColor: false, NumbericFormat: false },
                { name: "mgsy", num: 7, hasColor: false, NumbericFormat: false },
                { name: "mgjzc", num: 11, hasColor: false, NumbericFormat: false },
                { name: "roe", num: 20, hasColor: false, NumbericFormat: false },
                { name: "zgb", num: 10, hasColor: false, NumbericFormat: true },
                { name: "zsz", num: 12, hasColor: false, NumbericFormat: true },
                { name: "lb", num: 22, hasColor: false, NumbericFormat: false },
                { name: "update", num: 23, hasColor: false, NumbericFormat: false, template: "{{data}}" },
                {
                    name: "jj", num: 24, hasColor: true, NumbericFormat: false,
                    comparer: function (data) { return (isNaN(data[24]) ? 0 : data[24]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                { name: "np", num: 15, hasColor: true, NumbericFormat: true },
                { name: "wp", num: 6, hasColor: true, NumbericFormat: true },
                {
                    name: "mrj", num: 25, hasColor: true, NumbericFormat: false, blink: true,
                    comparer: function (data) { return (isNaN(data[25]) ? 0 : data[25]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                {
                    name: "mcj", num: 26, hasColor: true, NumbericFormat: false, blink: true,
                    comparer: function (data) { return (isNaN(data[26]) ? 0 : data[26]) - (isNaN(data[9]) ? 0 : data[9]); }
                },
                {
                    name: "wb", num: 27, hasColor: true, NumbericFormat: false, blink: true,
                    template: "{{data=='-'?'-':(data/100).toFixed(2) +'%'}}"
                },
                {
                    name: "wc", num: 28, hasColor: true, NumbericFormat: false, blink: true
                },
                //{
                //    name: "IsGC", num: 35, handler: function (data) {
                //        if (data === 'True') {
                //            $("#basic-info").hide();
                //            $("#itffo-wrapper").hide();
                //        }
                //    }
                //},
                {
                    name: "IsConversionDebt", num: 29, handler: function (data) {
                        //7国债 8地方债 9企业债 10公司债 11 可转债
                        if (data == 11) {
                            if (noRefresh == 0) {
                                kzzBaseMsg();
                                kzzBaseMsgAddData();
                                var _serverTime = '';
                                //console.log(common.formatDate(string(new Date())), '日期')
                                if (!serverTime) {
                                    _serverTime = new Date().format('yyyy/MM/dd');
                                } else {
                                    _serverTime = serverTime
                                }
                                var time = dateFun(_serverTime, "yyyy/MM/dd");
                                time = new Date(time) - 0;
                                var time_31 = new Date("2019/05/31") - 0;

                                if (stockEnity.stockCode === "123006" && time < time_31) {
                                    $(".noticeBox").show()
                                    dcNoticeFun()
                                }
                                kzzTime();
                                var flag = baseMsg();
                                if (!flag) {
                                    $(".bkzhzhBox").hide();
                                    $(".kzhzhBox").show();
                                }

                                $(".data-middle").addClass("middleBox");
                                noRefresh++;
                            }
                            instance.aboutType("m:1+b:MK0354,m:0+b:MK0354");
                        } else {
                            if (noRefresh == 0) {
                                var flag = baseMsg();
                                if (!flag) {
                                    $(".kzhzhBox").hide();
                                }
                                //国债期货
                                $(".data-middle").removeClass("middleBox");
                                $(".kzhzhBox").hide();
                                $(".bkzhzhBox").show();
                                $(".data-right").hide();
                                noRefresh++;
                            }

                            instance.loadRankTemplatenew({
                                type: "m:8+t:169+f:!8192",
                                dom: "#debt_index_rank tbody",
                                pz: 6,
                                link: "//quote.eastmoney.com/gzqh/{{code}}.html"
                            });
                            instance.aboutType("m:1+b:MK0351");
                        }
                    }
                }
            ]
        }
        //只针对普B现金
        if (stockEnity.stockId == "7060561") {
            $('.zxj').html('0.416');
            $('.zs').html('0.416');
            $('.quote_title').append('<span class="color666 ">报价单位：美元/股</span>')
        } else {
        }
        instance.loadQuoteData(loadQuoteDataOption);
        bindPageEvent();
        imgevt.bindEvent();
        instance.setChart().bindEvent();
        instance.setHotGuba(15);
        refresh();

        $("#chartimg_select").hide();
    }
    init();

    setInterval(refresh, 20 * 1000);

// });


//加自选模块
;(function($){
    var zddzxobj = {
        //Cookie Common Class
        getCookie: function (key) {
            var result = document.cookie.match(new RegExp("(^| )" + key + "=([^;]*)"));
            return result != null ? unescape(decodeURI(result[2])) : null;
        },
         //判断是否登陆
        getLoginStatus: function() {
            var _this = this;
            if (_this.getCookie('ut') && _this.getCookie('ct') && _this.getCookie('uidal')) {
                return true;
            }
            return false;
        },
        //初始化判断状态
        getstatus: function(code, market) {
            var _this = this;
            var quotecode = market + "." + code;
            var islogin = _this.getLoginStatus();
            var zxgurl = 'http://myfavor1.eastmoney.com/' //f=gsaandcheck
            var addzx = function (zxgparams) {
                var apistr = 'mystock_web'
                if (!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl + '' + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp: 'cb'
                });
            }
            addzx({ f: 'gsaandcheck', sc: quotecode }).then(function (res) {
                if (res.result == "1") {
                    var checkstatus = res.data.check;
                    _this.changeStatus(checkstatus);
                }

            })
        },
        addFavorEvent: function(code, market) {
            var _this = this;
            var islogin = _this.getLoginStatus();
            var url_status = 'mystock_web'
            if (!islogin) {
                url_status = 'mystock_webanonym'
            }
            var _html = $("#addZX_bond").html();
            if (_html == "+加自选") {
                var f = "asz";
                var check = "True";
                $("#addZX_bond").html("-删自选");
                $("#addZX_bond").css("background", "#999");
                window.open("//quote.eastmoney.com/zixuan/?from=zixuanmini")
            } else {
                var f = "dsz";
                var check = "False";
                $("#addZX_bond").html("+加自选");
                $("#addZX_bond").css("background", "#ff4a03");
                $("#addZX_bond").removeAttr("href");
            }
            var _url = "http://myfavor1.eastmoney.com/" + url_status + "?f=" + f + "&sc=" + market + "." + code;
            $.ajax({
                url: _url,
                dataType: "jsonp",
                jsonp: "cb",
                success: function (json) {
                    if (json.result == "1") {
                        // _this.changeStatus(check);
                        if (check == 'False'){
                            window.location.reload();
                        }
                    }
                }
            });
        },
        changeStatus: function(checkstatus) {
            if (checkstatus == "True") {//加自选
                $("#addZX_bond").html("-删自选");
                $("#addZX_bond").css("background", "#999");
                // $("#addZX_bond").removeAttr("href");
            } else {
                $("#addZX_bond").html("+加自选");
                $("#addZX_bond").css("background", "#ff4a03");
                // $("#addZX_bond").attr("href", "//quote.eastmoney.com/zixuan/?from=zixuanmini");
            }
        },
        init: function() {
            var _this = this;
            var code = $("#addZX_bond").attr("data-code")
            var market = $("#addZX_bond").attr("data-market");
            if(!code)return;
            $("#addZX_bond").on('click', function () {
                // var code = $(this).attr("data-code")
                // var market = $(this).attr("data-market");
                _this.addFavorEvent(code, market);
            })

            _this.getstatus(code, market);
        }
    }
    zddzxobj.init();
})(jQuery);




