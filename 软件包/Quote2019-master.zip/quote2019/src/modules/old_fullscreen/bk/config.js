var fomrat = require("../common/format");
var geturl = require("../tools/url");
module.exports = {

    host: geturl.get_url(),
    head: [
        [
            {
                name: "今开：",
                cls: "jk",
                color: "zs",
                type: 1
            },
            {
                name: "昨收：",
                cls: "zs",
                color: "zs"
            }
        ],
        [
            {
                name: "最高：",
                cls: "zg",
                color: "zs"
            },
            {
                name: "最低：",
                cls: "zd",
                color: "zs"
            }
        ],
        [
            {
                name: "涨跌幅：",
                cls: "zdf",
                sub: "%",
                color: 0
            },
            {
                name: "涨跌额：",
                cls: "zde",
                color: 0
            }
        ],
        [
            {
                name: "成交量：",
                cls: "cjl",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "成交额：",
                cls: "cje",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "内盘：",
                cls: "np",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "外盘：",
                cls: "wp",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "换手：",
                sub: "%",
                cls: "hs",
            },
            {
                name: "振幅：",
                sub: "%",
                cls: "zf",
            }
        ],
        [
            {
                name: "上涨家数：",
                cls: "szjs",
                sub: "家"
            },
            {
                name: "下跌家数：",
                cls: "xdjs",
                sub: "家"
            }
        ],
        [
            {
                name: "量比：",
                cls: "lb"
            },
            {
                name: "平盘家数：",
                cls: "ppjs",
                sub: "家"
            }
        ],
        [
            {
                name: "流通市值：",
                cls: "lz",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "流通股本：",
                cls: "ltg",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ]
    ]


};