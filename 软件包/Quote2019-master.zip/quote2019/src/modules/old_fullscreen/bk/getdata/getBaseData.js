var merge = _.merge;

var renderHead = require("../../common/renderHead");
var uri = require("../../common/uri");
var config = require("../config");

// var renderJdzf = require("./renderJdzf");
var renderZjl = require("./renderZjl");

function data(par) {
    this.par = par;

    this.publicData = {};

    
    this.getData();

    this.getSSEData();
}

data.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58, 106],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85, 50],       // 基础字段
        [119, 120, 121, 122],      // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                that.format(obj.data);
            }

        }
    });

}


data.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58, 106],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85, 50],       // 基础字段
        [119, 120, 121, 122],      // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = config.host + "api/qt/stock/sse?" + uri.parStringify(data);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }

}


data.prototype.format = function (d) {
    // console.log(d);
    var pdata = this.publicData;

    var oldo = this.o || {};       // 旧的对象
   
    var o = {};

    var f = oldo.f || Math.pow(10, d.f59) || 1;
    var f59 = oldo.f59 || d.f59;
    if (f59 < 2) {
        f59 = 2;
    }
    o.f59 = f59;
    o.f = f;

    if (d.f85) {
        o.ltg = d.f85;  // 流通股
    }



    if (d.f58) {
        o.name = d.f58;
    }
    if (d.f57) {
        o.code = d.f57;
    }


    if (d.f43) {
        o.xj = (d.f43 / f).toFixed(f59) || "-";
    }
    if (d.f46) {
        o.jk = (d.f46 / f).toFixed(f59) || "-";
    }
    if (d.f60) {
        o.zs = (d.f60 / f).toFixed(f59);
    }
    if (d.f44) {
        o.zg = (d.f44 / f).toFixed(f59) || "-";
    }
    if (d.f45) {
        o.zd = (d.f45 / f).toFixed(f59) || "-";
    }
    if (d.f43) {
        var zs = (oldo.zs || d.f60 / f);
        o.zde = (d.f43 / f - zs).toFixed(f59);
        o.zdf = ((d.f43 / f - zs) / zs * 100).toFixed(f59);
    }
    // if ((oldo.ltg || d.f85) && d.f47) {
    //     var ltg = oldo.ltg || d.f85;
    //     o.hs = ((d.f47 / ltg) * 100).toFixed(f59);
    // }
    if (d.f106) {
        o.f106 = d.f106;
    }
    if ((oldo.ltg || d.f85) && d.f47) {
        var ltg = oldo.ltg || d.f85;
        var f106 = oldo.f106 || d.f106;
        o.hs = ((d.f47 / ltg * f106) * 100).toFixed(f59);
    }
    if (d.f44 || d.f45) {
        var zg = d.f44 / f || oldo.zg;
        var zd = d.f45 / f || oldo.zd;
        var zs = oldo.zs || d.f60 / f;
        o.zf = ((zg - zd) / zs * 100).toFixed(f59);
    }
    if (d.f50) {
        o.lb = (d.f50 / 100).toFixed(f59);
    }
    if (d.f47) {
        o.cjl = d.f47;
    }
    if (d.f48) {
        o.cje = d.f48;
    }
    if (d.f49) {
        o.wp = d.f49;
        o.np = (oldo.cjl || d.f47) - d.f49;
    }
    if (d.f113) {
        o.szjs = d.f113;
    }
    if (d.f114) {
        o.xdjs = d.f114;
    }
    if (d.f115) {
        o.ppjs = d.f115;
    }
    if (d.f117) {
        o.lz = d.f117;
    }

    o.jdzf = {};
    if (d.f119) {
        o.jdzf.day5 = d.f119 / 100;
    }
    if (d.f120) {
        o.jdzf.day20 = d.f120 / 100;
    }
    if (d.f121) {
        o.jdzf.day60 = d.f121 / 100;
    }
    if (d.f122) {
        o.jdzf.dayyear = d.f122 / 100;
    }


    o.zjl = {
        // zl: [d.f135, d.f136, d.f137],
        // // ot: [
        // //     ["超大", d.f138, d.f139, d.f140],
        // //     ["大单", d.f141, d.f142, d.f143],
        // //     ["中单", d.f144, d.f145, d.f146],
        // //     ["小单", d.f147, d.f148, d.f149]
        // // ],
        // cd: [],
        // dd: [],
        // zd: [],
        // xd: []
    }

    // 其他 4个
    if (d.f135 || d.f136 || d.f137) {
        o.zjl.zl = [d.f135, d.f136, d.f137];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.cd = [d.f138, d.f139, d.f140];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.dd = [d.f141, d.f142, d.f143];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.zd = [d.f144, d.f145, d.f146];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.xd = [d.f147, d.f148, d.f149];
    }

    try {
        // 净资金流
        o.zjl.jzjl = [
            d.f140 || oldo.zjl.cd[2],
            d.f143 || oldo.zjl.dd[2],
            d.f146 || oldo.zjl.zd[2],
            d.f149 || oldo.zjl.xd[2]
        ];
    } catch (error) {

    }


    this.o = merge(oldo, o);
    // console.log(this.o)


    this.render(o);

}


data.prototype.render = function (obj) {

    renderHead(config.head, obj);
    // renderJdzf(obj);
    renderZjl(obj);


}

module.exports = data;