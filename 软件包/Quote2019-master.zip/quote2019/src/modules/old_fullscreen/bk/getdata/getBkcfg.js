var uri = require("../../common/uri");
var config = require("../config");

function cfg(par) {
    this.par = par;

    this.getData();
    this.getSSEData();
}


cfg.prototype.getData = function () {
    var that = this;

    var pars = {
        pn: 1,
        pz: 20,
        po: 1,
        fid: "f3",
        fields: "f1,f2,f3,f4,f12,f13,f14",
        fs: "b:" + this.par.code,
        ut: "fa5fd1943c7b386f172d6893dbfba10b"
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/clist/get?" + uri.parStringify(pars);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                that.render(obj);
            }

        }
    });

}



cfg.prototype.getSSEData = function () {
    var that = this;
    that.flag = 0;

    var pars = {
        pn: 1,
        pz: 20,
        po: 1,
        fid: "f3",
        fields: "f1,f2,f3,f4,f12,f13,f14",
        fs: "b:" + this.par.code,
        ut: "fa5fd1943c7b386f172d6893dbfba10b"
    }

    var fullurl = config.host + "api/qt/clist/sse?" + uri.parStringify(pars);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        // console.log(msg.data);
        var obj = JSON.parse(msg.data)
        // console.log(obj.data);
        that.render(obj);
    }

}



cfg.prototype.render = function (data) {
    var that =this;
    var bkcfg = $(".bkcfg tbody");
    var sdata = this.diff;

    // console.log(data.data);

    if (data.full == 1 && that.flag ==0) {
        that.flag =1;
        if (!data.data) {
            return false;
        }
        
        var diff = data.data.diff;
        var trs = [];
        for (var k in diff) {
            var item = diff[k];
            item._sortIndex = k;

            var f1 = item.f1;
            var pow = Math.pow(10, f1);
            var prise = (item.f2 / pow).toFixed(f1);
            var zdf = (item.f3 / pow).toFixed(f1);
            var zde = item.f4 / pow;

            var tr = $("<tr></tr>");
            var lianjie = '';
            if(item.f13 == 0) {
                lianjie = 'sz' + item.f12
            }else {
                lianjie = 'sh' + item.f12
            }
            var td1 = $('<a target="_blank" href="'+ 'http://quote.eastmoney.com/concept/'+ lianjie +'.html?from=bkqp#fschart-r' +'"></a>').text(item.f14);
            var td2 = $("<td></td>").text(prise);
            var td3 = $("<td></td>").text(zdf + "%");
            if (zde > 0) {
                td2.addClass("rise");
                td3.addClass("rise");
            } else if (zde < 0) {
                td2.addClass("fall");
                td3.addClass("fall");
            }
            tr.append(td1, td2, td3);
            tr.attr("data-sortindex", k);
            trs.push(tr);
                bkcfg.append(tr);
            
            
            
        }

        this.diff = diff;
        this.trs = trs;

       
    } else if(data.data){
        // var diff = this.diff;
        var trs = this.trs;

        var mv = data.data.mv;
        var diff = data.data.diff;

        // console.log(mv);
        
        // outhtml(trs);

        // 改变索引位置
        for (var k in mv) {
            trs[k].attr("data-sortindex", mv[k]);
        }
        // outhtml(trs);

        trs.sort(function(a, b){
            var ai = a.attr("data-sortindex");
            var bi = b.attr("data-sortindex");
            return ai - bi;
        });
        

        // 更新价格
        for (var k in diff) {
            var d = diff[k];
            var f1 = sdata[k / 1].f1;
            var pow = Math.pow(10, f1);
            var prise = (d.f2 / pow).toFixed(f1);
            var zdf = (d.f3 / pow).toFixed(f1);
            var zde = d.f4 / pow;

            var tr = trs[k / 1];
            var td2 = tr.find("td").eq(0);
            td2.text(prise);
            var td3 = tr.find("td").eq(1);
            td3.text(zdf + "%");

            if (zde > 0) {
                td2.removeClass().addClass("rise");
                td3.removeClass().addClass("rise");
            } else if (zde < 0) {
                td2.removeClass().addClass("fall");
                td3.removeClass().addClass("fall");
            }
        }
        // outhtml(trs);

        for(var i = 0, len = trs.length ; i < len ; i++){
            bkcfg.append(trs[i]);
        }

        // console.log("-----------------------");

    }


}



function outhtml(trs){
    console.log("==========");
    for (var i = 0; i < trs.length; i++) {
        console.log(trs[i].attr("data-sortindex") + "  " + trs[i].html());
    }
}



module.exports = cfg;