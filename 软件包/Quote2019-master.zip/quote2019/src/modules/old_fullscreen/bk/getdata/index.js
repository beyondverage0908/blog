var getBaseData = require("./getBaseData");
var getBkcfg = require("./getBkcfg");

module.exports = function(par){

    new getBaseData(par);
    new getBkcfg(par);

};