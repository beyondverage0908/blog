module.exports = function(ctm, pars){
    var that = this;

    this.ctm = ctm;
    this.pars = pars;


    $(".switchbar li,.switchbar .multi p").each(function(index, item){
        var t = $(item).attr("data-type");
        if (t == that.pars.type) {
            if (t.indexOf("t") == 0) {
                $(".day5 span").text($(item).text());
                $(".day5").addClass("active");
                $(".day5").attr("data-type", t);
            } else {
                $(item).addClass("active")
            }
        }
    });

    
    
    
    $(".switchbar").on("click", "li span", function(){

        var li = $(this).parent();

        var type = li.attr("data-type");

        $(".switchbar li").removeClass("active");
        li.addClass("active");

        // console.log(type);

        ctm.setType(type)
        
    });


    $(".switchbar").on("click", ".day5 .multi-day", function(){
        var t = $(this);
        if (t.hasClass("triangle-inline-down")) {
            t.removeClass("triangle-inline-down").addClass("triangle-inline-up");
            $(".multi").show();
        } else {
            t.removeClass("triangle-inline-up").addClass("triangle-inline-down");
            $(".multi").hide();
        }
    });
    

    $(".multi").on("click", "p", function(){
        var txt = $(this).text();
        var t = $(this).attr("data-type");
        $(".switchbar li").removeClass("active");
        $(".day5").attr("data-type", t);
        $(".day5").addClass("active");
        $(".day5 span").text(txt);
        $(".multi").hide();
        $(".multi-day").removeClass("triangle-inline-up").addClass("triangle-inline-down");

        // console.log(t);
        ctm.setType(t);
    });
    
};