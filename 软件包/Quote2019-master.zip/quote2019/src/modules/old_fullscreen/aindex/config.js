var fomrat = require("../common/format");
var geturl = require("../tools/url");
module.exports = {

    
    //host: "http://61.152.230.32:38618/", //61.129.249.233:18665  61.152.230.32:38618
    host: geturl.get_url(),
    head: [
        [
            {
                name: "今开：",
                cls: "jk",
                color: "zs"
            },
            {
                name: "昨收：",
                cls: "zs",
                color: "zs"
            }
        ],
        [
            {
                name: "最高：",
                cls: "zg",
                color: "zs"
            },
            {
                name: "最低：",
                cls: "zd",
                color: "zs"
            }
        ],
        [
            {
                name: "涨跌幅：",
                cls: "zdf",
                sub: "%",
                color: 0
            },
            {
                name: "涨跌额：",
                cls: "zde",
                color: 0
            }
        ],
        [
            {
                name: "换手：",
                sub: "%",
                cls: "hs",
            },
            {
                name: "振幅：",
                sub: "%",
                cls: "zf",
            }
        ],
        [
            {
                name: "成交量：",
                cls: "cjl",
                cb: function(num){
                    return fomrat.num(num);
                }
            },
            {
                name: "成交额：",
                cls: "cje",
                cb: function(num){
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "内盘：",
                cls: "np",
                cb: function(num){
                    return fomrat.num(num);
                }
            },
            {
                name: "外盘：",
                cls: "wp",
                cb: function(num){
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "上涨家数：",
                cls: "szjs",
                sub: "家"
            },
            {
                name: "下跌家数：",
                cls: "xdjs",
                sub: "家"
            }
        ],
        [
            {
                name: "流值：",
                cls: "lz",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "平盘家数：",
                cls: "ppjs",
                sub: "家"
            }
        ]
    ]
    
    
};