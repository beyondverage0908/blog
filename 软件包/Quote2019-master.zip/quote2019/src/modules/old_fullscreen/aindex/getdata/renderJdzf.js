var flicker = require("../../common/flicker");

// 阶段涨幅


module.exports = function(obj){

    var jdzf = $(".jdzf");

    var data = obj.jdzf;

    for (var k in data) {
        var val = data[k];
        var span = jdzf.find("." + k);
        span.text((val).toFixed(2) + "%");
        if (val > 0) {
            span.addClass("rise");
        } else if (val < 0) {
            span.addClass("fall");
        }
        flicker(span);
    }
    
    
};

