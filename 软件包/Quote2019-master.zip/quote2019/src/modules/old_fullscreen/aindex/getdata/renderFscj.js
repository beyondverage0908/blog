var fall = require("../../img/fall.png");
var rise = require("../../img/rise.png");


function fscj() {
    this.count = 16;
    this.flag = 0;
    
}


fscj.prototype.clear = function(){
    this.list = []
}

fscj.prototype.setData = function (data) {
    if (data.prePrice) {
        this.prePrice = data.prePrice;
    }

    var list = this.list || [];

    var details = data.details;
    this.list = list.concat(details);

    if (this.list.length > this.count) {
        this.list.splice(0, this.list.length - this.count)
    }
    this.render();
}




fscj.prototype.render = function () {

    var details = this.list;
    var prePrice = this.prePrice;
    $(".fscj table").html("")

    var tbody = $(".fscj table");


    for (var i = details.length - 1; i >= 0; i--) {
        var ar = details[i].split(",");

        var tr = $("<tr></tr>");
        var td1 = $("<td></td>").text(ar[0]);
        var td2 = $("<td></td>").text(ar[1]);
        if (ar[1] > prePrice) {
            td2.addClass("rise");
        } else if (ar[1] < prePrice) {
            td2.addClass("fall");
        }
        var td3 = $("<td></td>");

        if (ar[4] == 2) {
            td3.addClass("rise");
        } else if (ar[4] == 1){
            td3.addClass("fall");
        } else {
            td3.addClass("rise");
        }
        var span = $("<span></span>").text(ar[2]);
        var img = $("<img/>")
        if (ar[4] == 2) {
            img.attr("src", rise);
        } else if (ar[4] == 1){
            img.attr("src", fall);
        }else {
            img.attr("src", '');
        }
        span.append(img);
        td3.append(span);

        tr.append(td1, td2, td3);

        tbody.append(tr);
    }



}

module.exports = fscj;