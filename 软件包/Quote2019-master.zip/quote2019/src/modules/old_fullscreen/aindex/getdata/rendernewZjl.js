var format = require("../../common/format");
var flicker = require("../../common/flicker");

module.exports = function (obj) {

    var zjl = $(".righ .zjl");

    // 主力流向
    var zldata = obj.zjl.zl;
    // console.log(zldata)
    // [125743119616, 119175125760, 6567993856]

    // console.log(obj.zjl);

    if (zldata && zldata.length > 0) {
        var lx = zjl.find(".zjl-lx span");
        var rows = zjl.find(".zjl-lx .row");
        for (var i = 0; i < lx.size(); i++) {
            var lxi = lx.eq(i).text(format.num(zldata[i]));
            if (i == 0) {
                lxi.addClass("rise")
            }
            if (i == 1) {
                lxi.addClass("fall")
            }
            if (i == 2) {
                lx.eq(i).text(format.num(Math.abs(zldata[i])));
                if (zldata[2] > 0) {
                    rows.eq(i).find("label").text("主力净流入");
                    lxi.addClass("rise")
                } else if (zldata[2] < 0) {
                    rows.eq(i).find("label").text("主力净流出");
                    lxi.addClass("fall")
                }
            }
            flicker(lxi)
        }
    }


        // 其他
        var table = zjl.find(".zjl-table tbody");
        var names = ["超大", "大单", "中单", "小单"];
        var otzjl = [obj.zjl.cd, obj.zjl.dd, obj.zjl.zd, obj.zjl.xd];
        // console.log('otzjl')
        // console.log(otzjl)
        for (var i = 0, len = otzjl.length; i < len; i++) {
            var row = otzjl[i];
            if (row && row.length > 0) {
                var tr = table.find("tr").eq(i);
                tr.find("td").eq(0).text(names[i]);
                for (var ii = 0; ii < 2; ii++) {
                    if (row[ii] !== undefined && row[ii] + "" !== "NaN") {
                        var td = tr.find("td").eq(ii + 1);
                        var val = format.num(row[ii], 2);
                        td.text(val);
                        if (ii == 0) {
                            td.addClass("rise")
                        }
                        if (ii == 1) {
                            td.addClass("fall")
                        }
                        // flicker(td);     // 资金流全部发生变化，所有不要了
                    }
                }
            }
        }
    
    
        // 净资金流图
        var names = ["净超大", "净大单", "净中单", "净小单"];
        var jzjl = obj.zjl.jzjl || [];
    
        var max = null;
        for (var i = 0; i < jzjl.length; i++) {
            max = max > jzjl[i] ? max : jzjl[i];
        }
        // console.log(max)
    
        var trs = $(".zjl-chart tr");
        for (var i = 0; i < jzjl.length; i++) {
            trs.eq(2).find("td").eq(i).text(names[i]);
    
            var val = jzjl[i] || 0;
            var td1 = trs.eq(0).find("td").eq(i);
            var td2 = trs.eq(1).find("td").eq(i);
            if (val > 0) {
                td1.find("span").height(Math.abs(val / max) * 30 + 1 + "px");
                td2.text((val / 100000000).toFixed(2));
            } else {
                td2.find("span").height(Math.abs(val / max) * 30 + 1 + "px");
                td1.text((val / 100000000).toFixed(2));
            }
    
        }






};