


var URI = require('./em-urijs');
var marge = _.merge
var utils = require('./em-utils');
var cookie = utils.cookie;
var chartmanager = require('./em-chartmanager');
var minutedeals = require('./components/quote-parts/deals');
var TopSpeedQuote = require('./components/quote-parts/push');

require('./modules/jquery.tooltip');
require('./modules/jquery.fullscreen');


require('./modules/ie_sse_polyfill');

function h5chartkcb() { 
    var query = URI.parseQuery(location.search);
    var stockentry = {
        code: query.code,
        marketnum: query.market,
        shortmarket: query.market === "1" ? "sh" : "sz",
        id: query.id || (query.code + query.market)
    }
    
    this.init = function () {
        var chartTpye = (query.type || '').toLowerCase();

        //老的分时成交  注释掉
        // new minutedeals({
        //     id: stockentry.id
        // }).load();

        //之前的实时数据和画图方法
        renderQuote.apply(this);
        renderChart.apply(this, [chartTpye]);

        //新图
        newrenderChart.apply(this, [chartTpye]);

        $('#quote-code').html(stockentry.code);
        // var offset_tips_h = $('#deal_detail').offset().top;
        var offset_tips_h = $('#deal_detail').offset().top;
        var new_offset_tips_h =  $('.wbc-table').height() + $('#sell-table').height() + $('#buy-table').height() + $('#tips-box').height()
        var msg_h = $('#detail-msg-more').height();
        var _height = $(window).height() - new_offset_tips_h - msg_h - 22;
        if (_height <= 90) {
            _height = 90;
        }
        $('.deal_detail').height(_height);


        //xin
        setTimeout(function() {
            getHeadData();
        }, 1000)
        

        getFSData();



    }
    
    var tsq;
    function renderChart(type) {
        type = type || '0r';
        var wh = Math.max(568, $(window).height());
        var offset_h = $('#chart-container').offset().top;
        var _width, _height;
        _height = Math.floor(wh - offset_h) - 5;
        var rBoxW = $('#r-box-table').outerWidth(true)
    
        if ($(window).width() >= 1200) {
            _width = Math.floor($(window).width() - rBoxW);
        } else {
            _width = 1200 - rBoxW;
        }
        var cyqtypes = ['k', 'wk', 'mk', 'm5k', 'm15k', 'm30k', 'm60k'];
        var authority = getExrightsType();
        var options = {
            entry: stockentry,
            type: type,
            width: _width,
            height: _height,
            iscr: tsq.status === 'pre',
            authorityType: authority,
            update: tsq.status === 'close' ? -1 : 60 * 1000,
            padding: {
                top: 0,
                bottom: 0
            },
            onComplete: function () {
                $('#chart-container').trigger('drawComplete.emchart');
            }
            // update: 60 * 1000
        };
        this.chartType = options.type;
        var timeloader = new chartmanager('time', options),
            kloader = new chartmanager('k', options),
            timechart, kchart;

        var $cr = $('#type-selector i[data-type=cr]');
        $('#quote-time').on('tick', function (e, time, status) {
            if (status === 'close') {
                timeloader.stop();
                kloader.stop();
            }
        }).one('tick', function (e, time, status) {
            if (status === 'pre') {
                if (!$cr.hasClass('cur')) $cr.click();
            }
        });
    
        $('#quote-close-main').on('tsq.change', function (e, data) {
            var opt = $('#chart-container').data();
            if (!timechart || opt.charttype !== 'r') return false;
            var chartdata = timeloader.datacache.time;
            if (chartdata && chartdata.data instanceof Array) {
                var minute = chartdata.data.pop();
                if (typeof minute === 'string') {
                    var items = minute.split(',');
                    if (items[1] != data) {
                        items[1] = data;
                        chartdata.data.push(items.join(','));
                        timechart.setData(timeloader.datacache);
                        timechart.redraw();
                    } else {
                        chartdata.data.push(minute);
                    }
                }
            }
        });
    
        /** @type {chartmanager} */
        var chartloader;
        //之前点击事件
        // $('#type-selector .dataType').click(function () {
        //     $('#rk-box .rk-options').hide();
        //     $('#rk-box .select-icon').removeClass("select-up");
        //     $('#select-authority').removeClass('cur');
        //     if (chartloader) chartloader.stop();
        //     chartloader = timeloader;
        //     var $dom = $(this);
        //     if ($dom.hasClass('cur')) return false;
        //     var type = $dom.data('type');
        //     var displayTools = false;
        //     $('#type-selector .dataType.cur,#day-selector.cur').removeClass('cur');
        //     options.type = type;
        //     if (type === 'r') {
        //         $('#rk-box .r-box').hide(); //分时的时候右侧所有按钮隐藏   
        //         $('#day-selector').removeClass('cur');
        //         options.iscr = false;
        //         options.type = type;
        //     } else if (type === 'cr') {
        //         $('#rk-box .r-box').hide(); //盘前的时候右侧所有按钮隐藏       
        //         options.iscr = true;
        //         options.type = 'r';
        //     } else if (['t2', 't3', 't4', 't5'].indexOf(type) >= 0) {
        //         options.iscr = false;
        //         $('#day-selector').addClass('cur');
        //         $('#day-selector .rk-options').hide();
        //         $('#rk-box  .cmfb-li').hide();
        //     } else {
        //         displayTools = true;
        //         $('#day-selector').removeClass('cur');
        //         if (cyqtypes.indexOf(type) < 0) {
        //             $('#btn-cyq').hide();
        //             if ($('#btn-cyq').hasClass('cur')) {
        //                 $('#btn-cyq').click();
        //             }
        //             $('#select-authority').hide();
        //             options.yAxisType = 2;
        //         } else {
        //             $('#btn-cyq').show();
        //             $('#select-authority').show();
        //         }
        //         chartloader = kloader;
        //     }
        //     $('#chart-container').data('charttype', options.type);
        //     displayKChartToolBar(displayTools);
        //     $dom.addClass('cur');
        //     var currentchart = chartloader.load();
        //     if (options.type === 'r') {
        //         timechart = currentchart;
        //     } else {
        //         kchart = currentchart;
        //     }
        //     return false;
        // });



        $('#type-selector .dataType').click(function () {
            $('#rk-box .rk-options').hide();
            $('#rk-box .select-icon').removeClass("select-up");
            $('#select-authority').removeClass('cur');
            if (chartloader) chartloader.stop();
            chartloader = timeloader;
            var $dom = $(this);
            if ($dom.hasClass('cur')) return false;
            var type = $dom.data('type');
            var displayTools = false;
            $('#type-selector .dataType.cur,#day-selector.cur').removeClass('cur');
            options.type = type;
            // if (type === 'r') {
            //     $('#rk-box .r-box').hide(); //分时的时候右侧所有按钮隐藏   
            //     $('#day-selector').removeClass('cur');
            //     options.iscr = false;
            //     options.type = type;
            // } else if (type === 'cr') {
            //     $('#rk-box .r-box').hide(); //盘前的时候右侧所有按钮隐藏       
            //     options.iscr = true;
            //     options.type = 'r';
            // } else if (['t2', 't3', 't4', 't5'].indexOf(type) >= 0) {
            //     options.iscr = false;
            //     $('#day-selector').addClass('cur');
            //     $('#day-selector .rk-options').hide();
            //     $('#rk-box  .cmfb-li').hide();
            // } 

            // console.log('type')
            // console.log(type)
            // console.log(['t2', 't3', 't4', 't5'].indexOf(type))
            if(type === '0r' || (['t2', 't3', 't4', 't5'].indexOf(type) >= 0)) {
                //老方法 日k之前的点击事件全都注释

            }
            else {

                //显示拉长 缩短
                $("#btn-drawback").show();
                $("#btn-stretchout").show();


                displayTools = true;
                $('#day-selector').removeClass('cur');
                if (cyqtypes.indexOf(type) < 0) {
                    $('#btn-cyq').hide();
                    if ($('#btn-cyq').hasClass('cur')) {
                        $('#btn-cyq').click();
                    }
                    $('#select-authority').hide();
                    options.yAxisType = 2;
                } else {
                    $('#btn-cyq').show();
                    $('#select-authority').show();
                }
                chartloader = kloader;
            
            $('#chart-container').data('charttype', options.type);
            displayKChartToolBar(displayTools);
            $dom.addClass('cur');
            var currentchart = chartloader.load();

        }
            if (options.type === 'r') {
                timechart = currentchart;
            } else {
                kchart = currentchart;
            }
            return false;
        });





    
        $('#day-selector .click-icon').click(function (event) {
            $('#authority-options').hide();
            $('#select-authority').removeClass('cur');
            $('#select-authority .select-icon').removeClass("select-up");
    
            if ($('#day-selector .select-icon').hasClass('select-up')) {
                if (!$('#day-selector .selected-box ').hasClass('cur')) {
                    //考虑点击之前就已经是cur状态所以要判断
                    $('#day-selector').removeClass('cur');
                }
                $('#day-selector .rk-options').hide();
                $('#day-selector .select-icon').removeClass("select-up");
            } else {
                //加cur为防止鼠标离开的时候rk-options未消失上面的盒子已经变橙色
                $('#day-selector').addClass('cur');
                $('#day-selector .rk-options').show();
                $('#day-selector .select-icon').addClass("select-up");
            }
            return false;
    
        });
    
        //5日
        // $('#day-selector .data-type').click(function () {
        //     displayKChartToolBar(false);
        //     var $dom = $(this);
        //     $('#day-selector .rk-options').hide();
        //     $('#day-selector .select-icon').removeClass("select-up");
    
        //     if ($dom.hasClass('cur')) return false;
        //     var type = $dom.data('type');
        //     var _html = $dom.html();
        //     if (type == "r") {
        //         $("#day-selector").removeClass("cur");
        //         $('#type-selector .dataType').removeClass('cur');
        //         $('#type-selector .fshBox').addClass("cur");
        //     } else {
        //         $('#type-selector .dataType').removeClass("cur");
        //         $('#day-selector').addClass("cur");
        //         $('#day-selector .selected-box').html(_html).attr('data-type', type);
        //         $('#selected-box').removeClass('cur');
        //         $('#day-selector .data-type').removeClass("cur");
        //         $dom.addClass('cur');
        //     }
        //     options.iscr = false;
        //     options.type = type;
        //     timechart = timeloader.load();
        //     return false;
        // });
    
        $('[data-type=' + type + ']', '#type-selector, #day-selector').click();
    
        //拉长
        $('#btn-stretchout').click(function (e) {
            $('#rk-box .rk-options').hide();
            $('#rk-box .select-icon').removeClass("select-up");
            $('#select-authority').removeClass('cur');
    
            if (typeof kchart.elongate === 'function')
                kchart.elongate();
            return false;
        });
    
        //缩短
        $('#btn-drawback').click(function (e) {
            $('#rk-box .rk-options').hide();
            $('#rk-box .select-icon').removeClass("select-up");
            $('#select-authority').removeClass('cur');
    
            if (typeof kchart.shorten === 'function')
                kchart.shorten();
            return false;
        });
    
        //读取存入的前后复权
        if (typeof authority === 'string') {
            $('#authority-options>span').removeClass('cur')
            $('#authority-options>span').each(function () {
                if ($(this).attr('value') == authority) {
                    var html = $(this).html();
                    var val = $(this).attr('value');
                    $(this).addClass('cur');
                    $("#authority-options i.cur").html();
                    $("#select-authority .selected-box").html(html).attr('value', val);
                }
            })
        }
    
        //前后复权的下拉点击
        $('#select-authority').click(function () {
            $('#day-selector .rk-options').hide();
            $('#day-selector .select-icon').removeClass("select-up");
    
            if ($('#select-authority .select-icon').hasClass("select-up")) {
                $('#authority-options').hide();
                $('#select-authority').removeClass('cur');
                $('#select-authority .select-icon').removeClass("select-up");
    
            } else {
                $('#authority-options').show();
                $('#select-authority').addClass('cur');
                $('#select-authority .select-icon').addClass("select-up");
            }
    
            return false;
        });
    
        // 前后复权的下来盒子里的内容点击事件
        $('#authority-options>span').click(function () {
            var html = $(this).html();
            var val = $(this).attr('value');
            //var selected_val = $('#select-authority .selected-box').attr('value');
            var _html = $('#authority-options .cur').html();
            $('#authority-options').hide();
            $('#select-authority').removeClass('cur');
            if (html == _html) {
                return false
            };
            $('#authority-options .cur').removeClass("cur");
            $(this).addClass('cur');
            $("#select-authority .selected-box").html(html).attr('value', val);
            $('#select-authority .select-icon').removeClass("select-up");
            setExrightsType(val || '');
            options.authorityType = val;
            kchart = kloader.load();
            return false;
        });
    
        //点击页面其他地方下拉的盒子都隐藏
        $(document).click(function () {
            $('#rk-box .rk-options').hide();
            $('#rk-box .select-icon').removeClass("select-up");
            $('#select-authority').removeClass('cur');
            //点击了下拉没有选的时候可能会出现两个cur排除并删除一个   
            if ($('#day-selector').hasClass('cur') && $('#type-selector .dataType').not(".selected-box").hasClass('cur')) {
                $('#day-selector').removeClass('cur');
            }
        });
    
        var $cyqtips = $('<div class="cyq-tips"><span class="tips fl">筹码分布<b class="icon-help"></b></span><a class="close fr"><b class="icon-leave"></b>离开</a></div>');
        $cyqtips.find('.tips').tooltip({
            content: '红色筹码表示低于收盘价的获利筹码，蓝色筹码表示高于收盘价的套牢筹码'
        });
        $cyqtips.find('.close').click(function (e) {
            $('#btn-cyq').click();
            return false;
        });
    
        //筹码分布点击事件
        $('#btn-cyq').click(function (e, redraw) {
            var $this = $(this);
            if (!$this.hasClass('cur')) {
                $('#kchart-toolbar').data('cyq', true);
                $this.addClass('cur');
                $('.is-hide', $('#r-box-table')).hide();
                $('#r-box-table .wbc-table').css('height', '32px');
                $('#sell-table').css('border', 0);
                $('#chart-container').trigger('loadcyq.emchart');
            } else {
                $this.removeClass('cur');
                $('#kchart-toolbar').data('cyq', false);
                $('.is-hide', $('#r-box-table')).show();
                $('#r-box-table .wbc-table').css('height', '56px');
                $('#sell-table').css('border-bottom', 'solid 1px #e5e5e5');
                $('#chart-container').trigger('destorycyq.emchart');
            }
            if (redraw !== false) {
                kchart = kloader.load();
            }
            return false;
        });
    
        $('#chart-container').on('loadcyq.emchart', function (e) {
            $('#chart-container').data('cyq', true);
            options.width = $(window).width();
            options.cyq = {
                width: 270,
                gap: 10,
                accuracyFactor: 150,
                range: 120
            }
            options.padding.right = 3;
        }).on('destorycyq.emchart', function (e) {
            var ct = $('#chart-container').data('charttype');
            if (cyqtypes.indexOf(ct) >= 0) {
                $('#chart-container').data('cyq', false);
            }
            $cyqtips.hide();
            options.width = _width;
            options.cyq = false;
            options.padding.right = 65;
        });
    
        // JS图画图完成事件
        $('#chart-container').on('drawComplete.emchart', function (e) {
            var opt = $(this).data();
            // 筹码分布提示栏 'm5k', 'm15k', 'm30k', 'm60k'
            if (opt.cyq && cyqtypes.indexOf(opt.charttype) >= 0) {
                $('#chart-container').append($cyqtips.show());
            }
        });
    
        $('#type-selector, .r-box').on('selectstart', function () {
            return false;
        });
        bindKeyBoardsEvent();
        /**
         * 显示K图工具栏
         * @param {boolean} show 是否显示
         */
        function displayKChartToolBar(show) {
            var displayed = $('#btn-cyq').hasClass('cur');
            var cyq = $('#chart-container').data('cyq');
            if (show) {
                $('#kchart-toolbar').show();
                if (cyq && !displayed) {
                    $('#btn-cyq').trigger('click', [false]);
                }
            } else {
                $('#kchart-toolbar').hide();
                if (displayed) {
                    $('#btn-cyq').trigger('click', [false]);
                }
            }
        }
        /**
         * 行情图键击事件
         */
        function bindKeyBoardsEvent() {
            var hub = new windowMessageHub();
            $('#chart-container').focus();
            $('#chart-container').on('keydown', function (e) {
                var istime = ['r', 't2', 't3', 't4', 't5'].indexOf(options.type) >= 0;
                switch (e.which) {
                    case 13:
                        if (istime) {
                            $('#type-selector [data-type=k]').click();
                        } else {
                            $('#type-selector [data-type=r]').click();
                        }
                        break;
                    case 38:
                        if (!istime && typeof kchart.shorten === 'function') kchart.shorten();
                        break;
                    case 40:
                        if (!istime && typeof kchart.elongate === 'function') kchart.elongate();
                        break;
                    case 27:
                        hub.send('--close');
                        break;
                }
            });
        }
    }



    //新的画图方法
    function newrenderChart(type) {
        // type = type || 'r';
        var wh = Math.max(568, $(window).height());
        var offset_h = $('#chart-container').offset().top;
        var _width, _height;
        _height = Math.floor(wh - offset_h) - 5;
        var rBoxW = $('#r-box-table').outerWidth(true)
    
        if ($(window).width() >= 1200) {
            _width = Math.floor($(window).width() - rBoxW);
        } else {
            _width = 1200 - rBoxW;
        }


        var thissse = null;
        $.ajax({
            url: "//emcharts.dfcfw.com/ec/3.14.2/emcharts.min.js",
            method: "GET",
            cache: true,
            scriptCharset: "UTF-8",
            dataType: "script",
            success: function() {
                var tps = ['r','t2','t3','t4','t5']
                // timechart(0,0,1,'r');
                // timechart_sse(0,0,1,'r');


                var url = window.location.href;
                var hu_plag = url.split("#")[1];


                //fenshi
                // if(hu_plag == 'fschart-k' || hu_plag == 'fschart-wk' || hu_plag == 'fschart-wk' || hu_plag == 'fschart-mk' || hu_plag == 'fschart-m5k' || hu_plag == 'fschart-m5k' || hu_plag == 'fschart-m15k' || hu_plag == 'fschart-m30k' || hu_plag == 'fschart-m60k') {
                //    console.log('非分时')
                // }else  {
                //     console.log('分时')
                //     timechart(0,0,1,'r');
                //     timechart_sse(0,0,1,'r');

                //     $(this).addClass('cur');
                //     $(this).siblings().removeClass('cur');

                // }

                timechart(0,0,1,'r');
                timechart_sse(0,0,1,'r');

                $("#fens").addClass('cur');
                $("#fens").siblings().removeClass('cur');
               

                //隐藏拉长 缩短
                $("#btn-drawback").hide();
                $("#btn-stretchout").hide();
                $("#select-authority").hide();


                $("#pq").click(function (e) {

                    timechart(1,0,1,'r');
                    timechart_sse(1,0,1,'r');
                    

                    $(this).addClass('cur');
                    $(this).siblings().removeClass('cur');

                    //隐藏拉长 缩短
                    $("#btn-drawback").hide();
                    $("#btn-stretchout").hide();

                })
                $("#panh").click(function (e) {
                    timechart(0,1,1,'r');
                    timechart_sse(0,1,1,'r');
                    
                    $(this).addClass('cur');
                    $(this).siblings().removeClass('cur');

                     //隐藏拉长 缩短
                     $("#btn-drawback").hide();
                     $("#btn-stretchout").hide();
                })

                $("#fens").click(function (e) {
                    timechart(0,0,1,'r');
                    timechart_sse(0,0,1,'r');
                    
                    $(this).addClass('cur');
                    $(this).siblings().removeClass('cur');

                     //隐藏拉长 缩短
                     $("#btn-drawback").hide();
                     $("#btn-stretchout").hide();
                })



                // $("#day-selector .data-type").click(function (e) {

                //     var type = $(this).data('type');
                //     console.log('type')
                //     console.log(type)

                //     timechart(0,0,5,'t5');
                //     timechart_sse(0,0,5,'t5');
                //     $(this).addClass('cur');
                //     $(this).siblings().removeClass('cur');

                //     //隐藏拉长 缩短
                //     $("#btn-drawback").hide();
                //     $("#btn-stretchout").hide();
                //     $("#select-authority").hide();

                //     //阻止冒泡
                //     // e.preventDefault();
                //     // return false;
                // })


                $('#day-selector .data-type').click(function () {

                    // displayKChartToolBar(false);
                    var $dom = $(this);
                    $('#day-selector .rk-options').hide();
                    $('#day-selector .select-icon').removeClass("select-up");
            
                    // if ($dom.hasClass('cur')) return false;
                    var type = $dom.data('type');
                    var _html = $dom.html();

                    // console.log('type')
                    // console.log(type)

                   
                    if (type == "r") {
                        $("#day-selector").removeClass("cur");
                        $('#type-selector .dataType').removeClass('cur');
                        $('#type-selector .fshBox').addClass("cur");
                    } else {
                        $('#type-selector .dataType').removeClass("cur");
                        $('#day-selector').addClass("cur");
                        $('#day-selector .selected-box').html(_html).attr('data-type', type);
                        $('#selected-box').removeClass('cur');
                        $('#day-selector .data-type').removeClass("cur");
                        $dom.addClass('cur');
                    }
                    // options.iscr = false;
                    // options.type = type;
                    // timechart = timeloader.load();
                    return false;
                });

                $("#t1").click(function (e) {
                    fensDay1(e);
                })

                $("#t2").click(function (e) {
                    fensDay2(e);
                })

                $("#t3").click(function (e) {
                    fensDay3(e);
                })

                $("#t4").click(function (e) {

                    fensDay4(e);
                })

                $("#t5").click(function (e) {
                    fensDay5(e);
                })


                $("#five").click(function (e) {
                    // console.log('5日')
                    var type2 = $(this).data('type');

                    var whichday = $(this).html();
                    if(whichday == '1日') {
                        fensDay1(e);
                    }else if(whichday == '2日') {
                        fensDay2(e);
                    }else if(whichday == '3日') {
                        fensDay3(e);
                    }else if(whichday == '4日') {
                        fensDay4(e);
                    }else if(whichday == '5日') {
                        fensDay5(e);
                    }


                    $(this).parent().parent().addClass('cur');
                    $(this).parent().parent().siblings().removeClass('cur');


                    hideRightbar();
                })



                function hideRightbar() {
                    //隐藏拉长 缩短
                    $("#btn-drawback").hide();
                    $("#btn-stretchout").hide();
                    $("#select-authority").hide();

                    $(".rk-options").hide();
                    
                }

                function fensDay1(e) {
                    //  console.log('1日')
                     $('#five').html('1日')
                     timechart(0,0,1,'r');
                     timechart_sse(0,0,1,'r');


                    //  $(this).addClass('cur');
                    //  $(this).siblings().removeClass('cur');
                    //  $(this).parent().parent().siblings().removeClass('cur');

                    // $(this).parent().parent().siblings().removeClass('cur');
                    // $(this).siblings().removeClass('cur');
                    $("#fens").addClass('cur');
                    $("#panh").removeClass('cur');
 
                     //隐藏拉长 缩短
                     hideRightbar();
                     //阻止冒泡
                     e.preventDefault();
                     return false;

                }

                function fensDay2(e)  {
                    // console.log('2日')
                    $('#five').html('2日')
                    timechart(0,0,2,'t2');
                    timechart_sse(0,0,2,'t2');
                    $(this).addClass('cur');
                    $(this).siblings().removeClass('cur');
                    $(this).parent().parent().siblings().removeClass('cur');

                    //隐藏拉长 缩短
                    hideRightbar();
                    //阻止冒泡
                    e.preventDefault();
                    return false;
                }

                function fensDay3(e) {
                    $('#five').html('3日')
                    timechart(0,0,3,'t3');
                    timechart_sse(0,0,3,'t3');
                    $(this).addClass('cur');
                    $(this).siblings().removeClass('cur');
                    $(this).parent().parent().siblings().removeClass('cur');

                    //隐藏拉长 缩短
                    hideRightbar();
                     //阻止冒泡
                     e.preventDefault();
                     return false;

                }


                function fensDay4(e) {
                    $('#five').html('4日')
                    timechart(0,0,4,'t4');
                    timechart_sse(0,0,4,'t4');


                    $(this).addClass('cur');
                    $(this).siblings().removeClass('cur');
                    $(this).parent().parent().siblings().removeClass('cur');

                    //隐藏拉长 缩短
                    hideRightbar();
                     //阻止冒泡
                     e.preventDefault();
                     return false;

                }


                function fensDay5(e) {
                    $('#five').html('5日')
                    timechart(0,0,5,'t5');
                    timechart_sse(0,0,5,'t5');
                    $(this).addClass('cur');
                    $(this).siblings().removeClass('cur');
                    $(this).parent().parent().siblings().removeClass('cur');

                    //隐藏拉长 缩短
                    hideRightbar();
                     //阻止冒泡
                     e.preventDefault();
                     return false;

                }



                


        }
        
        
        
        });



        function timechart(iscr,iscca,ndays,type){
            var _opt =({
                container: '#chart-container',
                width: _width,
                height: _height,
                type: type,
                iscr: iscr,
                iscca:iscca,
                ndays:ndays,
                gridwh: {
                    //height: 25,
                    width: _width
                },
                padding: {
                    top: 0,
                    bottom: 5
                },
                color: {
                    line: '#326fb2',
                    fill: ['rgba(101,202,254, 0.2)', 'rgba(101,202,254, 0.1)']
                },
                // data: {
                //     time: [],
                //     positionChanges: []
                // },
                tip: {
                    show: true,
                    trading: true
                },
                show: {
                    indicatorArea: true, // 分时指标
                    CMA: true,
                    // ddx: args.type === 'r',
                    // cf: args.type === 'r'
                },
                onClickChanges: function () {
                    window.open('//quote.eastmoney.com/changes/stocks/' + args.entry.shortmarket + args.entry.code + '.html');
                },
                onComplete: function () {
    
                },
                onError: function (err) {
                    console.error(err);
                },
                update: 40 * 1000
            });
            var timer
            var chart = new emcharts3.time(_opt);
            //请求分时数据
            $.ajax({
                type: "get",
                url: 'http://push2.eastmoney.com/api/qt/stock/trends2/get?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&ndays='+ndays+'&iscr='+iscr+'&iscca='+iscca+'&secid=1.'+stockentry.code,
                // url: 'http://61.129.249.233:18665/api/qt/stock/trends2/get?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&ndays='+ndays+'&iscr='+iscr+'&iscca='+iscca+'&secid=1.'+stockentry.code,
                dataType: "jsonp",
                jsonp: "cb",
                success: function (msg) {
                    // msg.data.trendsTotal = 482
                    // console.log(time)
                    // console.log(msg)
                    chart.setData({
                        time: msg
                    });
                    chart.redraw();
                }
            });
            
        }
    
    
        function timechart_sse(iscr,iscca,ndays,type) {
            try {
                thissse.close()
            } catch (error) {
                
            }
            var _opt =({
                container: '#chart-container',
                width: _width,
                height: _height,
                type: type,
                iscr: iscr,
                iscca:iscca,
                ndays:ndays,
                gridwh: {
                    //height: 25,
                    width: _width
                },
                padding: {
                    top: 0,
                    bottom: 5
                },
                color: {
                    line: '#326fb2',
                    fill: ['rgba(101,202,254, 0.2)', 'rgba(101,202,254, 0.1)']
                },
                // data: {
                //     time: [],
                //     positionChanges: []
                // },
                tip: {
                    show: true,
                    trading: true
                },
                show: {
                    indicatorArea: true, // 分时指标
                    CMA: true,
                    // ddx: args.type === 'r',
                    // cf: args.type === 'r'
                },
                onClickChanges: function () {
                    window.open('//quote.eastmoney.com/changes/stocks/' + args.entry.shortmarket + args.entry.code + '.html');
                },
                onComplete: function () {
    
                },
                onError: function (err) {
                    console.error(err);
                },
                update: 40 * 1000
            });
            var timer
            var chart = new emcharts3.time(_opt);
            var fullurl = 'http://'+(Math.floor(Math.random() * 99) + 1)+'.push2.eastmoney.com/api/qt/stock/trends2/sse?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&ndays='+ndays+'&iscr='+iscr+'&iscca='+iscca+'&secid=1.'+stockentry.code;
            var nfullurl = 'http://'+(Math.floor(Math.random() * 99) + 1)+'.push2his.eastmoney.com/api/qt/stock/trends2/sse?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&ndays='+ndays+'&iscr='+iscr+'&iscca='+iscca+'&secid=1.'+stockentry.code;
            if(ndays==1){
                thissse = new EventSource(fullurl);
            }else{
                thissse = new EventSource(nfullurl);
            }
            // var fullurl = 'http://61.129.249.233:18665/api/qt/stock/trends2/sse?fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58&ut=fa5fd1943c7b386f172d6893dbfba10b&ndays='+ndays+'&iscr='+iscr+'&iscca='+iscca+'&secid=1.'+stockentry.code;
            // thissse = new EventSource(fullurl);
            thissse.onmessage = function (msg) {
                // console.log(msg);
                var fdata = JSON.parse(msg.data)
                // console.log(fdata);
                var fulldata = '';
                if (fdata.rc == 0 && fdata.data) {
    
                    var data = fdata.data;
    
                    if (data.beticks) {
                        fullData = fdata;
                    } else {
    
                        var source = fullData.data.trends;
                        var last = source[source.length - 1].split(",");
                        
                        var trends = data.trends;
                        var frist = trends[0].split(",");
    
                        if (last[0] == frist[0]) {
                            source.pop();
                        }
                        for(var i = 0, len = trends.length ; i < len ; i++){
                            source.push(trends[i]);
                        }
                    }
    
                    // console.log(that.fullData);
                    chart.setData({
                        time: fullData
                    });
                    chart.redraw();
                }
    
            }
        }
        



    }

    
    //全拼图自适应问题
    function autoFlex() {
        var w = window.innerWidth;
        var h = window.innerHeight;
        console.log('h,', h);
    }


    
    function renderQuote(args) {
        var _opt = getoptions(args);
        var cname = 'TSQ_' + (_opt.entry.shortmarket + _opt.entry.code).toUpperCase();
        if (tsq) tsq.stop();
        tsq = this.quoteLoader = new TopSpeedQuote(cname, {
            host: 'push1.eastmoney.com',
            stopWithoutQuote: true,
            enableMutiDomain: true
        });
        tsq.start();
        return tsq;
    
        function getoptions(args) {
            return marge({
                entry: stockentry || {
                    id: '3000592',
                    code: '300059',
                    marketnum: '2',
                    shortmarket: 'sz'
                },
                basic: {
                    ajax: {
                        url: '//nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&sty=CFPCD&js=((x))&token=4f1862fc3b5e77c150a2b985b12db0fd',
                        data: {},
                        dataType: 'jsonp',
                        jsonp: 'cb'
                    },
                    update: 1000 * 60 * 2
                }
            }, args);
        }
    }


    //新
    function getHeadData() {
        var secids = stockentry.marketnum +'.' + stockentry.code;
        //正式地址：
        var url = "http://" + (Math.floor(Math.random() * 99) + 1) +".push2.eastmoney.com/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f152,f288,f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f31,f32,f33,f34,f35,f36,f37,f38,f39,f40,f20,f19,f18,f17,f16,f15,f14,f13,f12,f11,f531&secid=" + secids;

        //测试地址：
        //var url = "http://61.152.230.191/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f152,f288,f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f31,f32,f33,f34,f35,f36,f37,f38,f39,f40,f20,f19,f18,f17,f16,f15,f14,f13,f12,f11,f531&secid=" + secids;

        $.ajax({
            url: url,
            scriptCharset: "utf-8",
            dataType: "jsonp",
            jsonp: "cb",
            success: function (json) {  
                if(json.data) {
                    // renderHead(json.data)
                    // renderSellandBuy(json.data)
                    formatHead(json)
                    sseHeadData();
                }

            }
        });

    }

    //sse
    function sseHeadData() {
        var secids = stockentry.marketnum +'.' + stockentry.code;

        //测试地址
       // var url = "http://61.152.230.191/api/qt/stock/sse?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f152,f288,f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f31,f32,f33,f34,f35,f36,f37,f38,f39,f40,f20,f19,f18,f17,f16,f15,f14,f13,f12,f11,f531&secid=" + secids;
      
        //正式地址
        var url = "http://" + (Math.floor(Math.random() * 99) + 1) +".push2.eastmoney.com/api/qt/stock/sse?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&invt=2&volt=2&fields=f152,f288,f43,f57,f58,f169,f170,f46,f44,f51,f168,f47,f164,f116,f60,f45,f52,f50,f48,f167,f117,f71,f161,f49,f530,f135,f136,f137,f138,f139,f141,f142,f144,f145,f147,f148,f140,f143,f146,f149,f55,f62,f162,f92,f173,f104,f105,f84,f85,f183,f184,f185,f186,f187,f188,f189,f190,f191,f192,f107,f111,f86,f177,f78,f110,f262,f263,f264,f267,f268,f250,f251,f252,f253,f254,f255,f256,f257,f258,f266,f269,f270,f271,f273,f274,f275,f127,f199,f128,f198,f259,f260,f261,f171,f277,f278,f279,f31,f32,f33,f34,f35,f36,f37,f38,f39,f40,f20,f19,f18,f17,f16,f15,f14,f13,f12,f11,f531&secid=" + secids;


        var evtSource = new EventSource(url);
        evtSource.onmessage = function (msg) {
            // console.log('head sse 推送')
            var obj = JSON.parse(msg.data)
            // console.log(obj.data.f168)
            
            if (obj.data) {
                formatHead(obj);
                changeColor(obj.data)
            }
        }
            

    }


    //head format
    var headSourceData;
    function formatHead(data) {
        // console.log(data);

        if(data.full == 1 && data.data){

            headSourceData = data.data;

        }
        else if(data.full == 0 && data.data ){   

            if(headSourceData) {
                
                headSourceData = marge(headSourceData, data.data);

            }
            
        }


        renderHead(headSourceData)
        renderSellandBuy(headSourceData)

    }

    //增加颜色判断
    function changeColor(data) {
        //换手
        if(data.f168) {
            flickerBlue($("#quote-turnoverRate-custom"))
        }

        //成交量
        if(data.f47) {
            flickerBlue($("#quote-volume-custom"))
        }

        //成交额
        if(data.f48) {
            flickerBlue($("#quote-amount-custom"))
        }

        //总市值
        if(data.f116) {
            flickerBlue($("#quote-zsz-custom"))
        }

        //委比
        if(data.f191 > 0 && data.f191 && data.f191!="-") {
            flickerRed($("#quote-cr"));
        }else if(data.f191 < 0) {
            flickerGreen($("#quote-cr"))
        }

        //委差
        if(data.f192 > 0 && data.f192 && data.f192!="-") {
            flickerRed($("#quote-cd"));
        }else if(data.f192 < 0) {
            flickerGreen($("#quote-cd"))
        }


        //最新价 涨跌额 涨跌幅
        if(data.f170 && data.f170 > 0) {
            flickerRed($("#quote-close-main"));
            flickerRed($("#quote-change-main"));
            flickerRed($("#quote-changePercent-main"));
            
        }else if(data.f170 && data.f170 <0 ) {
            flickerGreen($("#quote-close-main"))
            flickerGreen($("#quote-change-main"));
            flickerGreen($("#quote-changePercent-main"));
        }




        //sell 颜色
        if(data.f32) {
            flickerBlue($("#quote-s5v"))
        }
        if(data.f34) {
            flickerBlue($("#quote-s4v"))
        }
        if(data.f36) {
            flickerBlue($("#quote-s3v"))
        }
        if(data.f38) {
            flickerBlue($("#quote-s2v"))
        }
        if(data.f40) {
            flickerBlue($("#quote-s1v"))
        }


        //buy 颜色
        if(data.f20) {
            flickerBlue($("#quote-b1v"))
        }

        if(data.f18) {
            flickerBlue($("#quote-b2v"))
        }

        if(data.f16) {
            flickerBlue($("#quote-b3v"))
        }

        if(data.f14) {
            flickerBlue($("#quote-b4v"))
        }

        if(data.f12) {
            flickerBlue($("#quote-b5v"))
        }



        if(data.f206 && data.f206>0) {
            // flickerRed($("#quote-s5d"));
            $("#quote-s5d").addClass('red');
            $("#quote-s5d").removeClass('green');
        } else if(data.f206 && data.f206<0) {
            // flickerBlue($("#quote-s5d"))
            $("#quote-s5d").addClass('green');
            $("#quote-s5d").removeClass('red');
        }

        if(data.f207 && data.f207>0) {
            // flickerRed($("#quote-s4d"));
            $("#quote-s4d").addClass('red');
            $("#quote-s4d").removeClass('green');
        } else if(data.f207 && data.f207<0) {
            // flickerBlue($("#quote-s4d"))
            $("#quote-s4d").addClass('green');
            $("#quote-s4d").removeClass('red');
        }


        if(data.f208 && data.f208>0) {
            // flickerRed($("#quote-s3d"));
            $("#quote-s3d").addClass('red');
            $("#quote-s3d").removeClass('green');
        } else if(data.f208 && data.f208<0) {
            // flickerBlue($("#quote-s3d"))

            $("#quote-s3d").addClass('green');
            $("#quote-s3d").removeClass('red');
        }

        if(data.f209 && data.f209>0) {
            // flickerRed($("#quote-s2d"));
            $("#quote-s2d").addClass('red');
            $("#quote-s2d").removeClass('green');
        } else if(data.f209 && data.f209<0) {
            // flickerBlue($("#quote-s2d"))
            $("#quote-s2d").addClass('green');
            $("#quote-s2d").removeClass('red');
        }

        if(data.f210 && data.f210>0) {
            // flickerRed($("#quote-s1d"));
            $("#quote-s1d").addClass('red');
            $("#quote-s1d").removeClass('green');
        } else if(data.f210 && data.f210<0) {
            // flickerBlue($("#quote-s1d"))
            $("#quote-s1d").addClass('green');
            $("#quote-s1d").removeClass('red');
        }



        if(data.f211 && data.f211>0) {
            $("#quote-b1d").addClass('red');
            $("#quote-b1d").removeClass('green');
        } else if(data.f211 && data.f211<0) {
            $("#quote-b1d").addClass('green');
            $("#quote-b1d").removeClass('red');
        }


        if(data.f212 && data.f212>0) {
            $("#quote-b2d").addClass('red');
            $("#quote-b2d").removeClass('green');
        } else if(data.f212 && data.f212<0) {
            $("#quote-b2d").addClass('green');
            $("#quote-b2d").removeClass('red');
        }


        if(data.f213 && data.f213>0) {
            $("#quote-b3d").addClass('red');
            $("#quote-b3d").removeClass('green');
        } else if(data.f213 && data.f213<0) {
            $("#quote-b3d").addClass('green');
            $("#quote-b3d").removeClass('red');
        }


        if(data.f214 && data.f214>0) {
            $("#quote-b4d").addClass('red');
            $("#quote-b4d").removeClass('green');
        } else if(data.f214 && data.f214<0) {
            $("#quote-b4d").addClass('green');
            $("#quote-b4d").removeClass('red');
        }


        if(data.f215 && data.f215>0) {
            $("#quote-b5d").addClass('red');
            $("#quote-b5d").removeClass('green');
        } else if(data.f215 && data.f215<0) {
            $("#quote-b5d").addClass('green');
            $("#quote-b5d").removeClass('red');
        }


        
    }

    //增加数据格式判断--head成交量
    function myformatNum(num) {
        if (num == 0) {
            return num
        }
        if (num == undefined || num == '' || isNaN(num) || num == '-') {
            return '-';
        }
    
        var hz = '';
        var num2 = '';
        if (num >= 10000000000000) {
            num = num / 1000000000000;
            hz = '万亿';
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 1000000000000  && num < 10000000000000) {
            num = num / 1000000000000;
            hz = '万亿';
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 100000000000 && num < 1000000000000) {
            num = num / 100000000;
            hz = '亿';
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 10000000000 && num < 100000000000) {
            num = num / 100000000;
            hz = '亿';
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 100000000 && num < 10000000000) {
            num = num / 100000000;
            hz = '亿';
            num2 =  parseFloat(num).toFixed(2);
        }
        else if (num >= 10000000 && num < 100000000) {
            num = num / 10000;
            hz = '万';
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 1000000 && num < 10000000) {
            num = num / 10000;
            hz = '万';
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 10000 && num < 1000000) {
            num = num / 10000;
            hz = '万';
            num2 =  parseFloat(num).toFixed(2);
        }
        else if (num >= 1000 && num < 10000) {
            num2 =  parseFloat(num).toFixed(0);
        }
        else if (num >= 100 && num < 1000) {
            num2 =  parseFloat(num).toFixed(1);
        }
        else if (num >= 1 && num < 100) {
            num2 = parseFloat(num).toFixed(2);
        }
        else if (num >= 0 && num < 1) {
            num2 = parseFloat(num).toFixed(3);
        } 
        else if(num <0) {
            num2 = parseFloat(num).toFixed(2);
        }
        else {
            num2 =  parseFloat(num).toFixed(2);
            // return num;
        }
    
        
    
        // if(parseInt(num) >= 1000){ //整数部分超过4位
        //   num2 = num.toFixed(1);
        // }
    
        return num2.toString() + hz;
    }

    //科创板全屏 成交量new
    function kcbMyformatNum(num) {
        if (num == undefined || num == '' || isNaN(num) || num == '-') {
            return '';
        }
    
        var hz = '';
        var num2 = '';
        
        if (num >= 0 && num <= 99.999999999) {
            num2 = parseFloat(num).toFixed(2);
        }
        else if (num >= 100 && num <= 999) {
            num2 = parseFloat(num).toFixed(1);
        } 
        else if(num >= 1000) {
            num2 = parseFloat(num).toFixed(0);
        }


        //处理小于0
        if(num < 0) {
            num = Math.abs(num);

            if (num >= 0 && num <= 99) {
                num2 = parseFloat(num).toFixed(2);
            }
            else if (num >= 100 && num <= 999) {
                num2 = parseFloat(num).toFixed(1);
            } 
            else if(num >= 1000) {
                num2 = parseFloat(num).toFixed(0);
            }

            num2 = '-' + num2;

        }
        
    
    
        return num2.toString() + hz;
    }

    //渲染头部
    function renderHead(data) {
        // console.log('renderhead  数据数据');
        // console.log(data)

        //名称
        $("#quote-name").html(data.f58);
        //最新价
        if(data.f43 > data.f60) {
            $("#quote-close-main").css('color', 'red');
            $("#quote-arrow").show();
            $("#quote-arrow").addClass("icon-fullScreen-up");
            $("#quote-arrow").removeClass("icon-fullScreen-down");
        }else if(data.f43 < data.f60) {
            $("#quote-close-main").css('color', 'green');
            $("#quote-arrow").show();
            $("#quote-arrow").addClass("icon-fullScreen-down");
            $("#quote-arrow").removeClass("icon-fullScreen-up");
        }else {
            $("#quote-close-main").css('color', 'black');
            $("#quote-arrow").hide();
        }

        if(data.f43 !='-' && data.f43) {
            $("#quote-close-main").html((data.f43).toFixed(data.f152));
        }else {
            $("#quote-close-main").html('-');
        }
       

         //涨跌额
        
         if(data.f169 > 0) {
            $("#quote-change-main").css('color', 'red');
        }else if(data.f169 < 0) {
            $("#quote-change-main").css('color', 'green');
        }else {
            $("#quote-change-main").css('color', 'black');
        }

        if(data.f169 != '-' && data.f169) {
            $("#quote-change-main").html((data.f169).toFixed(data.f152));
        }else if(data.f169 == 0) {
            $("#quote-change-main").html('0.00');
        }
        else {
            $("#quote-change-main").html('-');
        }
         

        //涨跌幅
        var zdfvalue;
        if(data.f170 != '-' && data.f170) {
            zdfvalue = (data.f170.toFixed(data.f152));
        }else if(data.f170 == '0') {
            zdfvalue = '0.00';
        }
        else {
            zdfvalue = '-';
        }
       
        
        if(data.f170 > 0) {
            $("#quote-changePercent-main").css('color', 'red');
        }else if(data.f170 < 0) {
            $("#quote-changePercent-main").css('color', 'green');
        }else {
            $("#quote-changePercent-main").css('color', 'black');
        }
        if(zdfvalue !='-') {
            $("#quote-changePercent-main").html(zdfvalue + '%');
        }
        else {
            $("#quote-changePercent-main").html('-');
        }
       

        //今开
        if(data.f46 > data.f60) {
            $("#quote-open-custom").addClass('red');
        }else if(data.f46 < data.f60) {
            $("#quote-open-custom").addClass('green');
        }
        if(data.f46 != '-' && data.f46) {
            $("#quote-open-custom").html((data.f46.toFixed(data.f152)));
        }else {
            $("#quote-open-custom").html('-');
        }
        

        //最高
        if(data.f44 > data.f60) {
            $("#quote-high-custom").addClass('red');
        }else if(data.f44 < data.f60) {
            $("#quote-high-custom").addClass('green');
        }

        if(data.f44 != '-' && data.f44) {
            $("#quote-high-custom").html((data.f44.toFixed(data.f152)));
        }else {
            $("#quote-high-custom").html('-');
        }
        

        //换手
        if(data.f168 && data.f168 !='-') {
            $("#quote-turnoverRate-custom").html((data.f168).toFixed(2) + '%');
        }else {
            $("#quote-turnoverRate-custom").html('-');
        }
        

        //成交量
        if(data.f47 && data.f47!='-') {
            $("#quote-volume-custom").html(myformatNum(data.f47) + '手');
        }else {
            $("#quote-volume-custom").html('-');
        }
        


        //市盈率
        if(data.f164 && data.f164!='-') {
            $("#quote-PERation-custom").html((data.f164).toFixed(2));
        }else {
            $("#quote-PERation-custom").html('-');
        }
        


        //盈利
        var yingli = '';
        if(data.f288 == '1') {
            yingli = '否';
        }else if(data.f288 == '0') {
            yingli = '是';
        }else {
            yingli = '-'
        }
        $("#quote-ylValue-custom").html(yingli);

        //盘后成交量
        if(kcbMyformatNum(data.f260) != '-' && kcbMyformatNum(data.f260)) {
            $("#quote-phcjl-custom").html(kcbMyformatNum(data.f260) + '手');
        }else {
            $("#quote-phcjl-custom").html('-');
        }
        

        //昨收
        if(data.f60 != '-' && data.f60) {
            $("#quote-pc").html((data.f60.toFixed(data.f152)));
        }else {
            $("#quote-pc").html('-');
        }
        


        //最低
        if(data.f45 > data.f60) {
            $("#quote-low-custom").addClass('red');
        }else if(data.f45 < data.f60) {
            $("#quote-low-custom").addClass('green');
        }

        if(data.f45 != '-' && data.f45) {
            $("#quote-low-custom").html((data.f45.toFixed(data.f152)));
        }else {
            $("#quote-low-custom").html('-');
        }
        


        //量比
        $("#quote-volumeRate-custom").html(data.f50);

        //成交额
        $("#quote-amount-custom").html(myformatNum(data.f48));

        //总市值
        $("#quote-zsz-custom").html(myformatNum(data.f116));

        //同股同权
        var tgtq = '';
        if(data.f279 == '1') {
            tgtq = '是'
        }else if(data.f279 == '0') {
            tgtq = '否'
        }else {
            tgtq = '-'
        }
        
        $("#quote-tgtq-custom").html(tgtq);


        //盘后成交额
        $("#quote-pscje-custom").html(myformatNum(data.f261));



        //委比
        if(data.f191 > 0 && data.f191 && data.f191!="-") {
            $("#quote-cr").addClass('red');
            $("#quote-cr").removeClass('green');

        }else if(data.f191 < 0) {
            $("#quote-cr").addClass('green');
            $("#quote-cr").removeClass('red');
        }

        var wbval = '';
        if(data.f191 != '-' && data.f191) {
            wbval = (data.f191).toFixed(2);
            $("#quote-cr").html(wbval + '%');
        }else {
            $("#quote-cr").html('-');
        }
        

        //委差
        if(data.f192 > 0) {
            $("#quote-cd").addClass('red');
            $("#quote-cd").removeClass('green');
           

        }else if(data.f192 < 0) {
            $("#quote-cd").addClass('green');
            $("#quote-cd").removeClass('red');
           
        }
        $("#quote-cd").html(kcbMyformatNum(data.f192));


        //涨停
        if(data.f51 > data.f60) {
            $("#quote-raisePrice-main").addClass('red');
        }else if(data.f51 < data.f60) {
            $("#quote-raisePrice-main").addClass('green');
        }

        if(data.f51 !='-' && data.f51) {
            $("#quote-raisePrice-main").html((data.f51).toFixed(2));
        }else {
            $("#quote-raisePrice-main").html('-');
        }
        


        //跌停
        if(data.f52 > data.f60) {
            $("#quote-fallPrice-main").addClass('red');
        }else if(data.f52 < data.f60) {
            $("#quote-fallPrice-main").addClass('green');
        }

        if(data.f52 !='-' && data.f52) {
            $("#quote-fallPrice-main").html((data.f52).toFixed(2));
        }else {
            $("#quote-fallPrice-main").html('-');
        }

        

    }

    //渲染买卖入
    function renderSellandBuy(data) {
        // console.log('selll')
        // console.log(data)
        var MaxCount = [];
        MaxCount.push(data.f32, data.f34, data.f36, data.f38, data.f40, data.f20, data.f18, data.f16, data.f14, data.f12);
        var mv = Math.max.apply(this, MaxCount);
        if(data) {
            //sell 5
            if(data.f31 > data.f60) {
                $("#quote-s5p").css('color', 'red');

                $("#quote-s5vp").removeClass('green');
                $("#quote-s5vp").addClass('red');
                
            }else if(data.f31 < data.f60) {
                $("#quote-s5p").css('color', '#009944');

                $("#quote-s5vp").removeClass('red');
                $("#quote-s5vp").addClass('green');
            }else if(data.f31 == data.f60){
                $("#quote-s5p").css('color', 'black');

                $("#quote-s5vp").removeClass('green');
                $("#quote-s5vp").addClass('red');
            }

            if(data.f31 != '-' && data.f31) {
                $("#quote-s5p").html((data.f31).toFixed(data.f152));
            }

            //sell 4
            if(data.f33 > data.f60) {
                $("#quote-s4p").css('color', 'red');

                $("#quote-s4vp").removeClass('green');
                $("#quote-s4vp").addClass('red');
            }else if(data.f33 < data.f60) {
                $("#quote-s4p").css('color', '#009944');

                $("#quote-s4vp").removeClass('red');
                $("#quote-s4vp").addClass('green');
            }else if(data.f33 == data.f60){
                $("#quote-s4p").css('color', 'black');

                $("#quote-s4vp").removeClass('green');
                $("#quote-s4vp").addClass('red');
            }

            if(data.f33 != '-' && data.f33) {
                $("#quote-s4p").html((data.f33).toFixed(data.f152));
            }


            //sell 3
            if(data.f35 > data.f60) {
                $("#quote-s3p").css('color', 'red');

                $("#quote-s3vp").removeClass('green');
                $("#quote-s3vp").addClass('red');
            }else if(data.f35 < data.f60) {
                $("#quote-s3p").css('color', '#009944');

                $("#quote-s3vp").removeClass('red');
                $("#quote-s3vp").addClass('green');
            }else if(data.f35 == data.f60){
                $("#quote-s3p").css('color', 'black');

                $("#quote-s3vp").removeClass('green');
                $("#quote-s3vp").addClass('red');
            }

            if(data.f35 != '-' && data.f35) {
                $("#quote-s3p").html((data.f35).toFixed(data.f152));
            }


             //sell 2
            if(data.f37 > data.f60) {
                $("#quote-s2p").css('color', 'red');

                $("#quote-s2vp").removeClass('green');
                $("#quote-s2vp").addClass('red');
            }else if(data.f37 < data.f60) {
                $("#quote-s2p").css('color', '#009944');

                $("#quote-s2vp").removeClass('red');
                $("#quote-s2vp").addClass('green');
            }else if(data.f37 == data.f60){
                $("#quote-s2p").css('color', 'black');

                $("#quote-s2vp").removeClass('green');
                $("#quote-s2vp").addClass('red');
            }

            if(data.f37 != '-' && data.f37) {
                $("#quote-s2p").html((data.f37).toFixed(data.f152));
            }


            //sell 1
            if(data.f39 > data.f60) {
                $("#quote-s1p").css('color', 'red');

                $("#quote-s1vp").removeClass('green');
                $("#quote-s1vp").addClass('red');
            }else if(data.f39 < data.f60) {
                $("#quote-s1p").css('color', '#009944');

                $("#quote-s1vp").removeClass('red');
                $("#quote-s1vp").addClass('green');
            }else if(data.f39 == data.f60){
                $("#quote-s1p").css('color', 'black');

                $("#quote-s1vp").removeClass('green');
                $("#quote-s1vp").addClass('red');
            }


            if(data.f39 != '-' && data.f39) {
                $("#quote-s1p").html((data.f39).toFixed(data.f152));
            }


            //buy 1
            if(data.f19 > data.f60) {
                //#009944  green
                $("#quote-b1p").css('color', 'red');

                $("#quote-b1vp").removeClass('green');
                $("#quote-b1vp").addClass('red');
            }else if(data.f19 < data.f60) {
                $("#quote-b1p").css('color', '#009944');

                $("#quote-b1vp").removeClass('red');
                $("#quote-b1vp").addClass('green');
            }else if(data.f19 == data.f60) {
                $("#quote-b1p").css('color', 'black');

                $("#quote-b1vp").removeClass('green');
                $("#quote-b1vp").addClass('red');
            }
            if(data.f19 != '-' && data.f19) {
                $("#quote-b1p").html((data.f19).toFixed(data.f152));
            }


            //buy 2
            if(data.f17 > data.f60) {
                $("#quote-b2p").css('color', 'red');

                $("#quote-b2vp").removeClass('green');
                $("#quote-b2vp").addClass('red');
            }else if(data.f17 < data.f60) {
                $("#quote-b2p").css('color', '#009944');

                $("#quote-b2vp").removeClass('red');
                $("#quote-b2vp").addClass('green');
            }else if(data.f17 == data.f60) {
                $("#quote-b2p").css('color', 'black');

                $("#quote-b2vp").removeClass('green');
                $("#quote-b2vp").addClass('red');
            }
            if(data.f17 != '-' && data.f17) {
                $("#quote-b2p").html((data.f17).toFixed(data.f152));
            }


            //buy 3
            if(data.f15 > data.f60) {
                $("#quote-b3p").css('color', 'red');

                $("#quote-b3vp").removeClass('green');
                $("#quote-b3vp").addClass('red');
            }else if(data.f15 < data.f60) {

                $("#quote-b3p").css('color', '#009944');

                $("#quote-b3vp").removeClass('red');
                $("#quote-b3vp").addClass('green');
            }else if(data.f15 == data.f60) {
                $("#quote-b3p").css('color', 'black');

                $("#quote-b3vp").removeClass('green');
                $("#quote-b3vp").addClass('red');
            }
            if(data.f15 != '-' && data.f15) {
                $("#quote-b3p").html((data.f15).toFixed(data.f152));
            }


            //buy 4
            if(data.f13 > data.f60) {
                $("#quote-b4p").css('color', 'red');

                $("#quote-b4vp").removeClass('green');
                $("#quote-b4vp").addClass('red');
            }else if(data.f13 < data.f60) {
                $("#quote-b4p").css('color', '#009944');

                $("#quote-b4vp").removeClass('red');
                $("#quote-b4vp").addClass('green');
            }else if(data.f13 == data.f60) {
                $("#quote-b4p").css('color', 'black');

                $("#quote-b4vp").removeClass('green');
                $("#quote-b4vp").addClass('red');
            }
            if(data.f13 != '-' && data.f13) {
                $("#quote-b4p").html((data.f13).toFixed(data.f152));
            }


             //buy 5
             if(data.f11 > data.f60) {
                $("#quote-b5p").css('color', 'red');

                $("#quote-b5vp").removeClass('green');
                $("#quote-b5vp").addClass('red');
            }else if(data.f11 < data.f60) {
                $("#quote-b5p").css('color', '#009944');

                $("#quote-b5vp").removeClass('red');
                $("#quote-b5vp").addClass('green');
            }else if(data.f13 == data.f60) {
                $("#quote-b5p").css('color', 'black');

                $("#quote-b5vp").removeClass('green');
                $("#quote-b5vp").addClass('red');
            }
            if(data.f11 != '-' && data.f11) {
                $("#quote-b5p").html((data.f11).toFixed(data.f152));
            }



            //sell 5 count
            // $("#quote-s5v").html((data.f32));
            // $("#quote-s5v").html('-');
            if(data.f32 == '0') {
                $("#quote-s5v").html('-');
            }else {
                $("#quote-s5v").html(kcbMyformatNum(data.f32));
            }

            if(data.f34 == '0') {
                $("#quote-s4v").html('-');
            }else {
                $("#quote-s4v").html(kcbMyformatNum(data.f34));
            }

            if(data.f36 == '0') {
                $("#quote-s3v").html('-');
            }else {
                $("#quote-s3v").html(kcbMyformatNum(data.f36));
            }

            if(data.f38 == '0') {
                $("#quote-s2v").html('-');
            }else {
                $("#quote-s2v").html(kcbMyformatNum(data.f38));
            }

            if(data.f40 == '0') {
                $("#quote-s1v").html('-');
            }else {
                $("#quote-s1v").html(kcbMyformatNum(data.f40));
            }
            

            //sell
            $("#quote-s5vp").css('width', (data.f32 / mv)*100+'%');
            $("#quote-s4vp").css('width', (data.f34 / mv)*100+'%');
            $("#quote-s3vp").css('width', (data.f36 / mv)*100+'%');
            $("#quote-s2vp").css('width', (data.f38 / mv)*100+'%');
            $("#quote-s1vp").css('width', (data.f40 / mv)*100+'%');

            if((data.f32 / mv)*100 < 1 && (data.f32 / mv) !=0) {
                $("#quote-s5vp").css('width', '2%');
            }

            if((data.f34 / mv)*100 < 1  && (data.f34 / mv) !=0) {
                $("#quote-s4vp").css('width', '2%');
            }

            if((data.f36 / mv)*100 < 1 && (data.f36 / mv) !=0) {
                $("#quote-s3vp").css('width', '2%');
            }

            if((data.f38 / mv)*100 < 1 && (data.f38 / mv) !=0) {
                $("#quote-s2vp").css('width', '2%');
            }

            if((data.f40 / mv)*100 < 1 && (data.f40 / mv) !=0) {
                $("#quote-s1vp").css('width', '2%');
            }



            //buy 5 count quote-b1v
            if(data.f20 == '0') {
                $("#quote-b1v").html('-');
            }else {
                $("#quote-b1v").html(kcbMyformatNum(data.f20));
            }

            if(data.f18 == '0') {
                $("#quote-b2v").html('-');
            }else {
                $("#quote-b2v").html(kcbMyformatNum(data.f18));
            }

            if(data.f16 == '0') {
                $("#quote-b3v").html('-');
            }else {
                $("#quote-b3v").html(kcbMyformatNum(data.f16));
            }


            if(data.f14 == '0') {
                $("#quote-b4v").html('-');
            }else {
                $("#quote-b4v").html(kcbMyformatNum(data.f14));
            }


            if(data.f12 == '0') {
                $("#quote-b5v").html('-');
            }else {
                $("#quote-b5v").html(kcbMyformatNum(data.f12));
            }



            //buy
            $("#quote-b1vp").css('width', (data.f20 / mv)*100+'%');
            $("#quote-b2vp").css('width', (data.f18 / mv)*100+'%');
            $("#quote-b3vp").css('width', (data.f16 / mv)*100+'%');
            $("#quote-b4vp").css('width', (data.f14 / mv)*100+'%');
            $("#quote-b5vp").css('width', (data.f12 / mv)*100+'%');


            if((data.f20 / mv)*100 < 1 && (data.f20 / mv) !=0) {
                $("#quote-b1vp").css('width', '2%');
            }

            if((data.f18 / mv)*100 < 1 && (data.f18 / mv) !=0) {
                $("#quote-b2vp").css('width', '2%');
            }

            if((data.f16 / mv)*100 < 1 && (data.f16 / mv) !=0) {
                $("#quote-b3vp").css('width', '2%');
            }

            if((data.f14 / mv)*100 < 1 && (data.f14 / mv) !=0) {
                $("#quote-b4vp").css('width', '2%');
            }

            if((data.f12 / mv)*100 < 1 && (data.f12 / mv) !=0) {
                $("#quote-b5vp").css('width', '2%');
            }



            //渲染买卖差量
            if(data.f206) {
                if(data.f206 == '0') {
                    $("#quote-s5d").html('')
                }else {
                    var value = kcbMyformatNum(data.f206)
                    var val = data.f206 >0 ? '+' + value: value;
                    $("#quote-s5d").html(val);

                }
                
            }else {
                $("#quote-s5d").html('')
            }


            if(data.f207) {
                if(data.f207 == '0') {
                    $("#quote-s4d").html('')
                }else {
                    var value = kcbMyformatNum(data.f207)
                    var val = data.f207 >0 ? '+' + value: value;
                    $("#quote-s4d").html(val);
                }
                
            }else {
                $("#quote-s4d").html('')
            }


            if(data.f208) {
                if(data.f208 == '0') {
                    $("#quote-s3d").html('')
                }else {
                    var value = kcbMyformatNum(data.f208)
                    var val = data.f208 >0 ? '+' + value: value;
                    $("#quote-s3d").html(val);

                }
            }else {
                $("#quote-s3d").html('')
            }


            if(data.f209) {
                if(data.f209 == '0') {
                    $("#quote-s2d").html('')
                }else {
                    var value = kcbMyformatNum(data.f209)
                    var val = data.f209 >0 ? '+' + value: value;
                    $("#quote-s2d").html(val);
                }
                
            }else {
                
                $("#quote-s2d").html('')
            }


            if(data.f210) {
                if(data.f210 == '0') {
                    $("#quote-s1d").html('')
                }else {
                    var value = kcbMyformatNum(data.f210)
                    var val = data.f210 > 0 ? '+' + value: value;
                    $("#quote-s1d").html(val);

                }
                
            }else {
                $("#quote-s1d").html('')
            }

            if(data.f211) {
                if(data.f211 == '0') {
                    $("#quote-b1d").html('')
                }else {
                    var value = kcbMyformatNum(data.f211)
                    var val = data.f211 >0 ? '+' + value: value;
                    $("#quote-b1d").html(val)
                }
                
            }else {
                $("#quote-b1d").html('')
            }


            if(data.f212) {
                if(data.f212 == '0') {
                    $("#quote-b2d").html('')
                }else {
                    var value = kcbMyformatNum(data.f212)
                    var val = data.f212 >0 ? '+' + value: value;
                    $("#quote-b2d").html(val)
                }
                
            }else {
                $("#quote-b2d").html('')
            }

            if(data.f213) {
                if(data.f213 == '0') {
                    $("#quote-b3d").html('')
                }else {
                    var value = kcbMyformatNum(data.f213)
                    var val = data.f213 >0 ? '+' + value: value;
                    $("#quote-b3d").html(val)
                }
                
            }else {
                $("#quote-b3d").html('')
            }


            if(data.f214) {
                if(data.f214 == '0') {
                    $("#quote-b4d").html('')
                }else {
                    var value = kcbMyformatNum(data.f214)
                    var val = data.f214 >0 ? '+' + value: value;
                    $("#quote-b4d").html(val)
                }
            }else {
                $("#quote-b4d").html('')
            }

            if(data.f215) {
                if(data.f215 == '0') {
                    $("#quote-b5d").html('')
                }else {
                    var value = kcbMyformatNum(data.f215)
                    var val = data.f215 >0 ? '+' + value: value;
                    $("#quote-b5d").html(val)
                }
            }else {
                $("#quote-b5d").html('')
            }




            
            
            
        }
    }


    //变色
    function flickerBlue(dom){

        $(dom).css("background-color", "rgba(178, 195, 234)");
        // $(dom).animate({
        //     "backgroundColor": "rgba(255,0,0,0.5)"
        // }, 300);

        setTimeout(function(){
            $(dom).css("background-color", "rgba(255,0,0,0)");
         }, 300);
        
    }

    function flickerGreen(dom){

        $(dom).css("background-color", "rgba(180, 247, 175)");
        // $(dom).animate({
        //     "backgroundColor": "rgba(255,0,0,0.5)"
        // }, 300);

        setTimeout(function(){
            $(dom).css("background-color", "rgba(255,0,0,0)");
         }, 300);
        
    }


    function flickerRed(dom){

        $(dom).css("background-color", "rgba(255,0,0,0.5)");
        // $(dom).animate({
        //     "backgroundColor": "rgba(255,0,0,0.5)"
        // }, 300);

        setTimeout(function(){
            $(dom).css("background-color", "rgba(255,0,0,0)");
         }, 300);
        
    }



    //分时成交
    function getFSData() {
        var secids = stockentry.marketnum +'.' + stockentry.code;

        // var secids = '1.601229'
    
        var data = {
            ut: "fa5fd1943c7b386f172d6893dbfba10b",
            fields1: "f1,f2,f3,f4,f531",
            fields2: "f51,f52,f53,f54,f55",
            secid: secids,
            pos: '-20',
            volt: '2'
        }
    
        // 正式地址
        var fullurl = "http://" + (Math.floor(Math.random() * 99) + 1) +".push2.eastmoney.com/" + "api/qt/stock/details/get?" + parStringify(data);

        //测试地址：
        // var fullurl = "http://61.152.230.191/" + "api/qt/stock/details/get?" + parStringify(data);
    
        $.ajax({
            type: "get",
            data: '',
            url: fullurl,
            dataType: "jsonp",
            jsonp: 'cb'
        })
        .then(function (msg) {
                var obj = msg;
                // console.log('分时成交数据')
                // console.log(obj)
                if (obj.data) {
                    $("#detail-msg-more").show();

                    $("#detail-msg-more a").attr('href', 'http://quote.eastmoney.com/f1.html?id=' + stockentry.code + stockentry.marketnum);

                    fsFormat(obj);
                }
    
            })
        .always(function(){
            getsseFSdata();
        })
    
    }


    function getsseFSdata() {
        var secids = stockentry.marketnum +'.' + stockentry.code;

        // var secids = '1.601229'
    
        var data = {
            ut: "fa5fd1943c7b386f172d6893dbfba10b",
            fields1: "f1,f2,f3,f4",
            fields2: "f51,f52,f53,f54,f55",
            secid: secids,
            pos: '-20',
            volt: '2'
        }
    
        // 正式地址
       var fullurl = "http://" + (Math.floor(Math.random() * 99) + 1) +".push2.eastmoney.com/" + "api/qt/stock/details/sse?" + parStringify(data);

        //测试地址
        // var fullurl = "http://61.152.230.191/" + "api/qt/stock/details/sse?" + parStringify(data);


        var evtSource = new EventSource(fullurl);
        evtSource.onmessage = function (msg) {
            // console.log('推送')
            var obj = JSON.parse(msg.data)
            // console.log(obj)
            if (obj.data) {
                fsFormat(obj);
            }

        }


    }

    var msg,source_data,prePrice;
    function fsFormat (data) {

        if(data.full == 1 && data.data && data.data.details){
           
            msg = data.data;
            prePrice = data.data.prePrice;
            source_data = data.data.details
        }
        else if(data.full == 0 && data.data && data.data.details){    
            if(source_data) {
                source_data = source_data.concat(data.data.details);
            }
            
        }
  
        // console.log(source_data)

        fillFSHtml(msg, source_data, prePrice);

    }

    function fillFSHtml(msg, source_data, prePrice) {
        // console.log('分时成交 数据 啊啊啊')
        // console.log(msg)
        // console.log(source_data)


        if (!msg|| !(source_data.length)) {
            var height = "271px";
            $("#deal_detail").html("<tr><td colspan=3 style='height: " + height + ";text-align:center'>暂无数据</td></tr>");
            $("#detail-msg-more").hide();
            return;
        }
        var pc = parseFloat(prePrice), $tbody = $("<tbody></tbody>");
        var price =[]; 
        for(var i = 0; i < source_data.length; i++){
            price.push(parseFloat(source_data[i].substring(9,14)))
        }
      

        var pch=[];
        for(var i = 0; i < price.length-1; i++){
            pch[i]=price[i+1]-price[i];
        }
       
        var data=[];
        var singledata=[];
        var i = source_data.length - 1; i >= 0; i--
        // var i = 1; i < source_data.length; i++
        //分时成交量 --data[2]
        // console.log(source_data)
        

        if(source_data.length <= 20) {
            for (var i = source_data.length - 1; i >= 0; i--) {
                singledata = JSON.stringify(source_data[i])
                data = singledata.split(',');
                data[0]=data[0].substring(1);
                data[4]=data[4].substring(0,1);
                var $tr = $("<tr></tr>"),
                    priceColor = data[4] != 4 ? data[1] - pc > 0 ? "red" : data[1] - pc < 0 ? "green" : "#333333" : "",
                    dir = pch[i-1] < 0 ? "↓" : pch[i-1] > 0 ? "↑" : "",
                    dir_c = pch[i-1] < 0 ? "green" : pch[i-1] > 0 ? "red" : "",
                    vp = data[2] * data[1] * 100 * (data[4] == 1 ? -1 : data[4] == 2 ? 1 : 0),
                    v_c = data[4] != 4 ? vp >= 200000 ? "#ff00ff" : vp > 0 ? "red" : vp <= -200000 ? "#00b7ee" : vp < 0 ? "green" : "" : "";
    
                $("<td />").text(data[0]).appendTo($tr);
                $("<td />").text(data[1]).css("color", priceColor).appendTo($tr);
                $("<td class='myjx'/>")
                    .append($("<span />").text(kcbMyformatNum(data[2])).css("color", v_c))
                    .append($("<span class='myjiantou'/>").text(dir).css("color", dir_c))
                    .appendTo($tr);
                $tbody.append($tr);
            }

        }else {
            // var i = arr.length-1; i >=arr.length-13; i--
            for (var i = source_data.length-1; i >= source_data.length-20; i--) {
                singledata = JSON.stringify(source_data[i])
                data = singledata.split(',');
                data[0]=data[0].substring(1);
                data[4]=data[4].substring(0,1);
                var $tr = $("<tr></tr>"),
                    priceColor = data[4] != 4 ? data[1] - pc > 0 ? "red" : data[1] - pc < 0 ? "green" : "#333333" : "",
                    dir = pch[i-1] < 0 ? "↓" : pch[i-1] > 0 ? "↑" : "",
                    dir_c = pch[i-1] < 0 ? "green" : pch[i-1] > 0 ? "red" : "",
                    vp = data[2] * data[1] * 100 * (data[4] == 1 ? -1 : data[4] == 2 ? 1 : 0),
                    v_c = data[4] != 4 ? vp >= 200000 ? "#ff00ff" : vp > 0 ? "red" : vp <= -200000 ? "#14c3dc" : vp < 0 ? "green" : "" : "";
    
                $("<td />").text(data[0]).appendTo($tr);
                $("<td />").text(data[1]).css("color", priceColor).appendTo($tr);
                $("<td class='myjx'/>")
                    .append($("<span />").text(kcbMyformatNum(data[2])).css("color", v_c))
                    .append($("<span class='myjiantou'/>").text(dir).css("color", dir_c))
                    .appendTo($tr);
                $tbody.append($tr);
            }
        }
       
        $("#deal_detail").html($tbody.html());
           

    }



    function parStringify(obj){
        var arr = [];
        for (var k in obj) {
            arr.push(k + "=" + obj[k]);
        }
        return arr.join("&")
    }


}

/**
 * 获取行情图除复权类型
 */
function getExrightsType() {
    var type = cookie('emhq_picfq');
    switch (type) {
        case '0':
            return '';
        case '1':
            return 'fa';
        case '2':
            return 'ba';
        default:
            return 'fa';
    }
}

/**
 * 设置行情图除复权类型
 * @param {''|'fa'|'ba'} type 类型
 */
function setExrightsType(type) {
    var val = type;
    switch (type) {
        case '':
            val = '0';
            break;
        case 'fa':
            val = '1';
            break;
        case 'ba':
            val = '2';
            break;
    }
    cookie('emhq_picfq', val, {
        expires: 365, //天
        path: '/',
        domain: '.eastmoney.com'
    });
}

function windowMessageHub() {
    var orgin = location.protocol + '//' + location.host;
    var client = window.parent;
    this.connected = false;
    $(window).on('message', function (e) {
        var event = e.origin ? e : e.originalEvent;
        /** @type {Window} */
        var source = event.source;
        if (event.origin !== window.location.host) return;
        if (event.data === 'connecting') {
            source.postMessage('connected', orgin);
            client = source;
            this.connected = true;
        }
    });
    /**
     * 发送消息
     * @param {string} msg 消息
     */
    this.send = function (msg) {
        client.postMessage(msg, orgin);
    }
    this.onreceivemsg = function (e) {
        console.log(e);
    }
}

$(document).ready(function (e) {
    new h5chartkcb().init();
});