// require("../style/reset.less");
// require("../style/head.less");
// require("../style/right-hk.less");
require('./ie_sse_polyfill'); 

var main = require("./hk/main.html");
var right = require("./hk/right.html");

var uri = require("./common/uri");
var renderBlock = require("./common/renderBlock");

var config = require("./hk/config");

var addEvent = require("./aindex/addEvent");
var chartManager = require("./chart/index");

var getdata = require("./hk/getdata");

module.exports = function(){

  $(".main").html(main);
  $(".righ").html(right);


  renderBlock(config.head);
  var pars = uri.getParams();

  var ctm = new chartManager(pars);


  getdata(pars);
  addEvent(ctm, pars);


  // console.log('港股');
  //头部
  var w = window.innerWidth;
  // console.log('w,', w);
  if (w <= 1750) {
      var parent = document.getElementsByClassName("right")[0];
      var child = document.getElementsByClassName("block");

      parent.removeChild(child[8]);
      parent.removeChild(child[6]);
      parent.removeChild(child[2]);

  }

  //右侧
  var h = window.innerHeight;
  if (h <= 900) {
      var parent = document.getElementsByClassName("hqbj")[0];

      var child1 = document.getElementsByClassName("download")[0];
      //删广告
      // parent.removeChild(child1);



      //增加滚动条
      var hei = (h - 310) + 'px';
      $(".hqbj").css('height', hei);
      $(".hqbj").css('overflow', 'auto');

      //让滚动条处于中间位置
      var divhei = $(".hqbj").height();
      var vl = document.getElementsByClassName("hqbj")[0].scrollHeight;
      $(".hqbj").scrollTop((vl - divhei) * 0.5);


      //增加中间虚线
      // $(".hqbj table")[1].style.borderTop = '1px dashed gray';




  }  
}
