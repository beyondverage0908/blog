// require("../style/reset.less");
// require("../style/head.less");
// require("../style/right-us.less");

//require('eventsource-polyfill');
require('./ie_sse_polyfill');


var main = require("./us/main.html");
var right = require("./us/right.html");

var uri = require("./common/uri");
var renderBlock = require("./common/renderBlock");

var config = require("./us/config");

var addEvent = require("./aindex/addEvent");
var chartManager = require("./chart/index");

var getdata = require("./us/getdata");

module.exports = function(){
    $(".main").html(main);
    $(".righ").html(right);


    renderBlock(config.head);
    var pars = uri.getParams();
    getdata(pars)


    var ctm = new chartManager(pars);
    addEvent(ctm, pars);



    // console.log('美股');

    //右侧
    var h = window.innerHeight;
    // console.log('h', h) 
    if (h <= 938) {
        //增加滚动条
        $(".jdzf").hide();

        var hei = (h - 150) + 'px';
        $(".fscj").css('height', hei);
        $(".fscj").css('overflow', 'auto');

    } 
}

