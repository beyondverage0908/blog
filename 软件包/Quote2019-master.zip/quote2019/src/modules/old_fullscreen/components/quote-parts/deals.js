//var $ = require('jquery');
var extend = _.assignIn
var utils = require('../../em-utils/lib/stockutils');
var template = require('../../modules/template-web');
var tpl_deal = require('../../template/deal.art');

/**
 * 成交明细
 * @param {Object} args 参数
 * @param {string} args.id 股票ID
 * @param {string|JQuery<HTMLElement>} args.container 容器
 * @param {object} args.ajax ajax请求配置
 * @param {function} args.oncomplete 完成回调
 * @param {number} args.update 更新时间
 */
function deals(args) {
    var _opt = extend({
        container: '#deal_detail',
        id: '',
        ajax: {
            url: '//mdfm.eastmoney.com/EM_UBG_MinuteApi/Js/Get?dtype=25&style=tail&check=st&dtformat=HH:mm:ss&num=20',
            dataType: 'jsonp',
            data: {},
            jsonp: 'cb',
            success: render,
            error: onerror
        },
        oncomplete: null,
        update: 20 * 1000,
    }, args);
    var self = this;
    var timer;
    var pageRender = template.compile(tpl_deal);
    this.load = function () {
        this.stop();
        extend(_opt.ajax.data, {
            id: _opt.id
        });
        var jqXHR = $.ajax(_opt.ajax);
        if (_opt.update > 0) {
            timer = setInterval(function () {
                if (jqXHR) jqXHR.abort();
                jqXHR = $.ajax(_opt.ajax);
            }, _opt.update);
        }
    }

    this.stop = function () {
        clearInterval(timer);
    }

    function render(json) {
        //var big = 2 * Math.pow(10, 6);
        var modules;
        //t-时间，p-价格，v-成交量，bs-内外盘，wh-仓差，type-性质，vc-成交笔数或增仓量,pch-方向
        //内外盘：1:内盘(流出) 2:外盘(流入) 3:未知 4:集合竞价
        if (json && json.result) {
            for (var i = 0; i < json.value.data.length; i++) {
                var item = json.value.data[i];
                item.priceColor = item.bs === 4 ? '' : utils.getColor(item.p, json.value.pc);
                item.v = item.bs === 4 ? '-' : item.v;
                var vp = parseInt(item.v * item.p * 100) * (item.pch > 0 ? 1 : -1);
                item.volumnColor = item.bs != 4 ? vp >= 200000 ? 'purple' : vp > 0 ? 'red' : vp <= -200000 ? 'blue' : vp < 0 ? 'green' : '' : '';
            }
            modules = {
                state: json.result,
                data: json.value.data
            }
        } else {
            modules = {
                state: json.result,
                data: []
            }
        }
        $(_opt.container).html(pageRender(modules));

        if (!json.result) {
            $('#detail-msg-more').hide();
        } else {
            $('#detail-msg-more').show();
            $('#detail-msg-more a')
                .attr('href', 'http://quote.eastmoney.com/f1.html?id=' + _opt.id)
        }
        if (typeof _opt.oncomplete === 'function') {
            _opt.oncomplete.apply(self, [json, _opt]);
        }
    }

    function onerror(jqXHR, textStatus, error) {
        console.error(error);
    }
}

module.exports = deals;