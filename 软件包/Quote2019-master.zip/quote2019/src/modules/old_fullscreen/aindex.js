// require("../style/reset.less");
// require("../style/head.less");
// require("../style/right-aindex.less");

//require('eventsource-polyfill');
require('./ie_sse_polyfill');

var main = require("./aindex/main.html");
var right = require("./aindex/right.html");


var uri = require("./common/uri");
var renderBlock = require("./common/renderBlock");

var config = require("./aindex/config");


var addEvent = require("./aindex/addEvent");
var chartManager = require("./chart/index");
var getdata = require("./aindex/getdata");

module.exports = function(){
    $(".main").html(main);
    $(".righ").html(right);




    renderBlock(config.head);
    var pars = uri.getParams();

    getdata(pars);



    var ctm = new chartManager(pars);

    addEvent(ctm, pars);



    // console.log('指数');

    //右侧
    var h = window.innerHeight;
    // console.log('h', h) 
    if (h <= 969) {
        //增加滚动条
        $(".jdzf").hide();

        var hei = (h - 520) + 'px';
        $(".fscj").css('height', hei);
        $(".fscj").css('overflow', 'auto');

    }

}