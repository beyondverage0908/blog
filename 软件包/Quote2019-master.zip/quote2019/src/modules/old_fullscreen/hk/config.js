var fomrat = require("../common/format");
var geturl = require("../tools/url");
module.exports = {

    host: geturl.get_url(),
    head: [
        [
            {
                name: "今开：",
                cls: "jk",
                color: "zs"
            },
            {
                name: "昨收：",
                cls: "zs",
                color: "zs"
            }
        ],
        [
            {
                name: "最高：",
                cls: "zg",
                color: "zs"
            },
            {
                name: "最低：",
                cls: "zd",
                color: "zs"
            }
        ],
        [
            {
                name: "52周最高：",
                cls: "zg52",
                color: "zs"
            },
            {
                name: "52周最低：",
                cls: "zd52",
                color: "zs"
            }
        ],
        [
            {
                name: "成交量：",
                cls: "cjl",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "成交额：",
                cls: "cje",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "内盘：",
                cls: "np",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "外盘：",
                cls: "wp",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "总市值：",
                cls: "zsz",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "总股本：",
                cls: "zgb",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "流通市值：",
                cls: "lz",
                cb: function (num) {
                    return fomrat.num(num);
                }
            },
            {
                name: "流通股本：",
                cls: "ltg",
                cb: function (num) {
                    return fomrat.num(num);
                }
            }
        ],
        [
            {
                name: "市盈率：",               
                cls: "syl",
            },
            {
                name: "市净率：",             
                cls: "sjl",
            }
        ],
        [
            {
                name: "每股收益：",
                cls: "mgsy",
            },
            {
                name: "每股净资产：",
                cls: "mgjzc",
            }
        ],
        [
            {
                name: "换手率：",
                cls: "hs",
                sub: "%"
            },
            {
                name: "股息率：",
                cls: "gxl",
            }
        ],
        
    ]


};