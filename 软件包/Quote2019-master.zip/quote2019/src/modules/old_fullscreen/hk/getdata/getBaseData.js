var merge = _.merge;
var template = require("./template");

var renderHead = require("../../common/renderHead");
var uri = require("../../common/uri");
var config = require("../config");

var renderMmp = require("./renderMmp");
var renderXddp = require("./renderXddp");

var user = require('../../user');
var islogin = user.get() ? true: false;
// islogin = true;

function data(par) {
    this.par = par;

    this.publicData = {};

    this.renderMmp = new renderMmp();

    this.id = '';  //默认为国内ip
    this.hugantong = ''
    this.login = islogin;


    if(!this.login ) {
        var span1 = '<span>点击立即领取L2十档行情</span>';
        $(".hqbj .download a").html(span1);
    }

    //行情报价
    this.getData();

}


data.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58, 106, 105, 62, 106, 108],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85], // 基础字段
        [51, 52, 116, 84, 92, 55, 126, 109], // 港股的一些字段
        [123, 124, 125], // 相对大盘涨跌幅
        [530], // 10档买卖盘
        [119, 120, 121, 122], // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 177] // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    //正式接口
    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);
    //测试
    //  var fullurl = "http://61.129.249.233:18665/" + "api/qt/stock/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
                var obj = msg;
                that.id = obj.lt;
                // console.log('海外ip')
                // console.log(that.id)
                // that.id=2
               
                if(obj.data) {
                    that.hugantong = obj.data.f177 & (128|256);
                    
                    // console.log('沪深港通 标识')
                    // console.log(that.hugantong)
                     //假
                    // that.hugantong = 0

                    //开始行情报价
                    that.format(obj.data);

                }
               



                //若是国外ip  修改行情报价中间的字
                if(that.id == 2) {
                    var span1 = '<span>应港交所要求，仅大陆（不含港、澳、台地区）登录用户，才能免费享受本公司港股Level-2活动</span>';
                    $(".hqbj .download a").html(span1);

                    $(".hqbj .download a").attr("href", "###");
                    $(".hqbj .download a").attr("disabled","disabled"); 
                    $(".hqbj .download a").attr("cursor","default"); 
                    $(".hqbj .download a").hover(function () {
                        $(".hqbj .download a").attr("cursor","default");
                    })
                    $(".hqbj .download a").click(function (event) {
                        event.preventDefault();   // 如果<a>定义了 target="_blank“ 需要这句来阻止打开新页面
                    });

                    $("#finance_queue").click(function (event) {
                        event.preventDefault();   // 如果<a>定义了 target="_blank“ 需要这句来阻止打开新页面
                    });


                    //若是海外ip  显示弹框
                    $("#chinese_alert").show();
                }

                 //若是国外ip  修改经纪队列图片
                if(that.id == 2) {

                    $("#finance_queue").html("<div><a target='_blank' style='color:red;font-size: 15px;font-weight: bold;text-decoration:default;position: absolute;top: 48%;left:0;padding: 0px 29px;' href='https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=http%3a%2f%2f183.136.160.79%3a8080%2fEM_HKL2%2f%3fcode%3d00700'>应港交所要求，仅大陆（不含港、澳、台地区）登录用户，才能免费享受本公司港股Level-2活动>></a></div>");
                    $("#finance_queue").css("background", "url(http://quotationtest.eastmoney.com/web/Content/images/quecn1.png)"); //http://hqres.eastmoney.com/EMHKl2/images/jjdl-mask.png
                    var height = $(".hqbjjjdl").height() - 59;
                    $("#finance_queue").css("height", height); 
                    $("#finance_queue").css("text-align", 'center');  
                    $("#finance_queue").css("background-size", "100% 100%");
                    $("#finance_queue").css("background-repeat", "no-repeat");
                    $("#finance_queue").click(function (e) {
                        // window.open("https://zqhd.eastmoney.com/Html/hkhd/pc/20171019/html/activity1.html?tz=web_act_161118ggl2_hdrk_01_01_20_0&cburl=http%3A%2F%2Fquote.eastmoney.com%2Fhk%2F00700.html");
                        // that.stopPropagation(e);
                    });
                }


                //增加点击事件
                that.renderClick();
                

                //经济队列  
                //国内 && 非登录 
                if (!that.login && that.id !== 2) {
                    $("#finance_queue").html("<div><a target='_blank' style='color:red;font-size: 15px;font-weight: bold;text-decoration:default;' href='https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=http%3a%2f%2f183.136.160.79%3a8080%2fEM_HKL2%2f%3fcode%3d00700'>点击立即领取经纪队列>></a></div>");
                    $("#finance_queue").css("background", "url(http://quotationtest.eastmoney.com/web/Content/images/quecn1.png)"); //http://hqres.eastmoney.com/EMHKl2/images/jjdl-mask.png
                    var height = $(".hqbjjjdl").height() - 59;
                    $("#finance_queue").css("height", height);
                    $("#finance_queue").css("line-height", height+'px');
                    $("#finance_queue").css("text-align", 'center');  
                    $("#finance_queue").css("background-size", "100% 100%");
                    $("#finance_queue").css("background-repeat", "no-repeat");
                    $("#finance_queue").click(function (e) {
                        window.open("https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=http%3a%2f%2f183.136.160.79%3a8080%2fEM_HKL2%2f%3fcode%3d00700");
                        that.stopPropagation(e);
                    });

                    $("#finance_queue div a").click(function (e) {
                        // console.log('000')
                        that.stopPropagation(e);
                    });


                    $(".hqbj .download a").attr("href", "https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=http%3a%2f%2f183.136.160.79%3a8080%2fEM_HKL2%2f%3fcode%3d00700");


                    // return;
                }

                //登录和非国外ip
                $("#finance_queue").css("padding-bottom", "10px");
                

                
                //若是国内ip 登录了 就放出sse接口
                if(that.id !== 2 && that.login) {

                     //国内 登录 的 才去请求经纪队列接口
                     that.getHqQueData();


                    //行情报价 sse
                    that.getSSEData();
                    //经纪队列 sse
                    that.getSSEhqqueData();

                }


                 //若是国内ip  未登录 并且是 沪股通的  就放出sse接口
                 if(that.id !== 2 && !that.login && that.hugantong) {
                    //行情报价 sse
                    that.getSSEData();
                    //经纪队列 sse
                    that.getSSEhqqueData();
                }
            

        }
    });

}


data.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58, 106, 105, 62, 106, 108],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85], // 基础字段
        [51, 52, 116, 84, 92, 55, 126, 109], // 港股的一些字段
        [123, 124, 125], // 相对大盘涨跌幅
        [530], // 10档买卖盘
        [119, 120, 121, 122], // 阶段涨幅
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149] // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = config.host + "api/qt/stock/sse?" + uri.parStringify(data);
    //测试
    // var fullurl = "http://61.129.249.233:18665/" + "api/qt/stock/sse?" + uri.parStringify(data);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }

}


data.prototype.format = function (d) {
    // console.log(d)
    var that = this;

    var pdata = this.publicData;

    var oldo = this.o || {}; // 旧的对象

    var o = {};

    var f = oldo.f || Math.pow(10, d.f59) || 1;
    var f59 = oldo.f59 || d.f59;
    if (f59 < 2) {
        f59 = 2;
    }
    o.f59 = f59;
    o.f = f;

    if (d.f85) {
        o.ltg = d.f85; // 流通股
    }

    if (d.f58) {
        o.name = d.f58;
    }
    if (d.f57) {
        o.code = d.f57 + '.hk';
    }


    if (d.f43) {
        o.xj = (d.f43 / f).toFixed(f59) || "-";
    }
    if (d.f46) {
        o.jk = (d.f46 / f).toFixed(f59) || "-";
    }
    if (d.f60) {
        o.zs = (d.f60 / f).toFixed(f59);
    }
    if (d.f44) {
        o.zg = (d.f44 / f).toFixed(f59) || "-";
    }
    if (d.f45) {
        o.zd = (d.f45 / f).toFixed(f59) || "-";
    }
    if (d.f43) {
        var zs = (oldo.zs || d.f60 / f);
        o.zde = (d.f43 / f - zs).toFixed(f59);
        o.zdf = ((d.f43 / f - zs) / zs * 100).toFixed(f59);
    }
    // if ((oldo.ltg || d.f85) && d.f47) {
    //     var ltg = oldo.ltg || d.f85;
    //     o.hs = ((d.f47 / ltg) * 100).toFixed(f59);
    // }
    if (d.f106) {
        o.f106 = d.f106;
    }
    if ((oldo.ltg || d.f85) && d.f47) {
        var ltg = oldo.ltg || d.f85;
        var f106 = oldo.f106 || d.f106;
        o.hs = ((d.f47 / ltg * f106) * 100).toFixed(2);
    }
    if (d.f44 || d.f45) {
        var zg = d.f44 / f || oldo.zg;
        var zd = d.f45 / f || oldo.zd;
        var zs = oldo.zs || d.f60 / f;
        o.zf = ((zg - zd) / zs * 100).toFixed(f59);
    }
    if (d.f47) {
        o.cjl = d.f47;
    }
    if (d.f48) {
        o.cje = d.f48;
    }
    if (d.f49) {
        o.wp = d.f49;
        o.np = (oldo.cjl || d.f47) - d.f49;
    }
    if (d.f113) {
        o.szjs = d.f113;
    }
    if (d.f114) {
        o.xdjs = d.f114;
    }
    if (d.f115) {
        o.ppjs = d.f115;
    }
    if (d.f117) {
        o.lz = d.f117;
    }

    o.jdzf = {};
    if (d.f119) {
        o.jdzf.day5 = d.f119 / 100;
    }
    if (d.f120) {
        o.jdzf.day20 = d.f120 / 100;
    }
    if (d.f121) {
        o.jdzf.day60 = d.f121 / 100;
    }
    if (d.f122) {
        o.jdzf.dayyear = d.f122 / 100;
    }


    // 资金流
    o.zjl = {}

    // 其他 4个
    if (d.f135 || d.f136 || d.f137) {
        o.zjl.zl = [d.f135, d.f136, d.f137];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.cd = [d.f138, d.f139, d.f140];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.dd = [d.f141, d.f142, d.f143];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.zd = [d.f144, d.f145, d.f146];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.xd = [d.f147, d.f148, d.f149];
    }

    try {
        // 净资金流
        o.zjl.jzjl = [
            d.f140 || oldo.zjl.cd[2],
            d.f143 || oldo.zjl.dd[2],
            d.f146 || oldo.zjl.zd[2],
            d.f149 || oldo.zjl.xd[2]
        ];

    } catch (error) {

    }


    // 52 周
    if (d.f51) {
        o.zg52 = (d.f51 / f).toFixed(f59) || "-";
    }
    if (d.f52) {
        o.zd52 = (d.f52 / f).toFixed(f59) || "-";
    }

    if (d.f116) {
        o.zsz = d.f116;
    }
    if (d.f84) {
        o.zgb = d.f84;
    }
    if (d.f108) {
        o.mgsyttm = d.f108;
    }

    // 市盈率ttm
    if (d.f43 || d.f60 || d.f108) {
        var xj = d.f43 / f || oldo.xj;
        var zs = d.f60 / f || oldo.zs;

        var mgsyttm = d.f108 || oldo.mgsyttm;

        var chu = xj || zs;

        if (mgsyttm) {
            o.syl = (chu / mgsyttm).toFixed(f59);
        } else {
            o.syl = "-";
        }
    }


    if ((d.f43 || d.f60) && d.f92) {
        var xj = d.f43 / f || d.f60;
        var mgjzc = d.f92 || oldo.mgjzc;
        if (mgjzc) {
            o.sjl = (xj / mgjzc).toFixed(f59);
        } else {
            o.sjl = "-";
        }
    }

    if (d.f55) {
        o.mgsy = (d.f55).toFixed(f59)
    }
    if (d.f92) {
        o.mgjzc = (d.f92).toFixed(f59);
    }

    if (d.f126) {
        o.gxl = d.f126 + '%';
    }

    // 相对大盘涨跌幅
    if (d.f123 || d.f124 || d.f125) {
        o.xddp = {}
        o.xddp.month1 = d.f123 / 100 || oldo.xddp.month1;
        o.xddp.month3 = d.f124 / 100 || oldo.xddp.month3;
        o.xddp.week52 = d.f125 / 100 || oldo.xddp.week52;
    }


    // 买卖盘
    var mmp = {};
    var login = this.login; //用于区分登录状态，处理行情报价的显示条数

    // console.log('format  处理数据')
    // console.log(this.hugantong)
    //非海外的登录 和 非登录 情况
    if(this.id !== 2) {
        if(login) {
            mmp.buy = [
            [d.f21 / f, d.f22, d.f221],
            [d.f23 / f, d.f24, d.f222],
            [d.f25 / f, d.f26, d.f223],
            [d.f27 / f, d.f28, d.f224],
            [d.f29 / f, d.f30, d.f225],
            [d.f31 / f, d.f32, d.f226],
            [d.f33 / f, d.f34, d.f227],
            [d.f35 / f, d.f36, d.f228],
            [d.f37 / f, d.f38, d.f229],
            [d.f39 / f, d.f40, d.f230]
        ]
            mmp.sell = [
                [d.f19 / f, d.f20, d.f231],
                [d.f17 / f, d.f18, d.f232],
                [d.f15 / f, d.f16, d.f233],
                [d.f13 / f, d.f14, d.f234],
                [d.f11 / f, d.f12, d.f235],
                [d.f9 / f, d.f10, d.f236],
                [d.f7 / f, d.f8, d.f237],
                [d.f5 / f, d.f6, d.f238],
                [d.f3 / f, d.f4, d.f239],
                [d.f1 / f, d.f2, d.f240]
        ]
    
        }
        
        //国内未登录 and 沪股通
        if(!login && this.hugantong) {
            // console.log('22')
            mmp.buy = [
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                [d.f39 / f, d.f40, d.f230]
            ]
            mmp.sell = [
                [d.f19 / f, d.f20, d.f231],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-']
            ]


        }

        //国内未登录 and 不是沪股通
        if (!login && !this.hugantong){
            // console.log('333')
            mmp.buy = [
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-']
            ]
            mmp.sell = [
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-'],
                ['-', '-', '-']
            ]

        }

    }

    //海外情况
    if(this.id == 2)  {
        mmp.buy = [
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-']
        ]
        mmp.sell = [
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-'],
            ['-', '-', '-']
        ]


    }
    
    
    o.mmp = mmp;


    this.o = merge(oldo, o);

    this.render(o);

}


data.prototype.render = function (obj) {

    // console.log(obj);

    renderHead(config.head, obj);
    renderXddp(obj.xddp);

    var oldo = this.o || {};
    var zs = oldo.zs || obj.f60;

    //渲染行情报价
    this.renderMmp.setData(obj, zs);

    // console.log(obj.mmp)

    // renderZjl(obj);



}


data.prototype.renderClick = function () {

    $(".fiancequ").click(function () {
        $(".fiancequ").css("background", "#D3D3D3");
        $(".hangqp").css("background", "#fff");
        $("#finance_queue").show();
        $("#hangQA").hide();
    })

    $(".hangqp").click(function () {
        $(".hangqp").css("background", "#D3D3D3");
        $(".fiancequ").css("background", "#fff");
        $("#hangQA").show();
        $("#finance_queue").hide();
    })


    $("#chinese_alert .alert-remind b").click ( function() {
        $("#chinese_alert #bg").hide();
        $("#chinese_alert .alert-container").hide();

    })


    $("#chinese_alert .commit a").click ( function() {
        $("#chinese_alert #bg").hide();
        $("#chinese_alert .alert-container").hide();

    })
}


data.prototype.getHqQueData = function () {
    var that = this;
    var par = this.par;
    var secid = par.market + "." + par.code

    var fullurl = "http://push2.eastmoney.com/api/qt/stock/brkq/get?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + secid;

    //测试地址
    // var fullurl = "http://61.129.249.233:18665/api/qt/stock/brkq/get?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + secid;

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                var arr = obj.data.brkq;
                that.manerData(arr);
            }

        }
    });


}


data.prototype.getSSEhqqueData =  function () {

    var that = this;
    var par = this.par;
    var secid = par.market + "." + par.code

    var fullurl = "http://push2.eastmoney.com/api/qt/stock/brkq/sse?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + secid;

    // var fullurl = "http://61.129.249.233:18665/api/qt/stock/brkq/sse?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + secid;

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data);
        if (obj.rc == 0 && obj.data) {
            var arr = obj.data.brkq;

            that.manerData(arr);

        }
    }

}


//处理经济队列数据
data.prototype.manerData = function (arr) {
    // var that = this;

    var oldo = this.ol || {}; // 旧的对象

    var o = {};

    o.Blist = [];
    o.Slist = [];
    for (var i = 0; i < arr.length; i++) {
        var item = arr[i];
        if (item.substr(0, 1) == 'S') {
            o.Slist.push(item)
        } else if (item.substr(0, 1) == 'B') {
            o.Blist.push(item)
        }
    }

    // console.log(o.Blist)
    // console.log(o.Slist);


    this.ol = merge(oldo, o);

    var fullData = []
    for (var i = 0; i < this.ol.Blist.length; i++) {
        var temp = this.ol.Blist[i].split(',');

        for (var j = 0; j < temp.length; j++) {
            var tempj = temp[j].split('.');
            var shou = '';
            var name = '';
            shou = tempj[0];
            name = tempj[1];
            if (j == 0) {
                shou = tempj[0].split(':')[1];
            }
            var str = shou + '~' + name + '~' + 'B~' + (i + 1);
            fullData.push(str);

        }

    }


    for (var i = 0; i < this.ol.Slist.length; i++) {
        var temp = this.ol.Slist[i].split(',');

        for (var j = 0; j < temp.length; j++) {
            var tempj = temp[j].split('.');
            var shou = '';
            var name = '';
            shou = tempj[0];
            name = tempj[1];
            if (j == 0) {
                shou = tempj[0].split(':')[1];
            }
            var str = shou + '~' + name + '~' + 'S~' + (i + 1);
            fullData.push(str);

        }

    }
    
    var fullDatastr = fullData.join('|');

    // console.log(fullDatastr)

    //渲染经济队列
    this.renderFianceQe(fullDatastr);


}

//渲染经济队列
data.prototype.renderFianceQe = function (data) {
    var that = this;
    var lines = '';
    if(data) {
        lines = data.split('|');
    }
    

    var login = this.login;

    
    var blist = new Array(),
        slist = new Array();

    var currentIndexBuy = 0;
    var currentIndexSell = 0;

    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (!line) continue;
        var datum = line.split('~');

        if (datum.length > 1) {
            if (datum[2].toUpperCase() == "B") {
                if (currentIndexBuy != datum[3]) {
                    currentIndexBuy = datum[3];
                    blist.push({
                        idx: datum[3],
                        dir: datum[2],
                        seat: datum[0],
                        name: datum[1],
                        direction: "买" + currentIndexBuy
                    });
                } else {
                    blist.push({
                        idx: datum[3],
                        dir: datum[2],
                        seat: datum[0],
                        name: datum[1],
                        direction: ""
                    });
                }

            } else if (datum[2].toUpperCase() == "S") {
                if (currentIndexSell != datum[3]) {
                    currentIndexSell = datum[3];
                    slist.push({
                        idx: datum[3],
                        dir: datum[2],
                        seat: datum[0],
                        name: datum[1],
                        direction: "卖" + currentIndexSell
                    });
                } else {
                    slist.push({
                        idx: datum[3],
                        dir: datum[2],
                        seat: datum[0],
                        name: datum[1],
                        direction: ""
                    });
                }
            }
        }
    }
    var _bhtml = template("tmp_finance_queue", {
        list: blist
    });
    var _shtml = template("tmp_finance_queue", {
        list: slist
    });
    $("#finance_queue_buy tbody").html(_bhtml);
    $("#finance_queue_sell tbody").html(_shtml);
    var _herf = template("tmp_href", {
        logined: login
    });
    $("#finance_href").html(_herf);
}



data.prototype.stopPropagation = function (e) {
    e = e || window.event;
    if (e.stopPropagation) { //W3C阻止冒泡方法  
        e.stopPropagation();
    } else {
        e.cancelBubble = true; //IE阻止冒泡方法  
    }
}


module.exports = data;