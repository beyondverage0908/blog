var getBaseData = require("./getBaseData");
// var getJjdl = require("./getJjdl");

module.exports = function(par){

    new getBaseData(par);
    // new getJjdl(par);

};