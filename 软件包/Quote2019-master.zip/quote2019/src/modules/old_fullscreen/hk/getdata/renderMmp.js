var merge = _.merge;
var format = require("../../common/format");

function mmp() {

    this.data = {
        buy: [],
        sell: []
    }

    this.init();
}

mmp.prototype.init = function () {

    this.buy = $(".hqbj .buy");
    this.sell = $(".hqbj .sell");

    for (var i = 0, len = 10; i < len; i++) {
        var tr1 = $("<tr><td>卖" + (10 - i) + "</td><td>-</td><td>-</td><td>-</td></tr>");
        var tr2 = $("<tr><td>买" + (i + 1) + "</td><td>-</td><td>-</td><td>-</td></tr>");
        this.buy.append(tr1);
        this.sell.append(tr2);
    }

}

mmp.prototype.setData = function (fulldata, zs) {
    var sd = this.data;

    var data = fulldata.mmp;

    for (var key in data) {
        var dk = data[key];
        for (var i = 0, len = dk.length; i < len; i++) {
            var ar = dk[i];
            for (var ii = 0, len2 = ar.length; ii < len2; ii++) {
                var v = ar[ii];
                if (v + "" != "NaN" && v !== undefined && v !== '-') {
                    var td = this[key].find("tr").eq(i).find("td").eq(ii + 1);
                    
                    if (!sd[key][i]) {
                        sd[key][i] = [];
                    }
                    sd[key][i][ii] = v;
                    if (ii == 0) {
                        if (v > zs) {
                            td.removeClass().addClass("rise");
                        }
                        if (v < zs) {
                            td.removeClass().addClass("fall");
                        }
                        v = (v / 1).toFixed(3);
                    }
                    if (ii == 1) {
                        v = format.num(v);
                    }
                    if (ii == 2) {
                        v = "(" + v + ")";
                    }

                    
                    td.text(v)
                }
            }
        }
    }

}



module.exports = mmp;