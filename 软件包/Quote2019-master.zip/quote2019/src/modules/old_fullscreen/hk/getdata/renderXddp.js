module.exports = function (data) {

    if (!data) {
        return false;
    }
    
    var width = 160;

    var rows = $(".xddpbox .row");

    var month1 = data.month1 || 0;
    var month3 = data.month3 || 0;
    var week52 = data.week52 || 0;

    var max = Math.max(Math.abs(month1), Math.abs(month3), Math.abs(week52));

    var tit = ["1个月", "3个月", "52周"]
    var arr = [month1, month3, week52];

    for (var i = 0, len = arr.length; i < len; i++) {
        var val = arr[i];
        if (val && max > 0) {
            var row = rows.eq(i);
            row.find("label").text(tit[i] + " " + (val / 1).toFixed(2) + "%");

            var w = width * Math.abs(val) / max;
            var span = row.find("span");
            span.width(Math.abs(w + 1));
            span.removeClass();
            if (val > 0) {
                span.addClass("risebg")
            } else if (val < 0) {
                span.addClass("fallbg")
            } else {
                span.addClass("pingbg")
            }
        }
    }


};