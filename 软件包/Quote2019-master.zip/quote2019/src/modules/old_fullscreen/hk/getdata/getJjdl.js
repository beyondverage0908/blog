var uri = require("../../common/uri");
var config = require("../config");


function jjdl(par){
    this.par = par;
    this.getData();
}


jjdl.prototype.getData = function () {
    var that = this;
    var par = this.par;
    
    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: "f1",
        secid: par.market + "." + par.code
    }

    var fullurl = config.host + "api/qt/stock/sse?" + uri.parStringify(data);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        // console.log(obj);
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }

}


jjdl.prototype.format = function () {
    
}



module.exports = jjdl;