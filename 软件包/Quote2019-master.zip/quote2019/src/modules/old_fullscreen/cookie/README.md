# js读写cookie

```js
var cookie = require('em-cookie')

cookie.get('name')

//expiredays 过期天数
//doamin 域名
cookie.set('name', value, expiredays, domain)

cookie.del('name', domain)
```

