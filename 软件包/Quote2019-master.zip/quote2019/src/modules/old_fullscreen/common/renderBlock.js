
module.exports = function(heads){

    var selector = ".head .right";
    var box = $(selector);

    for(var i = 0, len = heads.length ; i < len ; i++){
        var block = heads[i];
        var blockBox = $("<div class='block'></div>")
        for(var ii = 0, len2 = block.length ; ii < len2 ; ii++){
            var line = block[ii];
            var row = $("<div class='row'></div>");
            var label = $("<label><label>").text(line.name);
            var span = $("<span>-<span>").attr("class", line.cls);
            row.append(label).append(span);
            blockBox.append(row);
        }
        box.append(blockBox);
    }
    
};