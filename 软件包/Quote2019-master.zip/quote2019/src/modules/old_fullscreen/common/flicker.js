module.exports = function(dom){

    $(dom).css("background-color", "rgba(255,0,0,0.5)");
    $(dom).animate({
        "backgroundColor": "rgba(255,0,0,0)"
    }, 300);
    
};