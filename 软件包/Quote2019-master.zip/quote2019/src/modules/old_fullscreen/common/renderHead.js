var flicker = require("./flicker");

module.exports = function (heads, data) {

    var head = heads;
    var obj = data;

    for (var i = 0; i < head.length; i++) {
        var ar = head[i];
        for (var ii = 0; ii < ar.length; ii++) {
            var blk = head[i][ii];
            var val = obj[blk.cls];
            var sub = blk.sub || "";
            var span = $(".head ." + blk.cls);

            // if (blk.cls == "hs") {
            //     console.log("hhhhhhhhhhh");
            // }

            if (val !== undefined) {
                if (blk.color !== undefined) {
                    var bj = "";
                    if (typeof blk.color === "string") {
                        bj = obj[blk.color];
                    } else {
                        bj = blk.color;
                    }
                    if (val > bj) {
                        span.addClass("rise")
                    } else if (val < bj) {
                        span.addClass("fall")
                    } else {
                        span.addClass("ping")
                    }
                }

                if (blk.cb) {
                    val = blk.cb(val);
                }
                var txt = val;
                if (val !== "-") {
                    txt += sub;
                }
                span.text(txt);
                if (blk.type != 1) {
                    flicker(span);
                }
            }
        }

    }


    $(".head .name").text(obj.name);
    $(".head .code").text(obj.code);
    var zde = $(".head .zde");
    var zdf = $(".head .zdf");
    var prise = $(".head .prise")
    prise.text(obj.xj);
    if (obj.zde > 0) {
        prise.addClass("triangle-up").addClass("rise");
    } else if (obj.zde < 0) {
        prise.addClass("triangle-down").addClass("fall");
    }

    if (obj.zde !== undefined) {
        if(obj.zde <= 0 ) {
            zde.text(obj.zde);
        }else if(obj.zde > 0) {
            zde.text('+' + obj.zde);
        }
        
        flicker(zde);
    }
    if (obj.zdf !== undefined) {
        if(obj.zdf <= 0) {
            zdf.text(obj.zdf + "%");
        }else if(obj.zdf > 0) {
            zdf.text('+' + obj.zdf + "%");
        }
        
        flicker(zdf);
    }

    if (obj.zde > 0) {
        zde.removeClass("fall").addClass("rise");
        zdf.removeClass("fall").addClass("rise");
    }
    if (obj.zde < 0) {
        zde.removeClass("rise").addClass("fall");
        zdf.removeClass("rise").addClass("fall");
    }




//判断right宽度,增加右侧left的自适应
var w = window.innerWidth;
// console.log('w,', w);
if(w <= 1550) {
    // console.log('小于1550')
    $(".fullbox .head .right .block").css("font-size", "12px");
    // $(".fullbox .head .left .name").css("font-size", "12px");
    $(".fullbox .head .right .block").css("margin-left", "10px");
    $(".fullbox .head .right .block").css("padding-right", "3px");
    // $(".fullbox .head .left .prise").css("font-size", "12px");
    
}else {
    $(".fullbox .head .right .block").css("font-size", "14px");
    $(".fullbox .head .right .block").css("margin-left", "40px");
    $(".fullbox .head .left .prise").css("font-size", "20px");
    $(".fullbox .head .right .block").css("padding-right", "5px");
}



    
    

};

