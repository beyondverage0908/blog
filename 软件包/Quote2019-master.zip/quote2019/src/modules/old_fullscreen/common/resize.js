module.exports = function () {

    var time = 0;

    window.onresize = function () {
        // console.log("rrrrrrrrrr");
        var w = window.innerWidth;
        var t = Date.now();

        if (w > 1800 && t - time > 2000) {
            location.reload();
        }

    }



};