module.exports = {

    getParams: function () {
        var str = location.search.substr(1);
        var arr = str.split("&");

        var obj = {};
        for (var i = 0, len = arr.length; i < len; i++) {
            var ar = arr[i].split("=");
            obj[ar[0]] = ar[1];
        }

        if (obj.mcid) {
            var temp = obj.mcid.split(".");
            obj.market = temp[0];
            obj.code = temp[1];
        }

        var chartBox = $(".chart-box");

        obj.width = chartBox.width();
        obj.height = chartBox.height();

        return obj;
    },


    parStringify: function(obj){
        var arr = [];
        for (var k in obj) {
            arr.push(k + "=" + obj[k]);
        }
        return arr.join("&")
    }


};