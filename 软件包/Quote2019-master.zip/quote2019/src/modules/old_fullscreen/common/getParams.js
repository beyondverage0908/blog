module.exports = function(){

    var str = location.search.substr(1);
    var arr = str.split("&");

    var obj = {};
    for(var i = 0, len = arr.length ; i < len ; i++){
        var ar = arr[i].split("=");
        obj[ar[0]] = ar[1];
    }


    var chartBox = $(".chart-box");

    obj.width = chartBox.width();
    obj.height = chartBox.height();

    return obj;
    
};