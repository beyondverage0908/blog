module.exports = {

    num: function (num, xs) {
        xs = xs === undefined ? 2 : xs;
        var abs = Math.abs(num);
        var fix = "";
        var res = "";

        if (abs + "" == "NaN") {
            return "-";
        } else {
            if (abs < 10000) {
                res = num;
            } else if (abs >= 10000 && abs < 100000000) {
                res = num / 10000;
                fix = "万"
            } else if (abs >= 100000000 && abs < 1000000000000) {
                res = num / 100000000;
                fix = "亿"
            } else if (abs >= 1000000000000) {
                res = num / 1000000000000;
                fix = "万亿"
            }
           // console.log(num , res)
            return res.toFixed(xs) + fix;
        }

    }


};