/**
 * 首页登录信息
 */
var user = require('./user');
var loginbox = require('../loginbox/loginbox'); 
var lazyload = require('../lazyload/lazyload')
var browser = require('../browser/browser');



module.exports = function (){
	var userdata = user.get();
	//console.info(userdata);
	if( userdata == null ){ //未登录

		var selfhref = self.location.href;
		var is18 = false;
		if (selfhref.indexOf('18.com.cn') >= 0) {
			is18 = true;
			selfhref = selfhref.replace('18.com.cn', 'eastmoney.com');
		}


		if (browser.isie6()) {
			$('#loginlink').add('#notlogin_icon').on('click', function (){
				window.open('http://exaccount2.eastmoney.com/BroswerUpgrade.html');
			});
		}
		else{
			if(is18){
	            var _oto = null;
	            $('#loginlink').on('mouseover', function(){
	                _oto = setTimeout(function(){location.href='http://www.eastmoney.com/'},300);
	            });
	            $('#loginlink').on('mouseout', function(){
	                clearTimeout(_oto);
	            });
	        }
	        else{
	        	loginbox.bindClick($('#loginlink'));
	        }
		    
		    loginbox.bindClick($('#notlogin_icon'));			
		}

	    $('#reglink').attr('href','https://passport2.eastmoney.com/pub/reg?backurl=' + selfhref);
	    $('#qqloginlink').attr('href','https://passport2.eastmoney.com/pub/jsonapi/QQLogin?backUrl=' + selfhref);
	    $('#wxloginlink').attr('href','https://exaccount2.eastmoney.com/jsonapi/WXLogin?backUrl=' + selfhref);
	    $('#wbloginlink').attr('href','https://passport2.eastmoney.com/pub/jsonapi/SinaLogin?backUrl=' + selfhref);
	}
	else{ //已登录
	    $('#user_nologin').hide();
	    $('#user_logined').show();
	    $('#user_ledphoto').html('<a href="http://i.eastmoney.com/"><img isrc="http://avator.eastmoney.com/qface/' + userdata.id + '/50" width="45" height="45" class="userphoto" id="userphoto"></a>');
	    $('#user_ledlink').text(userdata.nick);
	    $('#logoutlink').on('click', function(){
	       user.logOut(function(){
	           self.location.reload();
	       }); 
	    });
	    var ll_userphoto = new lazyload({
	        type: 'iframe',
	        objid: 'userphoto'
	    });
	    ll_userphoto.init();
	    
	    var jiavspan = $('#jiavspan');
	    // var jiavinfo = $('#jiavinfo');
	    // switch (userdata.jiav.vtype) {
	    //     case 1:
	    //         jiavinfo.html('<em class="icon icon_jiavp"></em>');
	    //         break;
	    //     case 2:
	    //         jiavinfo.html('<em class="icon icon_jiavp"></em>');
	    //         break;
	    //     case 3:
	    //         jiavinfo.html('<em class="icon icon_jiavq"></em>');
	    //         break;
	    // }

	    switch (userdata.jiav.vtype) {
	        case 1:
	            $('#user_ledphoto').append('<em class="icon icon_jiavp"></em>');
	            break;
	        case 2:
	            $('#user_ledphoto').append('<em class="icon icon_jiavp"></em>');
	            break;
	        case 3:
	            $('#user_ledphoto').append('<em class="icon icon_jiavq"></em>');
	            break;
	    }    
	    
	    if (userdata.jiav.state == 12 || userdata.jiav.state == 13) {
	        jiavspan.html('您的加V认证信息正在审核中');
	    }
	    else if(userdata.jiav.state == 11) {
	        jiavspan.html('加V认证审核未通过 <a href="http://v.eastmoney.com/">重新认证</a>');
	    }
	    else if(userdata.jiav.state == 0) {
	        jiavspan.html('您已经通过' + userdata.jiav.name + '加V认证');
	    }
	    else{
	        jiavspan.html('加V信息尚未认证&nbsp; <a href="http://v.eastmoney.com/">立即认证</a>');
	    }
	}	
};