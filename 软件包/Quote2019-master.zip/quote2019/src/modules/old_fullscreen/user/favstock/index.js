/**
 * 自选股
 */

var jpromise = require('../jpromise')
var user = require('../user')
var islogin = user.get() ? true: false


var zxgurl = 'http://myfavor1.eastmoney.com/' //f=gsaandcheck
var zxgurl2 = 'http://myfavor1.eastmoney.com/' //f=gsaandcheck


var zxg = {
    data: function(zxgparams){
        var apistr = 'mystock_web'
        if(!islogin){
            apistr = 'mystock_webanonym'
        }
        return $.ajax({
            type: "GET",
            url: zxgurl + apistr + '?cb=?',
            data: zxgparams,
            dataType: "jsonp"
        });
    }
}


var zxg2 = {
    data: function(zxgparams){
        var apistr = 'mystock_web'
        if(!islogin) {
            apistr = 'mystock_webanonym'
        }
        return $.ajax({
            type: "GET",
            url: zxgurl2 + apistr,
            data: zxgparams,
            dataType: "jsonp",
            jsonp:'cb'
        });
    }
}

module.exports = {
    /**
     * 获取默认分组的自选股列表
     */
    getDefaultStocks: function(){
        return zxg.data({
            f: 'gsaandcheck'
        }).then(function(list){
            // console.log('原 list')
            // console.log(list)
            return list.data.list
        })
    },
    /**
     * 添加自选
     *
     */
    add: function(code){
        return zxg2.data({
            f: 'asz',
            sc: code
        }).then(function(list){
            // console.log(list)
           // return list.result
            if (list.result == 1) {
                return true
            }
            else{
                return false
            }
        })
    },
    del: function(code){
        return zxg2.data({
            f: 'dsz',
            sc: code
        }).then(function(list){
            // console.log(list)
            //return list.result
            if (list.result == 1) {
                return true
            }
            else{
                return false
            }
        })
    },
    get: function(code){
        // return new jpromise(function(resolve, reject){
        //     resolve(false)
        // })
        return zxg2.data({
            f: 'gsaandcheck',
            sc: code
        }).then(function(list){
            // console.log(list)
            //return list.result
            //return false;
            if (list.data.check == 'True') {
                return true
            }
            else{
                return false
            }
        })

    }
}