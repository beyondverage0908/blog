/**
 * 用户信息
 */

var cookie = require('../cookie/');

/**
 * 用户
 */
var user = {
    /**
     * 获取用户信息
     */
    get: function(){
        if (cookie.get('ut') && cookie.get('ct') && cookie.get('uidal')) {
            
            //获取加v信息
            var jiav = {vtype:null, state: null, name: ''};
            if (cookie.get('vtpst') && cookie.get('vtpst') != '|') {
                var jiavarr = cookie.get('vtpst').split('|');
                if( jiavarr.length > 1 ){
                    //console.info(typeof jiavarr[0]);
                    if (jiavarr[1] == "0" || jiavarr[1] == "3") {
                        switch (jiavarr[0]) {
                            case "301":
                                jiav.vtype = 1;
                                jiav.name = '理财师';
                                break;
                            case "302":
                                jiav.vtype = 2;
                                jiav.name = '非理财师';
                                break;
                            case "303":
                                jiav.vtype = 3;
                                jiav.name = '企业';
                                break;
                            default:
                                break;
                        }
                    }

                    switch (jiavarr[1]) {
                        case "0":
                            jiav.state = 0; //审核通过
                            break;                        
                        case "1":
                            jiav.state = 11; //审核未通过
                            break;
                        case "2":
                            jiav.state = 12; //审核中
                            break;
                        case "3":
                            jiav.state = 13; //加v用户修改审核
                            break;
                        case "8":
                            jiav.state = 18; //加v用户修改审核
                            break;
                        case "9":
                            jiav.state = 19; //加v用户修改审核
                            break;
                        default:
                            break;
                    }
                    
                    //console.info(jiav);

                }
            }
            
            return {
              id: cookie.get('uidal').substring(0,16),
              nick: cookie.get('uidal').substring(16),
              jiav: jiav
            };
        }
        return null; 
    },
    /**
     * 退出登录
     * @param  {function} 退出之后回调
     */
    logOut: function (callback) {
        var date = new Date();
        document.cookie = "pi=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "ct=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "ut=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        document.cookie = "uidal=;path=/;domain=eastmoney.com;expires=" + date.toGMTString();
        if (callback) {
            callback();
        }
    },
    isLogin: function (){
        if( this.get() ){
            return true;
        }
        else{
            return false;
        }
    }
};

module.exports = user;



