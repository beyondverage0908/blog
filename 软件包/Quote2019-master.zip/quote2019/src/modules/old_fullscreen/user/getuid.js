/**
 * 登录用户获取uid,未登录用户获取指纹
 */

var user = require('./index')
var fingerprint = require('../browser_fingerprint')

module.exports = {
  get: function(){
    return new Promise(function(resolve, reject){
      if (user.get() != null) {
        resolve(user.get().id)
        return
      }
      
      fingerprint.get(function(zw){
        resolve(zw)
      })
    })
  }
}