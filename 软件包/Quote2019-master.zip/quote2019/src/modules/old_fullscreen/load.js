var resize = require("./common/resize");

resize(); //后期改过来
// 用于加载不同的js
; (function () {

    var str = location.search.substr(1);
    var arr = str.split("&");

    var obj = {};
    for (var i = 0, len = arr.length; i < len; i++) {
        var ar = arr[i].split("=");
        obj[ar[0]] = ar[1];
    }

    if (obj.mcid) {
        var temp = obj.mcid.split(".");
        obj.market = temp[0];
        obj.code = temp[1];
    }


    var market = obj.market;
    var js = "";

    switch (market) {
        case "1":
        case "0":
            js = "aindex";
            break;
        case "90":
            js = "bk";
            break;
        case "116":
            js = "hk";
            break;
        case "105":
        case "106":
        case "107":
            js = "us";
            break;
    }



    if (location.href.indexOf("http://127") >= 0) {
        $.getScript("../dist/" + js + ".js");
    } else if(location.href.indexOf("hqtest") > 0 || location.href.indexOf("quotationtest")>0 ) {
        $.getScript("http://hqtest.eastmoney.com/web/Content/js/static/dist/" + js + ".js")       
    } else if(location.href.indexOf("quote") > 0 ) {
        $.getScript("http://hqres.eastmoney.com/EMQuote_Basic/2018/js/dist/" + js + ".js")    //上线前确认下地址
    }
    



})();