var utils = require('../modules/utils.extend');
var jsonp = require('../modules/jsonp');
var isProd = environment === 'production';
var emchartscdn = EMCHARTSCDN;
/** @type {{chartdataurl: string, changedataurl: string}} */
var serverurls = SERVERURLS;
var newsapiurl = isProd ? '//cmsdataapi.eastmoney.com/api/infomine' : '//cmsdataapi.test.emapd.com/api/infomine';
var emcharts3 = window.emcharts3 || null;

function charts(type, args) {
    var self = this;
    var timer, chart;
    this.args = args;
    this.inited = false;
    this.datacache = false;
    this.chartType = type;

    /**
     * 创建emcharts3实例
     */
    var _create = this.create = function () {
        return _init.apply(self, [type, emcharts3]);
    }

    /**
     * 销毁当前实例
     */
    var _destory = this.destory = function () {
        chart = null;
        return this;
    }

    /**
     * 停止更新
     * @param {boolean} destory 是否销毁
     */
    var _stop = this.stop = function (destory) {
        if (typeof destory === 'undefined') destory = true;
        clearInterval(timer);
        if (destory) _destory();
        return this;
    }

    /**
     * 重载图像
     */
    var _reload = this.reload = function () {
        _load.apply(self);

        if (self.args.update > 0) {
            timer = setInterval(function () {
                _load.apply(self);
            }, self.args.update);
        }
    }

    /**
     * 加载图表
     */
    this.load = function () {
        self.inited = false;
        _stop();
        chart = _create();
        if (typeof chart.start === 'function') chart.start();
        _reload();
        return chart;
    }

    function _load() {
        if (typeof this.dataloader === 'function') {
            this.dataloader.apply(this);
        } else chart.draw();
    }

    function _init(type, emcharts3) {
        switch (type) {
            case 'time':
                return timeLoader.apply(this, [args]);
            case 'k':
                return kLoader.apply(this, [args]);
            default:
                if (typeof emcharts3[type] === 'function')
                    return new emcharts3[type](args);
                else return null;
        }
    }
}

charts.preload = function (callback, error) { //异步加载
    if (typeof emcharts3 === 'function') {
        if (typeof callback === 'function') callback(emcharts3);
        return emcharts3;
    }
    try {
        var script = document.createElement('script');
        script.id = 'emcharts3-script';
        script.setAttribute('src', emchartscdn);
        if (typeof error === 'function')
            script.onerror = error;
        document.getElementsByTagName("head")[0].appendChild(script);
        script.onload = script.onreadystatechange = function (evt) {
            emcharts3 = require('emcharts3');
            if (typeof callback === 'function') callback.call(emcharts3);
        }
    } catch (e) {
        console.error(e);
    }
}

/**
 * 分时图加载器
 * @param {*} args 分时图参数
 */
function timeLoader(args) {
    var self = this;
    var _opt = this.args = utils.extend({
        entry: {},
        container: '#chart-container',
        width: 720,
        height: 600,
        type: 'r',
        iscr: false,
        gridwh: {
            //height: 25,
            width: window.screen.availWidth
        },
        padding: {
            top: 0,
            bottom: 5
        },
        color: {
            line: '#326fb2',
            fill: ['rgba(101,202,254, 0.2)', 'rgba(101,202,254, 0.1)']
        },
        data: {
            time: [],
            positionChanges: []
        },
        tip: {
            show: true,
            trading: true
        },
        show: {
            indicatorArea: true, // 分时指标
            CMA: true,
            ddx: args.type === 'r',
            cf: args.type === 'r',
            cfjumptip: false
        },
        onClickChanges: function () {
            window.open('//quote.eastmoney.com/changes/stocks/' + args.entry.shortmarket + args.entry.code + '.html');
        },
        onComplete: function () {

        },
        onError: function (err) {
            console.error(err);
        },
        update: 40 * 1000
    }, args);
    var timer
    var chart = new emcharts3.time(_opt);
    // 加载数据
    this.dataloader = function () {
        if (!this.datacache) {
            this.datacache = {
                time: {},
                positionChanges: []
            };
        }
        jsonp(serverurls.chartdataurl, {
            rtntype: 5,
            id: args.entry.id,
            type: args.type,
            iscr: args.iscr
        }, 'cb', function (json) {
            chart.stop();
            if (!json || json.stats === false) return false;
            self.datacache.time = json;
            self.datacache.datak = false;
            chart.setData(self.datacache);
            clearTimeout(timer);
            timer = setTimeout(function () {
                // 打点
                makepoints(chart, args);
                // 盘口异动
                drawPositionChange();
            }, 500);
            // 分钟K线
            if (_opt.show && _opt.show.indicatorArea) {
                drawIndicators();
            }
            if (self.inited) chart.redraw();
            else {
                chart.draw();
                self.inited = true;
            }
        }, function (e) {
            console.error(e);
        });
    }
    return chart;
    /**
     * 盘口异动
     */
    function drawPositionChange() {
        jsonp(serverurls.changedataurl, {
            id: args.entry.id,
        }, 'cb', function (changes) {
            if (!changes) return false;
            if (typeof changes[0] !== 'string') return false;
            self.datacache.positionChanges = changes;
            chart.setData(self.datacache);
            if (self.inited) chart.redraw();
            else chart.draw();
        }, function () {

        });
    }

    /**
     * 分时指标
     */
    function drawIndicators() {
        jsonp(serverurls.chartdataurl, {
            rtntype: 5,
            id: args.entry.id,
            type: _opt.type + 'k',
            iscr: false
        }, 'cb', function (datak) {
            if (!datak) return false;
            if (datak.stats != false) {
                self.datacache.datak = datak;
                chart.setData(self.datacache);
                if (self.inited) chart.redraw();
                else chart.draw();
            }
        }, function () {

        });
    }
}

/**
 * K图加载器
 * @param {*} args K图参数
 */
function kLoader(args) {
    var timer, chart;
    var _opt = this.args = utils.extend({
        entry: {},
        container: "#chart-container",
        width: 720,
        height: 600,
        padding: {
            top: 10,
            //right: 0,
            bottom: 0
        },
        color: {
            border: '#eee'
        },
        show: {
            CMA: true,
            lr: args.type === 'k',
            cf: args.type === 'k',
            lrjumptip: false,
            cfjumptip: false
        },
        scale: {
            pillar: 60,
            min: 10
        },
        popWin: {
            type: "move"
        },
        yAxisType: 1,
        maxin: {
            //show: true,
            lineWidth: 30, // 线长
            skewx: 0, // x偏移   
            skewy: 0, // y偏移
        },
        data: {
            k: []
        },
        onComplete: function () {

        },
        onDragEnd: function () {
            clearTimeout(timer);
            timer = setTimeout(function () {
                makepoint(chart, args);
            }, 500);
        },
        onClick: function () {},
        onError: function (err) {
            console.error(err);
        },
        update: 60 * 1000
    }, args);
    //utils.extend(args, _opt);
    chart = new emcharts3.k2(_opt);
    this.dataloader = function () {
        jsonp(serverurls.chartdataurl, {
            rtntype: 6,
            id: args.entry.id,
            type: args.type,
            authorityType: args.authorityType
        }, 'cb', function (json) {
            chart.stop();
            if (!json || json.stats === false) return false;
            chart.setData({
                k: json
            }, _opt);
            if (self.inited) chart.redraw();
            else chart.draw();
            clearTimeout(timer)
            timer = setTimeout(function () {
                makepoints(chart, args);
            }, 500);
        }, function (e) {

        });
    }
    return chart;
}


function makepoints(chart, args) {
    var istimechart = ['r', 't2', 't3', 't4', 't5'].indexOf(args.type) >= 0;
    var displayInfomine = ['r', 't2', 't3', 't4', 't5', 'k', 'wk', 'mk'].indexOf(args.type) >= 0;
    if (displayInfomine) newsnoticepoints.apply(this);
    if (!istimechart) {
        //exrightspoints.apply(this);
    }

    /**
     * 新闻公告打点
     */
    function newsnoticepoints() {
        var data = istimechart ? chart.getData() : chart.getData().data;
        if (data instanceof Array) {
            var starttime = data[0][0],
                endtime = data[data.length - 1][0];
            var param = {
                code: args.entry.code,
                marketType: args.entry.marketnum,
                types: '1,2',
                startTime: starttime,
                endTime: endtime,
                format: istimechart ? 'yyyy-MM-dd HH:mm' : 'yyyy-MM-dd'
            };
            jsonp(newsapiurl, param, 'cb', function (json) {
                if (json && json.Data instanceof Array) {
                    /** 
                     * @typedef {{type: string, url: string, title: string, date: string}} InfoMine
                     * @type {Array.<InfoMine>} 
                     */
                    var points = [];
                    for (var i = 0; i < json.Data.length; i++) {
                        /** @type {{Time: string, Type: number, Title: string, Url: string, Code: string}} */
                        var element = json.Data[i];
                        if (!element.Time) continue;
                        points.push({
                            type: makepoints.newsTypeMap[element.Type],
                            date: element.Time,
                            title: element.Title,
                            url: element.Url
                        });
                    }
                    var newstpl = '<a href="{{url}}" title="{{title}}" target="_blank">{{date}}&nbsp;{{type}}&nbsp;{{title}}</a>';
                    chart.setData({
                        dot: {
                            infomine: {
                                position: 'top',
                                width: 9,
                                height: 9,
                                className: 'icon-mine',
                                /**
                                 * @param {InfoMine} point
                                 */
                                formatter: function (point) {
                                    if (!point) return '';
                                    return simpleTemplate(newstpl, point);
                                },
                                multiple: {
                                    className: 'icon-mine-muti'
                                },
                                points: points
                            }
                        }
                    });
                    if (istimechart) chart.redraw();
                    else chart.draw();
                    //chart.redraw();
                }
            }, function (err) {
                console.error('新闻打点异常', err);
            });
        }
    }

    /**
     * 除权除息打点
     */
    function exrightspoints() {
        // type: 1（派现）2（送股，转增）4（拆细合并）8（配股，供股）16（增发）
        jsonp(exrightsurl, {
            id: (args.entry.marketnum == 1 ? 'SH' : 'SZ') + args.entry.code,
            ut: 'e1e6871893c6386c5ff6967026016627'
        }, 'cb', function (json) {
            if (!json) return false;
            if (json.rc === 0 && json.data) {
                chart.setData({
                    dot: {
                        exrights: {
                            position: 'bottom',
                            width: 7,
                            height: 13,
                            className: 'icon-exrights',
                            formatter: formatter,
                            points: json.data.records
                        }
                    }
                });
                chart.draw();
            }
        }, function (err) {
            console.error('除权除息打点异常', err);
        });

        /**
         * 格式化器
         * @param {object} point 除权除息数据
         * @param {string} point.date 日期
         * @param {number} point.type 1:派现,2:送股、转增,4:拆细合并,8:配股、供股,16:增发
         * @param {number} point.pxbl 派现比例
         * @param {number} point.sgbl 送股（转增）比例
         * @param {number} point.cxbl 拆细比例
         * @param {number} point.pgbl 配股（供股）比例
         * @param {number} point.pgjg 配股（供股）价格
         * @param {number} point.zfbl 增发比例
         * @param {number} point.zfgs 增发股数（万股）
         * @param {number} point.zfjg 增发价格
         * @param {number} point.ggflag 为1表示外盘供股价格高于除净日前一日收盘价，此时不做前复权
         */
        function formatter(point) {
            if(!point || !point.date) return '';
            var result = point.date;
        } 
    }
}

/**
 * 模板处理器
 * @param {string} tpl 模板
 * @param {*} data 数据
 */
function simpleTemplate(tpl, data) {
    try {
        var result = tpl || '';
        for (var key in data) {
            if (data.hasOwnProperty(key)) {
                var element = data[key];
                result = result.replace(new RegExp('{{' + key + '}}', 'g'), element);
            }
        }
        return result;
    } catch (error) {
        console.error(error);
    }
    return '';
}


makepoints.newsTypeMap = {
    '1': '[新闻]',
    '2': '[公告]',
    '3': '[研报]'
};

module.exports = charts;