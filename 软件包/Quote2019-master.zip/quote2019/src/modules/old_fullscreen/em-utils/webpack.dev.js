const pkg = require('./package.json');
const webpack = require('webpack');
const path = require('path');

module.exports = {
    mode: 'development',
    entry: {
        'em-utils': './index.js'
    },
    output: {
        filename: './[name].js',
        path: path.resolve(__dirname, 'dist'),
        library: 'utils',
        libraryTarget: 'umd'
    },
    devtool: 'source-map',
    plugins:[
        new webpack.BannerPlugin(`em-utils version @${pkg.version} Copyright Eastmoney`)
    ]
}