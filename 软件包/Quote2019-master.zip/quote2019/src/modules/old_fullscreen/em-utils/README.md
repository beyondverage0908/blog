# em-utils
网站行情通用工具库

## Install
``` shell
npm i em-utils --registry http://10.228.129.64:4873 --save
```
## Common Usage ##
```js
var utils = require('em-utils');
// foooooooooo -> foo
utils.cutstr('foooooooooo', 3, '');
```
## Features
 * provide common [polyfills](#Polyfills)
 * provide useful functions: [jsonp](#jsonp), [mini](#mini), [cookie](#cookie), [cutstr](#cutstr), [formatDate](#formatDate)

## Usage & Examples ##
### Polyfills ###
* JSON
* addEventListener
* requestAnimationFrame

```js
// use
require('em-utils/polyfills/addEventListener');
```

### jsonp ###
```js
var jsonp = require('em-utils/lib/jsonp');
var script = jsonp('http://example.com',{id:'example id'},'callback',function(data){
    // todo
}, function(){
    console.log('error');
});
// manually abort request
script.abort();
```

### mini ###

A lightweight dom selector, same as `document.querySelector('query');`
```js
var mini = require('em-utils/lib/mini');
// get doms by id
var dom_id = mini('#id1, #id2');
if (dom_id.length > 0) 
    dom_id[0].style.display = 'none';
// get doms by className
var dom_cls = mini('.class');
for (var i = 0; i < dom_cls.lenght; i++){
    dom_cls[i].style.display = 'block';
}
// from specific context
var dom_cls = mini('.c1', dom_id);
```

### cookie ###
```js
var cookie = require('em-utils/lib/cookie');
// get cookie
var val = cookie('abc');
// set cookie
cookie('bcd', 'test2', {
    expires: 10, // days
    domain: 'example.com',
    path: '/',
    secure: false
});
// delete cookie
cookie.remove('bcd');
```

### cutstr ###
```js
var cutstr = require('em-utils/lib/cutstr');
// 东方财富...
console.log(cutstr('东方财富信息股份', 8, '...'));
```

### formatDate ###
```js
var formatDate = require('em-utils/lib/formatDate');
var date = formatDate(new Date, 'yyyy-MM-dd EEE HH:mm:ss.SSS');
// 2018-08-15 星期三 23:25:10.235
console.log(date);
```