module.exports = {
    cache: require('./lib/cache'),
    cookie: require('./lib/cookie'),
    jsonp: require('./lib/jsonp'),
    mini: require('./lib/mini'),
    formateDate: require('./lib/formatDate'),
    cutstr: require('./lib/cutstr'),
    isDom: require('./lib/isdom'),
    stockutils: require('./lib/stockutils')
}