var getBaseData = require("./getBaseData");
var getFscj = require("./getFscj");

module.exports = function(par){

    new getBaseData(par);
    new getFscj(par);

};