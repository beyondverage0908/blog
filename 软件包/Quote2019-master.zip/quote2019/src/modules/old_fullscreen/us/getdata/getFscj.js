var renderFscj = require("./renderFscj");
var uri = require("../../common/uri");
var config = require("../config");



function fscj(par) {
    this.par = par;

    this.fscj = new renderFscj();

    this.getData();
    // this.getSSEData();
}

fscj.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields1: "f1,f2,f3,f4",
        fields2: "f51,f52,f53,f54,f55",
        secid: par.market + "." + par.code,
        pos: '-30'
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/details/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb'
    })
    .then(function (msg) {
        var obj = msg;
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    })
    .always(function(){
        // console.info(2222)
        that.getSSEData();
    })

}

fscj.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields1: "f1,f2,f3,f4",
        fields2: "f51,f52,f53,f54,f55",
        secid: par.market + "." + par.code,
        pos: '-30'
    }

    var fullurl = config.host + "api/qt/stock/details/sse?" + uri.parStringify(data);

   this.fscj.clear();
    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data)
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }

}


fscj.prototype.format = function(data){
    this.fscj.setData(data)
}


module.exports = fscj;

