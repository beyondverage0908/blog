var merge = _.merge;

var renderHead = require("../../common/renderHead");
var uri = require("../../common/uri");
var config = require("../config");

// var renderJdzf = require("./renderJdzf");
// var renderZjl = require("./renderZjl");

function data(par) {
    this.par = par;
    this.publicData = {};

    this.getData();
    this.getSSEData();
}

data.prototype.getData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58,106,108],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85],       // 基础字段
        [116, 84, 109, 126, 55, 92, 105,62],     
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 164],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            var obj = msg;
            if (obj.rc == 0 && obj.data) {
                that.format(obj.data);
            }

        }
    });

}


data.prototype.getSSEData = function () {
    var that = this;
    var par = this.par;

    var zds = [
        [57, 58,106,108],
        [59, 43, 46, 60, 44, 45, 47, 48, 49, 113, 114, 115, 117, 85],       // 基础字段
        [116, 84, 109, 126, 55, 92, 105,62],     
        [135, , 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 164],     // 资金流
    ]


    var fils = [];
    for (var i = 0, len = zds.length; i < len; i++) {
        for (var ii = 0, len2 = zds[i].length; ii < len2; ii++) {
            if (zds[i][ii]) {
                fils.push("f" + zds[i][ii]);
            }
        }
    }

    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: fils.join(","),
        secid: par.market + "." + par.code
    }

    var fullurl = config.host + "api/qt/stock/sse?" + uri.parStringify(data);

    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        var obj = JSON.parse(msg.data);
        if (obj.rc == 0 && obj.data) {
            that.format(obj.data);
        }
    }
    

}


data.prototype.format = function (d) {
    var pdata = this.publicData;


    var oldo = this.o || {};       // 旧的对象

    var o = {};

    var f = oldo.f || Math.pow(10, d.f59) || 1;
    var f59 = oldo.f59 || d.f59;
    if (f59 < 2) {
        f59 = 2;
    }
    o.f59 = f59;
    o.f = f;

    if (d.f85) {
        o.ltg = d.f85;  // 流通股
    }



    if (d.f58) {
        o.name = d.f58;
    }
    if (d.f57) {
        o.code = d.f57;
    }


    if (d.f43) {
        o.xj = (d.f43 / f).toFixed(f59) || "-";
    }
    if (d.f46) {
        o.jk = (d.f46 / f).toFixed(f59) || "-";
    }
    if (d.f60) {
        o.zs = (d.f60 / f).toFixed(f59);
    }
    if (d.f44) {
        o.zg = (d.f44 / f).toFixed(f59) || "-";
    }
    if (d.f45) {
        o.zd = (d.f45 / f).toFixed(f59) || "-";
    }
    if (d.f43) {
        var zs = (oldo.zs || d.f60 / f);
        o.zde = (d.f43 / f - zs).toFixed(f59);
        o.zdf = ((d.f43 / f - zs) / zs * 100).toFixed(f59);
    }
    // if ((oldo.ltg || d.f85) && d.f47) {
    //     var ltg = oldo.ltg || d.f85;
    //     o.hs = ((d.f47 / ltg) * 100).toFixed(f59);
    // }
    if (d.f106) {
        o.f106 = d.f106;
    }
    if ((oldo.ltg || d.f85) && d.f47) {
        var ltg = oldo.ltg || d.f85;
        var f106 = oldo.f106 || d.f106;
        o.hs = ((d.f47 / ltg * f106) * 100).toFixed(f59);
    }
    if (d.f44 || d.f45) {
        var zg = d.f44 / f || oldo.zg;
        var zd = d.f45 / f || oldo.zd;
        var zs = oldo.zs || d.f60 / f;
        o.zf = ((zg - zd) / zs * 100).toFixed(f59);
    }
    if (d.f47) {
        o.cjl = d.f47;
    }
    if (d.f48) {
        o.cje = d.f48;
    }
    if (d.f49) {
        o.wp = d.f49;
        o.np = (oldo.cjl || d.f47) - d.f49;
    }
    if (d.f113) {
        o.szjs = d.f113;
    }
    if (d.f114) {
        o.xdjs = d.f114;
    }
    if (d.f115) {
        o.ppjs = d.f115;
    }
    if (d.f117) {
        o.lz = d.f117;
    }
    if(d.f116){
        o.zsz = d.f116;
    }
    if(d.f84){
        o.zgb = d.f84;
    }

    o.jdzf = {};
    if (d.f119) {
        o.jdzf.day5 = d.f119 / 100;
    }
    if (d.f120) {
        o.jdzf.day20 = d.f120 / 100;
    }
    if (d.f121) {
        o.jdzf.day60 = d.f121 / 100;
    }
    if (d.f122) {
        o.jdzf.dayyear = d.f122 / 100;
    }


    o.zjl = {}
    // 其他 4个
    if (d.f135 || d.f136 || d.f137) {
        o.zjl.zl = [d.f135, d.f136, d.f137];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.cd = [d.f138, d.f139, d.f140];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.dd = [d.f141, d.f142, d.f143];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.zd = [d.f144, d.f145, d.f146];
    }
    if (d.f138 || d.f139 || d.f140) {
        o.zjl.xd = [d.f147, d.f148, d.f149];
    }


    if (d.f55) {
        o.mgsy = (d.f55).toFixed(f59)
    }
    if (d.f92) {
        o.mgjzc = (d.f92).toFixed(f59);
    }
    if (d.f126) {
        o.gxl = d.f126;
    }
    // if (d.f109) {
    //     o.syl = (d.f116 / d.f109).toFixed(f59)
    // }

    if (d.f105) {
        o.jlr = d.f105;
    }
    // 财报季度
    if (d.f62) {
        o.cbjd = d.f62;
    }
    
    // 静态市盈率
    // if (d.f109 || d.f116) {
    //     var zsz = oldo.zsz || d.f116;
    //     if (d.f109) {
    //         o.syl = (zsz / d.f116).toFixed(f59);
    //     } else {
    //         o.syl = "-";
    //     }
    // }

    // 动态市盈率
    // if (d.f116 || d.f105 || d.f62) {
    //     var zsz = d.f116 || oldo.zsz;
    //     var jlr = d.f105 || oldo.f105 || 0;
    //     var cbjd = d.f62 || oldo.cbjd;
    //     o.syl = (zsz / jlr * cbjd / 4).toFixed(f59);
    // }
    
    // 市盈率ttm
    // if (d.f43 || d.f60 || d.f108) {
    //     var xj = d.f43 / f || oldo.xj;
    //     var zs = d.f60 / f || oldo.zs;
    //     var mgsyttm = d.f108 || oldo.mgsyttm;

    //     var chu = xj || zs;
    //     if (mgsyttm) {
    //         o.syl = (chu / mgsyttm).toFixed(f59);
    //     } else {
    //         o.syl = "-";
    //     }
    // }

    //修改市盈率
    if (d.f164) {
        var shiyinglv = (d.f164 / f).toFixed(f59);
        if( shiyinglv >= 0 ) {
            o.syl = shiyinglv;
        }else if( shiyinglv < 0 ) {
            o.syl = "亏损";
        }
    }



    this.o = merge(oldo, o);

    this.render(o);

}


data.prototype.render = function (obj) {

    
    if (obj.zde) {
        $(".head .zde").text(obj.zde)
    }
    
    obj.zs = this.o.zs;

    renderHead(config.head, obj);


}

module.exports = data;