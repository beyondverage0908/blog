var changeNum = require('./random');

module.exports = {

    get_url: function () {
        var str = '';
        //测试环境 "http://61.152.230.153:38619/"
        str = "https://" + changeNum() + ".push2.eastmoney.com/";
        return str;
    },
    get_Hisurl: function () {
        var str = '';
        str = "http://" + changeNum() +".push2his.eastmoney.com/";
        return str;

    }
}