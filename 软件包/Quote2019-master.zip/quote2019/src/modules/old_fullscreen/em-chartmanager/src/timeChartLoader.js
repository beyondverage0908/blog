var merge = _.merge
var throttle = _.throttle;
var jsonp = require('../../em-utils/lib/jsonp');
var dServerUrls = require('./serverUrls');
var makepoints = require('./makepoints');

function isAStock(jys) {
    return ['2', '6', '13', '80'].indexOf(jys) >= 0;
}

/**
 * 分时图加载器
 * @param {object} args 分时图参数
 * @param {object} args.entry 个股参数
 * @param {string} args.entry.id ID
 * @param {string} args.entry.code 代码
 * @param {string} args.entry.market 市场号
 * @param {'sh'|'sz'} args.entry.shortmarket 短市场
 * @param {string} args.entry.JYS 内部细分市场 
 * @param {string} args.type 分时图类型
 * @param {Object.<string,object>} args.styles 样式配置集合
 * @param {Object.<string,string>} args.serverUrls 服务端地址
 */
function timeChartLoader(args) {
    var self = this;
    var _opt = this.args = merge({
        entry: {},
        container: '#chart-container',
        width: 720,
        height: 655,
        type: 'r',
        iscr: false,
        color: {
            line: '#326fb2',
            fill: ['rgba(101,202,254, 0.2)', 'rgba(101,202,254, 0.1)']
        },
        // 网格线
        gridwh: {
            width: 720
        },
        data: {
            time: [],
            positionChanges: []
        },
        show: {
            indicatorArea: false, // 分时指标
            CMA: true,
            ddx: args.type === 'r',
            cf: args.type === 'r',
            infomine: true
        },
        styles: {},
        serverUrls: dServerUrls,
        onClickChanges: function () {
            // 盘口异动
            window.open('//quote.eastmoney.com/changes/stocks/' + _opt.entry.shortmarket + _opt.entry.code + '.html');
        },
        onComplete: function () {

        },
        onError: function (err) {
            console.error(err);
        },
        update: 40 * 1000
    }, args);
    
    var chart = new emcharts3.time(_opt);
    /** @type {throttle} */
    var throttled;
    // 加载数据
    this.dataloader = function () {
        if (!this.datacache) {
            this.datacache = {
                time: {},
                positionChanges: []
            };
        }
        jsonp(_opt.serverUrls.chartDataUrl, {
            rtntype: 5,
            id: _opt.entry.id,
            type: _opt.type,
            iscr: _opt.iscr
        }, 'cb', function (json) {
            if (typeof chart.stop === 'function') chart.stop();
            if (!json || json.stats === false) return false;
            self.datacache.time = json;
            chart.setData(self.datacache);

            // 分钟K线
            if (_opt.show && _opt.show.indicatorArea) {
                drawIndicators();
            }
            if (self.inited) chart.redraw();
            else {
                chart.draw();
                self.inited = true;
            }

            if (!throttled) {
                throttled = throttle(function () {
                    // 盘口异动，只有A股
                    if (isAStock(json.info.jys)) {
                        drawPositionChange();
                    }
                    if (_opt.show.infomine) {
                        makepoints['infomine'].apply(self, [chart, _opt]);
                    }
                }, _opt.update);
            }
            throttled();
        }, function (e) {
            console.error(e);
        });
    }

    return chart;

    /**
     * 盘口异动
     */
    function drawPositionChange() {
        jsonp(_opt.serverUrls.positionChangeDataUrl, {
            id: _opt.entry.id
        }, 'cb', function (changes) {
            if (!changes) return false;
            if (typeof changes[0] !== 'string') return false;
            self.datacache.positionChanges = changes;
            chart.setData(self.datacache);
            if (self.inited) chart.redraw();
            else chart.draw();
        }, function () {

        });
    }
    /**
     * 分时K指标
     */
    function drawIndicators() {
        jsonp(_opt.serverUrls.chartDataUrl, {
            rtntype: 5,
            id: _opt.entry.id,
            type: _opt.type + 'k',
            iscr: false
        }, 'cb', function (datak) {
            if (!datak) return false;
            if (datak.stats != false) {
                self.datacache.datak = datak;
                chart.setData(self.datacache);
                if (self.inited) chart.redraw();
                else chart.draw();
            }
        }, function () {

        });
    }
}

module.exports = timeChartLoader;