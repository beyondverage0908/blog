var merge = _.merge
var throttle = _.throttle
var jsonp = require('../../em-utils/lib/jsonp');
var dServerUrls = require('./serverUrls');
var makepoints = require('./makepoints');

/**
 * K线图加载器
 * @param {object} args K线图参数
 * @param {object} args.entry 个股参数
 * @param {string} args.entry.id ID
 * @param {string} args.entry.code 代码
 * @param {string} args.entry.market 市场号
 * @param {'sh'|'sz'} args.entry.shortmarket 短市场
 * @param {string} args.entry.JYS 内部细分市场
 * @param {string} args.type K线类型
 * @param {'fa'|'ba'|''} args.authorityType 除复权状态
 * @param {Object.<string, object>} args.styles 样式配置集合
 * @param {Object.<string, string>} args.serverUrls 服务端地址
 */
function kChartLoader(args) {
    var self = this;
    var timer, chart;
    var _opt = this.args = merge({
        entry: {},
        container: "#chart-container",
        width: 720,
        height: 655,
        show: {
            CMA: true,
            // 除权除息打点
            cqcx: ['k', 'wk', 'mk'].indexOf(args.type) >= 0,
            // 信息地雷打点
            infomine: ['k', 'wk', 'mk'].indexOf(args.type) >= 0,
            lr: args.type === 'k',
            cf: args.type === 'k'
        },
        padding: {
            top: 0,
            bottom: 0
        },
        kgap: {},
        scale: {
            pillar: 60,
            min: 10
        },
        popWin: {
            type: "move"
        },
        yAxisType: 1,
        maxin: {
            //show: true,
            lineWidth: 30, // 线长
            skewx: 0, // x偏移   
            skewy: 0 // y偏移
        },
        data: {
            k: []
        },
        styles: {},
        serverUrls: dServerUrls,
        onComplete: function () {

        },
        onClick: function () {},
        onDragEnd: function () {
            clearTimeout(timer);
            timer = setTimeout(function () {
                if (_opt.show.infomine) {
                    makepoints['infomine'].apply(self, [chart, _opt]);
                }
            }, 500);
        },
        onError: function (err) {
            console.error(err);
        },
        update: 60 * 1000
    }, args);

    // 打点预留高度
    if (_opt.show.cqcx && !_opt.kgap.bottom) {
        _opt.kgap.bottom = 18 + 13;
    }
    if (_opt.show.infomine && !_opt.kgap.top) {
        _opt.kgap.top = 18 + 9;
    }

    chart = new emcharts3.k2(_opt);
    /**@type {throttle} */
    var throttled;
    this.dataloader = function () {
        jsonp(_opt.serverUrls.chartDataUrl, {
            rtntype: 6,
            id: _opt.entry.id,
            type: _opt.type,
            authorityType: _opt.authorityType
        }, 'cb', function (json) {
            removeLoading();
            if (!json || json.stats === false) return false;
            chart.setData({
                k: json
            }, _opt);
            chart.draw();
            if (!throttled) {
                throttled = throttle(function () {
                    if (_opt.show.infomine) {
                        makepoints['infomine'].apply(self, [chart, _opt]);
                    }
                    if (_opt.show.cqcx) {
                        makepoints['exrights'].apply(self, [chart, _opt]);
                    }
                }, _opt.update);
            }
            throttled();
        }, function (e) {
            removeLoading();
            console.log('数据加载异常:' + _opt.serverUrls.chartDataUrl, e);
        });
    }
    return chart;
    /**
     * 移除loading
     */
    function removeLoading() {
        if (typeof chart.stop === 'function') chart.stop();
    }
}

module.exports = kChartLoader;