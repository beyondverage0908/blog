
module.exports = {
    /**
     * emcharts CDN地址
     */
    emchartscdn: (function (env) {
        return env === 'production' ? '//hqres.eastmoney.com/emcharts/v3/lts/emcharts.min.js' : '//172.16.58.95/emchart_test/EMCharts3/bundle/emcharts.js';
    })(window.environment),
    /**
     * 行情图数据
     */
    chartDataUrl: '//pdfm.eastmoney.com/EM_UBG_PDTI_Fast/api/js?token=4f1862fc3b5e77c150a2b985b12db0fd',
    /**
     * 盘口异动接口地址
     */
    positionChangeDataUrl: '//nuyd.eastmoney.com/EM_UBG_PositionChangesInterface/api/js?style=top&js=([(x)])&ac=normal&check=itntcd',
    /**
     * 新闻接口地址
     */
    newsApiUrl: '//cmsdataapi.eastmoney.com/api/infomine',
    /**
     * 除复权数据地址
     */
    exrightsDataUrl: '//push2.eastmoney.com/api/qt/stock/cqcx/get',
    /**
     * 兼容版图片地址
     */
    imageUrl: '//pifm.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx',
    /**
     * 兼容版分时图片地址
     */
    timeImageUrl: '//webquotepic.eastmoney.com/GetPic.aspx',
}