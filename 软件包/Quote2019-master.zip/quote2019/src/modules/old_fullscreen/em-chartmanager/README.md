# ChartManager

网站行情图管理器，基于emchart3的二次封装，参见 [emcharts3文档](http://172.16.58.95/emchart_test/EMCharts3/doc/index.html)