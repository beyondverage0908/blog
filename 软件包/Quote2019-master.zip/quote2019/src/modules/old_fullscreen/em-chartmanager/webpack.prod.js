const pkg = require('./package.json');
const webpack = require('webpack');
const path = require('path');
const UglifyJSPlugin = require('uglifyjs-webpack-plugin');

module.exports = {
    mode: 'none',
    entry: './src/manager',
    output: {
        filename: './chartManager.min.js',
        path: path.resolve(__dirname, 'dist'),
        library: 'chartManager',
        libraryTarget: 'umd'
    },
    devtool: 'source-map',
    externals: {
        emcharts3: 'emcharts3'
    },
    plugins:[
        new webpack.BannerPlugin(`em-utils version @${pkg.version} Copyright Eastmoney`),
        new webpack.EnvironmentPlugin({
            'process.env.NODE_ENV': JSON.stringify('production')
        }),
        new webpack.optimize.ModuleConcatenationPlugin(),
        new webpack.NoEmitOnErrorsPlugin(),
        new webpack.optimize.OccurrenceOrderPlugin(),
        new UglifyJSPlugin({
            sourceMap: true,
            uglifyOptions: {
                ie8: true,
                ecma: 5,
                compress: {
                    warnings: false,
                    drop_debugger: true,
                    drop_console: true
                }
            }
        })
    ]
}