const pkg = require('./package.json');
const webpack = require('webpack');
const path = require('path');

module.exports = {
    mode: 'development',
    entry: './src/manager',
    output: {
        filename: './chartManager.js',
        path: path.resolve(__dirname, 'dist'),
        library: 'chartManager',
        libraryTarget: 'umd'
    },
    devtool: 'source-map',
    externals: {
        emcharts3: 'emcharts3'
    },
    plugins:[
        new webpack.BannerPlugin(`em-utils version @${pkg.version} Copyright Eastmoney`)
    ]
}