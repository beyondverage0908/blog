// require("../style/reset.less");
// require("../style/head.less");
// require("../style/right-bk.less");

//require('eventsource-polyfill');
require('./ie_sse_polyfill');


var main = require("./bk/main.html");
var right = require("./bk/right.html");

var uri = require("./common/uri");
var renderBlock = require("./common/renderBlock");

var config = require("./bk/config");

var addEvent = require("./aindex/addEvent");
var chartManager = require("./chart/index");

var getdata = require("./bk/getdata");

module.exports = function(){
    $(".main").html(main);
    $(".righ").html(right);


    renderBlock(config.head);
    var pars = uri.getParams();
    getdata(pars)


    var ctm = new chartManager(pars);

    addEvent(ctm, pars);



    // console.log('板块');
    //头部
    var w = window.innerWidth;
    // console.log('w,', w);
    if (w <= 1750) {
        var parent = document.getElementsByClassName("right")[0];
        var child = document.getElementsByClassName("block");

        parent.removeChild(child[8]);

    }

    //右侧
    var h = window.innerHeight;
    // console.log('h', h)
    if (h <= 1200) {
        //增加滚动条
        var hei = (h - 550) + 'px';
        $(".bkcfg").css('height', hei);
        $(".bkcfg").css('overflow', 'auto');

    }  
}

