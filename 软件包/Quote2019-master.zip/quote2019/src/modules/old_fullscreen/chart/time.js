var merge = _.merge;

var geturl = require("../tools/url");

var uri = require("../common/uri");

var user = require('../user');
var islogin = user.get() ? true: false;

function chart(par) {
    this.par = par || {};

    this.option = {
        container: ".chart-box",
        width: par.width,
        height: par.height,
        type: par.type, 
        iscr: par.iscr ? 1 : 0,
        show: {
            tradingArea: true,
            indicatorArea: true,
        },
        gridwh: {
            width: 50000
        },
        restline: {
            isshow: true,
            color: "#eee",
            solid: 3,       // 实线长度
            dashed: 0,      // 虚线长度
        },
        tip: {
            trading: true
        },
        onError: function (err) {
            console.log(err);
        }
    };

    //console.info()

    this.url = geturl.get_url();
    this.urlHis = geturl.get_Hisurl();
    
    this.data = {
        fields1: "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13",
        fields2: "f51,f52,f53,f54,f55,f56,f57,f58",
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        iscr: par.iscr ? "1" : "0",
        ndays: 1
    };

    //登录状态
    this.login = islogin;

    this._init();
}


chart.prototype._init = function () {

    this.time = new emcharts3.time(this.option);

}


chart.prototype._getData = function () {
    var that = this;
    var par = this.par;
    var time = this.time;
    var data = this.data;
    var url = this.urlHis;

    if (par.market && par.code) {
        data.secid = par.market + "." + par.code;
    }

    // console.log('par.market')
    // console.log(par.market)

    var arr = [];
    for (var k in data) {
        arr.push(k + "=" + data[k]);
    }

    // 请求分时数据
    $.ajax({
        type: "get",
        url: url + "api/qt/stock/trends2/get?" + arr.join("&"),
        dataType: "jsonp",
        jsonp: "cb",
        success: function (msg) {
            time.setData({
                time: msg,
            });
            time.redraw();


            var obj = msg;
            that.id = obj.lt;
            //增加 港股 图 的  推送逻辑
            //若是国内ip 登录了 就放出sse接口
            // console.log('图')
            // console.log(msg)

            // if(that.id !== 2 && that.login) {
                 //图的sse接口
                // that._getSSE();
               
            // }
        }
    });
}


chart.prototype._getSSE = function () {
    var that = this;

    var par = this.par;
    var time = this.time;
    var data = this.data;
    var url = this.url;

    var typs = {
        r: 1,
        t2: 2,
        t3: 3,
        t4: 4,
        t5: 5,
    }

    if (par.market && par.code) {
        data.secid = par.market + "." + par.code;
    }
    if (par.type) {
        data.ndays = typs[par.type];
    }

    var arr = [];
    for (var k in data) {
        arr.push(k + "=" + data[k]);
    }   

    if(data.ndays > 1 && data.ndays < 6){
        url = this.urlHis
    }

    var fullurl = url + "api/qt/stock/trends2/sse" + "?" + arr.join("&");

    // console.info(fullurl)

    this.sseType = par.type;
    var evtSource = new EventSource(fullurl);
    evtSource.onmessage = function (msg) {
        // console.log(msg);
        var fdata = JSON.parse(msg.data)
        // console.log(fdata);

        if (fdata.rc == 0 && fdata.data) {

            var data = fdata.data;

            if (data.beticks) {
                that.fullData = fdata;
            } else {

                var source = that.fullData.data.trends;
                var last = source[source.length - 1].split(",");
                
                var trends = data.trends;
                var frist = trends[0].split(",");

                if (last[0] == frist[0]) {
                    source.pop();
                }
                for(var i = 0, len = trends.length ; i < len ; i++){
                    source.push(trends[i]);
                }
            }

            // console.log(that.fullData);
            time.setData({
                time: that.fullData,
            });
            time.redraw();
        }

    }

    this.sse = evtSource;
}


chart.prototype.setPar = function (par) {
    this.par = merge(this.par , par) ;
    this.time.option.type = par.type;
}


chart.prototype.go = function (type) {
    var that = this;

    if (this.sseType != this.type) {
        // console.log("结束");
        this.sse.close();
    }

    this._getData();

    //图的sse接口
    var data = {
        ut: "fa5fd1943c7b386f172d6893dbfba10b",
        fields: 'f107,f111,f177',
        secid: this.par.market + "." + this.par.code
    }
    //增加判断条件 若是为港股 增加 登录和非登录  图推送的逻辑
    var fullurl = "http://push2.eastmoney.com/" + "api/qt/stock/get?" + uri.parStringify(data);
    

    $.ajax({
        type: "get",
        data: '',
        url: fullurl,
        dataType: "jsonp",
        jsonp: 'cb',
        success: function (msg) {
            if(msg.data) {
                var data = msg.data;

                var mar = data.f107 == '116' || data.f107 == '128';
                var zqtype = data.f111 == '0' || data.f111 == '1' || data.f111 == '2' || data.f111 == '3' || data.f111 == '4' || data.f111 == '5' || data.f111 == '6';

                var hugantong = data.f177 & (128|256);
                //判断是否为港股
                if(mar && zqtype) {
                      
                    //并且是 国内  && 登录状态
                     if(that.id !== 2 && that.login) {
                        that._getSSE();
                     }

                     //或者是 国内 未登录 沪股通 的 港股
                     
                     if(that.id !== 2 && !that.login && hugantong) {
                         that._getSSE();
                     }


                } else {
                    // console.log('no')
                    that._getSSE();
                }
            }

        }
    })


    // this._getSSE();

}


module.exports = chart;


