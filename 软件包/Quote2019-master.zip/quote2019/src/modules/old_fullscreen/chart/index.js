var time = require("./time");
var k = require("./k");


function chartManager(par){
    this.par = par;
    this.type = this.par.type || "r";    // 默认是分时图

    this.k = null;
    this.time = null;

    this._init();
    
}


chartManager.prototype._init = function(){
    if (this.type.indexOf("k") > -1) {
        this.k = new k(this.par);
        this.time = null;
    } else {
        this.time = new time(this.par);
        this.k = null;
    }

    this.go();
}

chartManager.prototype.setType = function(type){
    if ((type || "").indexOf("k") > -1) {
        if (this.type.indexOf("k") == -1 && !this.k) {
            this.k = new k(this.par);
            this.time = null;
            // console.log("nnnnnnnnnnnnn kkkkkkkkkkk")
        }
    } else {
        if (!this.time) {
            this.time = new time(this.par);
            this.k = null;
            // console.log("nnnnnnnnnnnn ttttttttttt");
        }
    }

    this.type = type;

    // console.log(type);

    // console.log(this.time);
    // console.log(this.k)

    this.go();
}


chartManager.prototype.go = function() {
    if (this.k) {
        this.k.setPar({
            type: this.type
        })
        this.k.go();
    }
    if (this.time) {
        this.time.setPar({
            type: this.type
        })
        this.time.go();
    }
}


module.exports = chartManager;