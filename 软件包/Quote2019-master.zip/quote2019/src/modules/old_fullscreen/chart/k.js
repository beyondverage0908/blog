var merge = _.merge;

function chart(par) {
    this.par = par;

    this.option = {
        container: ".chart-box",
        width: par.width,
        height: par.height,  
        scale: {
            pillar: 50,
            min: 10
        },    
        onError: function (err) {
            console.log(err)
        }
    }

    this._init();
}


chart.prototype._init = function () {

    this.k = new emcharts3.k4(this.option);

}


chart.prototype._getData = function () {
    var par = this.par;

    var misd = {
        k: 101,
        wk: 102,
        mk: 103,
        m5k: 5,
        m15k: 15,
        m30k: 30,
        m60k: 60
    }

    this.k.setStock({
        secid: par.market + "." + par.code,
        klt: misd[par.type]
    });
    
}


chart.prototype.setPar = function (par) {
    this.par = merge(this.par , par) ;
    this.k.option.type = par.type;
}


chart.prototype.go = function (type) {

    this._getData();
}


module.exports = chart;


