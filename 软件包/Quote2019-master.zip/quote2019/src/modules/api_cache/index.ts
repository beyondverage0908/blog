/**
 * 接口缓存组件
 * 适用于不用太及时和量不太大的接口
 */

const config = require('../../../config/index.js')
import encryption from "../encryption"
import memorycache from "memory-cache"
import filecache from "../filecache"
import logger from "../logger"
import axios from "axios"
import {Method} from "axios"
import lodash from "lodash"
import object_hash from "object-hash";



/**
 * 是否开启api缓存
 */
const api_cache_enabled = config.getEnvParam('api_cache_enabled')

/**
 * 刷新缓存
 * @param options 
 */
async function refreshCache(key:string, cache_time:number, options:apicache_merge_options){
  if (Date.now() - cache_time < options.cache_time) { //时间少于过期时间 不刷新
    return false
  }

  // console.info('调异步接口')
  try {
    let aoptions:any = {
      method: options.method,
      url: options.url,
      timeout: options.timeout,
      data: options.postdata,
      headers: options.headers
    }
    if (options.is_stream) {
      aoptions.responseType = 'arraybuffer'
      aoptions.responseEncoding = 'binary'
    }
    let back = await axios(aoptions)

    let backdata = back.data

    if ( options.error_replace && options.check_callback) {
      if (options.check_callback(backdata)) {
    
      }
      else{
        logger.error({
          'error_message': '接口返回数据验证失败',
          'data': back.data,
          'url': options.url
        })              
        return false
      }
    }

    let cache_content = {
      time: Date.now(),
      body: back.data
    }

    memorycache.put(key, cache_content)

    //根据file_cache_time过期时间写入文件缓存
    if (Date.now() - cache_time > options.file_cache_time) {
      filecache.put(key, cache_content)
    }
    

    if(options.success_log){
      logger.info({
        url: options.url,
        back: back.data
      })
    }

    // console.info('写入缓存成功')

  } catch (error) {
    logger.error({
      'error_message': error.message,
      'stack': error.stack,
      'url': options.url
    })
  }
}

interface apicache_options{
  /**
   * 接口地址
   */
  url:string,
  /**
   * axios method
   */
  method?: Method,
  /**
   * 接口超时时间 ms 设置为0为不限制超时
   */
  timeout?: number,
  /**
   * 内存缓存有效时间 ms 超过这个时间会异步重刷接口 默认2分钟
   */
  cache_time?: number,

  /**
   * 文件缓存有效时间 ms 超过这个时间会异步重刷接口 默认10分钟
   */
  file_cache_time?: number,

  /**
   * 接口发生错误时，返回数据的替代
   */
  error_replace?:any,
  /**
   * 是否需要用日志记录成功请求的返回值
   */
  success_log?:boolean,

  /**
   * 生成Key的string，如果不为空则替代url生成Key
   */
  keystr?:string,

  /**
   * axios post data
   */
  postdata?: any,

  /**
   * 检测返回数据接口
   */
  check_callback?:Function,

  /**
   * axios headers
   */
  headers?:object,

  /**
   * 是否是流返回
   */
  is_stream?:boolean
}

interface apicache_merge_options{
  url:string,
  method: Method,
  timeout: number,
  cache_time: number,
  file_cache_time: number,
  error_replace:any,
  success_log:boolean,
  keystr:string,
  postdata: any,
  check_callback: Function,
  headers: object,
  is_stream: boolean
}

/**
 * api接口缓存
 * @param input_options 
 */
async function apiCache(input_options:apicache_options):Promise<any> {
  let default_options = {
    method: 'get',
    timeout: 5000,
    cache_time: 2 * 60 * 1000,
    file_cache_time: 10  * 60 * 1000,
    error_replace: undefined,
    success_log: false,
    keystr: '',
    postdata: null,
    check_callback: null,
    headers: null,
    is_stream: false
  }

  const options:apicache_merge_options = lodash.merge(default_options, input_options)
  
  // console.info(options)

  //#region 不开启api缓存
  if (!api_cache_enabled) {
    
    try {
      let aoptions:any = {
        method: options.method,
        url: options.url,
        timeout: options.timeout,
        data: options.postdata,
        headers: options.headers
      }
      if (options.is_stream) {
        aoptions.responseType = 'arraybuffer'
        aoptions.responseEncoding = 'binary'
      }
      let back = await axios(aoptions)
      // console.info(back)
      
      if ( options.error_replace && options.check_callback) {
        if (options.check_callback(back.data)) {
          return back.data  
        }
        else{
          logger.error({
            'error_message': '接口返回数据验证失败',
            'data': back.data,
            'url': options.url
          })              
          return options.error_replace
        }
      }

      return back.data      
    } catch (error) {    
      logger.error({
        'error_message': error.message,
        'stack': error.stack,
        'url': options.url
      })
      if (options.error_replace !== undefined) {
        return options.error_replace
      }
      else{
        throw error
      }
    }
  }
  //#endregion
  
  let key:string

  if (options.keystr != '') {
    key = encryption.sha1('apicache:' + options.keystr)
    
  }
  else if(options.postdata != null){
    key = encryption.sha1('apicache:' + options.url + ';data:' + object_hash(options.postdata))
  }
  else{
    key = encryption.sha1('apicache:' + options.url)
  }

  //   console.info(options.url)
  // console.info(key)

  let api_memery_cache = memorycache.get(key)

  
  if (api_memery_cache != null) { //有内存缓存
    // console.info('走内存')
    refreshCache(key, api_memery_cache.time, options)
    return api_memery_cache.body
  }
  else{
    let api_file_cache = await filecache.get(key) //尝试文件缓存
    if (api_file_cache != null) {
      // console.info('走文件')
      memorycache.put(key, api_file_cache) //写入内存
      refreshCache(key, api_file_cache.time, options)
      return api_file_cache.body
    }
  } 
  
  // console.info('直接调接口')
  
  try {
    let aoptions:any = {
      method: options.method,
      url: options.url,
      timeout: options.timeout,
      data: options.postdata,
      headers: options.headers
    }
    if (options.is_stream) {
      aoptions.responseType = 'arraybuffer'
      aoptions.responseEncoding = 'binary'
    }
    let back = await axios(aoptions)

    let backdata = back.data

    if ( options.error_replace && options.check_callback) {
      if (options.check_callback(backdata)) {
    
      }
      else{
        logger.error({
          'error_message': '接口返回数据验证失败',
          'data': back.data,
          'url': options.url
        })              
        backdata = options.error_replace
      }
    }

    let cache_content = {
      time: Date.now(),
      body: backdata
    }

    memorycache.put(key, cache_content)
    filecache.put(key, cache_content)

    if(options.success_log){
      logger.info({
        url: options.url,
        back: backdata
      })      
    }

    return backdata
  } catch (error) {
    logger.error({
      'error_message': error.message,
      'stack': error.stack,
      'url': options.url
    })
    if (options.error_replace !== undefined) {
      return options.error_replace
    }
    else{
      throw error
    }
  }
  
  
}

export default apiCache