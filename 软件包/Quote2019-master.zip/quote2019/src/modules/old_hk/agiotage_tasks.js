// define(["jquery"],function(jquery){
//     var $ = jquery;
    var $l =  $("#tab_wyzgzgp li");
    $l.on("click", function(){
        var $t = $(this);
        var ind = $t.prevAll("li").length;
        $l.removeClass("cur");
        $t.addClass("cur");
    
        var $tb = $t.parents(".wyzgzgp").next().find("tbody");
        $tb.hide().eq(ind).show();
    });
    $("#select3").hover(function(e){
        $(this).children("dl").css("display","block");
    },function(e){
        $(this).children("dl").css("display","none");
    });
    $("#RefPR").on("click", function(){
         window.location.reload();
    });
    
    $("#submitdate").on("click", function (){var date=$("#querydate")[0].value;var re=/(\d{4})(\d{2})(\d{2})/;var matches=re.exec(date);if(date===""){return}if(matches!==null){window.open('http://forex.eastmoney.com/fc'+matches[1]+'-'+matches[2]+'-'+matches[3]+'.html','_blank')}else{window.open('http://forex.eastmoney.com/fc'+date+'.html','_blank')}}
);

    /**
    * @description get cookie with param(cookie.name)
    * @param {string} name
    * @return {string|null} .val
    */
    function getCookie(t) {
        var i = document.cookie;
        t += "=";
        for (var e = 0; e < i.length; ) {
            var s = e + t.length;
            if (i.substring(e, s) == t) {
                var n = i.indexOf(";", s);
                return -1 == n && (n = i.length),
                unescape(i.substring(s, n))
            }
            if (e = i.indexOf(" ", e) + 1,0 === e){
                break;
            }
                
        }
        return null 
    }

    //@description  refresh 
    function GetRandomNum(e, t) {
        var s = t - e;
        var a = Math.random();
        return e + Math.round(a * s);
    }
    $("#refgbauls").on("click", function () {
        var eles = $("#gbauls").find("dl"), vis_index = $("#gbauls").find("dl:visible").data()["index"];
        for (var e = eles, t = (vis_index + 1) % e.length, s = 0; s < e.length; s++)
            if (s == t) {
                if (e[s].hasChildNodes())
                    for (var a = e[s].childNodes, i = 0; i < a.length; i++)
                        if (a[i].hasChildNodes()) {
                            var n = $(a[i]).children("img")[0];
                            n && !n.getAttribute("src") && n.setAttribute("src", n.getAttribute("data-value"));
                        }
                e[s].style.display = "";
            }
            else e[s].style.display = "none";
    });
    
    window.hotpersonafp = function hotpersonafp(e, t, s) {
        var a = !1;
        if (getCookie("pi")) {
            var i = getCookie("pi");
            if (i.split(";").length >= 3) {
                var n = i.split(";")[2];
                if (/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(n))
                    a = !0; 
                else { 
                    var r = "http://iguba.eastmoney.com/action.aspx?callback=&action=oaddfollowperson&uid2=" + e;
                    var now=new Date();

                    var script = document.createElement('script');
                    script.src = r + "&v=" + now.getDate()+""+now.getHours()+""+now.getMinutes()+"";
                    script.id = 'hotpersonafp';
                    document.getElementsByTagName('head')[0].appendChild(script);

                    function action(t){
                        t.className = "allow",
                        t.innerHTML = "",
                        t.onclick = null;
                        document.getElementsByTagName('head')[0].removeChild(script || document.getElementById('rmb_script'));
                    }

                    if (!!window.ActiveXObject || "ActiveXObject" in window){
                        script.onreadystatechange = function(){
                            
                            if(script.readyState === 'complete' || script.readyState === 'loaded'){
                                action(t)
                            }
                        }
                    }else{
                        $(script).on('load', function(){
                            action(t)
                        })
                    }
                }
            }else{
                a = !0;
            }
        }else{
            window.location.href = "https://passport2.eastmoney.com/pub/login?backurl=" + window.location.href;
        }
        // TODO
        t.className = "allow",
        t.innerHTML = "",
        t.onclick = null;   
        // a && (location.href = "http://guba.eastmoney.com/login.aspx?url=http://quote.eastmoney.com/" + s + ".html");
    }
// });