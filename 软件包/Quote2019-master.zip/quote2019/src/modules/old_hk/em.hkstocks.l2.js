﻿var template = require("./template");
// var merge = require("lodash/merge");
var merge = _.merge;
// var template = require('art-template');
var jQuery = window.$;


function EM_HKStocks_L2(code) {
    if (!code) code = window.stockcode;
    var _instance = this;
    var dataRefresher = this.dataRefresher = {};
    _instance.defaultApiURI = "//nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx";
    _instance.defaultImgURI = "//pifm3.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx";
    _instance.defaultTimeURI = "//quote.eastmoney.com/timezone.js";
    _instance.defaultInterval = window["defaultInterval"] = 10 * 1000;
    _instance.titleTemplate = "{{Name}} {{Close}} {{Change}}({{ChangePercent}})({{Code}})";
    _instance.stockinfo = {};
    _instance.apiToken = "4f1862fc3b5e77c150a2b985b12db0fd";
    _instance.companyInfoUrl = "http://datainterface.eastmoney.com/EM_DataCenter/JS.aspx?type=GJZB&sty=HKF10&code=" + code + "&js=var%20CompanyInfo=[(x)]";
    _instance.jgjzcUrl = "http://datainterface.eastmoney.com/EM_DataCenter/JS.aspx?type=HKPD&sty=HKSYPD&stat=10&code=" + code + "&fd=&edt=&ssdt=&sc=&cmd=&p=1&ps=6&js=var%20JGJZC=[(x)]";
    _instance.jgpjUrl = "http://datainterface.eastmoney.com/EM_DataCenter/JS.aspx?type=HKPD&sty=HKSYPD&stat=11&code=" + code + "&fd=&edt=&ssdt=&sc=&cmd=&p=1&ps=5&js=var%20JGPJ=[(x)]";
    _instance.gkjlUrl = "http://datainterface.eastmoney.com/EM_DataCenter/JS.aspx?type=HKPD&sty=HKSYPD&stat=2&code=" + code + "&fd=&edt=&ssdt=&sc=&cmd=&p=1&ps=9&js=var%20GKJL=[(x)]";
    _instance.baseUrl = 'http://push2.eastmoney.com'
    _instance.ut = 'bd1d9ddb04089700cf9c27f6f7426281'
    this.code = code;
    this.pageInit = function () {
        //initTime();
        pageEventHandler();
        
        //弹框 之前的逻辑
        // $.getScript("http://183.136.160.99:18306/EM_IPAnalayzeInterface/IP.ashx?js=var%20chinese=(x)", function () {
        //     if (window.chinese == -1) {
        //         window.chineseUser = false;
        //         $("#chinese_alert").show();
        //     } else {
        //         window.chineseUser = true;
        //         $("#chinese_alert").hide();
        //     }
        //     //if ($.getCookie("ut") && $.getCookie("ct") && window.chineseUser && $.getCookie("uidal")) {
        //     //    var uid = $.getCookie("uidal");
        //     //    $.getScript("http://61.129.248.35/EM_UBG_UserPermissionInterface/JS.ashx?uid=" + uid.substring(0, 16) + "&type=json&js=var%20hasright=\"(x)\"", function () {
        //     //        _pageInit(code);
        //     //    });
        //     //} else {
        //     //    _pageInit(code);
        //     //}
        //     //港股领取权限放开，若要开启，这把true去掉
        //     window.hasright = "True";
        // });
        window.chineseUser = true;
        window.hasright = "True";

        //新的加自选
        newAddzixuan(code);

        _pageInit(code);
        //百度隐藏广告
        if (getQueryStringByName("from") == "BaiduAladdin") {
            $("#tbggiframe").hide();
            $("#ifhqheadad").hide();

            $.ajax({
                url: "http://emres.dfcfw.com/public/js/aldtg.js",
                method: "GET",
                scriptCharset: 'UTF-8',
                dataType: "script"
            });

        } else {
            $.ajax({
                url: "http://emres.dfcfw.com/public/js/left.js",
                method: "GET",
                scriptCharset: 'UTF-8',
                dataType: "script"
            });

            $.ajax({
                url: "http://emres.dfcfw.com/public/js/em_news_fixed_right.js",
                method: "GET",
                scriptCharset: 'UTF-8',
                dataType: "script"
            });
        }
    }

    function getQueryStringByName(name) {
        var result = location.search.match(new RegExp("[\?\&]" + name + "=([^\&]+)", "i"));
        if (result == null || result.length < 1) {
            return "";
        }
        return result[1];
    };

    var _pageInit = function (code) {

        initCC(code);

        //IP限制关闭
        $(".alert-remind b").click(function () {
            $(".alert-container").hide();
            $("#bg").hide();
        });

        if (getLoginStatus()) {
            $("#gotoregster").hide();
            // $("#gotoopen").show();
            $("#gotoopen").hide();
            $("#lv2display").hide();
            $("#brief_topP").css('padding-top', '30px');
        } else {
            $("#gotoopen").hide();
            $("#gotoregster").show();
            $("#lv2display").show();
        }
        // initQuoteFinanceList(code);  //王
        // newinitQuoteFinanceList(code) //新 行情报价和经纪队列
        //注释之前图片1刷新
        initRTChart(code);
        initKLineChart(code);
        //我的自选增加登录逻辑   登录就自刷   非登录不自刷
        initMyHKFavorite(code);

        // dataRefresher["MFData"] = $.dataAutoRefresh(function () { initMyHKFavorite(code); }, defaultInterval);
        

        initIndustryCompaire(code);
        initIndustryStatistic(code);
        initHKStockRank(code);
        initRanking("hkstock", "C");
        initRanking("bluechips", "C");
        //initHGTDailyBalance();
        //initHGTSummeryBalance();
        initCapitalFlow();
        //股份回购
        initStockRebug();
        //相关股票
        initRelevant();
        if (getLoginStatus()) { //国内登录用户此模块1分钟自刷一次，海外用户或国内未登录用户不可自刷及推送
            setInterval(function() {
                initStockRebug();
            }, 60*1000);
        }
        //公司简介
        initCompanyInfo();
        //机构建增持
        initJGJZC();
        //机构评价
        initJGPJ();
        //沽空记录
        initGKJL();
        //四分卫
        // initSFW();
        quartile()
        //相对恒指跌涨幅
        // initRelevantRaise();  //之前王代码
        //AH股
        initAH();
        // 头条布告栏
        initBulletin();

        
    }

    function initAH() {
            var url = _instance.baseUrl + '/api/qt/stock/get?&ut=' + _instance.ut + '&secid=' + 116 + "." + window.stockcode + '&fields=f1,f2,f3,f12,f13,f14,f152,f250,f251,f252,f253,f254,f255,f256,f257,f258';
            $.ajax({
                url: url,
                dataType: 'jsonp',
                jsonp: 'cb',
                data: null,
                success: function (res) {
                    // console.log("AH对应数据>>", res.data)
                    var data = res.data
                    if (res.data && res.data.f258) {
                        if (stockcode == '06886') {
                            var url = _instance.baseUrl + '/api/qt/stock/get?&ut=' + _instance.ut + '&secid=156.HTSC&fields=f57,f58,f59,f43,f170,f152';
                            $.ajax({
                                url: url,
                                dataType: 'jsonp',
                                jsonp: 'cb',
                                data: null,
                                success: function (res2) {
                                    // console.log("华泰证券英股>>", res2.data)
                                    var data2 = res2.data
                                    var tmp_data = {
                                        ABAHCode: data.f256,
                                        ABAHName: data.f258,
                                        ABAHMarket: data.f257 == 1 ? "sh" : "sz",
                                        ABAHClose: data.f251 == 0 ? '-' : (data.f251 / Math.pow(10, data.f255)).toFixed(data.f255),
                                        ABAHCP: data.f251 == 0 ? '-' : (data.f252 / Math.pow(10, data.f152)).toFixed(data.f152) + "%",
                                        color: data.f252 > 0 ? "red" : data.f252 < 0 ? "green" : "",
                                        YGClose:data2.f43 == 0 ? '-' : (data2.f43 / Math.pow(10, data2.f59)).toFixed(data2.f59),
                                        YGCP: data2.f170 == 0 ? '-' : (data2.f170 / Math.pow(10, data2.f152)).toFixed(data2.f152) + "%",
                                        YGcolor: data2.f170 > 0 ? "red" : data2.f170 < 0 ? "green" : ""
                                    };
                                    var html = template("ABH_Tmp_HTSC", tmp_data);
                                    $(".hqcrt").html(html);
                                }
                            })
                            
                        } else {
                            var tmp_data = {
                                ABAHCode: data.f256,
                                ABAHName: data.f258,
                                ABAHMarket: data.f257 == 1 ? "sh" : "sz",
                                ABAHClose: data.f251 == 0 ? '-' : (data.f251 / Math.pow(10, data.f255)).toFixed(data.f255),
                                ABAHCP: data.f251 == 0 ? '-' : (data.f252 / Math.pow(10, data.f152)).toFixed(data.f152) + "%",
                                HABPremium: data.f253 == 0 ? '-' : ((data.f253 / 100 / Math.pow(10, data.f152))*100).toFixed(2) + '%',
                                HABPremiumColor: data.f253 > 0 ? "red" : data.f253 < 0 ? "green" : "",
                                BA_HA_HKD: data.f254 == 0 ? '-' : (data.f254 / Math.pow(10, data.f152)).toFixed(data.f152),
                                color: data.f252 > 0 ? "red" : data.f252 < 0 ? "green" : ""
                            };
                            var html = template("ABH_Tmp", tmp_data);
                            $(".hqcrt").html(html);
                        }

                    } else {
                        // $("#relevant").html("暂无数据");
                        return;
                    }
                }
            })
    }


    function initRelevantRaise() {
        var url = "//nuexd.eastmoney.com/EM_UBG_Finance2016TransferExtendInterface/js.ashx?type=ChangePercentViaRange&cmd=" + window.stockcode + "5,20,60,225|HSI5,20,60,225&js=((x))";
        var left = [], right = [];
        $.ajax({
            url: url,
            dataType: 'jsonp',
            jsonp: 'cb',
            success: function (data) {
                if (data instanceof Array && data.length === 2) {
                    var stock = data[0], hsi = data[1];
                    var onemonth = (parseFloat(stock.d20) - parseFloat(hsi.d20)) || 0,
                        threemonth = (parseFloat(stock.d60) - parseFloat(hsi.d60)) || 0,
                        oneyear = (parseFloat(stock.d225) - parseFloat(hsi.d225)) || 0;
                    var max = Math.max(Math.max(Math.abs(onemonth), Math.abs(threemonth)), Math.abs(oneyear));
                    if (max === 0) max = 1;
                    if (onemonth > 0) {
                        left.push('<p class="txt">1个月' + format(onemonth) + '%</p>');
                        right.push('<p><span style="width:' + Math.abs(onemonth / max).toFixed(1) * 100 + '%;" class="red"></p>');
                    }
                    else {
                        right.push('<p class="txt">1个月' + format(onemonth) + '%</p>');
                        left.push('<p><span style="width:' + Math.abs(onemonth / max).toFixed(1) * 100 + '%;" class="green"></p>');
                    }
                    if (threemonth > 0) {
                        left.push('<p class="txt">3个月' + format(threemonth) + '%</p>');
                        right.push('<p><span style="width:' + Math.abs(threemonth / max).toFixed(1) * 100 + '%;" class="red"></p>');
                    }
                    else {
                        right.push('<p class="txt">3个月' + format(threemonth) + '%</p>');
                        left.push('<p><span style="width:' + Math.abs(threemonth / max).toFixed(1) * 100 + '%;" class="green"></p>');
                    }
                    if (oneyear > 0) {
                        left.push('<p class="txt">52周' + format(oneyear) + '%</p>');
                        right.push('<p><span style="width:' + Math.abs(oneyear / max).toFixed(1) * 100 + '%;" class="red"></p>');
                    }
                    else {
                        right.push('<p class="txt">52周' + format(oneyear.toFixed(2) || '-') + '%</p>');
                        left.push('<p><span style="width:' + Math.abs(oneyear / max).toFixed(1) * 100 + '%;" class="green"></p>');
                    }
                    $("#ABH_HengSengIndex").html('<div class="lft">' + left.join('') + '</div><div class="rgt">' + right.join('') + '</div>');
                }
            }
        });

        function format(data) {
            try {
                if (!data) return '-';
                if (Math.abs(data) > 10000) return data.toFixed(0);
                else if (Math.abs(data) > 1000) return data.toFixed(1);
                else return data.toFixed(2);
            } catch (e) {
                return data;
            }
        }
    }



    //四分位属性
    function quartile() {



        //console.log(Def,'def')
        //注意域名
        $.ajax({
            // 'http://61.152.230.153:38619/api/qt/slist/get?spt=1&np=3&fltt=2&invt=2&fields=f12,f13,f14,f20,f58,f138,f132,f115,f23,f130,f131,f137,f134,f133,f1000,f3000&ut=bd1d9ddb04089700cf9c27f6f7426281'
            //http://quote.eastmoney.com/hk/00700.html
            url: "//push2.eastmoney.com/api/qt/slist/get?spt=1&np=3&fltt=2&invt=2&fields=f12,f13,f14,f20,f58,f138,f132,f115,f23,f130,f131,f137,f134,f133,f1000,f3000&ut=bd1d9ddb04089700cf9c27f6f7426281",
            data: { secid: 116 + '.' + window.stockcode },
            dataType: "jsonp",
            scriptCharset: "utf-8",
            jsonp: "cb",
            success: function (json) {
                if (json && json.data) {
                    var items = json.data.diff;
                    if (items && items.length > 0) {
                        // 20总市值  58 股东权益  138 净利润TTM  132 总营业收入TTM  115 市盈率TTM   23 市净率  130 市销率TTM  131 市现率TTM  137 净资产收益率TTM  133 股息率
                        var models = [], obj = items[0], obj_1 = items[1], model = {}, model_1 = {}, model_2 = {}, model_2 = {};

                        //表格第一行数据
                        model = {
                            name: '<a href="http://quote.eastmoney.com/hk/' + window.stockcode + '.html" target="_blank">' + obj.f14 + '</a>',
                            zsz: String(obj.f20).NumbericFormat(),
                            gdqy: String(obj.f58).NumbericFormat(),//注意正负
                            jlr: String(obj.f138).NumbericFormat(),
                            zyysr: String(obj.f132).NumbericFormat(),
                            syl: specialData(obj.f115), //负值处理
                            sjl: specialData(obj.f23),  //负值处理
                            sxiaol: specialData(obj.f130), //负值处理
                            sxianl: specialData(obj.f131), //负值处理
                            jzcsyl: addPercent(obj.f137),
                            gxl: obj.f133
                        };
                        // 行业排名
                        model_1 = {
                            name: "<b>行业排名</b>",
                            zsz: obj.f1020 + '|' + obj_1.f134,
                            gdqy: obj.f1058 + '|' + obj_1.f134,
                            jlr: obj.f1138 + '|' + obj_1.f134,
                            zyysr: obj.f1132 + '|' + obj_1.f134,
                            syl: specialData(obj.f115, obj.f1115, true) + '|' + obj_1.f134,
                            sjl: specialData(obj.f23, obj.f1023, true) + '|' + obj_1.f134,
                            sxiaol: specialData(obj.f130, obj.f1130, true) + '|' + obj_1.f134,
                            sxianl: specialData(obj.f131, obj.f1131, true) + '|' + obj_1.f134,
                            jzcsyl: obj.f1137 + '|' + obj_1.f134,
                            gxl: obj.f1133 + '|' + obj_1.f134
                        };
                        model_2 = CwzbHtml(obj)
                        models.push(model, model_1, model_2);
                        var $_html = "";
                        //console.log(models, '整理数据')
                        for (var i = 0; i < models.length; i++) {
                            var item = models[i];
                            $_html += '<tr>' +
                                '<td> ' + item.name + '</td >' +
                                '<td> ' + item.zsz + '</td >' +
                                '<td> ' + item.gdqy + '</td >' +
                                '<td> ' + item.jlr + '</td >' +
                                '<td> ' + item.zyysr + '</td >' +
                                '<td> ' + item.syl + '</td >' +
                                '<td> ' + item.sjl + '</td >' +
                                '<td> ' + item.sxiaol + '</td >' +
                                '<td> ' + item.sxianl + '</td >' +
                                '<td> ' + item.jzcsyl + '</td >' +
                                '<td> ' + item.gxl + '</td >' +
                                '</tr > '
                            '</tr > '
                        }

                        $("#financial_analysis tbody").html($_html);

                        showRedTipsHover();
                    }
                }
            }
        })
    }

    //添加百分号
    function addPercent(vs) {
        var num = parseFloat(vs), item;
        if (num == 0) {
            item = num.toFixed(2) + "%";
        } else if (num) {
            item = num.toFixed(2) + "%";
        } else {
            item = vs;
        }
        return item
    }
    function showRedTipsHover() {
        $(".showRedTips").mouseover(function () {
            $(this).parent("td").find(".sfwsx_title").show();
        });

        $(".showRedTips").mouseout(function () {
            $(".sfwsx_title").hide();
        });
    }

    //市盈率特殊处理
    function specialData(num, pm, status) {
        var syl = parseFloat(num), item = "";
        if (!status) {
            if (syl >= 0 || syl < 0) {
                syl >= 0 ? item = syl.toFixed(2) : item = "负值";
            } else {
                syl ? item = syl.toFixed(2) : item = "-";
            }
        } else {
            if (syl >= 0) {
                item = parseFloat(pm);
            } else {
                item = "-";
            }
        }

        return item;
    }

    //四分位数据逻辑
    function CwzbHtml(obj) {
        var text = {
            td_0: '<span id="tips" class="sfwsx_title" style="display: none;">四分位属性是指根据每个指标的属性，进行数值大小排序，然后分为四等分，每个部分大约包含排名的四分之一。将属性分为高、较高、较低、低四类。<span class="red">注：鼠标移至四分位图标上时，会出现每个指标的说明和用途。</span></span>',
            td_1: '<span class="sfwsx_title" style="display: none;">总市值计算公式为公司总股本乘以市价。该指标侧面反映出一家公司的规模和行业地位。总市值越大，公司规模越大，相应的行业地位也越高。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></span>',
            td_2: '<span class="sfwsx_title" style="display: none;">股东权益又名净资产，是资产总额减去负债总额后的净额。该指标反映企业所有者在企业中的财产价值。股东权益越大，信用风险越低。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></span>',
            td_3: '<span class="sfwsx_title" style="display: none;">净利润又称税后利润，计算公司为利润总额减去所得税费用。净利润是一个企业经营的最终成果，是衡量一个企业经营效益的主要指标。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></span>',
            td_4: '<span class="sfwsx_title" style="display: none;">总营业收入指主营业务收入与其他业务收入之和，是企业取得利润的重要保障，是企业现金流入量的重要组成部分。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></span>',
            td_5: '<span class="sfwsx_title" style="display: none;">市盈率是公司股票价格与每股收益的比率。该指标主要衡量公司的价值，高市盈率一般由高成长支撑着。市盈率越低，股票越便宜，相对投资价值越大。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></span>',
            td_6: '<span class="sfwsx_title" style="display: none;">市净率是公司股票价格与每股净资产的比率。市净率越低，每股内含净资产值越高，投资价值越高。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></span>',
            td_7: '<span class="sfwsx_title" style="display: none;">市销率是股票价格与每股销售额的比率，市销率越低，说明该公司股票目前的投资价值越大。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></span>',
            td_8: '<span class="sfwsx_title" style="display: none;">市现率是股票价格与每股现金流量的比率。市现率可用于评价股票的价格水平和风险水平。市现率越小，表明上市公司的每股现金增加额越多，经营压力越小。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></span>',
            td_9: '<span class="sfwsx_title" style="display: none;">净资产收益率是公司税后利润除以净资产的比率，该指标体现了自有资本获得净收益的能力。指标值越高，说明投资带来的收益越高。<br><span class="red">注：四分位属性以行业排名为比较基准。</span></span>',
            td_10: '<span class="sfwsx_title" style="display: none;">股息率是股息与股票价格的比率。股息率是衡量企业是否具有投资价值的重要标尺之一，是投资收益率的简化形式。<br><span class="red">注：四分位属性以行业排名为比较基准</span></span>'
        };

        var model_3 = {
            name: '<b>四分位属性</b><b id="cwzb_sfwsxTit" class="showRedTips hxsjccsyl">' + text.td_0 + '</b>',
            zsz: rankFun(obj.f3020) + '<p> ' + getDesc(obj.f3020) + '</p>' + text.td_1,
            gdqy: rankFun(obj.f3058) + '<p> ' + getDesc(obj.f3058) + '</p>' + text.td_2,
            jlr: rankFun(obj.f3138) + '<p> ' + getDesc(obj.f3138) + '</p>' + text.td_3,
            zyysr: rankFun(obj.f3132) + '<p> ' + getDesc(obj.f3132) + '</p>' + text.td_4,
            syl: rankFun(obj.f3115, obj.f115, "市盈率TTM") + '<p> ' + getDesc(obj.f3115, obj.f115, "市盈率TTM") + '</p>' + text.td_5, //市盈率
            sjl: rankFun(obj.f3023, obj.f23, "市净率") + '<p> ' + getDesc(obj.f3023, obj.f23, "市净率") + '</p>' + text.td_6, // 市净率
            sxiaol: rankFun(obj.f3130, obj.f130, "市销率TTM") + '<p> ' + getDesc(obj.f3130, obj.f130, "市销率TTM") + '</p>' + text.td_7, //市销率
            sxianl: rankFun(obj.f3131, obj.f131, "市现率TTM") + '<p> ' + getDesc(obj.f3131, obj.f131, "市现率TTM") + '</p>' + text.td_8,//市现率
            jzcsyl: rankFun(obj.f3137) + '<p> ' + getDesc(obj.f3137) + '</p>' + text.td_9,
            gxl: rankFun(obj.f3133) + '<p> ' + getDesc(obj.f3133) + '</p>' + text.td_10
        }
        return model_3
    }

    function getDesc(rank, num, dir) { //市盈率市净率还要重新考虑
        var item = "";
        var $html = '- - <b title="' + dir + '为负值，不参与四分位排名" class="hxsjccsyl" style="margin - top: 5px;"></b>'
        if (dir) {
            //市盈率市净率四分位属性判断之前先判断市净率市盈率值的正负，正的话直接用rank判断，负值直接--加title
            var _num = parseFloat(num);
            if (_num >= 0) {
                if (parseInt(rank)) {
                    if (0 < rank < 5) {
                        var desc = ['高', '较高', '较低', '低'];
                        item = desc[rank - 1];
                    } else {
                        item = '- -';
                    }
                } else {
                    item = $html;
                }
            } else if (_num < 0) {
                item = $html;
            } else {
                item = '- -';
            }
        } else {
            if (parseInt(rank)) {
                if (0 < rank < 5) {
                    var desc = ['高', '较高', '较低', '低'];
                    item = desc[rank - 1];
                } else {
                    item = '- -';
                }
            } else {
                item = $html;
            }
        }
        return item;
    }
    function rankFun(str, num, dir) {
        //市盈率市净率的展示是反的
        var _str = Number(str);
        var bgColor_1 = "", bgColor_2 = "", bgColor_3 = "", bgColor_4 = "";
        if (dir) {
            //市盈率市净率为负值时特殊处理
            var _num = parseFloat(num);
            if (_num >= 0) {
                _str = _str;
            } else {
                _str = 0;
            }
            if (_str >= 1) {
                bgColor_1 = "#deecff";
            }
            if (_str >= 2) {
                bgColor_2 = "#c4ddff";
            }
            if (_str >= 3) {
                bgColor_3 = "#a3cbff";
            }
            if (_str >= 4) {
                bgColor_4 = "#78b1ff";
            }

        } else {

            if (_str <= 1) {
                bgColor_1 = "#78b1ff";
            }
            if (_str <= 2) {
                bgColor_2 = "#a3cbff";
            }
            if (_str <= 3) {
                bgColor_3 = "#c4ddff";
            }
            if (_str <= 4) {
                bgColor_4 = "#deecff";
            }

        }
        if (dir) {
            var list = '<ul class="showRedTips">' +
                '<li style="background-color: ' + bgColor_4 + '"></li>' +
                '<li style="background-color: ' + bgColor_3 + '"></li>' +
                '<li style="background-color: ' + bgColor_2 + '"></li>' +
                '<li style="border-bottom:none;background-color: ' + bgColor_1 + '"></li>' +
                '</ul >';

        } else {
            var list = '<ul class="showRedTips">' +
                '<li style="background-color: ' + bgColor_1 + '"></li>' +
                '<li style="background-color: ' + bgColor_2 + '"></li>' +
                '<li style="background-color: ' + bgColor_3 + '"></li>' +
                '<li style="border-bottom:none;background-color: ' + bgColor_4 + '"></li>' +
                '</ul >';
        }


        return list;

    }
    //四分位结束

    function getLoginStatus() {
        //登陆+中国用户
        if ($.getCookie("ut") && $.getCookie("ct") && window.chineseUser && window.hasright == "True") {
            return true;
        } else {
            return false;
        }
    }

    function initGKJL() {
        var url = _instance.gkjlUrl;
        var str = "";
        $.getScript(url, function () {
            if (GKJL && GKJL.stats != false && GKJL[0].stats != false) {
                var item = GKJL;
                for (var i = 0; i < item.length; i++) {
                    var itemArray = item[i].split(",");
                    str += '<tr><td>' + itemArray[3].fixAmt(0, 2) + '</td><td>' + itemArray[4].fixAmt(0, 2) + '</td><td>' + parseFloat(itemArray[6]).toFixed(2) + '%</td></tr>';
                }
            } else {
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td>暂无数据</td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
            }

            $("#gkjl_table").html(str);
        });
    }

    function initJGPJ() {
        var url = _instance.jgpjUrl;
        var str = "";
        $.getScript(url, function () {
            if (JGPJ && JGPJ.stats != false && JGPJ[0].stats != false) {

                var item = JGPJ;

                for (var i = 0; i < item.length; i++) {
                    var itemArray = item[i].split(",");
                    itemArray[6] = itemArray[6] === "" ? "-" : itemArray[6];
                    str += '<tr><td><span title="' + itemArray[4] + '">' + itemArray[5].substring(0, 4) + '</span></td><td>' + itemArray[6] + '</td><td>' + itemArray[9] + '</td></tr>';
                }

            } else {
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td>暂无数据</td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
            }

            $("#jgpj_table").html(str);
        });

    }

    function initJGJZC() {
        var url = _instance.jgjzcUrl;
        var str = "";
        $.getScript(url, function () {
            if (JGJZC && JGJZC[0].stats != false) {

                var item = JGJZC;

                for (var i = 0; i < item.length; i++) {
                    var itemArray = item[i].split(",");
                    if (itemArray[2].length > 8) {
                        itemArray[2] = itemArray[2].substring(0, 8);
                    }
                    str += '<tr><td><span>' + itemArray[2].cutString(11) + '</span></td><td>' + itemArray[3] + '</td><td>' + itemArray[4].fixAmt(0, 2) + '</td></tr>';
                }

            } else {
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td>暂无数据</td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
                str += '<tr><td></td><td></td><td></td></tr>';
            }
            $("#jgzjc_table").html(str);
        });
    }

    function initCompanyInfo() {
        var url = _instance.companyInfoUrl;
        var str = "";
        $.getScript(url, function () {
            if (CompanyInfo && CompanyInfo[0].stats != false) {
                
                str += "<dt style=\"height:10px\"></dt>";
                var item = CompanyInfo[0];
                if (item.stats == false) return;
                str += '<dt><h2 title="' + item.COMPANYNAME + '">' + item.COMPANYNAME.cutString(26) + '</h2></dt>';
                str += '<dd>所属行业：' + item.INDUSTRY.cutString(18) + '</dd>';
                str += '<dd>总股本(万股)：' + (item.TOTALEQUITY / 10000).toFixed(2) + '</dd>';
                str += '<dd>港股股本(万股)：' + (item.HKEQUITY / 10000).toFixed(2) + '</dd>';
                str += '<dd>每手股数:' + item.LOTSIZE + '</dd>';
                str += '<dd>市盈率:' + parseFloat(item.PERATIO).toFixed(2) + '</dd>';
                str += '<dd>30天均价(元):' + parseFloat(item.AVERAGEOFTHIRTYDAYS).toFixed(2) + '</dd>';
                str += '<dd title="' + item.COMPANYWEBSITE + '">网址:' + item.COMPANYWEBSITE.cutString(20) + '</dd>';
                $(".companyIntroduce").html(str);
            }
            else{
                $(".companyIntroduce").html('<div style="text-align:center; padding-top:10px;">暂无数据</div>');
            }
        });
    }

    function initRelevant() {   //zxw
        var bkid = $("#relevant").attr("hyid").split('_')[0];
        var url = _instance.baseUrl + '/api/qt/clist/get?&ut=' + _instance.ut + '&pi=0&pz=7&po=1&fid=f3&fs=b:HKBLOCK|' + bkid;
        var str = "";
        $.ajax({
            url: url,
            dataType: 'jsonp',
            jsonp: 'cb',
            data: null,
            success: function (res) {
                if (!res.data) {
                    $("#relevant").html("暂无数据");
                    return;
                }
                var data = res.data.diff
                for (var i in data) {
                    var color = "";
                    if (data[i].f4 < 0) {
                        color = "green";
                    } else if (data[i].f4>0){
                        color = "red";
                    }
                    str += '<li class="fl"><a href="http://quote.eastmoney.com/hk/' + data[i].f12 + '.html" target="_blank" title="' + data[i].f14+'">'
                        + data[i].f14.cutString(9, '..') + '</a><span>(<b class="mR5 ' + color + '">' + (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1) + '</b><b class="' + color + '">' + (data[i].f3 / Math.pow(10, 2)).toFixed(2) + '%' + '</b>)</span></li>';
                }

                $("#relevant").html(str);
            }
        })
    }

    function initStockRebug() {
        var url = "http://datainterface.eastmoney.com/EM_DataCenter/JS.aspx?type=HKPD&sty=HKSYPD&stat=1&code=" + window.stockcode + "&fd=&edt=&ssdt=&sc=&cmd=&p=1&ps=6&js=var%20stockRebug=[(x)]";
        var str = "";
        $.getScript(url, function () {
            if (stockRebug && stockRebug[0] != "" && stockRebug[0].stats != false) {
                for (var i = 0; i < stockRebug.length; i++) {
                    var itemList = stockRebug[i].split(",");
                    str += "<tr>" +
                        "<td>" + itemList[2] + "</td>" +
                        "<td>" + itemList[3].fixAmt(0, 2) + "</td>" +
                        "<td>" + itemList[4].fixAmt(0, 1) + "</td></tr>";
                }
            } else {
                str += "<tr><td></td><td></td><td></td><tr>";
                str += "<tr><td></td><td></td><td></td><tr>";
                str += "<tr><td></td><td></td><td></td><tr>";
                str += "<tr><td></td><td>暂无数据</td><td></td><tr>";
                str += "<tr><td></td><td></td><td></td><tr>";
                str += "<tr><td></td><td></td><td></td><tr>";
                str += "<tr><td></td><td></td><td></td><tr>";
            }
            $("#stock_rebug").html(str);
        });
    }

    var _autoinitRTChart;
    var _autoinitKLineChart;
    function initRTChart(code) {
        _autoinitRTChart = dataRefresher["RTChart"] = $.dataAutoRefresh({
            url: "//webquotepic.eastmoney.com/GetPic.aspx",
            dataType: "img",
            width: 578,
            height: 276,
            data: {
                imageType: "RF",
                nid: '116.' + code,
                token: _instance.apiToken
            },
            success: function (img) {
                // console.log('图刷新1')
                if (_instance.stockinfo && ["2", "4"].indexOf(_instance.stockinfo.StockStatus) >= 0)
                    return false;
                $(img).attr("alt", template.compile("{{Name}}({{Code}})")(_instance.stockinfo));
                // $("#picr").html($(img));
                //修改逻辑Bug
                // $("#picr").append($(img));

                if (_instance["underlying"] === false) _autoinitRTChart.stop();
            }
        });
        _autoinitRTChart.start();
    }

    var initKLineChart = this.initKLineChart = function (code) {
        _autoinitKLineChart = dataRefresher["KLineChart"] = $.dataAutoRefresh(function () {
            // console.log('图刷新222')
            var params = $("#pick").data();
            // console.log(params)
            if (_instance.stockinfo && ["2", "4"].indexOf(_instance.stockinfo.StockStatus) >= 0)
                $("#pick").attr("src", "//hqres.eastmoney.com/emag14/images/np_k.png");
            else {
                $("#pick").attr("src", "http://webquoteklinepic.eastmoney.com/GetPic.aspx?imageType=KXL&" + $.param({
                    nid: "116." + code,
                    token: _instance.apiToken,
                    type: params.type,
                    unitWidth: params.unit,
                    ef: params.ef,
                    formula: params.formula
                }));
            }
            if (_instance["underlying"] === false) _autoinitKLineChart.stop();

            // console.log('图刷新222')
            // var params = $("#pick").data();
            // if (_instance.stockinfo && ["2", "4"].indexOf(_instance.stockinfo.StockStatus) >= 0)
            //     $("#pick").attr("src", "//hqres.eastmoney.com/emag14/images/np_k.png");
            // else {
            //     $("#pick").attr("src", "http://pifm3.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx" + "?" + $.param({
            //         ID: code + "5",
            //         Formula: params.formula,
            //         EF: params.ef,
            //         ImageType: "KXL",
            //         UnitWidth: params.unit,
            //         type: params.type,
            //         token: "44c9d251add88e27b65ed86506f6e5da"
            //     }));
            // }
            // if (_instance["underlying"] === false) _autoinitKLineChart.stop();
        }, 1000 * 10);
    }

    //设置图片
    function setPicr() {
        // console.log('刷新图片')
        if(stockcode && stockmarket) {
            $("#picr img").attr("src", "//webquotepic.eastmoney.com/GetPic.aspx?imageType=RF&token=4f1862fc3b5e77c150a2b985b12db0fd&id=" + stockcode + stockmarket  + '&'+Math.random());
        }
    };
    //刷新图片
    function setReflash() {
        setInterval(function() {
            setPicr();
        }, 30 * 1000);

    }


    //实时行情数据
    function initCC(code) {
        // console.log('实时行情数据 刷新')
        var datasour;
        var datainfo;       // 港股信息
        var my_hugangtong;

        var url = "";
        var par = {
            secid: "116." + code,
            fields: "f18,f59,f51,f52,f57,f58,f106,f105,f62,f108,f177,f43,f46,f60,f44,f45,f47,f48,f49,f113,f114,f115,f85,f84,f169,f170,f161,f163,f164,f171,f126,f168,f162,f116,f55,f92,f71,f50,f167,f117,f86,f172,f174,f175",
            ut: "e1e6871893c6386c5ff6967026016627",
            fltt: 2
        }



        var arr = [];
        for (var key in par) {
            arr.push(key + "=" + par[key]);
        }

        //行情基础数据
        // getdata();
        function getdata() {
            console.log('实时行情数据 刷新')
            $.ajax({
                url: "http://push2.eastmoney.com/api/qt/stock/get?" + arr.join("&"),
                method: "GET",
                dataType: "jsonp",
                jsonp: "cb",
                success: function (msg) {
                    console.log(111)
                    datainfo = msg;
                    my_hugangtong = msg.data.f177 & (128 | 256);
                    // console.log(my_hugangtong)
                    success();
                },
                error: function (err) {

                }
            });
        }

        function success() {

            if (!datainfo || datainfo.rc != 0) {
                return false;
            }
            var data = datainfo;
            if (!data) {
                return false;
            }
            // 时间刷新
            var time = ((datainfo.data.f86) * 1000)
            var tc = ((new Date(time)).pattern("(yyyy-MM-dd HH:mm:ss)"))
            // console.log(tc)
            $("#current_time").html(tc);
            var dw = datainfo.data.f172 == 'CNY' ? '人民币' : '港元'
            $(".dw").text('单位：' + dw)

            var model = {}
            // 用新接口的52周数据替换老接口的52周数据
            var f59 = Math.pow(10, datainfo.data.f59);
            var f59f = datainfo.data.f59;
            model[42] = (datainfo.data.f51 / f59).toFixed(f59f) + "|" + (datainfo.data.f52 / f59).toFixed(f59f);
            model[15] = datainfo.data.f49 + "";

            // 换行情数据---new
            model[5] = (datainfo.data.f43).toFixed(3) + "";
            model[6] = (datainfo.data.f169).toFixed(3) + "";
            model[7] = (datainfo.data.f170).toFixed(2) + "%";

            //
            model[42] = (datainfo.data.f174).toFixed(3) + "|" + (datainfo.data.f175).toFixed(3);
            //
            model[3] = (datainfo.data.f46).toFixed(3) + "";
            model[4] = (datainfo.data.f60).toFixed(3) + "";
            model[20] = (datainfo.data.f84).toFixed(2) + "";
            model[21] = (datainfo.data.f116).toFixed(2) + "";
            //
            model[9] = (datainfo.data.f44).toFixed(3) + "";
            model[10] = (datainfo.data.f45).toFixed(3) + "";
            model[22] = (datainfo.data.f85).toFixed(2) + "";
            model[23] = (datainfo.data.f117).toFixed(2) + "";
            //
            model[24] = (datainfo.data.f167).toFixed(3) + "";
            model[18] = (datainfo.data.f164).toFixed(3) + "";
            //
            model[11] = (datainfo.data.f47).toFixed(2) + "";
            model[12] = (datainfo.data.f48).toFixed(2) + "";
            model[25] = (datainfo.data.f108).toFixed(2) + "";;
            model[31] = (datainfo.data.f92).toFixed(3) + "";

            //
            model[15] = (datainfo.data.f49).toFixed(2) + "";
            model[16] = (datainfo.data.f161).toFixed(2) + "";
            if (datainfo.data.f126 == 0 || !datainfo.data.f126) {
                model[35] = '-';
            } else {
                model[35] = (datainfo.data.f126).toFixed(2) + "%";
            }

            model[8] = (datainfo.data.f168).toFixed(2) + "%";
            //

            // 非港股标的股停止自刷  
            // if (model[37] !== "港股通" && $("#btnRefresh").length > 0) {

            //海外的  都不要刷新  包括图
            if (datainfo.lt == 2) {
                _auto.stop();
                _autoinitRTChart.stop(); //图1
                _autoinitKLineChart.stop(); //图2
            }
            var login = getLoginStatus()
            if (login) {
                if(my_hugangtong) {
                    $("#underlying").show();
                }
                newinitQuoteFinanceList(code); //刷新行情报价
            }
            else {
                if (!my_hugangtong && $("#btnRefresh").length > 0) {

                    newinitQuoteFinanceList(code); //刷新行情报价

                    _instance["underlying"] = false;
                    $(".page_refresh").hide();
                    $("#btnRefresh").show().click(function () { location.reload(); });
                    _auto.stop();
                } else {
                    $("#underlying").show();
                    newinitQuoteFinanceList(code); //刷新行情报价
                }
            }
            var pnf = parseFloat(model[6]) > 0 ? 1 : parseFloat(model[6]) < 0 ? -1 : 0;
            _instance.stockinfo = {
                Code: model[1],
                Name: model[2],
                Close: model[5],
                Change: model[6],
                ChangePercent: model[7],
                StockStatus: model[4]
            };
            $("#hqstat i").html($.getStockStatus(model[29]));
            if (model[29] == 0) {
                $("#hqstat b").removeClass().addClass("on");
            } else {
                $("#hqstat b").removeClass().addClass("off");
            }


            //document.title = template.compile(_instance.titleTemplate)(_instance.stockinfo);
            //52周最高最低
            if (model[42]) {
                $("#base_info [data-ex]").each(function (idx, ele) {
                    var high = model[42].split('|')[0], low = model[42].split('|')[1];
                    if ($(ele).data()["ex"] === "high") {
                        $(ele).find("i").attr("class", "red").html(high);
                    } else if ($(ele).data()["ex"] === "low") {
                        $(ele).find("i").attr("class", "green").html(low);
                    }
                });
            }

            //行情数据
            $("#base_info li,#brief_info [data-cc],#rt_quotes td").each(function (idx, target) {
                var $target = $(target), pos = parseInt($target.data()["cc"]);
                if (pos) {
                    var $ele = null, value = !model[pos] ? "-" : model[pos];
                    if (target.tagName.toLowerCase() === "i") {
                        $ele = $target;
                        if (model[pos] && pnf > 0 && model[pos].indexOf("+") !== 0)
                            value = "+" + value;
                    } else {
                        $ele = $target.find("i");
                        value = model[pos];
                    }
                    if (parseFloat(value) > 1000 && value.indexOf('%') < 0) value = value.fixAmt("0.00", 2);

                    var _org = $ele.html();
                    $ele.html(value);
                    switch (pos) {
                        case 5:
                        case 6:
                        case 7:
                            $ele.removeClass("red").removeClass("green");
                            $target.find("em").removeClass("arrow_up").removeClass("arrow_down");
                            if (pnf > 0) {
                                $ele.addClass("red");
                                if (_org !== value)
                                    $ele.textBlink({ color: ["#FFDDDD", "#FFEEEE", ""], blinktime: 150 });
                                $target.find("em").addClass("arrow_up");
                            } else if (pnf < 0) {
                                $ele.addClass("green");
                                if (_org !== value)
                                    $ele.textBlink({ color: ["#b4f7af", "#ccffcc", ""], blinktime: 150 });
                                $target.find("em").addClass("arrow_down");
                            }
                            if (pos === 5 && model[5].length > 6 && $ele.css("font-size") === "30px")
                                $ele.css("font-size", 30 * 16 / (10 + model[5].length) + "px");
                            break;
                        case 3:
                        case 9:
                        case 10:
                            {
                                $ele.removeClass();
                                var zsj = model[4];
                                if (zsj > $ele.html()) {
                                    $ele.addClass("green");
                                } else {
                                    $ele.addClass("red");
                                }
                                break;
                            }
                    }
                }
            });
        }


        var _auto = dataRefresher["CCData"] = $.dataAutoRefresh({
            url: "http://push2.eastmoney.com/api/qt/stock/get?" + arr.join("&"),
            type: "GET",
            dataType: "jsonp",
            success: function (msg) {
                datainfo = msg;
                my_hugangtong = msg.data.f177 & (128 | 256);
                success();
            }
        });
        _auto.start();

        //覆盖xiangdui
        $(".hqcrt p a").html("相对恒指涨跌幅");


    }

    // 行情报价&经济队列
    function initQuoteFinanceList() {
        var _auto = dataRefresher["QFData"] = $.dataAutoRefresh({
            url: _instance.defaultApiURI,
            type: "GET",
            dataType: "jsonp",
            timeout: 5000,
            data: {
                type: "CT",
                cmd: code + "5",
                sty: "FDPHKL2B",
                st: "(Code)",
                token: _instance["apiToken"]
            },
            success: function (json) {
                if (json && json instanceof Array) {
                    var _data = json[0].split(',');
                    // console.log(_data)
                    if (_data[37] !== "港股通") _auto.stop();
                    //王
                    // initQuoteList(_data[4], _data[34], _data[37] == "港股通" ? true : false);


                    //新增行情报价
                    //newinitQAbaojia(code);

                    //
                    // initFinanceQueue(_data[33]);
                    // console.log(_data[33])


                    //新增 经纪队列
                    //newinitFinanceQueue(code);
                }
            }
        });
        _auto.start();
    }


    //new 行情报价&经济队列
    function newinitQuoteFinanceList(code) {

        //新增行情报价
        newinitQAbaojia(code);

    }

    //新接 行情报价
    function newinitQAbaojia(code) {

        var that = this;
        //正式地址
        // var fullurl = "http://push2.eastmoney.com/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fields=f57,f58,f106,f105,f62,f106,f108,f59,f43,f46,f60,f44,f45,f47,f48,f49,f113,f114,f115,f117,f85,f51,f52,f116,f84,f92,f55,f126,f109,f123,f124,f125,f530,f119,f120,f121,f122,f135,f136,f137,f138,f139,f140,f141,f142,f143,f144,f145,f146,f147,f148,f149&secid=" + "116." + code;
        //测试地址
        var fullurl = "http://push2.eastmoney.com/api/qt/stock/get?ut=fa5fd1943c7b386f172d6893dbfba10b&fltt=2&fields=f57,f177,f58,f106,f105,f62,f108,f59,f43,f46,f60,f44,f45,f47,f48,f49,f113,f114,f115,f117,f85,f51,f52,f116,f84,f92,f55,f126,f109,f123,f124,f125,f530,f119,f120,f121,f122,f135,f136,f137,f138,f139,f140,f141,f142,f143,f144,f145,f146,f147,f148,f149,f152&secid=" + "116." + code;

        $.ajax({
            type: "get",
            data: '',
            url: fullurl,
            dataType: "jsonp",
            jsonp: 'cb',
            success: function (msg) {
                var obj = msg;
                // obj.lt=2;
                that.id = obj.lt;
                // //弹框
                if (that.id == 2) {
                    $("#chinese_alert").show();
                }

                //海外ip  遮住 经纪队列
                if (that.id == 2) {
                    // console.log('haiwai')
                    $("#finance_queue").html("");
                    $("#finance_queue").css("background", "url(http://hqres.eastmoney.com/EMHKl2/images/jjdl-mask.png)");
                    $("#finance_queue").css("height", "304px");
                    $("#finance_queue").click(function () {
                        window.open("https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=" + encodeURIComponent(location.href));
                        stopPropagation(e);
                    });
                }

                //刷新图片，增加登录逻辑：国内登录用户才可以刷新图片
                if (getLoginStatus() && that.id !== 2) {
                    setReflash();
                } else {
                    setPicr();
                }

                //我的自选  国内登录用户刷新
                if (getLoginStatus() && that.id !== 2) {
                    // console.log('我的自选刷新')
                    // dataRefresher["MFData"] = $.dataAutoRefresh(function () { initMyHKFavorite(code); }, defaultInterval);

                    setInterval(function () {
                        initMyHKFavorite(code);
                      
                    }, 30* 1000);

                   
                }


                if (obj.rc == 0 && obj.data) {
                    var zuoshou = obj.data.f60;
                    var fixed = obj.data.f152;
                    // console.log(fixed)
                    var gangutong = obj.data.f177 & (128 | 256);
                    //console.log(gangutong)
                    new_format(zuoshou, obj.data, gangutong, fixed);
                }

                //新增 经纪队列
                newinitFinanceQueue(code);

            }
        });

    }

    function new_format(zuoshou, d, gangutong, fixed) {

        var oldo = this.o || {};       // 旧的对象

        var o = {};
        // var f = oldo.f || Math.pow(10, d.f59) || 1;
        var f = 1;

        // 买卖盘  行情报价模块
        var mmp = {};
        var login = getLoginStatus();
        if (login) {
            mmp.sell = [
                [(d.f21 / f).toFixed(fixed), d.f22, d.f221],
                [(d.f23 / f).toFixed(fixed), d.f24, d.f222],
                [(d.f25 / f).toFixed(fixed), d.f26, d.f223],
                [(d.f27 / f).toFixed(fixed), d.f28, d.f224],
                [(d.f29 / f).toFixed(fixed), d.f30, d.f225],
                [(d.f31 / f).toFixed(fixed), d.f32, d.f226],
                [(d.f33 / f).toFixed(fixed), d.f34, d.f227],
                [(d.f35 / f).toFixed(fixed), d.f36, d.f228],
                [(d.f37 / f).toFixed(fixed), d.f38, d.f229],
                [(d.f39 / f).toFixed(fixed), d.f40, d.f230]
            ]
            mmp.buy = [
                [(d.f19 / f).toFixed(fixed), d.f20, d.f231],
                [(d.f17 / f).toFixed(fixed), d.f18, d.f232],
                [(d.f15 / f).toFixed(fixed), d.f16, d.f233],
                [(d.f13 / f).toFixed(fixed), d.f14, d.f234],
                [(d.f11 / f).toFixed(fixed), d.f12, d.f235],
                [(d.f9 / f).toFixed(fixed), d.f10, d.f236],
                [(d.f7 / f).toFixed(fixed), d.f8, d.f237],
                [(d.f5 / f).toFixed(fixed), d.f6, d.f238],
                [(d.f3 / f).toFixed(fixed), d.f4, d.f239],
                [(d.f1 / f).toFixed(fixed), d.f2, d.f240]
            ]
        } else {
            mmp.sell = [
                [(d.f31 / f).toFixed(fixed), d.f32, d.f226],
                [(d.f33 / f).toFixed(fixed), d.f34, d.f227],
                [(d.f35 / f).toFixed(fixed), d.f36, d.f228],
                [(d.f37 / f).toFixed(fixed), d.f38, d.f229],
                [(d.f39 / f).toFixed(fixed), d.f40, d.f230]
            ]
            mmp.buy = [
                [(d.f19 / f).toFixed(fixed), d.f20, d.f231],
                [(d.f17 / f).toFixed(fixed), d.f18, d.f232],
                [(d.f15 / f).toFixed(fixed), d.f16, d.f233],
                [(d.f13 / f).toFixed(fixed), d.f14, d.f234],
                [(d.f11 / f).toFixed(fixed), d.f12, d.f235]
            ]
            // console.log(222,mmp)

        }

        // 相对大盘涨跌幅
        if (d.f123 || d.f124 || d.f125) {
            o.xddp = {}
            o.xddp.month1 = d.f123 / 100 || oldo.xddp.month1;
            o.xddp.month3 = d.f124 / 100 || oldo.xddp.month3;
            o.xddp.week52 = d.f125 / 100 || oldo.xddp.week52;
        }

        o.mmp = mmp;
        this.o = merge(oldo, o);
        //渲染行情报价模块
        new_rander(zuoshou, o, gangutong);
        //渲染恒指涨跌幅
        new_rander_hengzhi(o);

    }

    function new_rander(close, data, ishugutong) {
        var that = this;
        // console.log(close);
        if (!data) return false;

        //处理数据
        var arrlist = [];
        var sell = data.mmp.sell;
        var buy = data.mmp.buy;
        var slist = []
        var blist = []
        for (var i = 0; i < sell.length; i++) {
            var temp = {};
            temp.Price = "" + sell[i][0]
            temp.Amount = "" + sell[i][1]
            temp.Seat = "" + sell[i][2]
            slist.push(temp)
        }

        for (var i = 0; i < buy.length; i++) {
            var temp = {};
            temp.Price = "" + buy[i][0]
            temp.Amount = "" + buy[i][1]
            temp.Seat = "" + buy[i][2]
            blist.push(temp)
        }

        //    console.log(blist)

        //之前普数据逻辑
        var login = getLoginStatus(), count = login ? 10 : 5, smodels = new Array(), bmodels = new Array();
        //五档蒙层
        if (!login && !ishugutong) {
            $("#wjpk_container").html("");
            $("#wjpk_container").css("background", "url(http://hqres.eastmoney.com/EMHKl2/images/wdbj-mask.png)");
            $("#wjpk_container").css("height", "304px");
            $("#wjpk_container").click(function () {
                window.open("https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=" + encodeURIComponent(location.href));
                stopPropagation(e);
            });
            return;
        }

        var _defualt = { Color: "", Price: "-", Seat: "-", Amount: "-" };
        //沪股通只显示1手
        for (var i = 0; i < count; i++) {
            if ((slist[i] && login) || (!login && ishugutong && i == 4)) {
                var n = count - i;
                smodels.push({
                    Key: "卖" + n,
                    Color: parseFloat(slist[i].Price) > close ? "red" : parseFloat(slist[i].Price) < close ? "green" : "",
                    Price: !slist[i].Price ? "-" : slist[i].Price,
                    Seat: !slist[i].Seat ? "-" : "(" + slist[i].Seat + ")",
                    Amount: !slist[i].Amount ? "-" : slist[i].Amount.fixAmt("-", 1)
                });
            } else {
                var s_default = $.extend(true, { Key: "卖" + (count - i) }, _defualt);
                smodels.push(s_default);
            }
            if ((blist[i] && login) || (!login && ishugutong && i == 0)) {
                bmodels.push({
                    Key: "买" + (i + 1),
                    Color: parseFloat(blist[i].Price) > close ? "red" : parseFloat(blist[i].Price) < close ? "green" : "",
                    Price: !blist[i].Price ? "-" : blist[i].Price,
                    Seat: !blist[i].Seat ? "-" : "(" + blist[i].Seat + ")",
                    Amount: !blist[i].Amount ? "-" : blist[i].Amount.fixAmt("-", 1)
                });
            }
            else {
                var b_default = $.extend(true, { Key: "买" + (i + 1) }, _defualt);
                bmodels.push(b_default);
            }
        }
        //   console.log(slist)
        //   console.log(smodels)
        //增加海外情况
        //   console.log('增加海外情况')
        //   console.log(that.id);
        if (that.id == 2) {
            smodels = [
                {
                    Key: "卖五",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                },
                {
                    Key: "卖四",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                },
                {
                    Key: "卖三",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                },
                {
                    Key: "卖二",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                },
                {
                    Key: "卖一",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                }

            ];
            bmodels = [
                {
                    Key: "买五",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                },
                {
                    Key: "买四",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                },
                {
                    Key: "买三",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                },
                {
                    Key: "买二",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                },
                {
                    Key: "买一",
                    Color: "-",
                    Price: "-",
                    Seat: "-",
                    Amount: "-"
                }

            ];
        }


        var _shtml = template("tmp_quote_list", { list: smodels });
        var _bhtml = template("tmp_quote_list", { list: bmodels });
        $("#quote_sell tbody").html(_shtml);
        $("#quote_buy tbody").html(_bhtml);
        if (login) {
            $("#rt_quotes").hide();
            if (!$("#fq_container").hasClass("alignmentDiv")) {
                $("#fq_container").addClass("alignmentDiv");
            }
        }
        var _herf = template("tmp_href", { logined: login });
        $("#quote_href").html(_herf);



    }

    function new_rander_hengzhi(data) {
        var left = [], right = [];
        if (data.xddp) {
            var onemonth = (data.xddp.month1)*100 || 0,
                threemonth = (data.xddp.month3)*100 || 0,
                oneyear = (data.xddp.week52)*100 || 0;
            var max = Math.max(Math.max(Math.abs(onemonth), Math.abs(threemonth)), Math.abs(oneyear));
            if (max === 0) max = 1;
            if (onemonth > 0) {
                left.push('<p class="txt">1个月' + onemonth.toFixed(2) + '%</p>');
                right.push('<p><span style="width:' + Math.abs(onemonth / max).toFixed(1) * 100 + '%;" class="red"></p>');
            }
            else {
                right.push('<p class="txt">1个月' + onemonth.toFixed(2) + '%</p>');
                left.push('<p><span style="width:' + Math.abs(onemonth / max).toFixed(1) * 100 + '%;" class="green"></p>');
            }
            if (threemonth > 0) {
                left.push('<p class="txt">3个月' + threemonth.toFixed(2) + '%</p>');
                right.push('<p><span style="width:' + Math.abs(threemonth / max).toFixed(1) * 100 + '%;" class="red"></p>');
            }
            else {
                right.push('<p class="txt">3个月' + threemonth.toFixed(2) + '%</p>');
                left.push('<p><span style="width:' + Math.abs(threemonth / max).toFixed(1) * 100 + '%;" class="green"></p>');
            }
            if (oneyear > 0) {
                left.push('<p class="txt">52周' + oneyear.toFixed(2) + '%</p>');
                right.push('<p><span style="width:' + Math.abs(oneyear / max).toFixed(1) * 100 + '%;" class="red"></p>');
            }
            else {
                right.push('<p class="txt">52周' + oneyear.toFixed(2) + '%</p>');
                left.push('<p><span style="width:' + Math.abs(oneyear / max).toFixed(1) * 100 + '%;" class="green"></p>');
            }
            $("#ABH_HengSengIndex").html('<div class="lft">' + left.join('') + '</div><div class="rgt">' + right.join('') + '</div>');
        }

    }

    //5档10档  王代码
    function initQuoteList(close, data, ishugutong) {
        // console.log(data)
        if (!data) return false;
        var blist = new Array(), slist = new Array();
        var _len = data.split('|').length;
        $.each(data.split('|'), function (idx, val) {
            if (!val) return false;
            var _data = val.split('~');
            var obj = { Price: _data[0], Amount: _data[1], Seat: _data[2] };
            if (idx < _len / 2) slist.push(obj);
            else blist.push(obj);
        });
        var login = getLoginStatus(), count = login ? 10 : 5, smodels = new Array(), bmodels = new Array();

        //五档蒙层
        if (!login && !ishugutong) {
            $("#wjpk_container").html("");
            $("#wjpk_container").css("background", "url(http://hqres.eastmoney.com/EMHKl2/images/wdbj-mask.png)");
            $("#wjpk_container").css("height", "304px");
            $("#wjpk_container").click(function () {
                window.open("https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=" + encodeURIComponent(location.href));
                stopPropagation(e);
            });
            return;
        }

        var _defualt = { Color: "", Price: "-", Seat: "-", Amount: "-" };
        //沪股通只显示1手
        for (var i = 0; i < count; i++) {
            if ((slist[i] && login) || (!login && ishugutong && i == 4)) {
                var n = count - i;
                smodels.push({
                    Key: "卖" + n,
                    Color: parseFloat(slist[i].Price) > close ? "red" : parseFloat(slist[i].Price) < close ? "green" : "",
                    Price: !slist[i].Price ? "-" : slist[i].Price,
                    Seat: !slist[i].Seat ? "-" : "(" + slist[i].Seat + ")",
                    Amount: !slist[i].Amount ? "-" : slist[i].Amount.fixAmt("-", 1)
                });
            } else {
                var s_default = $.extend(true, { Key: "卖" + (count - i) }, _defualt);
                smodels.push(s_default);
            }
            if ((blist[i] && login) || (!login && ishugutong && i == 0)) {
                bmodels.push({
                    Key: "买" + (i + 1),
                    Color: parseFloat(blist[i].Price) > close ? "red" : parseFloat(blist[i].Price) < close ? "green" : "",
                    Price: !blist[i].Price ? "-" : blist[i].Price,
                    Seat: !blist[i].Seat ? "-" : "(" + blist[i].Seat + ")",
                    Amount: !blist[i].Amount ? "-" : blist[i].Amount.fixAmt("-", 1)
                });
            }
            else {
                var b_default = $.extend(true, { Key: "买" + (i + 1) }, _defualt);
                bmodels.push(b_default);
            }
        }
        var _shtml = template("tmp_quote_list", { list: smodels });
        var _bhtml = template("tmp_quote_list", { list: bmodels });
        $("#quote_sell tbody").html(_shtml);
        $("#quote_buy tbody").html(_bhtml);
        if (login) {
            $("#rt_quotes").hide();
            if (!$("#fq_container").hasClass("alignmentDiv")) {
                $("#fq_container").addClass("alignmentDiv");
            }
        }
        var _herf = template("tmp_href", { logined: login });
        $("#quote_href").html(_herf);
    }

    // 渲染 经济队列
    function initFinanceQueue(data) {
        if (!data && data != "-") return false;
        var lines = data.split('|');
        var login = getLoginStatus();


        // login = true;


        if (!login) {
            $("#finance_queue").html("");
            $("#finance_queue").css("background", "url(http://hqres.eastmoney.com/EMHKl2/images/jjdl-mask.png)");
            $("#finance_queue").css("height", "304px");
            $("#finance_queue").click(function () {
                window.open("https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=" + encodeURIComponent(location.href));
                stopPropagation(e);
            });
            return;
        }

        $("#finance_queue").css("padding-bottom", "10px");
        var blist = new Array(), slist = new Array();

        var currentIndexBuy = 0;
        var currentIndexSell = 0;
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            if (!line) continue;
            var datum = line.split('~');
            if (datum.length > 1) {
                if (datum[2].toUpperCase() == "B") {
                    if (currentIndexBuy != datum[3]) {
                        currentIndexBuy = datum[3];
                        blist.push({ idx: datum[3], dir: datum[2], seat: datum[0], name: datum[1], direction: "买" + currentIndexBuy });
                    } else {
                        blist.push({ idx: datum[3], dir: datum[2], seat: datum[0], name: datum[1], direction: "" });
                    }

                } else if (datum[2].toUpperCase() == "S") {
                    if (currentIndexSell != datum[3]) {
                        currentIndexSell = datum[3];
                        slist.push({ idx: datum[3], dir: datum[2], seat: datum[0], name: datum[1], direction: "卖" + currentIndexSell });
                    } else {
                        slist.push({ idx: datum[3], dir: datum[2], seat: datum[0], name: datum[1], direction: "" });
                    }
                }
            }
        }
        var _bhtml = template("tmp_finance_queue", { list: blist });
        var _shtml = template("tmp_finance_queue", { list: slist });
        $("#finance_queue_buy tbody").html(_bhtml);
        $("#finance_queue_sell tbody").html(_shtml);
        var _herf = template("tmp_href", { logined: login });
        $("#finance_href").html(_herf);
    }

    //new 经纪队列
    function newinitFinanceQueue(code) {
        // var secid = par.market + "." + par.code

        // var fullurl = "http://push2.eastmoney.com/api/qt/stock/brkq/get?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + secid;

        //测试地址
        var fullurl = "http://push2.eastmoney.com/api/qt/stock/brkq/get?fields=f1&ut=fa5fd1943c7b386f172d6893dbfba10b&secid=" + "116." + code;

        $.ajax({
            type: "get",
            data: '',
            url: fullurl,
            dataType: "jsonp",
            jsonp: 'cb',
            success: function (msg) {
                var obj = msg;
                if (obj.rc == 0 && obj.data) {
                    var arr = obj.data.brkq;
                    manerData(arr);
                }

            }
        });

    }

    //new 处理经纪队列数据
    function manerData(arr) {
        // var that = this;

        var oldo = this.ol || {}; // 旧的对象

        var o = {};

        o.Blist = [];
        o.Slist = [];
        for (var i = 0; i < arr.length; i++) {
            var item = arr[i];
            if (item.substr(0, 1) == 'S') {
                o.Slist.push(item)
            } else if (item.substr(0, 1) == 'B') {
                o.Blist.push(item)
            }
        }

        // console.log(o.Blist)
        // console.log(o.Slist);


        this.ol = merge(oldo, o);

        var fullData = []
        for (var i = 0; i < this.ol.Blist.length; i++) {
            var temp = this.ol.Blist[i].split(',');

            for (var j = 0; j < temp.length; j++) {
                var tempj = temp[j].split('.');
                var shou = '';
                var name = '';
                shou = tempj[0];
                name = tempj[1];
                if (j == 0) {
                    shou = tempj[0].split(':')[1];
                }
                var str = shou + '~' + name + '~' + 'B~' + (i + 1);
                fullData.push(str);

            }

        }


        for (var i = 0; i < this.ol.Slist.length; i++) {
            var temp = this.ol.Slist[i].split(',');

            for (var j = 0; j < temp.length; j++) {
                var tempj = temp[j].split('.');
                var shou = '';
                var name = '';
                shou = tempj[0];
                name = tempj[1];
                if (j == 0) {
                    shou = tempj[0].split(':')[1];
                }
                var str = shou + '~' + name + '~' + 'S~' + (i + 1);
                fullData.push(str);

            }

        }

        var fullDatastr = fullData.join('|');
        // console.log(fullDatastr)
        //渲染经济队列
        initFinanceQueue(fullDatastr)


    }


    function sortby(a, b) {
        if (typeof a === "object" && typeof b === "object" && a && b) {
            if (a["dir"] == "B") {
                if (a["idx"] == b["idx"]) {
                    return a["idx"].seat > b["idx"].seat ? 1 : -1;
                }
                else {
                    return parseInt(a["idx"]) - parseInt(b["idx"]);
                }
            }
            else {
                if (a["idx"] == b["idx"]) {
                    return -1 * (a["idx"].seat > b["idx"].seat ? 1 : -1);
                }
                else {
                    return -1 * (parseInt(a["idx"]) - parseInt(b["idx"]));
                }
            }
        }
    }


    function stopPropagation(e) {
        e = e || window.event;
        if (e.stopPropagation) { //W3C阻止冒泡方法  
            e.stopPropagation();
        } else {
            e.cancelBubble = true; //IE阻止冒泡方法  
        }
    }

    //港股涨幅榜
    function initHKStockRank(code) { //zxw
        var _auto = dataRefresher["HKRank"] = $.dataAutoRefresh({
            url: _instance.baseUrl + '/api/qt/clist/get?pi=0&pz=6&po=1&fs=m:116+t:3,m:116+t:4&ut=' + _instance.ut + '&fid=f3&fields=f1,f2,f3,f4,f12,f13,f14,f152',
            type: "GET",
            dataType: 'jsonp',
            jsonp: 'cb',
            data: null,
            success: function (data) {
                //console.log("港股涨幅榜>>",data.data.diff)
                var data = data.data.diff
                var models = new Array();
                for (var i in data) {
                    models.push({
                        Code: data[i].f12,
                        Name: data[i].f14.substr(0, 4),
                        Title: data[i].f14,
                        Change: (data[i].f3 / Math.pow(10, data[i].f152)).toFixed(2) + '%',
                        ChangePercent: (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                        Color: data[i].f3 > 0 ? "red" : data[i].f3 < 0 ? "green" : ""
                    })
                }
                $("#hkstock_rank tbody").html(template("tmp_hkstock_rank", { list: models }));
            }
        });
        _auto.intInterval = 10 * 1000;
        _auto.start();
    }
    //行业对比
    function initIndustryCompaire(code) { //zxw
        //console.log("id",$("#relevant").attr("hyid"))
        var bkid = $("#relevant").attr("hyid").split('_')[0]
        var _auto = dataRefresher["ICData"] = $.dataAutoRefresh({
            url: _instance.baseUrl + '/api/qt/clist/get?&ut=' + _instance.ut + '&pi=0&pz=7&po=1&fid=f3&fs=b:HKBLOCK|' + bkid,
            type: "GET",
            dataType: 'jsonp',
            jsonp: 'cb',
            timeout: 5000,
            data: null,
            success: function (res) {
                //console.log("行业对比",res.data.diff)
               
                if (!res.data) {
                    var html = template("tmp_industry_company", { list: null });
                    $("#industry_company tbody").html(html);
                    // $("#industry_company tbody").html('该股暂无纳入任何行业，暂无行业数据')
                    return;
                }
                var data = res.data.diff
                var models = new Array();
                for (var i in data) {
                    if (data[i].f12 == Number(code)) continue;
                    models.push({
                        Code: data[i].f12,
                        Name: data[i].f14,
                        Close: data[i].f2 == 0 ? '-' : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(data[i].f1),
                        Change: data[i].f2 == 0 ? '-' : (data[i].f4 / Math.pow(10, data[i].f1)).toFixed(data[i].f1),
                        ChangePercent: data[i].f2 == 0 ? '-' : (data[i].f3 / Math.pow(10, 2)).toFixed(2) + '%',
                        High: data[i].f15 == 0 ? '-' : (data[i].f15 / Math.pow(10, data[i].f1)).toFixed(data[i].f1),
                        Low: data[i].f16 == 0 ? '-' : (data[i].f16 / Math.pow(10, data[i].f1)).toFixed(data[i].f1),
                        Open: data[i].f17 == 0 ? '-' : (data[i].f17 / Math.pow(10, data[i].f1)).toFixed(data[i].f1),
                        TurnoverRate: data[i].f2 == 0 ? '-' : (data[i].f8 / Math.pow(10, 2)).toFixed(2) + '%',
                        Volume: data[i].f2 == 0 ? '-' : data[i].f5.toString().fixAmt("-", 2),
                        Amount: data[i].f2 == 0 ? '-' : data[i].f6.toString().fixAmt("-", 2),
                        MarketValue: data[i].f20.toString().fixAmt("-", 2),
                        PERation: data[i].f9 == 0 ? '-' : (data[i].f9 / Math.pow(10, 2)).toFixed(2) + '%',
                        Color: data[i].f4 > 0 ? "red" : data[i].f4 < 0 ? "green" : ""
                    });

                }
                var html = template("tmp_industry_company", { list: models });
                $("#industry_company tbody").html(html);
            }
        });
        _auto.intInterval = 20 * 1000;
        _auto.start();
    }
    //行业统计
    function initIndustryStatistic(code) {
        // var _auto = dataRefresher["ISData"] = $.dataAutoRefresh({
        //     url: _instance.defaultApiURI,
        //     type: "GET",
        //     dataType: "jsonp",
        //     timeout: 5000,
        //     data: {
        //         type: "CT",
        //         cmd: $("#relevant").attr("hyid"),
        //         sty: "FDPHKL2MRF",
        //         st: "A",
        //         token: _instance["apiToken"]
        //     },
        //     success: function (json) {
        //         console.log(json)
        //         if (!json || !json.length || json[0].stats == false) return false;
        //         var data = json[0].split(",");
        //         var model = {
        //             Code: data[0],
        //             Name: $("#relevant").attr("hyname"),
        //             ChangePercent: data[5] === "-" ? "-" : data[5],
        //             ChangeColor: data[5].isPositive() ? "red" : "green",
        //             RiseCount: data[1] == "-" ? data[1] : parseInt(data[1].split('|')[0]),
        //             PlainCount: data[1] == "-" ? data[1] : parseInt(data[1].split('|')[1]),
        //             FallCount: data[1] == "-" ? data[1] : parseInt(data[1].split('|')[2])
        //         };
        //         var sum = model.RiseCount + model.PlainCount + model.FallCount;
        //         model.RisePercent = parseInt((model.RiseCount / sum * 100).toFixed(1));
        //         model.PlainPercent = parseInt((model.PlainCount / sum * 100).toFixed(1));
        //         model.FallPercent = parseInt((model.FallCount / sum * 100).toFixed(1));
        //         var html = template("tmp_industry_statistic", model);
        //         $("#industry_statistic").html(html);
        //     }
        // });
        // _auto.intInterval = 20 * 1000;
        // _auto.start();
    }
    //港股通排行&蓝筹股排行
    var initRanking = this.initRanking = function (type, sort) { //zxw
        sort = !sort || typeof sort !== "string" ? "C" : sort.toUpperCase();
        type = !type || typeof type !== "string" ? "HKStock".toLowerCase() : type.toLowerCase();

        var sortType = sort == "C" ? "f3" : sort == "D" ? "f4" : sort == "E" ? "f6" : "f5"
        var cmdType = type === "bluechips" ? "b:MK0104" : "b:MK0144";
        var _auto = dataRefresher[type.charAt(0).toUpperCase() + "Ranking"] = $.dataAutoRefresh({
            url: _instance.baseUrl + '/api/qt/clist/get?pi=0&pz=10&po=1&fs=' + cmdType + '&ut=' + _instance.ut + '&fid=' + sortType + '&fields=f1,f2,f3,f12,f13,f14,f152,' + sortType,
            type: "GET",
            dataType: 'jsonp',
            jsonp: 'cb',
            timeout: 5000,
            data: null,
            success: function (data) {
                // console.log( _instance.baseUrl + '/api/qt/clist/get?pi=0&pz=10&po=1&fs=' + cmdType + '&ut=' + _instance.ut + '&fid='+ sortType +'&fields=f1,f2,f3,f12,f13,f14,f152,' + sortType)
                // console.log( (type === "bluechips"?"港股通":"蓝筹股") +"排行>>",data)
                var data = data.data.diff
                var models = new Array();
                for (var i in data) {
                    var result, item, th, color;
                    if (type === "bluechips") {
                        item = $("#bluechips_ranking_select span").html();
                        th = $("#bluechips_ranking th:last");
                    } else {
                        item = $("#hkstock_ranking_select span").html();
                        th = $("#hkstock_ranking th:last");
                    }
                    if (item == "股票涨跌幅排行") {
                        result = (data[i].f3 / Math.pow(10, data[i].f152)).toFixed(2) + '%';
                        $(th).html("涨跌幅");
                        color = data[i].f3 > 0 ? "red" : data[i].f3 == 0 ? "" : "green";
                    } else if (item == "股票涨跌排行") {
                        result = (data[i].f4 / Math.pow(10, data[i].f1)).toFixed(3);
                        $(th).html("涨跌");
                        color = data[i].f4 > 0 ? "red" : data[i].f4 == 0 ? "" : "green";
                    } else if (item == "股票成交额排行") {
                        result = data[i].f6.toString().fixAmt(0, 1);
                        $(th).html("成交额");
                        color = "";
                    } else {
                        result = data[i].f5.toString().fixAmt(0, 1);
                        $(th).html("成交量");
                        color = "";
                    }
                    models.push({
                        Code: data[i].f12,
                        Title: data[i].f14,
                        Name: data[i].f14,
                        Close: data[i].f2 == 0 ? '-' : (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
                        ChangePercent: result == 0 ? '-' : result,
                        Color1: data[i].f3 > 0 ? "red" : data[i].f3 == 0 ? "" : "green",
                        Color2: color
                    });
                }
                var id = type === "bluechips" ? "bluechips_ranking" : "hkstock_ranking";
                var html = template("tmp_ranking", { list: models });
                $("#" + id + " tbody").html(html);
            }
        });
        _auto.intInterval = 1000 * 20;
        _auto.start();
    }

    //我的港股自选股
    // function initMyHKFavorite(code) { //zxw
    //     //base.baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + base.ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152'
    //     // console.log(code)
    //     // var stocks = ["000015", "000025", "000035", "000045", "000055", "000065", "000075", "000085", "000095", "000105"];
    //     var stocks = ["116.00001", "116.00002", "116.00003", "116.00004", "116.00005", "116.00006", "116.00007", "116.00008", "116.00009", "116.00010"];


    //     $.getScript("http://myfavor.eastmoney.com/mystock?f=gsa&t=5&c=6&var=allstocklist&rt=" + (+new Date()), function () {
    //         var ids = new Array();
    //         if (allstocklist.result == "-1") {
    //             ids = stocks.slice(0, 6);
    //         } else {
    //             var fav = allstocklist.data.list.split(","), tmps = [];

    //             for (var j = 0; j < fav.length; j++) {

    //                 var stockCode = fav[j].split("|")[0];
    //                 if (code == stockCode) continue;
    //                 tmps.push("116." + stockCode);
    //             }

    //             ids = tmps.concat(stocks).unique().slice(0, 6);
    //         }
    //         if (ids.length == 0) return;

    //         var url = _instance.baseUrl + '/api/qt/ulist/get?secids=' + ids.join(",") + "&ut=" + _instance.ut + '&po=1&fid=f3&pi=0&pz=6&fields=f1,f2,f3,f12,f13,f14,f152'
    //         $.ajax({
    //             type: "GET",
    //             url: url,
    //             data: null,
    //             dataType: 'jsonp',
    //             jsonp: 'cb',
    //             success: function (res) {
    //                 // console.log("自选股>>>",res.data.diff)
    //                 var data = res.data.diff;
    //                 var models = new Array();
    //                 for (var i in data) {
    //                     models.push({
    //                         Code: data[i].f12,
    //                         Title: data[i].f14,
    //                         Name: data[i].f14.substr(0, 4),
    //                         Close: (data[i].f2 / Math.pow(10, data[i].f1)).toFixed(3),
    //                         ChangePercent: (data[i].f3 / Math.pow(10, data[i].f152)).toFixed(2) + '%',
    //                         Color: data[i].f3 > 0 ? "red" : data[i].f3 < 0 ? "green" : "",
    //                     })
    //                 }
    //                 var html = template("tmp_myfavorite", { list: models });
    //                 $("#myfavorite tbody").html(html);
    //             }
    //         })
    //     });
    // }
    
    //新的我的自选股
    function initMyHKFavorite(code) {
        // console.log('新的自选股')
        getDefaultStocks().then(function(list){
            var myzixuan = $("#myfavorite tbody");
            if (list) {
                var secids = list;
                var url = "http://" + Math.floor(Math.random()*100+1) + ".push2.eastmoney.com/api/qt/ulist.np/get?ut=bd1d9ddb04089700cf9c27f6f7426281&fields=f2,f3,f14,f12,f13,f1&fltt=2&secids=" + secids;
                $.ajax({
                    type: "get",
                    data: '',
                    url: url,
                    dataType: "jsonp",
                    jsonp: 'cb',
                    success: function (msg) {
                    // console.log('自选股行情数据')
                    // console.log(msg)
                    
                    var showCount = 6;
                    
                    if(msg.data) {
                        
                    if(msg.data.diff) {
                       
                        var arr = msg.data.diff;
                        
                        var myzixuan_data = "";
                        if (arr.length >= showCount) {
                            for (var i = 0; i < showCount; i++) {
                                var zhengquancode = '';
                                zhengquancode = arr[i].f13 + '.' + arr[i].f12;

                                if (arr[i].f3 > 0) {
                                    myzixuan_data += "<tr>" + "<td class='td_width'>" + '<a style="display: block;width: 70px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" href="http://quote.eastmoney.com/unify/r/' + zhengquancode + '" target="_blank" title="' + arr[i].f14 + '">' + arr[i].f14 + '</a>' + "</td>" + "<td class='red'>" + (arr[i].f2).toFixed(arr[i].f1) + "</td>" + "<td class='red'>" + (arr[i].f3).toFixed(2) + "%" + "</td>" + "</tr>";

                                } else if (arr[i].f3 < 0) {
                                    myzixuan_data += "<tr>" + "<td class='td_width'>" + '<a style="display: block;width: 70px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" href="http://quote.eastmoney.com/unify/r/' + zhengquancode + '" target="_blank" title="' + arr[i].f14 + '">' + arr[i].f14 + '</a>' + "</td>" + "<td class='green'>" + (arr[i].f2).toFixed(arr[i].f1) + "</td>" + "<td class='green'>" + (arr[i].f3).toFixed(2) + "%" + "</td>" + "</tr>";

                                } else if (arr[i].f3 == 0) {
                                    myzixuan_data += "<tr>" + "<td class='td_width'>" + '<a style="display: block;width: 70px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" href="http://quote.eastmoney.com/unify/r/' + zhengquancode + '" target="_blank" title="' + arr[i].f14 + '">' + arr[i].f14 + '</a>' + "</td>" + "<td class=''>" + (arr[i].f2).toFixed(arr[i].f1) + "</td>" + "<td class=''>" + (arr[i].f3).toFixed(2) + "%" + "</td>" + "</tr>";
                                }


                            }
                        } else if (arr.length > 0 && arr.length < showCount) {
                            for (var i = 0; i < arr.length; i++) {
                                var zhengquancode = '';
                                zhengquancode = arr[i].f13 + '.' + arr[i].f12;


                                if (arr[i].f3 > 0) {
                                    myzixuan_data += "<tr>" + "<td class='td_width'>" + '<a style="display: block;width: 70px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" href="http://quote.eastmoney.com/unify/r/' + zhengquancode + '" target="_blank" title="' + arr[i].f14 + '">' + arr[i].f14 + '</a>' + "</td>" + "<td class='red'>" + (arr[i].f2).toFixed(arr[i].f1) + "</td>" + "<td class='red'>" + (arr[i].f3).toFixed(2) + "%" + "</td>" + "</tr>";
                                } else if (arr[i].f3 < 0) {
                                    myzixuan_data += "<tr>" + "<td class='td_width'>" + '<a style="display: block;width: 70px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" href="http://quote.eastmoney.com/unify/r/' + zhengquancode + '" target="_blank" title="' + arr[i].f14 + '">' + arr[i].f14 + '</a>' + "</td>" + "<td class='green'>" + (arr[i].f2).toFixed(arr[i].f1) + "</td>" + "<td class='green'>" + (arr[i].f3).toFixed(2) + "%" + "</td>" + "</tr>";
                                } else if (arr[i].f3 == 0) {
                                    myzixuan_data += "<tr>" + "<td class='td_width'>" + '<a style="display: block;width: 70px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" href="http://quote.eastmoney.com/unify/r/' + zhengquancode + '" target="_blank" title="' + arr[i].f14 + '">' + arr[i].f14 + '</a>' + "</td>" + "<td class=''>" + (arr[i].f2).toFixed(arr[i].f1) + "</td>" + "<td class=''>" + (arr[i].f3).toFixed(2) + "%" + "</td>" + "</tr>";
                                }

                            }

                        }
                        myzixuan.html(myzixuan_data);

                    }else{
                        $("#zxMsgMore").css({ "display": "none" });
                        var nonehtml = "<tr><td colspan='3' class='nonemystock'>您暂无自选股</td></tr>";
                        myzixuan.html(nonehtml);
                    }

                }

                    }
                });


            } else {
                $("#zxMsgMore").css({ "display": "none" });
                var nonehtml = "<tr><td colspan='3' class='nonemystock'>您暂无自选股</td></tr>";
                myzixuan.html(nonehtml);
            }
        })

    }


    //沪港通资金流向
    function initCapitalFlow() {  //zxw
        var _auto = dataRefresher["CFData"] = $.dataAutoRefresh({
            url: _instance.baseUrl + '/api/qt/kamt/get?ut=' + _instance.ut + '&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54',
            type: "GET",
            dataType: 'jsonp',
            jsonp: 'cb',
            timeout: 5000,
            data: null,
            success: function (res1) {
                var data1 = res1.data
                //console.log("沪港通资金流向",data1)
                $.ajax({
                    type: "GET",
                    url: _instance.baseUrl + '/api/qt/ulist.np/get?secids=90.BK0707,201.HK32,1.000001,100.HSI&fields=f12,f13,f14,f3,f128,f136,f152,f104,f105,f106&ut=' + _instance.ut,
                    data: null,
                    dataType: 'jsonp',
                    jsonp: 'cb',
                    success: function (res2) {
                        var models = new Array();
                        var data2 = res2.data.diff
                        for (var i = 0; i < data2.length; i++) {
                            if (i <= 1) {
                                var ishk2sh = data2[i].f12 == "BK0707" ? true : false //s是否是沪股通
                                var status = ishk2sh ? data1.hk2sh.status : data1.sh2hk.status//交易状态
                                var link_tmp = template.compile("http://quote.eastmoney.com/{{HKPath}}{{Code}}.html");
                                models.push({
                                    Name: data2[i].f14.substr(0, 3),
                                    Hash: /^沪股通$/.test(data2[i].f14) ? "28003707_12_2" : /港股通/.test(data2[i].f14) ? "mk0144_12" : "",
                                    StockStatus: status == 1 ? "额度可用" : status == 2 ? "额度已满" : status == 3 ? "收盘" : "休市",
                                    FundInto: ((ishk2sh ? data1.hk2sh.dayNetAmtIn : data1.sh2hk.dayNetAmtIn) * 10000).toString().fixAmt(0, 2),
                                    FundColor: (ishk2sh ? data1.hk2sh.dayNetAmtIn : data1.sh2hk.dayNetAmtIn) < 0 ? "green" : "red",
                                    Balance: ((ishk2sh ? data1.hk2sh.dayAmtRemain : data1.sh2hk.dayAmtRemain) * 10000).toString().fixAmt(0, 2),
                                    BKCode: data2[i].f12,
                                    RaiseCount: data2[i].f104,
                                    PlainCount: data2[i].f106,
                                    FallCount: data2[i].f105,
                                    StockMarket: data2[i].f141,
                                    StockLink: link_tmp({ Code: data2[i].f140 || '', HKPath: data2[i].f140 ? (data2[i].f140.length > 5 ? "" : "hk/") : '' }),
                                    StockChangePercent: data2[i].f136 ? ((data2[i].f136 / Math.pow(10, data2[i].f152)).toFixed(2) + '%') : '-',
                                    StockName: data2[i].f128 ? data2[i].f128 : '-',
                                    StockColor: data2[i].f136 > 0 ? "red" : "green",
                                    IndexMarket: ishk2sh ? data2[2].f13 : data2[3].f13,
                                    IndexCode: ishk2sh ? data2[2].f12 : "110000",
                                    IndexChangePercent: (ishk2sh ? (data2[2].f3 / Math.pow(10, data2[2].f152)) : (data2[3].f3 / Math.pow(10, data2[3].f152))).toFixed(2) + '%',
                                    IndexName: ishk2sh ? data2[2].f14 : data2[3].f14,
                                    IndexHK: i == 1 ? true : false,
                                    IndexColor: (ishk2sh ? data2[2].f3 : data2[3].f3) > 0 ? "red" : "green"
                                })
                            }
                        }
                        $("#hgttable tbody").html(template("tmp_hgttable", { list: models }));
                    }
                })
            }
        });
        _auto.intInterval = 10 * 1000;
        _auto.start();
    }

    //事件处理器
    function pageEventHandler() {
        //行业对比的hover效果
        $(".hover_img").hover(function () {
            $(this).find(".imgTd").show();
        }, function () {
            $(this).find(".imgTd").hide();
        });
        // 下拉框处理
        $(".myselect").hover(function () {
            $(this).children("dl").css("display", "block")
        }, function () {
            $(this).children("dl").css("display", "none")
        });
        $("#hkstock_ranking_select dd").click(function () {
            $("#hkstock_ranking_select span").html($(this).html());
            _instance.dataRefresher["HRanking"].stop();
            _instance.initRanking("hkstock", $(this).data()["sort"]);
        });
        $("#bluechips_ranking_select dd").click(function () {
            $("#bluechips_ranking_select span").html($(this).html());
            _instance.dataRefresher["BRanking"].stop();
            _instance.initRanking("bluechips", $(this).data()["sort"]);
        });
        // tab页处理
        $(".tabLi").mouseover(function () { $(this).tabs(); });
        $(".tabs_more").mouseover(function () { $(this).tabs_more(); });
        $(".showRedTips").hover(function () { $("#tips").show(); }, function () { $("#tips").hide(); });
        // 登陆按钮
        //$("#loginstate").html(template("tmp_loginstate", window.location));
        // K线图各按钮
        $("#zkeya li,#zkeyb li,#zkeyc li").click(function () {
            // console.log($(this)[0].getAttribute("value"))
            var value = $(this)[0].getAttribute("value") || "";
            // var value = $(this).text()
            // console.log(value)
            //$(this).addClass('at');
            if (["zkeyb", "zkeyc"].indexOf($(this).parent().attr("id")) >= 0) {
                $("#zkeyb li,#zkeyc li").parent().find("li.at").removeClass("at");
                $("#pick").data("formula", value);
            }
            else {
                $(this).parent().find("li.at").removeClass("at");
                $("#pick").data("ef", value);
            }
            $(this).addClass('at');
            $("#zkeya li[value=\"" + value + "\"],#zkeyb li[value=\"" + value + "\"],#zkeyc li[value=\"" + value + "\"]").addClass("at");
            _instance.initKLineChart(code);
        });
        $("#pictit span").click(function () {
            $("#pictit span.cur").removeClass("cur");
            var ef = $("#zkeya li.at").attr("value");
            var formula = $("#zkeyb li.at").attr("value");
            var type = $(this).addClass("cur").attr("value");
            $("#pick").data("type", type);
            _instance.initKLineChart(code);
        });
        $("#picksd,#picklc").click(function () {
            var unit = $("#pick").data("unit");
            var id = $(this).attr("id");
            if (unit <= -8 && id === "picklc" || unit >= 0 && id === "picksd") {
                $(this).css("cursor", "not-allowed");
                return false;
            }
            $("#picksd,#picklc").css("cursor", "pointer");
            if (id === "picksd") unit += 1;
            else if (id === "picklc") unit -= 1;
            $("#pick").data("unit", unit);
            _instance.initKLineChart(code);
        });

        initNotice();
        fullScreenFun();

        $("#gotoregster").click(function () {
            window.open("https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_20_0?cburl=" + encodeURIComponent(location.href));
            stopPropagation(e);
        });

        $("#gotoopen").click(function () {
            window.open("https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_19_0");
            stopPropagation(e);
        });

        $("#hkadv").click(function () {
            window.open(" https://acttg.eastmoney.com/pub/web_act_161118ggl2_hdrk_01_01_17_0?cburl=" + encodeURIComponent(location.href));
            stopPropagation(e);
        });

        //自选股
        //initFavor();
    }

    function initBulletin() {
        // $.ajax({
        //     url: "/web/api/StockApi/GetBulletin/486",
        //     dataType: "html",
        //     charset: "utf-8",
        //     success: function (html) {
        //         if (!html) return;
        //         var cnt = "[头条]" + $(html).find("li h3 a").html();
        //         $(".topnav").append('<li class="fz12 clearfix fl"><a href="//hk.eastmoney.com" target="_blank" class="fl red" style="margin:0 0 0 10px;text-decoration:underline;font-weight:700">' + cnt + '</a></li>');
        //     }
        // });
        var html = $('#toutiaohtml').html()
        if (!html) return;
        var cnt = "[头条]" + $(html).find("li h3 a").html();
        $(".topnav").append('<li class="fz12 clearfix fl"><a href="//hk.eastmoney.com" target="_blank" class="fl red" style="margin:0 0 0 10px;text-decoration:underline;font-weight:700">' + cnt + '</a></li>');
    }

    function initFavor() {
        $("#addZX").click(function () {
            if ($(this).find("a span").html() == "加自选") {
                $(this).find("a span").html("减自选");
                $(this).find("a b").removeClass().addClass("minus");
                $(this).find("a").attr("href", "http://quote.eastmoney.com/hk/favor/infavor.html?code=" + window.stockcode);
                OpZXToOld("asz", window.stockcode);

            } else {
                $(this).find("a span").html("加自选");
                $(this).find("a b").removeClass().addClass("add");
                $(this).find("a").attr("href", "javascript:;");

                $.getScript("http://mystock.eastmoney.com/mystock.aspx?f=dsz&sc=" + window.stockcode + "|05|01&var=opfavres&rt=");
                OpZXToOld("dsz", window.stockcode);
            }

        });
    }

    //新的  加自选
    function newAddzixuan(code) {
        var mark_code = MktNum + '.' + code;
        // console.log(mark_code) 

        zixuan_show(mark_code);
        zixuan_add(mark_code);
        zixuan_del(mark_code);
    }

    function zixuan_show(code) {
        myShowzixuan(code).then(function (res) {
            if(res == true) {
                $("#addZX1").css("display", "none");
                $("#addZX2").css("display", "false");
            }else if(res == false) {
                $("#addZX1").css("display", "block");
                $("#addZX2").css("display", "none");
            }
        })
        

    }

    function zixuan_add(code) {
        $("#addZX1").click(function() {
            myAddzixuan(code).then(function(res) {
                if(res == true) {
                    $("#addZX1").css("display", "none");
                    $("#addZX2").css("display", "block");
                }
            })

        })

    }

    function zixuan_del(code) {
        $("#addZX2").click(function() {
            myDelzixuan(code).then(function(res) {
                // console.log('del: ' +res)
                if(res == true) {
                    $("#addZX1").css("display", "block");
                    $("#addZX2").css("display", "none");
                }
            })
        })

    }


    //获取自选股列表
    function getDefaultStocks(){

        var zxgurl = 'http://myfavor1.eastmoney.com/' 

        var islogin = getLoginStatus();
        // console.log(islogin);

        var zxg = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin){
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl + apistr + '?cb=?',
                    data: zxgparams,
                    dataType: "jsonp"
                });
            }
        }
            
        
        return zxg.data({
                f: 'gsaandcheck'
            }).then(function(list){
                // console.log('原 list')
                // console.log(list)
                return list.data.list
            })
    }


    //加自选
    function myAddzixuan (code) {
        var islogin = getLoginStatus();
        var zxgurl2 = 'http://myfavor1.eastmoney.com/' 
        var zxg2 = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl2 + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp:'cb'
                });
            }
        }

        return zxg2.data({
            f: 'asz',
            sc: code
        }).then(function(list){
            // console.log(list)
           // return list.result
            if (list.result == 1) {
                return true
            }
            else{
                return false
            }
        })

    }

    //删自选
    function myDelzixuan (code) {
        var islogin = getLoginStatus();
        var zxgurl2 = 'http://myfavor1.eastmoney.com/' 
        var zxg2 = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl2 + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp:'cb'
                });
            }
        }

        return zxg2.data({
            f: 'dsz',
            sc: code
        }).then(function(list){
            // console.log(list)
            //return list.result
            if (list.result == 1) {
                return true
            }
            else{
                return false
            }
        })

    }

    //show自选  get自选
    function myShowzixuan (code) {
        var islogin = getLoginStatus();
        var zxgurl2 = 'http://myfavor1.eastmoney.com/' 
        var zxg2 = {
            data: function(zxgparams){
                var apistr = 'mystock_web'
                if(!islogin) {
                    apistr = 'mystock_webanonym'
                }
                return $.ajax({
                    type: "GET",
                    url: zxgurl2 + apistr,
                    data: zxgparams,
                    dataType: "jsonp",
                    jsonp:'cb'
                });
            }
        }

        return zxg2.data({
            f: 'gsaandcheck',
            sc: code
        }).then(function(list){
            // console.log(list)
            //return list.result
            //return false;
            if (list.data.check == 'True') {
                return true
            }
            else{
                return false
            }
        })

    }


    

    function OpZXToOld(op, code) {
        var cookiesValue = $.getCookie("emhq_stock");
        if (op == "dsz") {
            if (cookiesValue != null) {
                cookiesValue = decodeURIComponent(cookiesValue);
                cookiesValue = cookiesValue.replace("," + code, "").replace(code + ",", "").replace(code, "");
            }
        } else {
            if (cookiesValue == "" || cookiesValue == null) {
                cookiesValue = code;
            }
            else {
                if (cookiesValue.indexOf(code) == -1) {
                    cookiesValue = decodeURIComponent(cookiesValue);
                    cookiesValue = code + "," + cookiesValue;
                }
            }
        }

        $.writeCookie("emhq_stock", cookiesValue, 8760);
    }

    // 实时公告滚动事件
    function initNotice() {
        //var $slideBox = $("#realtime_notice");
        setTimeout(function () {
            var speed = 5000;
            var delay = 0;
            var id = "realtime_notice";
            var t;
            var p = false;
            var o = document.getElementById(id);
            o.innerHTML += o.innerHTML + o.innerHTML + o.innerHTML;
            $(".leftNotice ").mouseenter(function () {
                p = true;
            });

            $(".leftNotice ").mouseleave(function () {
                p = false;
            });

            function start() {
                t = setInterval(scrolling, speed);
            }

            function scrolling() {
                if (o.offsetTop < 0) {
                    if (!p) {
                        $(o).css("top", o.offsetTop + 32);
                    }
                } else {
                    clearInterval(t);
                    var liCount = $("#realtime_notice li").length;
                    $(o).css("top", "-" + liCount * 32);
                    setTimeout(start, delay);
                }
            }
            setTimeout(start, delay);
        }, 1000);



        $('.icon_notice .icon-notice_up').click(function () {
            var obj = $("#realtime_notice");
            var currentTop = parseInt(obj.css("top").replace("px", ""));

            if (currentTop + 32 > 0) {
                return;
            }
            $(obj).css("top", parseInt(currentTop) + 32);
        });

        $('.icon_notice .icon-notice_prev').click(function () {
            var obj = $("#realtime_notice");
            var currentTop = parseInt(obj.css("top").replace("px", ""));
            var liCount = $("#realtime_notice li").length;

            if ((currentTop - 32) * -1 >= liCount * 32) {
                return;
            }

            $(obj).css("top", parseInt(currentTop) - 32);
        });
    }
    //全屏的方法
    function fullScreenFun() {
        // ie9以下隐藏全屏按钮
        if (document.all && !document.addEventListener) {
            $(".fullScreenBtn").hide();
            $("#beta-text-link1").hide();
            $("#beta-text-link2").hide();
            window.location.hash = "";
        }else {
            $(".fullScreenBtn").show();
        
        
        var id = 116 + "." + window.stockcode
        var url = "//quote.eastmoney.com/basic/full.html?mcid=" + id + "&type=r";
        var $context = $('<div class="fs-wrapper"><div class= "mark-box"></div><div class="full-box"><span class="full-close">×</span><iframe src = "' + url + '" style="height:98%;width:99%"></iframe></div ></div>');
        $(".fullScreenBtn").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        if (location.href.indexOf("#fullScreenChart") > 0) {
            $(".fullScreenBtn").trigger("click");
        }

        //增加 点击图片 跳转全屏图
        $("#picr").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });

        //增加点击 k线图 跳转全屏图
        $("#pick").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        $("#beta-text-link1").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });
        $("#beta-text-link2").click(function () {
            $("body").append($context)
            $(".full-close").click(function () {
                $($context).remove()
                window.location.hash = "";
            })
        });

    }




    }

}

// 扩展方法定义
function extendFuncs() {

    // jquery扩展
    jQuery.extend({
        //定时数据获取扩展
        dataAutoRefresh: function (settings) {
            var fname = "", core = null, isAjax = false, args = new Object();
            var _init = false, _intInterval = !window["defaultInterval"] ? 1000 * 20 : window.defaultInterval, _intThread = -1;
            if (typeof settings === "object") {
                if (!settings["dataType"]) settings["dataType"] = "text";
                if (!!settings["dataType"] && settings["dataType"] === "jsonp") {
                    if (!settings["jsonpCallback"] || settings["jsonpCallback"] === "?") {
                        var fCallback = null;
                        fname = "jQuery" + Math.random().toString().split('.')[1] + "_" + (+new Date());
                        settings["jsonpCallback"] = "jQuery." + fname;
                        if (typeof settings["success"] === "function") {
                            jQuery[fname] = settings["success"];
                        }
                        fCallback = jQuery[fname];
                    }
                }
                core = function () {
                    this.init = true;
                    if (settings.dataType.toLowerCase() === "img") {
                        $.imgLoader(settings);
                    } else {
                        var _timeout = 5000;
                        settings["timeout"] = !settings.timeout ? _timeout : settings["timeout"];
                        if (settings.dataType && settings.dataType.toLowerCase() === "jsonp") {
                            settings["type"] = "GET";
                            settings["jsonp"] = !settings.jsonp ? "cb" : settings.jsonp;
                        }
                        $.ajax(settings);
                    }
                };
            } else if (typeof arguments[0] === "function") {
                fname = arguments[0].name;
                _intInterval = parseInt(arguments[1]) || _intInterval;
                core = arguments[0];
                for (var i = 2; i < arguments.length; i++)
                    args[i - 2] = arguments[i];
                core();
                _init = true;
                _intThread = setInterval(core, _intInterval, args);
            }
            return {
                init: _init,
                intInterval: _intInterval,
                intThread: _intThread,
                callback: fname,
                load: core,
                start: function () {
                    this.stop();
                    this.load();
                    if (this.intInterval >= 0) {
                        this.intThread = setInterval(this.load, this.intInterval, args);
                    }
                },
                stop: function () {
                    if (this.intThread !== -1) {
                        clearInterval(this.intThread);
                        if (isAjax) fCallback = null;
                    }
                    this.intThread = -1;
                }
            }
        },
        //异步动态图片加载
        imgLoader: function (setting) {
            if (typeof (setting) !== "object" || !setting["url"]) return false;
            var fCallback = typeof (setting["success"]) === "function" ? setting["success"] : null;
            var _url = setting["url"];
            if (setting["data"]) {
                var _data = $.param(setting["data"]);
                _url = _url.indexOf("?") > 0 ? _url + "&" + _data : _url + "?" + _data;
            }
            if (!setting["cache"]) {
                _url += _url.indexOf("?") > 0 ? "&_=" + Math.random() : "?_=" + Math.random();
            }
            var _image = document.createElement("img");
            var height = parseFloat(setting["height"]),
                width = parseFloat(setting["width"]),
                border = parseFloat(setting["border"]);
            if (!isNaN(height) && height > 0) {
                _image.setAttribute("height", height);
            }
            if (!isNaN(width) && width > 0) {
                _image.setAttribute("width", width);
            }
            if (!isNaN(border) && border > 0) {
                _image.setAttribute("border", border);
            }
            _image.setAttribute('src', _url);
            if (typeof (setting["error"]) === "function")
                $(_image).error(function () { setting["error"](_image); });
            _image.onload = _image.onreadystatechange = function (evt) {
                if (!_image.readyState || /loaded|complete/.test(_image.readyState)) {
                    // Handle memory leak in IE
                    _image.onload = _image.onreadystatechange = null;
                    // Callback if not abort
                    if (fCallback) fCallback(_image);
                }
            };
        },
        //异步动态脚本加载
        jsLoader: function (setting) {
            if (typeof (setting) !== "object" || !setting["url"]) return false;
            var fCallback = typeof (setting["success"]) === "function" ? setting["success"] : null;
            var _url = setting["url"], _charset = !setting["charset"] ? "utf-8" : setting["charset"];
            if (setting["data"]) {
                var _data = $.param(setting["data"]);
                _url = _url.indexOf("?") > 0 ? _url + "&" + _data : _url + "?" + _data;
            }
            if (!setting["cache"]) {
                _url += _url.indexOf("?") > 0 ? "&_=" + Math.random() : "?_=" + Math.random();
            }
            var _script = document.createElement('script');
            if (typeof (setting["async"]) !== "boolean") {
                _script.async = _script.defer = true;
            } else _script.async = _script.defer = setting["async"];
            _script.setAttribute('charset', _charset);
            _script.setAttribute('type', 'text/javascript');
            _script.setAttribute('src', _url);
            _script.onload = _script.onreadystatechange = function () {
                if (!_script.readyState || /loaded|complete/.test(_script.readyState)) {
                    // Handle memory leak in IE
                    _script.onload = _script.onreadystatechange = null;
                    // Callback if not abort
                    if (fCallback) fCallback();
                    // Remove the script
                    if (_script.parentNode) {
                        _script.parentNode.removeChild(_script);
                    }
                    // Dereference the script
                    _script = null;
                }
            };
            document.getElementsByTagName('head')[0].appendChild(_script);
        },
        //个股状态
        getStockStatus: function (num) {
            var code = parseInt(num);
            switch (code) {
                case -2:
                    return "不存在/额度不可用";
                case -1:
                    return "已停牌";
                case 0:
                    return "已开盘/额度可用";
                case 1:
                    return "已收盘";
                case 2:
                    return "午盘";
                case 3:
                    return "休市";
                case 4:
                    return "早盘清空";
                case 5:
                    return "限制买入";
                case 6:
                    return "限制卖出";
                case 7:
                    return "暂停交易";
                case 8:
                    return "上涨熔断5%";
                case 9:
                    return "上涨熔断7%";
                case 10:
                    return "下跌熔断5%";
                case 11:
                    return "下跌熔断7%";
                default:
                    return "不存在/额度不可用";
            }
        },
        //获取Cookie的值
        getCookie: function (key) {
            var arr, reg = new RegExp("(^| )" + key + "=([^;]*)(;|$)");
            if (arr = document.cookie.match(reg))
                return unescape(arr[2]);
            else
                return null;
        },
        writeCookie: function (name, value, hours) {
            var expire = "";
            if (hours != null) {
                expire = new Date((new Date()).getTime() + hours * 3600000);
                expire = "; expires=" + expire.toGMTString() + ";path=/;domain=.eastmoney.com";
            }
            document.cookie = name + "=" + escape(value) + expire;
        }


    });
    jQuery.fn.extend({
        //让文字闪烁起来
        textBlink: function (options) {
            var dom = this;
            var defaults = {
                color: ["#fff", "#ffe2d1", "#ffc2a1", "#ffa370", "#ff8340", "#ff630f"], //轮番颜色 默认橙色
                blinktime: 60, //每帧时间 毫秒
                circle: 2 //闪烁次数
            }
            var _options = jQuery.extend(defaults, options);
            var loop = 0;
            for (var i = 0; i < _options.color.length * _options.circle; i++) {
                setTimeout(function () {
                    jQuery(dom).css("background-color", _options.color[loop]);
                    loop++;
                    loop = loop % _options.color.length;
                }, _options.blinktime * i);
            }
        },
        tabs: function () {
            var _obj = $(this);
            _obj.addClass("cur").siblings().removeClass("cur");
            var i = _obj.val() - 1;
            _obj.parentsUntil(".tabExchange").parent().find(".info_list").each(function (idx, ele) {
                $(ele).removeClass("active");
                if (idx == i) $(ele).addClass("active");
            });
        },
        tabs_more: function () {
            var obj = this;
            $(obj).addClass("cur").siblings().removeClass("cur");
            var i = $(obj).val() - 1;
            $(obj).parentsUntil(".tabExchange").parent().find(".info_list").each(function (idx, ele) {
                $(ele).removeClass("active");
                if (idx == i) $(ele).addClass("active");

                $(obj).parent().parent().find(".more").css("display", "none");
                $(obj).parent().parent().find(".more").eq(i).css("display", "block");
            });
            //$(obj).parentsUntil(".tabExchange").find(".more").eq(i).css("display", "block").siblings("a").css("display", "none");
        }
    });
    String.prototype.isPositive = function () {
        var context = this;
        if (typeof (context).toLowerCase() === "string") {
            context = context.replace("%", "");
            var regNum = new RegExp("^([\\-\\+]?\\d+(\\.\\d+)?)$");
            if (regNum.test(context)) {
                var reg = new RegExp("^-");
                return !reg.test(context);
            } else return Number.NaN;
        }
    }
    /**
     * 对Date的扩展，将 Date 转化为指定格式的String
     * 月(M)、日(d)、12小时(h)、24小时(H)、分(m)、秒(s)、周(E)、季度(q) 可以用 1-2 个占位符
     * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
     * eg:
     * (new Date()).pattern("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
     * (new Date()).pattern("yyyy-MM-dd E HH:mm:ss") ==> 2009-03-10 二 20:09:04
     * (new Date()).pattern("yyyy-MM-dd EE hh:mm:ss") ==> 2009-03-10 周二 08:09:04
     * (new Date()).pattern("yyyy-MM-dd EEE hh:mm:ss") ==> 2009-03-10 星期二 08:09:04
     * (new Date()).pattern("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18
     * @param {string} fmt format for date.
     * @returns {string} string date.
    **/
    Date.prototype.pattern = function (fmt) {
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours() % 12 === 0 ? 12 : this.getHours() % 12, //小时
            "H+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        var week = {
            "0": "\u65e5",
            "1": "\u4e00",
            "2": "\u4e8c",
            "3": "\u4e09",
            "4": "\u56db",
            "5": "\u4e94",
            "6": "\u516d"
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        if (/(E+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\fu5468") : "") + week[this.getDay() + ""]);
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return fmt;
    }
    /**
     * 对template的扩展，将 Date 转化为指定格式的String
     * {{time | dateFormat:'yyyy-MM-dd hh:mm:ss'}}
     * @param {date} date date.
     * @param {string} formate format for date.
     * @returns {string} string date.
    **/
    template.helper('dateFormat', function (date, formate) {
        date = date.replace("-", "/");
        return new Date(date).pattern(formate);
    });
    template.helper('cutstr', function (str, len, ellipsis) {
        if (typeof ellipsis != "string") ellipsis = "...";
        var str_length = 0;
        var str_len = 0;
        str_cut = new String();
        for (var i = 0; i < str.length; i++) {
            a = str.charAt(i);
            str_length++;
            if (escape(a).length > 4) {
                //中文字符的长度经编码之后大于4  
                str_length++;
            }
            //str_cut = str_cut.concat(a);
            if (str_length <= len) {
                str_len++;
            }
        }
        //如果给定字符串小于指定长度，则返回源字符串；  
        if (str_length <= len) {
            return str.toString();
        }
        else {
            return str.substr(0, str_len).concat(ellipsis);
        }
    });
    //字符串长度处理，超出部分变为...
    String.prototype.interceptString = function (length, length1) {
        var str = this;
        if (!length1) length1 = 0;
        if (typeof (length) !== "number") return str;
        str = str.replace(/[" "|"　"]/g, ""); //去半角+全角空格
        if (str.length > length) {
            if (length1 === 0) {
                length1 = length;
            }
            if (str.length >= length1) {
                var str_left = str; //.substr(0, length1);cut
                //var str_right = str.substr(length1);
                var banjiao = 0;
                var quanjiao = 0;
                var strCode;
                for (var i = 0; i < str.length; i++) {
                    strCode = str.charCodeAt(i);
                    if (strCode >= 33 && strCode <= 126) {
                        banjiao++;
                    } else {
                        quanjiao++;
                    }
                }
                if ((quanjiao + banjiao / 2) > length || (quanjiao + banjiao / 2) - length === 0.5) {
                    str_left = str_left.substr(0, str_left.length - 1.5);
                    return str_left;
                } else if ((quanjiao + banjiao / 2) - length !== 0) {
                    if (length1 + 1 <= str.length) {
                        str_left = str.interceptString(length, length1 + 1);
                    }
                }
                return str_left;
            }
        } else return str;
    }

    /**
     *成交量,成交额修复(只对正数进行判断)
     * 1234 对应 1234
     * 12345 对应 1.23万
     * 123456 对应 12.3万
     * 1234567 对应 123万
     * 12345678 对应 1234万
     * 123456789 对应 1.23亿
     * 1234567890 对应 12.3亿
     * 12345678900 对应 123亿
     * @param {string} defval default value.
     * @param {number} fixNum number to fix.
     * @returns {string} string number.
    **/
    String.prototype.fixAmt = function (defval, fixNum) {
        var result = typeof defval !== "string" ? defval.toString() : defval,
            fix = isNaN(parseInt(fixNum)) ? 2 : parseInt(fixNum);
        var val = parseFloat(this);
        if (isNaN(val)) return result;
        var fs = val < 0;
        val = Math.abs(val);
        if (val >= Math.pow(10, 12)) {
            result = (val / Math.pow(10, 12)).toFixed(fix).toString() + "万亿";
        } else if (val >= Math.pow(10, 11)) {
            result = (val / Math.pow(10, 8)).toFixed(fix).toString() + "亿";
        } else if (val >= Math.pow(10, 10)) {
            result = (val / Math.pow(10, 8)).toFixed(fix).toString() + "亿";
        } else if (val >= Math.pow(10, 9)) {
            result = (val / Math.pow(10, 8)).toFixed(fix).toString() + "亿";
        } else if (val >= Math.pow(10, 8)) {
            result = (val / Math.pow(10, 8)).toFixed(fix).toString() + "亿";
        } else if (val >= Math.pow(10, 7)) {
            result = (val / Math.pow(10, 4)).toFixed(fix).toString() + "万";
        } else if (val >= Math.pow(10, 6)) {
            result = (val / Math.pow(10, 4)).toFixed(fix).toString() + "万";
        } else if (val >= Math.pow(10, 5)) {
            result = (val / Math.pow(10, 4)).toFixed(fix).toString() + "万";
        } else if (val >= Math.pow(10, 4)) {
            result = (val / Math.pow(10, 4)).toFixed(fix).toString() + "万";
        } else {
            result = val.toFixed(fix).toString();
        }
        result = fs ? "-" + result : "" + result;
        return result;
    }
    //单位换算
    String.prototype.NumbericFormat = function (fixed) {
        var context = this;
        //var fushu = false;
        fixed = typeof fixed === "number" && fixed >= 0 ? fixed : NaN;
        if (!isNaN(context)) {
            var item = parseInt(this);
            if ((item > 0 && item < 1e4) || (item < 0 && item > -1e4)) {
                return item;
            } else if ((item > 0 && item < 1e6) || (item < 0 && item > -1e6)) {
                item = item / 10000;
                return item.toFixed(fixed || 2) + "万";
            } else if ((item > 0 && item < 1e7) || (item < 0 && item > -1e7)) {
                item = item / 10000;
                return item.toFixed(fixed || 1) + "万";
            } else if ((item > 0 && item < 1e8) || (item < 0 && item > -1e8)) {
                item = item / 10000;
                return item.toFixed(fixed || 0) + "万";
            } else if ((item > 0 && item < 1e10) || (item < 0 && item > -1e10)) {
                item = item / 1e8;
                return item.toFixed(fixed || 2) + "亿";
            } else if ((item > 0 && item < 1e11) || (item < 0 && item > -1e11)) {
                item = item / 1e8;
                return item.toFixed(fixed || 1) + "亿";
            } else if ((item > 0 && item < 1e12) || (item < 0 && item > -1e12)) {
                item = item / 1e8;
                return item.toFixed(fixed || 0) + "亿";
            } else if ((item > 0 && item < 1e14) || (item < 0 && item > -1e14)) {
                item = item / 1e12;
                return item.toFixed(fixed || 1) + "万亿";
            } else if ((item > 0 && item < 1e16) || (item < 0 && item > -1e16)) {
                item = item / 1e12;
                return item.toFixed(fixed || 0) + "万亿";
            } else {
                return item;
            }
        }
        else {
            return '-';
        }
        //return context.toString();
    }

    String.prototype.cutString = function (len, txt) {
        txt = txt || "...";
        var str = this;
        //length属性读出来的汉字长度为1
        if (str.length * 2 <= len) {
            return str;
        }
        var strlen = 0;
        var s = "";
        for (var i = 0; i < str.length; i++) {
            s = s + str.charAt(i);
            if (str.charCodeAt(i) > 128) {
                strlen = strlen + 2;
                if (strlen >= len) {
                    return s.substring(0, s.length - 1) + txt;
                }
            } else {
                strlen = strlen + 1;
                if (strlen >= len) {
                    return s.substring(0, s.length - 2) + txt;
                }
            }
        }
        return s;
    }

    if (!Array.prototype.indexOf) {
        Array.prototype.indexOf = function (elt /*, from*/) {
            var len = this.length >>> 0;
            var from = Number(arguments[1]) || 0;
            from = (from < 0)
                ? Math.ceil(from)
                : Math.floor(from);
            if (from < 0)
                from += len;
            for (; from < len; from++) {
                if (from in this &&
                    this[from] === elt)
                    return from;
            }
            return -1;
        };
    }

    //数组去重
    Array.prototype.unique = function () {
        var arr = this;
        var result = [], hash = {};
        for (var i = 0; i < arr.length; i++) {
            if (!hash[arr[i]]) {
                result.push(arr[i]);
                hash[arr[i]] = true;
            }
        }
        return result;
    }
}

// var template = window.template, $ = window.jQuery;
// RequireJS && SeaJS
// if (typeof define === 'function') {
//     define(["jquery", "template"], function (jq, tmp) {
//         $ = jq; template = tmp;
//         extendFuncs($, tmp);
//         return EM_HKStocks_L2;
//     });
// } else {
extendFuncs(jQuery, template);
window["EM_HKStocks_L2"] = EM_HKStocks_L2;
// }


module.exports = EM_HKStocks_L2;