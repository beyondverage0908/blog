/**
 * 页面缓存中间件
 * 注意： 此中间件只用于行情单页缓存，不能用于接口之类的
 * 只会缓存200返回的页面，404 500 都不会缓存
 */
import { Context } from "koa"
import encryption from "../encryption"
import memorycache from "memory-cache"
import filecache from "../filecache"
import logger from "../logger"
const config = require('../../../config/index.js')


interface pagecache_option{
  /**
   * 内存缓存时间 ms
   */
  cachetime?:number,

  /**
   * 硬盘缓存时间 ms
   */
  file_cachetime?:number,
  /**
   * 忽略url上的search参数
   */
  ignore_search?:boolean
}

async function refreshCache(ctx: Context, next: Function, key:string, cache_time: number, options:any){
  // console.info(Date.now())
  // console.info(cache_time)
  // console.info(options)
  
  
  if (Date.now() - cache_time < options.cachetime) { //时间少于过期时间 不刷新
    // console.info('不刷新')
    
    return false
  }

  // console.info('刷新')
  

  try {
    await next()
    if(ctx.status != 200 || ctx.body == ''){ //非正常页面
      return
    }
    let cache_content = {
      time: Date.now(),
      body: ctx.body
    }
    
    memorycache.put(key, cache_content) //写入内存

    if (Date.now() - cache_time > options.file_cachetime) {
      filecache.put(key, cache_content) //写入文件
    }

    
  } catch (error) {
    logger.error(error)
  }
}

/**
 * 页面缓存中间件
 */
export default function(options?:pagecache_option) {
  let default_options = {
    cachetime: 2 * 60 * 1000,
    file_cachetime: 10 * 60 * 1000,
    ignore_search: true
  }

  let this_options = Object.assign(default_options, options)

  return async function (ctx: Context, next: Function) {
    if (!config.getEnvParam('page_cache_enabled')) { //不开起缓存
      await next()
      return
    }

    let key
    if (this_options.ignore_search) {
      key = encryption.sha1('pagecache:' + ctx.path)
    }
    else{
      key = encryption.sha1('pagecache:' + ctx.path + '?' + ctx.querystring)
    }

    let page_cache = memorycache.get(key)

    //符合缓存获取条件
    if (page_cache != null) {
      // console.info('走缓存')
      
      //&& page_cache.time && (  )
      // console.info('go memory cache')
      ctx.body = page_cache.body
      refreshCache(ctx, next, key, page_cache.time, this_options)
      return
    }
    else{
      //尝试文件缓存
      let file_page_cache = await filecache.get(key)
      if (file_page_cache != null) {
        //file_page_cache.time && ( Date.now() - file_page_cache.time < this_options.cachetime )
        // console.info('go file cache')
        memorycache.put(key, file_page_cache)
        ctx.body = file_page_cache.body
        refreshCache(ctx, next, key, file_page_cache.time, this_options)
        return
      }
    }

    try {
      //正常获取页面
      await next()
      if(ctx.status != 200 || ctx.body == ''){ //非正常页面
        return
      }

      let cache_content = {
        time: Date.now(),
        body: ctx.body
      }

      memorycache.put(key, cache_content) //写入内存

      filecache.put(key, cache_content) //写入文件

    } catch (error) {
      logger.error(error)

      ctx.status = 500
      if (process.env.NODE_ENV != "production") {
        ctx.body = `<textarea style="width: 800px; height: 400px; margin:0 auto;display:block;font-family: consolas; font-size:14px; line-height:175%; overflow:auto; border:0;background-color:#f3f3f3; padding:20px;">ERROR\n${error.stack}</textarea>`
      }
      else {
        await ctx.render('shared/error', {
          title: '500',
          layout: false
        })
      }
    }
  }
}