// require(["baseStock", "common", "template"], function (baseStock, common, template) {
var baseStock = require('./basestock')
var common = require('../old_b/common')
var template = require('../old_b/template')

    function Index() {
        baseStock.call(this);  //第二次调用基类的构造函数
    }
    Index.prototype = new baseStock();
    var instance = new Index();
    // 链接跳转地址
    var _link = "//quote.eastmoney.com/gb/zs{{code}}.html";

    function renderRankList(options) {
        if ($(options.dom).length === 0) return;
        //return instance.loadRankTemplate(options);
        return instance.loadRankTemplatenew(options)
    }

    function onChangeDataRender($dom, item, settings) {
        if (item != 0 && item != "-") {
            if (item.isPositive()) {
                $("#arrow-find").removeClass("down-arrow").addClass("up-arrow");
            } else {
                $("#arrow-find").removeClass("up-arrow").addClass("down-arrow");
            }
        } else {
            $("#arrow-find").removeClass("up-arrow").removeClass("down-arrow");
        }
    }

    //热门港股吧
    Index.prototype.setHotHKGuba = function (len) {
        var _len = len || 15;
        var url = "//gubaapi.eastmoney.com/v3/read/Guba/HotGuba.aspx?type=3&deviceid=21163A425F7727789381D8356B6068E2&p=1&product=EastMoney&plat=Web";
        $.ajax({
            url: url,
            dataType: "jsonp",
            data: { version: 100, ps: _len },
            jsonpCallback: "hotHKGubaCallback"
        });
    }
 
    // 热门港股吧回调
    window.hotHKGubaCallback = function (json) {
        if (!json || json.length == 0) return;
        var ids = [];
        var html = "";
        if (json.rc === 1) {
            if (!json.rc || json.rc.length == 0) return;
            if (json.re.length == 0) return;
            var html = template("tmp_hotguba_hk", json);
            $("#hotguba_hk tbody").html(html);
        }
    }

    // 右边栏其他指数 美洲指数 澳洲指数
    Index.prototype.otherGlobalIndex = function () {
        if (!stockEnity.otherIndexCmds || !stockEnity.displayAreas) return;
        //总条数计数器，不超过35条
        counter = 35;
        var az = 0, yz = 0, mz = 0, oz = 0, hk = 0
        if (stockEnity.area == 'HK') { //澳洲指数
            hk = 15
            az = 3;
            mz = 9;
            oz = 8;
            yz = 0;
        }
        if (stockEnity.area == 'AUS') { //澳洲指数
            hk = 0;
            az = 3;
            mz = 9;
            oz = 15;
            yz = 8;
        } else if (stockEnity.area == 'ASIA') { //亚洲指数
            hk = 0;
            az = 3;
            mz = 9;
            oz = 11;
            yz = 12;
        } else if (stockEnity.area == 'EUR') { //欧洲指数
            hk = 0;
            az = 3;
            mz = 9;
            oz = 15;
            yz = 8;
        } else if (stockEnity.area == 'AME') { //美洲指数
            hk = 0;
            az = 3;
            mz = 9;
            oz = 15;
            yz = 8;
        }

        //香港
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=" + hk + "&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=m:124,m:125,m:305&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#HKIndex tbody",
            link: "//quote.eastmoney.com/gb/zs{{code}}.html"
        })
        //美洲
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=" + mz + "&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=i:100.NDX100,i:100.UDI,i:100.NDX,i:100.SPX,i:100.BVSP,i:100.DJIA,i:100.TSX,i:100.CRB,i:100.MXX&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#AMEIndex tbody",
            link: "//quote.eastmoney.com/gb/zs{{code}}.html"
        })
        //澳洲
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=" + az + "&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=i:100.NZ50,i:100.AS51,i:100.AORD&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#AUSIndex tbody",
            link: "//quote.eastmoney.com/gb/zs{{code}}.html"
        })
        //欧洲
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=" + oz + "&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=i:100.WIG,i:100.PSI20,i:100.RTS,i:100.OSEBX,i:100.ISEQ,i:100.MIB,i:100.MCX,i:100.FTSE,i:100.AXX,i:100.OMXSPI,i:100.IBEX,i:100.SSMI,i:100.ICEXI,i:100.PX,i:100.OMXC20,i:100.SX5E,i:100.ATX,i:100.BDI,i:100.BFX,i:100.GDAXI,i:100.AEX,i:100.ASE,i:100.FCHI,i:100.HEX25,i:100.HEX&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#EURIndex tbody",
            link: "//quote.eastmoney.com/gb/zs{{code}}.html"
        })
        //亚洲
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=" + yz + "&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=i:1.000001,i:0.399001,i:1.000300,i:0.399006,i:0.399005,i:100.HSI,i:100.HSCEI,i:124.HSCCI,i:100.SENSEX,i:100.JKSE,i:100.N225,i:100.KOSPI200,i:100.KS11,i:100.KLSE,i:100.PSI,i:100.KSE100,i:100.STI,i:100.CSEALL,i:100.SET,i:100.TWII,i:100.VNINDEX&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#ASIAIndex tbody",
            link: "//quote.eastmoney.com/gb/zs{{code}}.html"
        })
    }

    // 全球时间
    _GlobalTime.prototype.show = function () {
        var a = this;
        var f = a.Option;
        var b = f.citys.length;
        var l = [], k = [];
        var el = document.getElementById("worldtime").getElementsByTagName("i");
        var date = "";
        var h = function () {
            var d = a.utils.now() + a.deviation - (3600000 * 8);
            for (var c = 0; c < b; c++) {
                var j = a.utils.formatTime(d, f.citys[c].utc);
                el[c].innerHTML = a.utils.dateFromat(j, f.display);
            }
        };
        h();
        var g = setInterval(h, 1000);
    };

    /**
    * 我的港股自选股
    */
    Index.prototype.initMyHKFavorite = function () {
        var code = stockEnity.stockCode;
        var stocks = ["116.00001", "116.00002", "116.00003", "116.00004", "116.00005", "116.00006", "116.00007", "116.00008", "116.00009", "116.00010"];
        $.getScript("http://myfavor.eastmoney.com/mystock?f=gsa&t=5&c=6&var=allstocklist&rt=" + (+new Date()), function () {
            var ids = new Array();
            if (allstocklist.result == "-1") {
                ids = stocks.slice(0, 7);
            } else {
                var fav = allstocklist.data.list.split(","), tmps = [];
                for (var j = 0; j < fav.length; j++) {
                    var stockCode = fav[j].split("|")[0];
                    if (code == stockCode) continue;
                    tmps.push(stockCode + "5");
                    //fav[j] = stockCode + "5";
                }

                ids = tmps.concat(stocks).unique().slice(0, 7);
            }

            renderRankList({
                url: instance.baseUrl + '/api/qt/ulist/get?secids=' + ids.join(",") + "&ut=" + instance.ut + '&po=1&fid=f3&pi=0&pz=6&fields=f1,f2,f3,f12,f13,f14,f152',
                dom: "#favorTable tbody",
                link: "//quote.eastmoney.com/hk/{{code}}.html"
            })
        });
    }

    /**
     * 海外直播
     */
    function liveBroadcast() {
        var maxId = "", minId = 0;
        var bodyTemplate = '{{each news as val idx}}'
            + '<li><span class="kx_itime">{{val.showtime | formatDate: "HH:mm:ss"}}</span><span class="kx_itime_end">|</span><span class="bd_i_txt {{val.titlestyle | getLiveBroadcastCss}}">'
            + '{{if val.newstype != 2}}<a href="{{val.url_unique}}" target="_blank">{{val.digest || val.title}}&nbsp;[点击查看全文]</a></span></li>'
            + '{{else}}{{val.digest || val.title}}</span></li>{{/if}}'
            + '{{/each}}',
            headTemplate = '{{if news.length>0}}刚刚为您更新了{{news.length}}条资讯'
                + '{{else}}暂无资讯更新{{/if}}';

        template.helper("getLiveBroadcastCss", function (titlestyle) {
            //0-默认 1-加粗 2-跳红 3-跳红加粗.
            var res = "";
            switch (titlestyle) {
                case "1": res = "bold"; break;
                case "2": res = "red"; break;
                case "3": res = "redbold"; break;
            }
            return res;
        });

        var timer = common.timer({
            dom: ".kx_auto_sec",
            callback: function (args) {
                load();
                timer.reset();
            }
        });

        function load() {
            if (stockEnity.area !== "HK") {
                $.ajax({
                    url: "//newsinfo.eastmoney.com/kuaixun/v2/api/list?column=132&limit=50",
                    dataType: "jsonp",
                    data: { id: maxId },
                    success: function (json) {
                        render(json);
                        maxId = json.MaxID;
                    }
                });
            }
            else {
                $.ajax({
                    url: "//newsinfo.eastmoney.com/kuaixun/v2/api/Channel/5/0/" + minId + "/50",
                    dataType: "jsonp",
                    data: { id: minId },
                    success: function (json) {
                        if (!json || !json.success) return;
                        var model = { news: new Array(json.data.length) };
                        for (var i = 0; i < json.data.length; i++) {
                            if (i === 0) minId = json.data[i].Art_Code;
                            model.news[i] = {
                                showtime: json.data[i].Art_ShowTime,
                                newstype: 1,
                                title: json.data[i].Art_Title,
                                titlestyle: json.data[i].Art_TitleColor,
                                digest: json.data[i].Art_Digest,
                                url_w: json.data[i].Art_Url
                            };
                        }
                        render(model);
                    }
                });
            }
        }

        function render(json) {
            if (typeof json !== "object") return;
            var body = template.render(bodyTemplate, json);
            $("#kx_lists").prepend(body);
            if (maxId || minId) {
                $(".tipstr").html(template.render(headTemplate, json));
                setTimeout(function () { $(".tipstr").html("直播中..."); }, 3000);
            }
        }

        // 快讯事件
        function bindEvents() {
            if (stockEnity.area === "HK") {
                $(".zhibo").find("h3").html("<a href='http://roll.eastmoney.com/hk.html' target='_blank'>港股直播</a>");
            }
            $("#kx_refresh").off()
            $("#kx_refresh").click(function () { load(); });
            $("#kx_auto").click(function () {
                if ($(".kx_auto").hasClass("kx_auto kx_autoing")) {
                    $(".kx_auto").removeClass("kx_autoing");
                    timer.stop();
                }
                else {
                    $(".kx_auto").addClass("kx_autoing");
                    timer.reset();
                }
            });
            $(".kx_fontsize").click(function () {
                if ($(".kx_list").attr("class") == "kx_list") {
                    $(".kx_list").addClass("kx_fz14");
                    $(".kx_fontsize").html("小字-");
                } else {
                    $(".kx_list").removeClass("kx_fz14");
                    $(".kx_fontsize").html("大字+")
                }
            });
        }

        timer.start();
        bindEvents();
        load();
    }

    //全球直播
    function globalZhb() {
        var tpl = '{{each news as val idx}}<li class="fl" title ="{{val.title}}" >'
            + '{{if val.newstype!=2}}<a href="{{val.url_unique}}" target="_blank">·{{val.title | cutstr: 80,"..."}}</a>'
            + '{{else}}<a href="http://kuaixun.eastmoney.com" target="_blank">·{{val.title | cutstr: 80,"..."}}</a>{{/if}}'
            + '</li>{{/each}}';
        jQuery.ajax({
            url: "//newsinfo.eastmoney.com/kuaixun/v2/api/list?column=zhiboall&limit=1",
            dataType: "jsonp",
            success: function (json) {
                if (json.rc == 1) {
                    var html = template.render(tpl, json);
                    $(".ScrollMIIRBox").html(html);
                }
            }
        });
    }

    function refresh() {
        imgevt.changeImg();
        //全球直播
        globalZhb();
        // 右边栏其他指数 zxw
        instance.otherGlobalIndex();
        // 外汇 zxw
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=8&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=m:119,m:120,m:121,m:133&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#forex_rank tbody",
            link: "//quote.eastmoney.com/forex/{{code}}.html"
        })

        // 国际期货zxw
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=7&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=m:102,m:103,m:108,m:109,m:111,m:112&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#globalfutures_rank tbody",
            link: "//quote.eastmoney.com/globalfuture/{{code}}.html"
        })

        // 互联网中国zxw
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=6&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=b:MK0202&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#chinese_network tbody",
            link: "//quote.eastmoney.com/us/{{code}}.html"
        })

        // 中概股 zxw
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=5&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=b:MK0201&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#chinese_stocks tbody",
            link: "//quote.eastmoney.com/us/{{code}}.html"
        })


        // 知名美股zxw
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=7&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=b:MK0001&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#famous_usstock tbody",
            link: "//quote.eastmoney.com/us/{{code}}.html"
        })

        // 指数成分股涨幅榜zxw
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=6&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=b:MK0141&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#index_constituents tbody",
            link: "//quote.eastmoney.com/hk/{{code}}.html"
        })

        // 港股涨幅榜zxw
        renderRankList({
            url: instance.baseUrl + "/api/qt/clist/get?pn=1&pz=6&po=1&np=1&ut=" + instance.ut + "&fltt=2&invt=2&fid=f3&fs=m:116&fields=f1,f2,f3,f4,f5,f12,f13,f14,f152",
            dom: "#hkstock_rank tbody",
            link: "//quote.eastmoney.com/hk/{{code}}.html"
        })


        // 加载图片
        $("#picDiv img").each(function (idx, img) {
            var cmd = $(img).data("cmd");
            $.imgLoader({
                url: "//webquotepic.eastmoney.com/GetPic.aspx?imageType=RS4UI&token=44c9d251add88e27b65ed86506f6e5da",
                data: { id: cmd },
                success: function (item) {
                    var $new = $(item).data("cmd", cmd);
                    $(img).replaceWith($new);
                }
            });
        });

        //港股自选股 zxw
        instance.initMyHKFavorite();
    }
    var imgevt = instance.bindChartImgEvent();
    function init() {
        //海外直播
        liveBroadcast();

        instance.loadQuoteData({
            ajax: {
                url: instance.baseUrl + '/api/qt/stock/get?secid=' + stockEnity.fullcode + "&ut=" + instance.ut + "&fields=f43,f44,f45,f46,f47,f59,f60,f152,f169,f86,f170,f171,f118",
                data: {

                },
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get'
            },
            dataResolver: function (json) {
                var data = json["data"]
                var arr = []
                arr.push(data.f43 == 0 ? '-' : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59))//0最新价
                arr.push(data.f43 == 0 ? '-' : (data.f44 / Math.pow(10, data.f59)).toFixed(data.f59))//1最高价
                arr.push(data.f43 == 0 ? '-' : (data.f45 / Math.pow(10, data.f59)).toFixed(data.f59))//2最低价
                arr.push(data.f43 == 0 ? '-' : (data.f46 / Math.pow(10, data.f59)).toFixed(data.f59))//3开盘价
                arr.push(data.f43 == 0 ? '-' : data.f47)//4成交量
                arr.push(data.f59)// 5小数位数(f59)
                arr.push((data.f60 / Math.pow(10, data.f59)).toFixed(data.f59))//6昨收价(f60)
                arr.push(data.f152)//7小数位数字段(2)
                arr.push(data.f43 == 0 ? '-' : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))//8涨跌值(f169) 
                arr.push(data.f43 == 0 ? '-' : data.f170)//9涨跌幅(f170) 
                arr.push(common.formatDate(new Date(data.f86 * 1000), 'yyyy-MM-dd HH:mm:ss'))//10行情时间Unix时间戳，单位秒(f86)
                arr.push(data.f43 == 0 ? '-' : data.f171)//11振幅(f171)
                arr.push(data.f118)//12振幅(f118)
                return arr;
            },
            fields: [
                {
                    name: "zxj", num: 0, hasColor: true, NumbericFormat: false, blink: true,
                    comparer: function (data) {
                        return data[8];
                    }
                },
                { name: "zde", num: 8, hasColor: true, blink: true },
                { name: "zdf", num: 9, hasColor: true, template: "{{data=='-'?'-':(data/100).toFixed(2) +'%'}}", blink: true, render: onChangeDataRender },
                {
                    name: "jk", num: 3, hasColor: true,
                    comparer: function (data) {
                        return isNaN(data[3]) || isNaN(data[6]) ? 0 : data[3] - data[6];
                    }
                },
                { name: "zs", num: 6, hasColor: false },
                {
                    name: "zgj", num: 1, hasColor: true,
                    comparer: function (data) {
                        return isNaN(data[1]) || isNaN(data[6]) ? 0 : data[1] - data[6];
                    }
                },
                {
                    name: "zdj", num: 2, hasColor: true,
                    comparer: function (data) {
                        return isNaN(data[2]) || isNaN(data[6]) ? 0 : data[2] - data[6];
                    }
                },
                { name: "zf", num: 11, hasColor: false, template: "{{data=='-'?'-':(data/100).toFixed(2)+'%'}}" },
                { name: "cjl", num: 4, hasColor: false, NumbericFormat: true },
                { name: "stock_time", num: 10 },
                {
                    name: "hqstat", num: 12, hasColor: true,
                    comparer: function (data) { return (data[12] == 0 || data[12] == -1 ? 1 : 0) },
                    render: function ($dom, data, settings) {
                        var css = data == 1 || data == 2 || data == 4 ? 'on red' : 'off ';
                        var str = data == 1 ? "集合竞价" : data == 4 ? "集合竞价" : data == 2 ? "交易中" : data == 3 ? "午间休市" : "已收盘"
                        $dom.html("<b class='" + css + "' title='" + data + "'></b><span class='" + css + "'>" + str + "</span>");
                    }
                }
            ]
        });
        // 世界时间
        new _GlobalTime("worldtime");

        if (stockEnity.area.toLowerCase() != "HK".toLowerCase()) {
            instance.setHotGuba(15);
        }

        imgevt.bindEvent();
        instance.setChart().bindEvent();
        instance.setHotHKGuba(6);

        // h5 js行情图片
        $("#chartimg_select").hide();
        //var noth8 = !+'\v1';
        //if (noth8) {
        //    $("#chartimg_select").hide();
        //} else {
        //    $("#h5_show").click();
        //    instance.setChart().init();
        //};

        refresh();
    }

    init();

    setInterval(function () {
        refresh();
    }, 20 * 1000);
// });