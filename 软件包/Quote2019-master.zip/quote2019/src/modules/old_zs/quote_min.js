var HistoryViews = require('./hisacc');

var gdomain = "http://hqdigi2.eastmoney.com/EM_Quote2010NumericApplication/";
var token = "44c9d251add88e27b65ed86506f6e5da";
var PicR = "http://webquotepic.eastmoney.com/GetPic.aspx?nid={0}.{1}&imageType={2}&token=" + token;
var PicK = "http://hqpick.eastmoney.com/k/";
var PicN = "http://pifm3.eastmoney.com/EM_Finance2014PictureInterface/Index.aspx?id={0}{1}&imageType={2}&token=" + token;
//var PicN = "http://webquoteklinepic.eastmoney.com/GetPic.aspx?token=44c9d251add88e27b65ed86506f6e5da&nid=0.399006&unitWidth=-6&ef=&formula=RSI&type=&imageType=KXL&&0.04516759924739544"
var $x = function (id) { return "string" == typeof id ? document.getElementById(id) : id; };
var baseUrl = 'http://push2.eastmoney.com'
var ut = 'bd1d9ddb04089700cf9c27f6f7426281'
function inArray(el, array) { for (var i = 0, n = array.length; i < n; i++) { if (array[i] === el) { return true; } } return false; }
function unique(array) { var i = 0, n = array.length, ret = []; for (; i < n; i++) { if (!inArray(array[i], ret)) { ret.push(array[i]); } } return ret; }
function ForDight(Dight, How) { rDight = parseFloat(Dight).toFixed(How); if (rDight == "NaN") { rDight = "--"; } return rDight; }
//显示完整时间
function GetFullWeekTime(time) {
    var dt = new Date(Date.parse(time.replace(/-/g, "/")));
    var day = dt.getDay();
    var arr_week = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");
    var week = arr_week[day];
    return time.replace(" ", " " + week + " ");
}

//单位格式化
function NumbericFormat(string) {
    var context = Number(string);
    //var fushu = false;
    if (!isNaN(context)) {
        var item = parseInt(string);
        if ((item > 0 && item < 1e4) || (item < 0 && item > -1e4)) {
            return item;
        } else if ((item > 0 && item < 1e6) || (item < 0 && item > -1e6)) {
            item = item / 10000;
            return item.toFixed(2) + "万";
        } else if ((item > 0 && item < 1e7) || (item < 0 && item > -1e7)) {
            item = item / 10000;
            return item.toFixed(1) + "万";
        } else if ((item > 0 && item < 1e8) || (item < 0 && item > -1e8)) {
            item = item / 10000;
            return item.toFixed(0) + "万";
        } else if ((item > 0 && item < 1e10) || (item < 0 && item > -1e10)) {
            item = item / 1e8;
            return item.toFixed(2) + "亿";
        } else if ((item > 0 && item < 1e11) || (item < 0 && item > -1e11)) {
            item = item / 1e8;
            return item.toFixed(1) + "亿";
        } else if ((item > 0 && item < 1e12) || (item < 0 && item > -1e12)) {
            item = item / 1e8;
            return item.toFixed(0) + "亿";
        } else if ((item > 0 && item < 1e14) || (item < 0 && item > -1e14)) {
            item = item / 1e12;
            return item.toFixed(2) + "万亿";
        } else if ((item > 0 && item < 1e15) || (item < 0 && item > -1e15)) {
            item = item / 1e12;
            return item.toFixed(1) + "万亿";
        } else if ((item > 0 && item < 1e16) || (item < 0 && item > -1e16)) {
            item = item / 1e12;
            return item.toFixed(0) + "万亿";
        } else {
            return item;
        }
    }
    return context.toString();
}

//时间格式化处理
function dateFtt(fmt, date) { //author: meizz   
    var o = {
        "M+": date.getMonth() + 1,                 //月份   
        "d+": date.getDate(),                    //日   
        "h+": date.getHours(),                   //小时   
        "m+": date.getMinutes(),                 //分   
        "s+": date.getSeconds(),                 //秒   
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度   
        "S": date.getMilliseconds()             //毫秒   
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

//刷新本页
function prefresh() {
    window.location.reload();
}

//涨跌标记
function udt(vs) {
    if (vs > 0) {
        return "↑";
    } else if (vs < 0) {
        return "↓";
    } else { return ""; }
}

//涨跌颜色
function udcls(vsa, vsb) {
    vsa = vsa.replace("%", "");
    if (arguments.length == 1) {
        if (vsa > 0) { return "red"; } else if (vsa < 0) { return "green"; } else { return ""; }
    } else {
        vsb = vsb.replace("%", "");
        if (vsa - vsb > 0) {
            return "red";
        } else if (vsa - vsb < 0) {
            return "green";
        } else {
            return "";
        }
    }
}

//涨跌颜色
function udc(vsa, vsb) {
    vsa = vsa.replace("%", "");
    if (vsb == "" || vsb == null || vsb == "undefined") {
        if (vsa > 0) {
            return "#f00";
        } else if (vsa < 0) {
            return "#090";
        } else {
            return "";
        }
    } else {
        vsb = vsb.replace("%", "");
        if (vsa - vsb > 0) {
            return "#f00";
        } else if (vsa - vsb < 0) {
            return "#090";
        } else {
            return "";
        }
    }
}

//涨跌颜色
function udcolor(vsa, vsb) {
    vsa = vsa.replace("%", "");
    if (vsb == "" || vsb == null || vsb == "undefined") {
        if (vsa > 0) {
            return "color:#f00";
        } else if (vsa < 0) {
            return "color:#090";
        } else {
            return "";
        }
    } else {
        vsb = vsb.replace("%", "");
        if (vsa - vsb > 0) {
            return "color:#f00";
        } else if (vsa - vsb < 0) {
            return "color:#090";
        } else {
            return "";
        }
    }
}

//数字涨跌
function rendercolor(a,b) {
    if (a > b) {
        return 'red'
    } else if (a < b) {
        return 'green'
    } else {
        return ''
    }
}

//涨跌平判断
function zdp(Pnum) {
    if (Pnum > 0) {
        return 1;
    } else if (Pnum < 0) {
        return -1;
    } else {
        return 0;
    }
}

//增减标记
function fvc(vs) {
    if (vs == 0 || vs == "") {
        return "";
    } else {
        if (vs > 0) {
            return "+" + vs;
        } else {
            return vs;
        }
    }
}

//数字格式化
function ForDight(Dight, How) {
    rDight = parseFloat(Dight).toFixed(How);
    if (rDight == "NaN") {
        rDight = "--";
    }
    return rDight;
}

//数字格式化
function ForWc(Di) {
    var chu = 1;
    var res = Di;
    if (Di > 0 && Di.length >= 6) {
        chu = 6;
    } if (Di < 0 && Di.length >= 7) {
        chu = 6;
    } if (chu == 6) {
        res = ForDight((Di / 10000), 2) + "万";
    }
    return res;
}

//获取市场
function getmarket(cd) {
    var j = cd.substring(0, 3);
    var i = j.substring(0, 1);
    if (i == "5" || i == "6" || i == "9") {
        return "1";
    } else {
        if (j == "009" || j == "126" || j == "110") {
            return "1";
        } else {
            return "2";
        }
    }
}

//写cookies
function WriteCookie(name, value, hours) {
    var expire = "";
    if (hours != null) {
        expire = new Date((new Date()).getTime() + hours * 3600000);
        expire = "; expires=" + expire.toGMTString() + ";path=/;domain=.eastmoney.com";
    }
    document.cookie = name + "=" + escape(value) + expire;
}

//取cookies
function GetCookie(name) {
    var dc = document.cookie;
    var prefix = name + "=";
    var begin = dc.indexOf("; " + prefix);
    if (begin == -1) {
        begin = dc.indexOf(prefix);
        if (begin != 0) {
            return null;
        };
    } else {
        begin += 2;
    }
    var end = document.cookie.indexOf(";", begin);
    if (end == -1) {
        end = dc.length;
    }
    return unescape(dc.substring(begin + prefix.length, end));
}

window.GetCookie = GetCookie


//增加登录逻辑
function myCookie(name) {
	var xarr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
	if (xarr != null)
		return decodeURIComponent(xarr[2]);
	return null;
	
}
function myuserGet() {
    if (myCookie('ut') && myCookie('ct') && myCookie('uidal')) {
        
        //获取加v信息
        var jiav = {vtype:null, state: null, name: ''};
        if (myCookie('vtpst') && myCookie('vtpst') != '|') {
            var jiavarr = GetCookie('vtpst').split('|');
            if( jiavarr.length > 1 ){
                //console.info(typeof jiavarr[0]);
                if (jiavarr[1] == "0" || jiavarr[1] == "3") {
                    switch (jiavarr[0]) {
                        case "301":
                            jiav.vtype = 1;
                            jiav.name = '理财师';
                            break;
                        case "302":
                            jiav.vtype = 2;
                            jiav.name = '非理财师';
                            break;
                        case "303":
                            jiav.vtype = 3;
                            jiav.name = '企业';
                            break;
                        default:
                            break;
                    }
                }

                switch (jiavarr[1]) {
                    case "0":
                        jiav.state = 0; //审核通过
                        break;                        
                    case "1":
                        jiav.state = 11; //审核未通过
                        break;
                    case "2":
                        jiav.state = 12; //审核中
                        break;
                    case "3":
                        jiav.state = 13; //加v用户修改审核
                        break;
                    case "8":
                        jiav.state = 18; //加v用户修改审核
                        break;
                    case "9":
                        jiav.state = 19; //加v用户修改审核
                        break;
                    default:
                        break;
                }
                
                //console.info(jiav);

            }
        }
        
        return {
          id: myCookie('uidal').substring(0,16),
          nick: myCookie('uidal').substring(16),
          jiav: jiav
        };
    }
    return null; 
}

var islogin = myuserGet() ? true: false
// console.log(islogin);




function Getcks(key) {
    var result = document.cookie.match(new RegExp(key + "=([^;]*)"));
    return result != null ? unescape(decodeURI(result[1])) : null;
}

//拉长缩短K线
function picklc() {
    KBd.Change('-');
}

//拉长缩短K线
function picksd() {
    KBd.Change('+');
}

/** 
 * js截取字符串，中英文都能用 
 * @param {string} str: 需要截取的字符串 
 * @param {number} len: 需要截取的长度
 * @param {string} ellipsis: 溢出文字
 * @returns {string} 截取后的字符串
 */
function cutstr(str, len, ellipsis) {
    if (typeof ellipsis != "string") ellipsis = "...";
    var str_length = 0;
    var str_len = 0;
    str_cut = new String();
    for (var i = 0; i < str.length; i++) {
        a = str.charAt(i);
        str_length++;
        if (escape(a).length > 4) {
            //中文字符的长度经编码之后大于4  
            str_length++;
        }
        //str_cut = str_cut.concat(a);
        if (str_length <= len) {
            str_len++;
        }
    }
    //如果给定字符串小于指定长度，则返回源字符串；  
    if (str_length <= len) {
        return str.toString();
    } else {
        return str.substr(0, str_len).concat(ellipsis);
    }
}

var Browser = { ie: /msie/.test(window.navigator.userAgent.toLowerCase()), moz: /gecko/.test(window.navigator.userAgent.toLowerCase()), opera: /opera/.test(window.navigator.userAgent.toLowerCase()), safari: /safari/.test(window.navigator.userAgent.toLowerCase()) };
var Min = new Object(); Min.Loader = {
    load: function (sUrl, sBianMa, fCallback) {
        var _script = document.createElement('script'); _script.setAttribute('charset', sBianMa); _script.setAttribute('type', 'text/javascript'); _script.setAttribute('src', sUrl);
        document.getElementsByTagName('head')[0].appendChild(_script);
        if (Browser.ie) {
            _script.onreadystatechange = function () { if (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') { _script.parentNode.removeChild(_script); fCallback(); } };
        } else if (Browser.moz || Browser.opera) {
            _script.onload = function () { _script.parentNode.removeChild(_script); fCallback(); };
        } else { _script.parentNode.removeChild(_script); fCallback(); }
    }
};

(function () {
    function QaDefault(Code, Market, Market_10, Name, styleid, zjlCode, zdpCode) {
        //代码，市场_12，市场_10，名称，排行对应ID,资金流代码，涨跌平代码,
        _this = this; _this._Code = Code; _this._Market = Market == 2 ? 0 : Market; _this._Market_10 = Market_10; _this._Name = Name; _this.styleid = styleid; _this._zjlCode = zjlCode; _this._zdpCode = zdpCode;
        _this.$ = function (id) { return "string" == typeof id ? document.getElementById(id) : id; };
        _this.sansuoNum = 0; _this.cbian = true; _this.sansuo; _this.tempStatus = {}; _this.ColorStatus = {};
        _this.hongdise = function () {
            var span = [_this.$("price9"), _this.$("km1"), _this.$("km2")];
            for (i = 0; i < 3; i++) {
                _this.ColorStatus[i] = (_this.ColorStatus[i]) ? false : true;
                if (_this.cbian) {
                    if (!_this.ColorStatus[i]) {
                        _this.tempStatus[i] = span[i].style.color; span[i].style.color = "#000000";
                    } else {
                        span[i].style.color = _this.tempStatus[i];
                    }
                }
            }
            _this.sansuoNum++;
            if (_this.sansuoNum > 6) {
                clearInterval(_this.sansuo);
                _this.sansuoNum = 0; _this.tempStatus = {}; _this.ColorStatus = {}; _this.cbian = false;
                _this.$("price9").style.color = ""; _this.$("km1").style.color = ""; _this.$("km2").style.color = "";
                
            }
        };
    };
    QaDefault.prototype = {
        init: function () {
            window.quoteIsFirst = true; window.quoteRefresh = 12000;//行情
            window.zxgIsFirst = true; window.zxgRefresh = 30000; window.zxgDisNum = 6; window.favorsetInterval = 0;//自选股
            window.GetBkphNUM = 1; window.GetBkzj = 1; window.GetLzBk = 1; window.GetKX = 1; window.GetKXMaxID; window.GetRankNUM = 1; window.GetZjlxNUM = 1; window.GetZdpNUM = 1; window.GetGzqhNUM = 1;

            window.GetTimeZoneInfo = false;
            _this.bindPageEvent();
            _this.Gethis();//最近访问
            _this.fullScreenFun();
            //createSWF(_this._Code, _this._Market, _this._Name, 578, 276, 565, 415, "1", "0", "1");
                
        

            //第一次执行我的自选
            // setTimeout(function () { 
            //     console.log('我的自选')
            //     _this.GetFavorList(_this._Code); 

            // }, 100);

            //我的自选自刷
            _this.GetControlMyzixuan();


            setTimeout(function () {
                loadBkph("_BKHY", "-1");
                loadBkph("_BKHY", "1");
                loadBkph("_BKGN", "-1");
                loadBkph("_BKGN", "1");
                loadBkzj("_BKHY");
                loadBkzj("_BKGN");
                LoadLzbk();
                LoadZyzs();
                Loadgzqh();
                loadRank(_this.styleid);
                loadKuaiXun();
                loadhyzjlx(); //行业资金流向图
                yjbgList(); //研究报告
            }, 200);
            setInterval(function () {
                LoadLzbk();
                LoadZyzs();
                Loadgzqh();
                loadRank(_this.styleid);
            }, 10000);
            setInterval(function () {
                loadBkph("_BKHY", "-1");
                loadBkph("_BKHY", "1");
                loadBkph("_BKGN", "-1");
                loadBkph("_BKGN", "1");
            }, 15000);

            //百度隐藏广告
            if (_this.getQueryStringByName("from") == "BaiduAladdin") {
                $("#tbggiframe").hide();
                $("#ifhqheadad").hide();

                $.ajax({
                    url: "http://emres.dfcfw.com/public/js/aldtg.js",
                    method: "GET",
                    scriptCharset: 'UTF-8',
                    dataType: "script"
                });

            } else {
                $.ajax({
                    url: "http://emres.dfcfw.com/public/js/left.js",
                    method: "GET",
                    scriptCharset: 'UTF-8',
                    dataType: "script"
                });

                $.ajax({
                    url: "http://emres.dfcfw.com/public/js/em_news_fixed_right.js",
                    method: "GET",
                    scriptCharset: 'UTF-8',
                    dataType: "script"
                });
            }
        },
        getQueryStringByName: function (name) {
            var result = location.search.match(new RegExp("[\?\&]" + name + "=([^\&]+)", "i"));
            if (result == null || result.length < 1) {
                return "";
            }
            return result[1];
        },
        bindPageEvent: function () {//页面事件绑定
            _this.DisQuote();
            setInterval(function () { _this.DisQuote(); }, window.quoteRefresh);
            _this.GetTimeZone(); setInterval(function () { _this.GetTimeZone(); _this.UpZjlx() }, 30000);//时间戳 资金流向
            setInterval(function () { _this.UpPic(true); }, 180000);//更新R图和K线
            _this.$("RefPR").onclick = function () { prefresh(); }
            _this.$("refgbauls").onclick = function () {
                var dl = _this.$("gbauls").getElementsByTagName("dl");
                var sedl = GetRandomNum(0, dl.length - 1);
                for (var i = 0; i < dl.length; i++) {
                    if (i == sedl) {
                        if (dl[i].hasChildNodes()) {
                            var dd = dl[i].childNodes;
                            for (var j = 0; j < dd.length; j++) {
                                if (dd[j].hasChildNodes()) {
                                    var ddimg = dd[j].childNodes[0].getElementsByTagName('img')[0];
                                    if (ddimg && !ddimg.getAttribute('src'))
                                        ddimg.setAttribute('src', ddimg.getAttribute('data-value'));
                                }
                            }
                        }
                        dl[i].style.display = "";
                    } else {
                        dl[i].style.display = "none";
                    }
                }
            };
            _this.$("kx_fontsize").onclick = function () {
                //if ($x("flash_box").style.display == "block") {
                //    _this.$("kx_list").className = _this.$("kx_list").className == "kx_list kx_listfls" ? "kx_list kx_fz14 kx_listfls" : "kx_list kx_listfls";
                //} else {
                //    _this.$("kx_list").className = _this.$("kx_list").className == "kx_list" ? "kx_list kx_fz14" : "kx_list";
                //}

                _this.$("kx_list").className = _this.$("kx_list").className == "kx_list" ? "kx_list kx_fz14" : "kx_list";
                _this.$("kx_fontsize").innerHTML = _this.$("kx_list").className.indexOf("kx_fz14") > 0 ? "小字-" : "大字+";
            };
            _this.$("kx_refresh").onclick = function () { loadKuaiXun(); };
            _this.$("kx_auto").onclick = function () {
                if (_this.$("kx_auto").className == "kx_auto kx_autoing") {
                    _this.$("kx_auto").className = "kx_auto"; clearInterval(window.kxst);
                }
                else {
                    _this.$("kx_auto").className = "kx_auto kx_autoing"; loadKuaiXun();
                }
            };
            _this.$('lookVote0').onclick = function () { window.open('http://vote.eastmoney.com/vote_look1.asp?action=look'); };
            _this.$('lookVote1').onclick = function () { window.open('http://vote.eastmoney.com/vote_look1.asp?action=look'); };
            _this.$('lookVote2').onclick = function () { window.open('http://vote.eastmoney.com/vote_look2.asp?action=look'); };
            _this.$("hq_cr_close").onclick = function () { _this.$("hq_cr_tips").style.display = "none"; WriteCookie("emhq_cr", "1", 12); };
            _this.$("hq_cr_b").onmouseover = function () { _this.$("hq_cr_tips").style.display = "block"; };
            _this.$("hq_cr_b").onmouseout = function () { _this.$("hq_cr_tips").style.display = "none"; };
            // _this.$('zjlx_bars').onclick = function () {
            //     var s1 = _this.$("zjlx_bar").value; var s = escape(s1);
            //     if (s1 == "输代码、名称或拼音" || s1 == "" || isNaN(parseInt(s1)) || s1.length != 6) { alert("请输入所查询股票的代码！"); return false; } else { var url = "http://data.eastmoney.com/rzrq/detail/" + s1 + ".html"; window.open(url); }
            // };
            // var zz = new StockSuggest("zjlx_bar", {
            //     text: "输代码、名称或拼音",
            //     type: "ABSTOCK",
            //     autoSubmit: false,
            //     width: 190,
            //     header: ["选项", "代码", "名称", "类型"],
            //     body: [-1, 1, 4, -2],
            //     callback: function (ag) {
            //         var url = "http://data.eastmoney.com/rzrq/detail/" + ag.code + ".html";
            //         window.open(url);
            //     }
            // });
            var newsuggest = new suggest2017({ //新建实例
                width: 300,
                placeholder: '输代码、名称或拼音',
                showblank:false,
                offset:{
                    left:-140,
                    top:0
                },
                stockcount: 10,
                showstocklink: false,
                modules: ['stock'],
                filter: {
                    securitytype: '1,2,3,4'
                },
                onConfirmStock : function(result){ //事件
                    window.open('http://data.eastmoney.com/rzrq/detail/' + result.stock.Code + '.html')
                    return false;
                },
                onSubmit : function(result){ //事件
                    if (result.key == '') {
                        return false
                    }
                    window.open('http://data.eastmoney.com/rzrq/detail/' + result.stock.Code + '.html')
                    return false;
                },                
                inputid: 'zjlx_bar' //参数部分
            })

        },
        Bian: function (dt) {//是否在开盘期间
            var res = false;
            var hs = dt.getHours();
            var ms = dt.getMinutes();
            if (hs >= 9 && hs <= 11) {
                res = true;
                if ((hs == 11) && ms >= 30)
                    res = false;
            }
            if (hs >= 13 && hs < 15) { res = true; }
            return res;
        },
        PanQian: function (dt) {//是否在盘前期间
            var res = false;
            var hs = dt.getHours();
            var ms = dt.getMinutes();
            if (hs == 9) { if ((ms >= 14) && ms < 29) { res = true; } }
            return res;
        },
        GetTimeZone: function () {//系统时间
            Min.Loader.load("http://quote.eastmoney.com/timezone.js?" + formatm(), 'utf-8', function () {
                var dt = new Date(window["bjTime"] * 1000);
                window.GetTimeZoneInfo = _this.Bian(dt);
                var Notify = window["Notify"];
                //_this.setPicrTab(dt);
                if (Notify != "undefined" && Notify != "" && !window.Notifyed && _this.IsNotify) {
                    if (Notify == 0) { clearInterval(window.NotifyS); } else { _this.NotifyPage(Notify * 60000); }
                }
            });
        },
        NotifyPage: function (num) {//通知页面刷新
            window.Notifyed = true; window.NotifyS = setInterval("prefresh()", num);
        },
        //控制我的自选自刷问题：
        GetControlMyzixuan: function () {
            jQuery.ajax({
                url: baseUrl + "/api/qt/stock/get?secid=" + _this._Market + "." + _this._Code + '&ut=' + ut +'&fields=f118&invt=2',
                dataType: 'jsonp',
                jsonp: 'cb',
                scriptCharset: "utf-8",
                success: function (res) {
                    // console.log('外加方法：')
                    // console.log(res);

                    //增加判断 国内登录我的自选刷新
                    if(res) {
                        _this.GetFavorList(_this._Code, res.lt, islogin); 
                    }


                }
            })

        },
        GetFavorList: function (thisCode, lt, islogin) {
            // console.log('执行 GetFavorList');
            var iscks = false;
            if (GetCookie("pi")) {
                var gcks = Getcks("pi");
                if (gcks.split(';').length >= 3) {
                    var name = gcks.split(';')[2];
                    if (/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) { iscks = true; }
                    else {
                        Min.Loader.load("https://myfavor1.eastmoney.com/mystock?f=gsaandcheck&sc=" + _this._Code + "|0" + _this._Market + "|01&c=13&var=asl&rt=" + formatm(), "utf-8", function () {
                            var allstocklist = "";
                            if (asl.result == "1") {
                                var sl = asl.data.list.split(',');
                                for (var i = 0; i < sl.length; i++) {
                                    var item = sl[i].split('|');
                                    if (i == sl.length - 1) {
                                        allstocklist += item[0];
                                    } else {
                                        allstocklist += item[0] + ",";
                                    }
                                }
                            }
                            _this.FavorPad(allstocklist, thisCode, lt, islogin);
                        });
                    }
                }
                else {
                    iscks = true;
                }
            } else {
                iscks = true;
            }
            if (iscks) {
                var emhq_stock = GetCookie("emhq_stock");
                if (emhq_stock) {
                    _this.FavorPad(emhq_stock, thisCode);
                } else {
                    _this.FavorPad("", thisCode);
                }
            }
        },
        FavorPad: function (initlist, thisCode, lt, islogin) {
            var arr = new Array();
            initlist += ",000001,000002,000004,000005,000006,000008,000009,000010,000011,000012,000014,000016,000017,000018";
            var list = unique(initlist.split(","));
            for (var k = 0; k < list.length; k++) {
                if (list[k] != "") {
                    var code = list[k];
                    var market = getmarket(code)==1?1:0;
                    if (thisCode != code) {
                        arr.push(market + '.' +code);
                    }
                }
            }
            _this.FavorDis(arr);
            window.zxgIsFirst = true;

            //判断若是国内登录 刷新我的自选列表
            if(lt !== 2 && islogin) {
                 window.favorsetInterval = setInterval(function () {
                    //   console.log('刷新我的自选列表')
                      _this.FavorDis(arr); 
                }, window.zxgRefresh);
            }
            
        },
        //自选股
        FavorDis: function (arr) {
            if (window.GetTimeZoneInfo || window.zxgIsFirst) {
                var res = arr.slice(0, window.zxgDisNum);
                var codestr = res.join(",")
                var url = baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2'
                $.ajax({
                    url: url,
                    dataType: 'jsonp',
                    jsonp: 'cb',
                    Type: 'get',
                    success: function (json) {
                        var list = json.data.diff
                        var htm = ''
                        for (var i = 0; i < list.length; i++) {
                            var color = rendercolor(list[i].f3, 0)
                            var zxj = list[i].f2 == '-' ? list[i].f2 : (list[i].f2 / Math.pow(10, list[i].f1)).toFixed(list[i].f1)
                            var zdf = list[i].f3 == '-' ? '-' : ((list[i].f3 / 100).toFixed(2)+'%')
                            htm += '<tr><td class="nm"><span class="' + color + '"><a href="http://quote.eastmoney.com/' + list[i].f12 + '.html" target="_blank">' + list[i].f14 + '</a></span></td><td class="' + color + '">' + zxj+'</td><td class="'+color+'">'+zdf+'</td></tr>'
                        }

                        $("#favorlist").html(htm)
                    }
                })
                window.zxgIsFirst = false;
            }
        },
        Gethis: function () {
            var arg = { def: "", set: "f-0-" + _this._Code + "-" + _this._Name }; var HV = new HistoryViews("historyest", arg);
        },
        Setudclass: function (zd) {
            var hqcr = _this.$("arrowud").getAttribute("xid");
            if (zd > 0) {
                _this.$("arrowud").className = hqcr == "1" ? "cr red" : "red";
                _this.$("arrow-find").className = "xp2 up-arrow";
            } else if (zd < 0) {
                _this.$("arrowud").className = hqcr == "1" ? "cr green" : "green";
                _this.$("arrow-find").className = "xp2 down-arrow";
            } else {
                _this.$("arrowud").className = hqcr == "1" ? "cr" : "";
                _this.$("arrow-find").className = "";
            }
        },
        DisQuote: function () {
            if (window.GetTimeZoneInfo || window.quoteIsFirst) {

                jQuery.ajax({
                    url: baseUrl + "/api/qt/stock/get?secid=" + _this._Market + "." + _this._Code + '&ut=' + ut +'&fields=f118,f107,f57,f58,f59,f152,f43,f169,f170,f46,f60,f44,f45,f168,f50,f47,f48,f49,f46,f169,f161,f117,f85,f47,f48,f163,f171,f113,f114,f115,f86,f117,f85,f119,f120,f121,f122&invt=2',
                    dataType: 'jsonp',
                    jsonp: 'cb',
                    scriptCharset: "utf-8",
                    success: function (res) {
                        // console.log("基本数据>>", res)
                        var data = res.data
                        getHqStat(data.f118)

                        var zxj = data.f43 == '-' ? data.f43 : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var zd = (data.f169 == "-" ? "-" : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))
                        var zdf = data.f43 == '-' ? '-' : (data.f170 / 100).toFixed(2)
                        var time = dateFtt("yyyy-MM-dd hh:mm:ss", new Date(data.f86 * 1000))
                        var jkj = data.f46 == '-' ? data.f46 : (data.f46 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var zgj = data.f44 == '-' ? data.f44 : (data.f44 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var zdj = data.f45 == '-' ? data.f45 : (data.f45 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var zsj = data.f60 == '-' ? data.f60 : (data.f60 / Math.pow(10, data.f59)).toFixed(data.f59)
                        var kpj = data.f46 == '-' ? data.f46 : (data.f46 / Math.pow(10, data.f59)).toFixed(data.f59)

                        document.title = (data.f58 + " " + zxj + " " + zd + "(" + zdf + "%) _ 股票行情 _ 东方财富网");
                        $("#price9").text(zxj).addClass(rendercolor(data.f43, data.f60)) //最新价
                        $("#arrow-find").addClass(data.f43 > data.f60 ? 'up-arrow' :'down-arrow')
                        $("#km1").text(zd).addClass(rendercolor(data.f43, data.f60));//涨跌
                        $("#km2").text(zdf + "%").addClass(rendercolor(data.f43, data.f60));//涨幅
                        $("#hqday").text("（" + GetFullWeekTime(time) + "）");//时间
                        $("#gt1").text(jkj).addClass(rendercolor(data.f46, data.f60)) //今开
                        $("#gt2").text(zgj).addClass(rendercolor(data.f44, data.f60)) //最高
                        $("#gt3").text(zdf + '%').addClass(rendercolor(data.f43, data.f60)) //涨幅
                        $("#gt4").text((data.f168 / 100).toFixed(2) + '%') //换手
                        $("#gt5").text(data.f47 == 0 ? '-' : (NumbericFormat(data.f47) + '手'));//成交量
                        $("#gt7").text(zsj) //昨收
                        $("#gt8").text(zdj).addClass(rendercolor(data.f45, data.f60)) //最低
                        $("#gt9").text(zd).addClass(rendercolor(data.f43, data.f60)) //涨跌
                        $("#gt10").text((data.f171 / 100).toFixed(2) + '%') //振幅
                        $("#gt11").text(data.f48 == '-' ? '-' : (NumbericFormat(data.f48) + "元"))//成交額

                        $("#rgt1").text(zxj).addClass(rendercolor(data.f43, data.f60)) //最新价
                        $("#rgt2").text(kpj).addClass(rendercolor(data.f46, data.f60)) //最新价
                        $("#rgt3").text(zgj).addClass(rendercolor(data.f44, data.f60)) //最高
                        $("#rgt4").text(zdj).addClass(rendercolor(data.f45, data.f60)) //最低
                        $("#rgt5").text(zdf + "%").addClass(rendercolor(data.f43, data.f60));//涨幅
                        $("#rgt6").text(zd).addClass(rendercolor(data.f43, data.f60)) //涨跌
                        $("#rgt7").text(data.f47 == 0?'-': (NumbericFormat(data.f47) +'手'));//成交量
                        $("#rgt8").text(data.f48 == '-' ? '-' : (NumbericFormat(data.f48)))//成交額
                        $("#rgt9").text((data.f168 / 100).toFixed(2) + '%') //换手
                        $("#rgt10").text(data.f117 == '-' ? '-' : (NumbericFormat(data.f117)))//流通市值
                        $("#rgt11").text(data.f161 == '-' ? '-' : fmtdig(data.f161, "手"))//内盘
                        $("#rgt12").text(data.f49 == '-' ? '-' : fmtdig(data.f49, "手"))//外盘
                        $("#rgt13").text((data.f171 / 100).toFixed(2) + '%') //振幅

                        $("#rgt17").text((data.f119 == '-' ? '-' : (data.f119 / 100).toFixed(2)) + "%").addClass(rendercolor(data.f119, 0));//5涨幅
                        $("#rgt18").text((data.f120 == '-' ? '-' : (data.f120 / 100).toFixed(2)) + "%").addClass(rendercolor(data.f120, 0));//20涨幅
                        $("#rgt19").text((data.f121 == '-' ? '-' : (data.f121 / 100).toFixed(2)) + "%").addClass(rendercolor(data.f121, 0));//30涨幅
                        $("#rgt20").text((data.f122 == '-' ? '-' : (data.f122 / 100).toFixed(2)) + "%").addClass(rendercolor(data.f122, 0));//今年涨幅
                        $("#rgt14").text(data.f113 + '家').addClass('red')
                        $("#rgt15").text(data.f114 + '家').addClass('green')
                        $("#rgt16").text(data.f115 + '家') 

                        _this.GetFbFj()


                        var fullcode = _this._Market + "." + _this._Code
                        if (fullcode == '0.399006' || fullcode == '0.399005') { // 创业板指 中小板指
                            _this.showzs(fullcode)
                        } else {
                            if (data.f107 == 1) {
                                _this.showzs('1.000001') //显示上证成指
                            } else {
                                _this.showzs('0.399001')//显示深证指数
                            }
                        }

                        if (data.f107 == 1) {
                            _this.showzsb('0.399001')//显示深证指数
                        } else {
                            _this.showzsb('1.000001') //显示上证成指
                        }


                    }
                });
                _this.sansuo = setInterval(_this.hongdise, 300);
                window.quoteIsFirst = false;
            }
        }, 

        
        //获取单个指数涨跌
        showzsb: function (zscode) {
            var url = baseUrl + "/api/qt/stock/get?secid=" + zscode + '&ut=' + ut + '&fields=f57,f58,f59,f107,f43,f169,f170,f135,f136,f137,f193,f138,f139,f140,f194,f141,f142,f143,f195,f144,f145,f146,f196,f147,f148,f149,f197&invt=2'
            $.ajax({
                url: url,
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get',
                success: function (json) {
                    var data = json.data
                    var zxj = data.f43 == '-' ? data.f43 : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59)
                    var zd = (data.f169 == "-" ? "-" : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))
                    var zdf = data.f43 == '-' ? '-' :( (data.f170 / 100).toFixed(2) + '%')
                    var str1 = "<a href=\"http://quote.eastmoney.com/zs" + data.f57 + ".html\" target=\"_blank\">" + data.f58 + "A股行情</a>"
                    var str2 = zxj + "&nbsp;&nbsp;" + zd + "&nbsp;&nbsp;" + zdf;
                    $("#rstocka").html(str1);
                    $("#rstockb").html(str2).addClass(rendercolor(data.f170, 0));
                }
            })

        },

        //获取资金流
        showzs: function (zscode) {
            var url = baseUrl + "/api/qt/stock/get?secid=" + zscode + '&ut=' + ut + '&fields=f57,f58,f59,f107,f43,f169,f170,f135,f136,f137,f193,f138,f139,f140,f194,f141,f142,f143,f195,f144,f145,f146,f196,f147,f148,f149,f197&invt=2'
            $.ajax({
                url: url,
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get',
                success: function (json) {
                    var data = json.data
                    //资金流
                    $("#hz_a").text(data.f135 == '-' ? '-' : (NumbericFormat(data.f135) + '元'))
                    $("#hz_b").text(data.f136 == '-' ? '-' : (NumbericFormat(data.f136) + '元'))
                    $("#hz_c").text(data.f137 == '-' ? '-' : (NumbericFormat(Math.abs(data.f137)) + '元')).addClass(rendercolor(data.f137, 0))
                    $("#hz_c_t").text(data.f137 < 0 ? "主力净流出" : "主力净流入");
                    $("#hz_d").text(data.f138 == '-' ? '-' : (NumbericFormat(data.f138)))
                    $("#hz_e").text(data.f139 == '-' ? '-' : (NumbericFormat(data.f139)))
                    $("#hz_f").text(data.f141 == '-' ? '-' : (NumbericFormat(data.f141)))
                    $("#hz_g").text(data.f142 == '-' ? '-' : (NumbericFormat(data.f142)))
                    $("#hz_h").text(data.f144 == '-' ? '-' : (NumbericFormat(data.f144)))
                    $("#hz_i").text(data.f145 == '-' ? '-' : (NumbericFormat(data.f145)))
                    $("#hz_j").text(data.f147 == '-' ? '-' : (NumbericFormat(data.f147)))
                    $("#hz_k").text(data.f148 == '-' ? '-' : (NumbericFormat(data.f148)))
                    var _l = [[data.f138 == '-' ? 0 : data.f138, data.f139 == '-' ? 0 : -data.f139], [data.f141 == '-' ? 0 : data.f141, data.f142 == '-' ? 0 : -data.f142], [data.f144 == '-' ? '0' : data.f144, data.f145 == '-' ? '0' : -data.f145], [data.f147 == '-' ? 0 : data.f147, data.f148 == '-' ? 0 : -data.f148]]
                    if (_l[0][0] != '-') {
                        ZjlxCek(_l)
                    }   

                    //var zxj = data.f43 == '-' ? data.f43 : (data.f43 / Math.pow(10, data.f59)).toFixed(data.f59)
                    //var zd = (data.f169 == "-" ? "-" : (data.f169 / Math.pow(10, data.f59)).toFixed(data.f59))
                    //var zdf = data.f43 == '-' ? '-' :( (data.f170 / 100).toFixed(2) + '%')
                    //var str1 = "<a href=\"http://quote.eastmoney.com/zs" + data.f57 + ".html\" target=\"_blank\">" + data.f58 + "A股行情</a>"
                    //var str2 = zxj + "&nbsp;&nbsp;" + zd + "&nbsp;&nbsp;" + zdf;
                    //$("#rstocka").html(str1);
                    //$("#rstockb").html(str2).addClass(rendercolor(data.f170, 0));

                    //var fullcode = _this._Market + "." + _this._Code
                    //if (fullcode == '0.399006' || fullcode == '0.399005') {

                    //} else {
                       
                    //}
                }
            })
        },

        GetFbFj: function () {
            var _url = baseUrl + "/api/qt/stock/details/get?secid=" + _this._Market + "." + _this._Code + "&ut=" + ut + "&fields1=f1,f2,f3,f4&fields2=f51,f52,f53,f54,f55&pos=-13&invt=2"
            $.ajax({
                url: _url,
                dataType: 'jsonp',
                jsonp: 'cb',
                Type: 'get',
                success: function (json) {
                    var data = json.data
                    if (!data.details.length || !data.prePrice) return;
                    var list = [];
                    var details = data.details
                    for (var i = 0; i < details.length; i++) {
                        if (i > 0) {
                            var itemslast = details[i - 1].split(",")
                            var items = details[i].split(",");
                            var dir = (items[1] > itemslast[1] ? "↑" : items[1] == itemslast[1] ? " " : "↓")
                            var listitem = {
                                time: items[0],
                                close: items[1],
                                closeCss: rendercolor(items[1], data.prePrice),
                                volumn: items[2],
                                dir: dir,
                                volumnCss: items[4] == 0 ? lastcolor : (items[4] == 2 ? 'red' : 'green'),
                                arrowcolor: items[1] > itemslast[1] ? "red" : items[1] == itemslast[1] ? " " : "green"
                            }
                            list.push(listitem);
                            var lastcolor = listitem.volumnCss
                        }
                    }
                    list = list.reverse()
                    var htm = ''
                    for (var i = 0; i < list.length; i++) {
                        htm += '<tr><td class="nm">' + list[i].time + '</td><td class="' + list[i].closeCss + '">' + list[i].close + '</td><td class="' + list[i].volumnCss + '">' + list[i].volumn + list[i].dir +'</td></tr>' 
                    }
                    $("#fblist").html(htm)
                }
            });
        },
        UpZjlx: function () {
            RefZjlx(_this._zjlCode)
        },
        UpPic: function (refk, pq) {//更新图 (refk是否需要更新K图，是否为盘前图)
            var pqtit = _this.$("tab_picr").getElementsByTagName("span");
            for (var i = 0; i < pqtit.length; i++) {
                pqtit[i].className = "";
            }
            //if (pq) {
            //    pqtit[0].className = "cur";
            //    _this.$("picr").src = PicR.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "r") + "&rt=" + formatm();
            //} else {
            pqtit[0].className = "cur";
            _this.$("picr").src = PicR.replace("{0}", _this._Market).replace("{1}", _this._Code).replace("{2}", "r") + "&rt=" + formatm();
            //}
            if (refk) {
                if (_this.Lstng == "0") {
                    _this.$("pick").src = "http://hqres.eastmoney.com/EMQuote_Lib/img/picknotfund.gif?1";
                } else {
                    var src = $("#pick").attr("src").split("&&")[0] + '&&' + new Date().getTime()
                    _this.$("pick").src = src
                    //_this.$("pick").src = PicN.replace("{0}", _this._Code).replace("{1}", _this._Market).replace("{2}", "KXL") + "&rt=" + formatm();
                }
            }
        },
        hqcr: function (hq_cr_type, _hq_cr_time, hq_cr_cnt) {
            var hq_cr_time = _hq_cr_time.length > 5 ? _hq_cr_time.substring(16, 11) : "-";
            if (hq_cr_type == "8" || hq_cr_type == "9" || hq_cr_type == "10" || hq_cr_type == "11") {
                _this.$("hq_cr").style.display = "block";
                //_this.$("hq_cr_time").innerHTML = hq_cr_time == "-" ? "暂停交易" : "暂停交易至" + hq_cr_time;
                if (hq_cr_type == "8" || hq_cr_type == "10") { _this.$("hq_cr_time").innerHTML = "暂停交易15分钟"; } else { _this.$("hq_cr_time").innerHTML = "暂停交易至15:00"; }
                _this.$("arrowud").setAttribute("xid", "1"); _this.$("arrowud").className = _this.$("arrowud").className.indexOf("cr") == -1 ? "cr " + _this.$("arrowud").className : _this.$("arrowud").className;
                switch (hq_cr_type) {
                    case "8": _this.$("hq_cr_type").innerHTML = "5%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgr"; break;
                    case "9": _this.$("hq_cr_type").innerHTML = "7%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgr"; break;
                    case "10": _this.$("hq_cr_type").innerHTML = "-5%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgg"; break;
                    case "11": _this.$("hq_cr_type").innerHTML = "-7%熔断"; _this.$("hq_cr_type").className = "hq_cr_a bgg"; break;
                }
                var _rdContent = "";
                switch (hq_cr_cnt.toLowerCase()) {
                    case "aa1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "aa2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "aa3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，于9：30起暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "aa4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，于9：30起暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ab1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ab2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ab3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ab4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ac4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ad1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ad2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ad3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ad4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，暂停交易至15：00。熔断期间仅接受撤销申报，不接受其他申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ba1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ba2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "ba3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ba4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "bb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，11:30前未完成的15分钟指数熔断，延续至13:00后继续进行，直至届满。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "bb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，于9：30起暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易至14：57。熔断期间您可以继续申报，也可以撤销申报。熔断结束后进入3分钟的尾盘集合竞价。";
                        break;
                    case "bc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易至14：57。熔断期间您可以继续申报，也可以撤销申报。熔断结束后进入3分钟的尾盘集合竞价。";
                        break;
                    case "bc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "bd4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "be1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "be2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "be3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "be4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，暂停交易至15：00。熔断期间您可以继续申报，也可以撤销申报。当日不再进行集合竞价撮合成交。";
                        break;
                    case "ca1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "ca2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "ca3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "ca4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间（熔断发生在11:15-11:18之间，下午开盘直接进入3分钟集合竞价），期间接受指令申报和撤销。";
                        break;
                    case "cb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间（熔断发生在11:15-11:18之间，下午开盘直接进入3分钟集合竞价），期间接受指令申报和撤销。";
                        break;
                    case "cb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定相关合约收市前15分钟内触发5%阈值，暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定相关合约收市前15分钟内触发5%阈值，暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "cc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，相关合约暂停交易至当日收市。熔断期间暂停交易，不接受指令申报和撤销。";
                        break;
                    case "taa1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "taa2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "taa3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "taa4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tab1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tab2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tab3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tab4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tac4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据上交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tba1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tba2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，于9：30起暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tba3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tba4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tbb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，暂停交易15分钟。熔断期间您可以继续申报，也可以撤销申报。熔断结束后，您可以继续正常交易。";
                        break;
                    case "tbb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tbc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据深交所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tca1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tca2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约于9：30起暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tca3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tca4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tcb1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tcb2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，相关合约暂停交易12分钟。熔断期间暂停交易，不接受指令申报和撤销。熔断结束后进入3分钟集合竞价指令申报时间，期间接受指令申报和撤销。";
                        break;
                    case "tcb3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tcb4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间不接受指令申报和撤销；熔断结束后，您可正常交易。";
                        break;
                    case "tcc1":
                        _rdContent = "沪深300指数上涨触及5%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tcc2":
                        _rdContent = "沪深300指数下跌触及5%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tcc3":
                        _rdContent = "沪深300指数上涨触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                    case "tcc4":
                        _rdContent = "沪深300指数下跌触及7%熔断阈值，根据中金所规定，交易日为股指期货合约交割日的，当日指数熔断时间跨越11:30的，于当日13:00起恢复交易；当日13:00至15:00期间，不实施指数熔断；熔断期间您可以继续申报，也可以撤销申报；熔断结束后，您可正常交易。";
                        break;
                }
                var cookies_cr = GetCookie("emhq_cr");
                _this.$("hq_cr_cnt").innerHTML = _rdContent;
                if (_rdContent == "") { _this.$("hq_cr_tips").style.display = "none"; _this.$("hq_cr_b").style.display = "none"; }
                if ((cookies_cr == "" || cookies_cr == null) && _rdContent != "") { _this.$("hq_cr_tips").style.display = "block"; _this.$("hq_cr_b").style.display = "block"; }
            } else {
                _this.$("hq_cr").style.display = "none"; _this.$("hq_cr_type").className = "hq_cr_a"; _this.$("arrowud").setAttribute("xid", "0"); _this.$("arrowud").className = _this.$("arrowud").className.replace("cr", "");
            }
        },
        //全屏的方法
        fullScreenFun: function () {
            // ie9以下隐藏全屏按钮
            if (document.all && !document.addEventListener) {
                $(".fullScreenBtn").hide();
                window.location.hash = "";
            }
            var id = _this._Market_10 + "." + _this._Code
            var url = "//quote.eastmoney.com/basic/full.html?mcid=" + id + "&type=r";
            var $context = $('<div class="fs-wrapper"><div class= "mark-box"></div><div class="full-box"><span class="full-close">×</span><iframe src = "' + url + '" style="height:98%;width:99%"></iframe></div ></div>');
            $(".fullScreenBtn").click(function () {
                $("body").append($context)
                $(".full-close").click(function () {
                    $($context).remove()
                    window.location.hash = "";
                })
            });
            if (location.href.indexOf("#fullScreenChart") > 0) {
                $(".fullScreenBtn").trigger("click");
            }
        }
    };
    window.QaDefault = QaDefault;
})();


//行业板块涨跌幅  zxw
function loadBkph(type, sortType) {
    var url = baseUrl + '/api/qt/clist/get?pi=0&pz=5&po=' + (sortType == -1 ? 1 : 0) + "&ut=" + ut + '&fs=m:90+t:' + (type == '_BKHY' ? 2 : 3) + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152,' + (sortType == '-1' ? 'f128':'f207')+'&invt=2'
    $.ajax({
        type: "GET",
        url: url,
        data: null,
        dataType: 'jsonp',
        jsonp: 'cb',
        success: function (res) {
            //console.log("行业涨跌幅", res.data.diff)
            var item = res.data.diff
            var html = "";
            for (var i in item) {
                var color = item[i].f3 > 0 ? "red" : "green";
                var market = sortType == '-1' ? (item[i].f141 == 1 ? "sh" : "sz"):(item[i].f209 == 1 ? "sh" : "sz");
                var name = sortType == '-1' ? item[i].f128 : item[i].f207
                var code = sortType == '-1' ? item[i].f140 : item[i].f208
                html += '<tr><td><a href="http://quote.eastmoney.com/center/list.html#28002' + item[i].f12.slice(3) + '.html" target="_blank">' + item[i].f14 + '</a></td>' +
                    '<td class="' + color + '">' + (item[i].f3=='-'?'-':(item[i].f3 / 100).toFixed(2) + '%') + '</td>' +
                    '<td><a href="http://quote.eastmoney.com/' + market + code + '.html" target="_blank">' + name + '</a></td></tr>';
            }
            if (type == "_BKHY") {
                if (sortType == "-1") {
                    $("#cnt_hyzfb_list").html(html);
                } else {
                    $("#cnt_hydfb_list").html(html);
                }
            } else {
                if (sortType == "-1") {
                    $("#cnt_gnzfb_list").html(html);
                } else {
                    $("#cnt_gndfb_list").html(html);
                }
            }
        }
    })
}

function loadBkzj(type) {
    var url = baseUrl + '/api/qt/clist/get?pi=0&pz=5&po=1&ut=' + ut + '&fs=m:90+t:' + (type == '_BKHY' ? 2 : 3) + '&fid=f62&fields=f1,f2,f3,f12,f13,f14,f62,f152,f128,f204&invt=2'
    $.ajax({
        type: "GET",
        url: url,
        data: null,
        dataType: 'jsonp',
        jsonp: 'cb',
        success: function (res) {
            //console.log(url)
            //console.log("行业资金", res.data.diff)
            var item = res.data.diff
            var html = "";
            for (var i in item) {
                var color = item[i].f62 > 0 ? "red" : "green";
                html += '<tr><td><a href="http://quote.eastmoney.com/center/list.html#28002' + item[i].f12.slice(3) + '.html" target="_blank">' + item[i].f14 + '</a></td>' +
                    '<td class="' + color + '">' + (item[i].f62 == '-' ? '-' : NumbericFormat(item[i].f62))  + '</td>' +
                    '<td><a href="http://quote.eastmoney.com/' + item[i].f205 + '.html" target="_blank">' + item[i].f204 + '</a></td></tr>';
            }
            if (type == "_BKHY") {
                $("#hyzjlpy").html(html);
            } else {
                $("#gnzjlpy").html(html);
            }
        }
    })
}

function _loadBkzj() {
    if (window.GetTimeZoneInfo == true || window.GetBkzj == 1) {
        jQuery.ajax({
            url: "http://quote.eastmoney.com/hq2data/bk/data/indexbkzj.js",
            dataType: "jsonp",
            scriptCharset: "gb2312",
            contentType: 'application/x-javascript',
            jsonpCallback: "callbackbkzj",
            success: function (json) {
                var htmlhy = [];
                for (var i = 0; i < json.hy.length; i++) {
                    var item = json.hy[i].split(",");
                    var marketcode = item[4].substring(6) == "1" ? "sh" + item[4].substring(0, 6) : "sz" + item[4].substring(0, 6);
                    var link = "<a href=\"http://quote.eastmoney.com/" + marketcode + ".html\" target=\"_blank\" title='" + item[5] + "'>" + cutstr(item[5], 8) + "</a>";
                    var bkcode = item[1].replace("BK0", "");
                    htmlhy.push('<tr><td><a href="http://quote.eastmoney.com/center/list.html#28002' + bkcode + '_0_2" target="_blank" title="' + item[2] + '">' + cutstr(item[2], 8) + '</a></td><td style="' + udcolor(item[3]) + '">' + fmtdig(item[3] * 10000, "-") + '</td><td>' + link + '</td></tr>');
                }
                removeAllChild("hyzjlpy"); $("#hyzjlpy").append(htmlhy.join(''));

                var htmlgn = [];
                for (var i = 0; i < json.gn.length; i++) {
                    var item = json.gn[i].split(",");
                    var marketcode = item[4].substring(6) == "1" ? "sh" + item[4].substring(0, 6) : "sz" + item[4].substring(0, 6);
                    var link = "<a href=\"http://quote.eastmoney.com/" + marketcode + ".html\" target=\"_blank\" title='" + item[5] + "'>" + cutstr(item[5], 8) + "</a>";
                    var bkcode = item[1].replace("BK0", "");
                    htmlgn.push('<tr><td><a href="http://quote.eastmoney.com/center/list.html#28003' + bkcode + '_0_2" target="_blank" title="' + item[2] + '">' + cutstr(item[2], 8) + '</a></td><td style="' + udcolor(item[3]) + '">' + fmtdig(item[3] * 10000, "-") + '</td><td>' + link + '</td></tr>');
                }
                removeAllChild("gnzjlpy"); $("#gnzjlpy").append(htmlgn.join(''));
            }
        });
        window.GetBkzj = 0;
    }
}

function LoadLzbk() {
    if (window.GetTimeZoneInfo == true || window.GetLzBk == 1) {

        var url = baseUrl + '/api/qt/clist/get?pi=0&pz=1&po=1&ut=' + ut + '&fs=m:90+t:2&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152,f128,f104,f105,f106&invt=2'
        $.ajax({
            url: url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var data = json.data.diff['0']
                var str = "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">" +
                    "<tr><td width=\"248\" align=\"center\"><a href=\"http://quote.eastmoney.com/center/list.html#28002" + data.f12.replace("BK0", "") + "_0_2\" target=\"_blank\">" +
                    "<img src=\"http://webquotepic.eastmoney.com/GetPic.aspx?id=" + data.f12 + "1&imageType=rs&token=44c9d251add88e27b65ed86506f6e5da\" border=\"0\" /></a></td><td>" +
                    "<br><p>上涨家数:<span style=\"color:#f00\">" + data.f104 + "</span></p><p>下跌家数:<span style=\"color:#090\">" + data.f105 + "</span></p><p><b>领涨股票：</b></p><p><a href=\"http://quote.eastmoney.com/" + data.f140 + ".html\" target=\"_blank\">" + data.f128 + "</a></p><p>涨幅:<span style=\"color:" + rendercolor(data.f3, 0) + "\">" + (data.f3 == '-' ? '-' : (data.f3 / 100).toFixed(2) +'%') + "</span></p></td></tr></table>";
                $("#lzbkinfo").html(str)
            }
        })
        window.GetLzBk = 0;
    }
}

// 重要指数 zxw
function LoadZyzs() {
    var url = baseUrl + '/api/qt/ulist.np/get?secids=1.000001,0.399001,0.399005,0.399006,100.hsi&ut=' + ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2'
    $.ajax({
        url: url,
        dataType: 'jsonp',
        jsonp: 'cb',
        Type: 'get',
        success: function (json) {
            var list = json.data.diff
            var htm = ''
            for (var i = 0; i < list.length; i++) {
                var color = rendercolor(list[i].f3, 0)
                var zxj = list[i].f2 == '-' ? list[i].f2 : (list[i].f2 / Math.pow(10, list[i].f1)).toFixed(list[i].f1)
                var zdf = list[i].f3 == '-' ? '-' : ((list[i].f3 / 100).toFixed(2) + '%')
                htm += '<tr><td class="nm"><span class="' + color + '"><a href="' + (list[i].f12 == 'HSI' ? 'http://quote.eastmoney.com/hk/zs110000' : ('http://quote.eastmoney.com/zs'+list[i].f12)) + '.html" target="_blank">' + list[i].f14 + '</a></span></td><td class="' + color + '">' + zxj + '</td><td class="' + color + '">' + zdf + '</td></tr>'
            }

            $("#zyzslist").html(htm)
        }
    })
}

function Loadgzqh() {
    if (window.GetTimeZoneInfo == true || window.GetGzqhNUM == 1) {
        var codeList = ['8.040120', '8.040121', '8.060120', '8.060121', '8.070120', '8.070121',]
        var codestr = codeList.join(',')
        var url = baseUrl + '/api/qt/ulist.np/get?secids=' + codestr + "&ut=" + ut + '&fid=f3&fields=f1,f2,f3,f12,f13,f14,f152&invt=2'
        $.ajax({
            url: url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                var list = json.data.diff
                var htm = ''
                for (var i = 0; i < list.length; i++) {
                    var gzname = list[i].f14.replace("连续", "");
                    var gzcode = gzname.replace("当月", "DYLX").replace("下月", "XYLX");
                    if (gzname.indexOf('IF') < 0) { gzcode = gzcode.replace("LX", ""); }
                    var color = rendercolor(list[i].f3, 0)
                    var zxj = list[i].f2 == '-' ? list[i].f2 : (list[i].f2 / Math.pow(10, list[i].f1)).toFixed(list[i].f1)
                    var zdf = list[i].f3 == '-' ? '-' : ((list[i].f3 / 100).toFixed(2) + '%')
                    htm += '<tr><td class="nm"><a href="http://quote.eastmoney.com/gzqh/' + gzcode + '.html" target="_blank">' + gzname + '</a></td><td class="' + color + '">' + zxj + '</td><td class="' + color + '">' + zdf + '</td></tr>'
                }
                $("#gzqhlist").html(htm)
            }
        })
        window.GetGzqhNUM = 0;
    }
}

function loadRank() {
    if (window.GetTimeZoneInfo == true || window.GetRankNUM == 1) {
        var fs = _this._Market == 1 ? 'm:1+t:2+f:!18' :'m:0+t:6+f:!18,m:0+t:13+f:!18,m:0+t:80+f:!18'
        var url = baseUrl + '/api/qt/clist/get?ut=' + ut + '&pi=0&pz=15&po=1&fs='+ fs  +'&fid=f3&fields=f1,f2,f3,f12,f13,f14&invt=2'
        //console.log(url)
        $.ajax({
            url: url,
            dataType: 'jsonp',
            jsonp: 'cb',
            Type: 'get',
            success: function (json) {
                //console.log('涨幅排行>>',json.data.diff)
                var list = json.data.diff
                var htm = ''
                for (var i in list) {
                    var color = rendercolor(list[i].f3, 0)
                    var zxj = list[i].f2 == '-' ? list[i].f2 : (list[i].f2 / Math.pow(10, list[i].f1)).toFixed(list[i].f1)
                    var zdf = list[i].f3 == '-' ? '-' : ((list[i].f3 / 100).toFixed(2) + '%')
                    htm += '<tr><td class="nm"><a href="http://quote.eastmoney.com/' + list[i].f12 + '.html" target="_blank">' + list[i].f14 + '</a></td><td class="' + color + '">' + zxj + '</td><td class="' + color + '">' + zdf + '</td></tr>'
                }
                $("#pylist").html(htm)
            }
        })
        window.GetRankNUM = 0;
    }
}

//行业资金流向图
function loadhyzjlx() {
    var url = baseUrl + '/api/qt/clist/get?pi=0&pz=38&po=1&ut=' + ut + '&fs=m:90+t:2&fid=f62&fields=f1,f2,f3,f12,f13,f14,f62,f152,f128,f204&invt=2'
    $.ajax({
        type: "GET",
        url: url,
        data: null,
        dataType: 'jsonp',
        jsonp: 'cb',
        success: function (res) {
            chart({ data: res.data.diff, appendHTML: "<span class='danwei'>单位：亿元</span><div class='shuoming'><i class='sup'>&nbsp;</i>主力净流入 <i class='sdown'>&nbsp;</i>主力净流出</div>", many: 38 })
        }
    })
}


//研究报告
function yjbgList() {
    // console.log('研究报告');

     //行业研报
    var date = new Date();
    date = new Date(date.setFullYear(date.getFullYear()-2)) ;
    var fields = 'orgCode,orgSName,sRatingName,encodeUrl,title,publishDate';
    var  _url = "http://reportapi.eastmoney.com/report/list?beginTime="+ formateDate(date,"yyyy-MM-dd")+"&endTime="+ formateDate(new Date(),"yyyy-MM-dd")+"&pageNo=1&pageSize=4&qType=1&industryCode=*&fields="+ fields;
    var that = this;
    var html = '<tr><td align="center">机构</td><td align="center">评级</td><td class="text-indent10">研报</td></tr>';
    getNewReportUrl(_url,function(data){
        for(var i = 0;i<data.length;i++){
            var item = data[i];
            html += '<tr style="line-height:25px;"><td align="center"><a target="_blank" href="http://data.eastmoney.com/report/orgpublish.jshtml?orgcode='+item.orgCode+'" class="lightBlue" title="'+item.orgSName+'">'+ txtPoint(item.orgSName) +'</a></td>'+
                        '<td align="center"><span>'+ txtPoint(item.sRatingName) +'</span></td>'+
                        '<td class="text-indent10"><span class="dt">'+ formateDate(item.publishDate,"MM-dd")+'</span><a target="_blank" href="http://data.eastmoney.com/report/zw_industry.jshtml?encodeUrl=' + item.encodeUrl +'" title="'+item.title+' ">'+cutstr(item.title,22)+'</a></td></tr>'
    }
    $("#hyybTable tbody").html(html)

        },function(){
            html += "<tr><td colspan=\"3\"><span class=\"nodatalist\">暂无数据</span></td></tr>";
            $("#hyybTable tbody").html(html)
        })

}

//截取字数长度 大于四字则截取
function txtPoint(value) {
    var len = value.length,
        charCode = -1,
        realLength = 0
        strChar=[];
    
    if (len > 4) {
        value = value.substr(0,4) + '..';
    }

    return value
}

//
function formateDate(date, fmt) {
            fmt = fmt || "yyyy-MM-dd HH:mm:ss"
            if (typeof date === "string")
                date = new Date(date.replace(/-/g, '/').replace('T', ' ').split('+')[0]);
            var o = {
                "M+": date.getMonth() + 1, //月份         
                "d+": date.getDate(), //日         
                "h+": date.getHours() % 12 == 0 ? 12 : date.getHours() % 12, //小时         
                "H+": date.getHours(), //小时         
                "m+": date.getMinutes(), //分         
                "s+": date.getSeconds(), //秒         
                "q+": Math.floor((date.getMonth() + 3) / 3), //季度         
                "S": date.getMilliseconds() //毫秒         
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[date.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
}


//获取新版研报接口
function getNewReportUrl(url,sucess,fail){
    $.ajax({
        url:url,
        dataType: "jsonp",
        scriptCharset: "utf-8",
        jsonp:"cb",
        jsonpCallback:'callback' + Math.floor(Math.random() * 10000000 + 1)
    }).done(function(json){
        try{
            if(json && json.data && json.data.length){
                sucess &&sucess(json.data)
            }else{
                fail && fail()
            }
        }catch(error){
           console && console.log(error)
            fail && fail()
        }
    }).fail(function(error){
        console && console.log(error)
        fail && fail()
    })
}


function loadKuaiXun() {
    clearInterval(window.kxst); countRDown(60);
    var sjs = Math.random().toString().replace('.', '');
    var padRight = window.GetKX == 1 ? "" : "&id=" + window.GetKXMaxID;
    jQuery.ajax({
        url: "http://newsapi.eastmoney.com/kuaixun/v2/api/list?column=zhiboall&limit=50" + padRight,
        dataType: "jsonp",
        scriptCharset: "utf-8",
        jsonpCallback: "callback" + sjs,
        success: function (json) {
            if (json.rc = 1) {
                var info = json.news;
                var html = "";
                for (var i = 0; i < info.length; i++) {
                    var TopZbStr = "";
                    if (i == 0) { TopZbStr = '<span class="dt">' + gethhmm(info[i].showtime) + '</span><span class="t">' + info[i].title + '</span>'; }
                    if (info[i].newstype == 1) {//news.
                        html += '<li><span class="kx_itime">' + gethhmm(info[i].showtime) + '</span><span class="kx_itime_end">|</span><span class="bd_i_txt' + kxgetstyle(info[i].titlestyle) + '"><a href="' + info[i].url_unique + '" target="_blank">';
                        if (info[i].digest != "") { html += info[i].digest.replace(/\n+/g, "<br />"); } else { html += info[i].title; }
                        html += '&nbsp;[点击查看全文]</a></span></li>';
                        if (i == 0) { TopZbStr = '<span class="dt">' + gethhmm(info[i].showtime) + '</span><span class="t"><a href="' + info[i].url_unique + '" target="_blank">' + info[i].title + '</a></span>'; }
                    }
                    else if (info[i].newstype == 2) {//zhaiyao.
                        html += '<li><span class="kx_itime">' + gethhmm(info[i].showtime) + '</span><span class="kx_itime_end">|</span><span class="bd_i_txt' + kxgetstyle(info[i].titlestyle) + '">' + info[i].digest + '</span></li>';
                    }
                    else {
                        html += '<li><span class="kx_itime">' + gethhmm(info[i].showtime) + '</span><span class="kx_itime_end">|</span><span class="bd_i_txt' + kxgetstyle(info[i].titlestyle) + '"><a href="' + info[i].url_unique + '" target="_blank">' + info[i].title + '&nbsp;>[点击查看全文]</a></span></li>';
                        TopZbStr = '<span class="dt">' + gethhmm(info[i].showtime) + '</span><span class="t"><a href="' + info[i].url_unique + '" target="_blank">' + info[i].title + '</a></span>';
                    }
                    if (i == 0) { $x("ScrollMIIRBox").innerHTML = TopZbStr; window.GetKXMaxID = json.MaxID; }
                }
                var tipstr = info.length == 0 ? "暂无新闻更新" : "刚刚为您更新了" + info.length + "条新闻";
                if (html != "") {
                    if (window.GetKX == 1) { $x("kx_lists").innerHTML = html; } else {
                        $("#kx_lists").prepend(html);
                        $x("tipstr").innerHTML = tipstr;
                        setTimeout(function () { $x("tipstr").innerHTML = "直播中..."; }, 3000)
                    }
                } else {
                    $x("tipstr").innerHTML = "暂无新闻更新";
                    setTimeout(function () { $x("tipstr").innerHTML = "直播中..."; }, 3000)
                }
                window.GetKX = 0;
            }
        }
    });
}

// 全球直播和财富号 轮询
function caifuhao() {
    var timeCount = 0;
    var cfhIndex = 0;

    var list = window.cfhArtilce || [];

    if (list.length > 0) {

        var html = $(".gszb .lox").clone().html();
        // var html1 = $(".gszb .lox").html();
        // var html2 = $(".gszb .rox").html();
        // var newhtml = html1 + html1.replace("lox", "cfh") + html2;

        var html = '<div class="cfh" style="display: none;">' +
            '<div class="tit"><a href="http://caifuhao.eastmoney.com/" target="_blank">财富号</a></div>' +
            '<div class="cnt"><ul><li id="ScrollMIIRBox2"><span class="dt">21:06</span><span class="t"><a href="" target="_blank"></a></span></li></ul></div>' +
            '</div>';

        var clone = $(html);

        $(".gszb .rox").before(clone);

        // 每分钟切换一次
        setInterval(function () {
            if (timeCount % 2 == 0) {
                $(".gszb .lox").hide();
                $(".gszb .cfh").show();
            } else {
                $(".gszb .lox").show();
                $(".gszb .cfh").hide();
            }

            timeCount++;
        }, 60 * 1000);


        setInterval(function () {
            var item = list[cfhIndex];
            var sp1 = $("<span class='dt'></span>").text((item.Showtime || "").substr(10, 6));
            var sp2 = $("<span class='t'><a target='_blank'></a></span>");
            sp2.find("a").attr("href", "http://caifuhao.eastmoney.com/news/" + item.ArtCode).text(item.Title);

            clone.find(".cnt li").html("").append(sp1).append(sp2);
            cfhIndex++;

            cfhIndex = cfhIndex % list.length;
        }, 10 * 1000);
    }

}



function kxgetstyle(titlestyle) {
    //0-默认 1-加粗 2-跳红 3-跳红加粗.
    var res = "";
    switch (titlestyle) {
        case "1": res = " bold"; break;
        case "2": res = " red"; break;
        case "3": res = " redbold"; break;
    }
    return res;
}

function countRDown(secs) {
    $x("kx_auto_sec").innerHTML = secs;
    if (--secs >= 0) { window.kxst = setTimeout("countRDown(" + secs + ")", 1000); }
    else { loadKuaiXun(); }
}

window.countRDown = countRDown

//更新资金流数据
function RefZjlx(zjlcode) {
    //if (window.GetTimeZoneInfo == true || window.GetZjlxNUM == 1) {
    //    var rcode = _this._Market == "1" ? "3990012" : "0000011";
    //    jQuery.ajax({
    //        url: "http://nufm3.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=P.(x),(x)|" + zjlcode + "," + _this._Code + _this._Market + "|" + rcode + "&sty=IFDPFI|IFDPFITA&token=" + token,
    //        dataType: "jsonp",
    //        scriptCharset: "utf-8",
    //        jsonp: 'cb',
    //        success: function (json) {
    //            if (json.length == 3) {
    //                var item = json[0].split(',');
    //                var ritem = json[2].split(',');
    //                var jitem = json[1].split(',');
    //                //$x("hz_a").innerHTML = fmtdigm(item[3] * 10000, 0, "亿元");
    //                //$x("hz_b").innerHTML = fmtdigm(item[4].replace('-', '') * 10000, 0, "亿元");
    //                //$x("hz_c").innerHTML = fmtdigm(ForDight(parseFloat(item[3]) + parseFloat(item[4]), 2) * 10000, 0, "亿元").replace('-', ''); $x("hz_c").className = udcls(ForDight(parseFloat(item[3]) + parseFloat(item[4]), 2));
    //                //$x("hz_c_t").innerHTML = $x("hz_c").className == "green" ? "主力净流出" : "主力净流入";
    //                //$x("hz_d").innerHTML = fmtdigm(Math.abs(item[6]), 0, "-"); $x("hz_e").innerHTML = fmtdigm(Math.abs(item[7]), 0, "-");
    //                //$x("hz_f").innerHTML = fmtdigm(Math.abs(item[8]), 0, "-"); $x("hz_g").innerHTML = fmtdigm(Math.abs(item[9]), 0, "-");
    //                //$x("hz_h").innerHTML = fmtdigm(Math.abs(item[10]), 0, "-"); $x("hz_i").innerHTML = fmtdigm(Math.abs(item[11]), 0, "-");
    //                //$x("hz_j").innerHTML = fmtdigm(Math.abs(item[12]), 0, "-"); $x("hz_k").innerHTML = fmtdigm(Math.abs(item[13]), 0, "-");
    //                //var _l = [[item[6], item[7]], [item[8], item[9]], [item[10], item[11]], [item[12], item[13]]]; ZjlxCek(_l);
    //                ////
                   
    //                //$x("rstocka").innerHTML = "<a href=\"http://quote.eastmoney.com/zs" + ritem[1] + ".html\" target=\"_blank\">" + ritem[2] + "A股行情</a>";
    //                //$x("rstockb").innerHTML = ritem[3] + "&nbsp;&nbsp;" + ritem[4] + "&nbsp;&nbsp;" + ritem[5]; $x("rstockb").className = udcls(ritem[4]);
    //                //
    //            }
    //        }
    //    });
    //    window.GetZjlxNUM = 0;
    //}


    //function percentRender(data) {
    //    if (typeof data === 'number') return data + '%';
    //    if (!isNaN(data) && data.indexOf('%') !== data.length - 1) {
    //        return data + '%';
    //    }
    //    return data;
    //}
}


function getHqStat(stat) {
    var str = "";
    switch (stat) {
        case 1: str = '<b class="red on" title="' + stat + '"></b>集合竞价'; $x("hqstat").className = "hqstat red"; break;
        case 4: str = '<b class="red on" title="' + stat + '"></b>集合竞价'; $x("hqstat").className = "hqstat red"; break;
        case 2: str = '<b class="red on" title="' + stat + '"></b>交易中'; $x("hqstat").className = "hqstat red"; break;
        case 3: str = '<b class="off" title="' + stat + '"></b>午间休市'; break;
        case 5: str = '<b class="off" title="' + stat + '"></b>已收盘'; break;
    }
    $x("hqstat").innerHTML = str;
}

//资金流向数据更新
function ZjlxCek(ls) {
    var _in = 0; var _out = 0; var items = [];
    for (var i = 0; i <= 3; i++) {
        var _l = parseFloat(ls[i][0]) + parseFloat(ls[i][1]);
        $x("hz_" + i + "l").innerHTML = ""; $x("hz_" + i + "r").innerHTML = "";
        if (_l >= 0) {
            _in += Math.abs(parseFloat(_l));
            $x("hz_" + i + "l").innerHTML = "<div class=\"box\" id=\"hz_" + i + "h\"></div><span class=\"red\">" + fmtdigm(_l, 1, "-") + "</span>";
            $x("hz_" + i + "l").style.borderBottom = "1px solid #ccc";
        }
        if (_l < 0) {
            _out += Math.abs(parseFloat(_l));
            $x("hz_" + i + "r").innerHTML = "<div class=\"box\" id=\"hz_" + i + "h\"></div><span class=\"green\">" + fmtdigm(_l, 1, "-") + "</span>";
            $x("hz_" + i + "r").style.borderTop = "1px solid #ccc";
        }
        items[i] = Math.abs(_l);
    }
    var total = _out + _in;
    for (var i = 0; i <= 3; i++) {
        if (items[i] != 0) {
            $x("hz_" + i + "h").style.height = items[i] / total * 36 + "px";
        }
    }
}

function showMore(tp, obj) { var over = $x("xh" + tp + obj).style.display = "block"; }
function hideall(tp, obj) { var over = $x("xh" + tp + obj).style.display = "none"; }

function fmtdig(Data, _Unit) {//数值,阀值，小数位，单位后尾随字符(为-表示不需要)
    var isfs = false;
    if (parseFloat(Data) < 0) { isfs = true; }
    var res = Data; var Unit = "万"; var Fix = 0; var Mat = 10000;
    if (Data != "" && Data != "--" && Data != "-") {
        var _temp = parseFloat(Math.abs(Data));
        if (_temp > 100000000000)//大于千亿
        {
            Mat = 1000000000000; Unit = "万亿"; Fix = 2;
        }
        else if (_temp > 100000000000)//等于千亿
        {
            Mat = 100000000; Unit = "亿"; Fix = 0;
        }
        else if (_temp > 100000000)//大于等于亿
        {
            Mat = 100000000; Unit = "亿"; Fix = 2;
        }
        else if (_temp == 0)//等于0
        {
            Mat = 1; Unit = ""; Fix = 0; _Unit = "-"
        }
        res = ForDight((_temp / Mat), Fix);
    }
    return (isfs ? "-" : "") + res + Unit + (_Unit == "-" ? "" : _Unit);
}

function fmtdigw(Data, Fix, padRight) {//数值 单位固定亿
    var isfs = false;
    if (parseFloat(Data) < 0) { isfs = true; }
    var res = Data; var Mat = 10000;
    if (Data != "" && Data != "--" && Data != "-") {
        var _temp = parseFloat(Math.abs(Data));
        res = ForDight((_temp / Mat), Fix);
    }
    return (isfs ? "-" : "") + res + (padRight == "-" ? "" : padRight);
}

function fmtdigm(Data, Fix, padRight) {//数值 单位固定亿
    var isfs = false;
    if (parseFloat(Data) < 0) { isfs = true; }
    var res = Data; var Mat = 100000000;
    if (Data != "" && Data != "--" && Data != "-") {
        var _temp = parseFloat(Math.abs(Data));
        res = ForDight((_temp / Mat), Fix);
    }
    return (isfs ? "-" : "") + res + (padRight == "-" ? "" : padRight);
}

//时间随机数
function formatm() {
    var now = new Date();
    return now.getDate() + "" + now.getHours() + "" + now.getMinutes() + "";
}

function gethhmm(time) { return time.substr(11, 5); }

//随机数
function GetRandomNum(Min, Max) { var Range = Max - Min; var Rand = Math.random(); return (Min + Math.round(Rand * Range)); }

function showimg() {
    $x("js_box").style.display = "none";
    var c_cn = $x("kx_list").className;
    if (c_cn.indexOf("fz14") > 0) {
        $x("kx_list").className = "kx_list kx_fz14";
    } else {
        $x("kx_list").className = "kx_list";
    }
    $x("image_box").style.display = "block"; window.zxgIsFirst = true; window.quoteIsFirst = true; //Def.DisQuote();
    WriteCookie("em_hq_fls", "old", 99999);
}
window.showimg = showimg

function showjs() {
    $x("js_box").style.display = "block";
    var c_cn = $x("kx_list").className;
    if (c_cn.indexOf("fz14") > 0) {
        $x("kx_list").className = "kx_list kx_fz14 kx_listfls";
    } else {
        $x("kx_list").className = "kx_list kx_listfls";
    }
    $x("image_box").style.display = "none"; window.zxgIsFirst = true; window.quoteIsFirst = true; //Def.DisQuote();
    WriteCookie("em_hq_fls", "js", 99999);
}

window.showjs = showjs

function showfls() {
    $x("flash_box").style.display = "block";
    var c_cn = $x("kx_list").className;
    if (c_cn.indexOf("fz14") > 0) {
        $x("kx_list").className = "kx_list kx_fz14 kx_listfls";
    } else {
        $x("kx_list").className = "kx_list kx_listfls";
    }
    $x("image_box").style.display = "none"; window.zxgIsFirst = true; window.quoteIsFirst = true; Def.DisQuote();
    WriteCookie("em_hq_fls", "new", 99999);
    var picrtr = $x("actTab1").getElementsByTagName("span");
    var picrtk = $x("actTab2").getElementsByTagName("span");
    for (var i = 2; i < picrtr.length; i++) {
        if (picrtr[i].className == "cur") {
            setTimeout(function () { stockr.selectDay(i - 1); }, 200);
            break;
        }
    }
    for (var j = 0; j < picrtk.length; j++) {
        if (picrtk[j].className == "cur") {
            setTimeout(function () { stock.kMT = false; stock.FlashObj.selectButton(j + 1, 10); }, 2000);
            break;
        }
    }
}

window.hotpersonafp = function hotpersonafp(uid, oid, marketcode) {
    var iscks = false;
    if (GetCookie("pi")) {
        var gcks = Getcks("pi");
        if (gcks.split(';').length >= 3) {
            var name = gcks.split(';')[2];
            if (/^[\u4E00-\u9FA5][0-9a-zA-Z]{6}$/g.test(name)) { iscks = true; }
            else {
                var url = "http://iguba.eastmoney.com/action.aspx?callback=&action=oaddfollowperson&uid2=" + uid;
                Min.Loader.load(url + "&v=" + formatm(), "utf-8", function () {
                    oid.className = "allow"; oid.innerHTML = ""; oid.onclick = null;
                });
            }
        }
        else { iscks = true; }
    }
    else { iscks = true; }
    if (iscks) {
        location.href = "https://passport2.eastmoney.com/pub/login?backurl=" + location.href;
    }
}


function getdomain(min, max) {
    var min = 1; var max = 10;
    var res = "nufm3.dfcfw.com"; var m2 = "nufm2.dfcfw.com";
    var rom = GetRandomNum(min, max);
    if (rom != "1" && rom != "2" && rom != "3") { res = m2; }//80% ->nufm2
    //if (rom == "1") { res = m2; }//10% ->nufm2
    return res;
}

function removeAllChild(obj) {
    var div = $x(obj);
    while (div.hasChildNodes()) //当div下还存在子节点时 循环继续
    {
        div.removeChild(div.firstChild);
    }
}


window.onload = function () {
    setTimeout(function () {
        caifuhao();
    }, 500);
}
