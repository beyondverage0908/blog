/**
 * 日志模块
 */

import winston from "winston"
import dailyrotatefile from "winston-daily-rotate-file"
const config = require('../../../config/index.js')

const { combine, timestamp, label, printf } = winston.format

const log_transport = new dailyrotatefile({
  filename: config.getEnvParam('log_folder') + 'log-%DATE%.log',
  datePattern: 'YYYY-MM-DD-HH',
  zippedArchive: false,
  maxSize: '20m',
  maxFiles: '14d'
})

const error_transport = new dailyrotatefile({
  filename: config.getEnvParam('log_folder') + 'error-%DATE%.log',
  datePattern: 'YYYY-MM-DD-HH',
  zippedArchive: false,
  maxSize: '20m',
  maxFiles: '14d'
})

const logFormat = printf(({ level, message, label, timestamp }) => {
  return JSON.stringify({
    time: timestamp,
    message: message
  })
})

const log_logger = winston.createLogger({
  format: combine(
    label({ label: 'info' }),
    timestamp(),
    logFormat
  ),
  transports: [
    log_transport
  ]
})

const errorFormat = printf(({ level, message, label, timestamp }) => {
  return JSON.stringify({
    time: timestamp,
    message: message
  })
})

const error_logger = winston.createLogger({
  format: combine(
    label({ label: 'error' }),
    timestamp(),
    errorFormat
  ),
  transports: [
    error_transport
  ]
})


export default {
  /**
   * 信息日志
   */
  info(message:any){
    if(process.env.NODE_ENV == 'development'){
      console.info(new Date().toLocaleString())
      console.info(message)
    }
    if (!config.getEnvParam('log_enabled')) {
      return false
    }
    log_logger.info(message)
  },
  /**
   * 报错日志
   */
  error(message:any){
    if(process.env.NODE_ENV == 'development'){
      console.info(new Date().toLocaleString())
      console.error(message)
    }
    if (!config.getEnvParam('log_enabled')) {
      return false
    }
    if (message instanceof Error) {
      error_logger.error({
        error_message: message.message,
        name: message.name,
        stack: message.stack
      })
    }
    else{
      error_logger.error(message)
    }
    
  }
}