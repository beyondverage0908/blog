var path = require('path')
var webpack = require('webpack')
const glob = require('glob')

let jslist = glob.sync('./jssrc/*.ts')
let entrylist = {}
jslist.forEach(v=>{
  let name = path.basename(v, '.ts')
  entrylist[name] = v
})



module.exports = {
  entry: entrylist,
  output: {
    path: path.resolve(__dirname, './public/newstatic/js/'),
    filename: '[name].js'
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: {
          loader: 'ts-loader',
          options:{
            configFile: 'fe_tsconfig.json'
          }
        },

      },
      {
        test: /\.(html|ejs|art)$/,
        use: 'raw-loader'
      },
      {
        test: /\.(jpg|gif|png)$/i,
        use: [{
            loader: 'url-loader',
            options: {
                limit: 80000
            }
        }]
      }
    ]
  },
  resolve: {
    extensions: ['.ts', '.js', '.json']
  },
  externals: {
    jquery: "jQuery",
    lodash: "_"
  },
  mode: 'development',
  devtool: 'source-map'
}