module.exports = {
  development: {
    log_enabled: true, //是否激活写日志
    log_folder: '../logs/quote2019/', //日志文件夹
    page_cache_enabled: false, //是否开启页面缓存
    api_cache_enabled: false, //是否开始接口缓存
    cache_file_path: '../cache/quote2019/', //落地缓存文件夹
    cmsapi: 'http://cmsdataapi.eastmoney.com/', //资讯 刘涛
    quoteapi: 'http://push2.eastmoney.com/', //行情 杨向东
    voteapi: 'http://gwapi.dfcfw.com/', //投票数据
    ltgdapi:'http://wfcn.eastmoney.com/',//十大股东 崔志强
    cfh_articles: 'https://mycaifuhao.eastmoney.com/channel/Api/getarticlesbycolumn', //财富号文章
    sczmapi: 'http://61.152.230.32:1870/', //市场总貌api
    report: 'http://reportapi.eastmoney.com/', //研报api
    bulletin: 'http://bulletin.eastmoney.com/',//布告栏
    newsinfo: 'http://newsinfo.eastmoney.com/', //newsinfo
    newsnotice: 'http://newsnotice.eastmoney.com/', //newsnotice
    guba_api: 'http://gbapi.eastmoney.com/', //股吧接口
    gubawebapi: 'http://gubawebapi.eastmoney.com/', //股吧webapi
    nuexd: 'http://nuexd.eastmoney.com/',
    datainterface: 'http://datainterface.eastmoney.com/',
    searchapi: 'https://searchapi.eastmoney.com/',
    fundmobapitest: 'http://fundmobapitest.eastmoney.com/',
    datainterface3: 'http://datainterface3.eastmoney.com/',
    option: 'http://futssetest.eastmoney.com/' //期权接口
  },
  zptest: {
    log_enabled: true,
    log_folder: '../logs/quote2019/',
    page_cache_enabled: true,
    api_cache_enabled: true,
    cache_file_path: '../cache/quote2019/',
    cmsapi: 'http://cmsdataapi.emapd.com/',
    quoteapi: 'http://10.205.242.202/',
    voteapi: 'http://gwapi.em/',
    ltgdapi: 'http://wfcn.emapd.com/',
    cfh_articles: 'http://caifuhaoapi.emapd.com/api/v1/article/article/GetArticlesByColumn',
    sczmapi: 'http://10.205.241.79/', // http://10.205.241.79 周浦内网正式
    report: 'http://reportapi.emapd.com/', //研报api
    bulletin: 'http://bulletin.eastmoney.com/',
    newsinfo: 'http://newsinfo.eastmoney.com/',
    newsnotice: 'http://newsnotice.eastmoney.com/',
    guba_api: 'http://gbapi.em/',
    gubawebapi: 'http://gubawebapi.eastmoney.com/',
    nuexd: 'http://nuexd.eastmoney.com/',
    datainterface: 'http://datainterface.eastmoney.com/',
    searchapi: 'https://searchapi.eastmoney.com/',
    fundmobapitest: 'http://fundmobapitest.eastmoney.com/',
    datainterface3: 'http://datainterface3.eastmoney.com/',
    option: 'http://futssetest.eastmoney.com/' //期权接口
  },
  production: {
    log_enabled: true,
    log_folder: '../logs/quote2019/',
    page_cache_enabled: true,
    api_cache_enabled: true,
    cache_file_path: '../cache/quote2019/',
    cmsapi: 'http://cmsdataapi.emapd.com/',
    quoteapi: 'http://10.205.242.202/',
    voteapi: 'http://gwapi.em/',
    ltgdapi: 'http://wfcn.emapd.com/',
    cfh_articles: 'http://caifuhaoapi.emapd.com/api/v1/article/article/GetArticlesByColumn',
    sczmapi: 'http://10.205.241.79/', // http://10.205.241.79 周浦内网正式
    report: 'http://reportapi.emapd.com/', //研报api
    bulletin: 'http://bulletin.eastmoney.com/',
    newsinfo: 'http://newsinfo.eastmoney.com/',
    newsnotice: 'http://newsnotice.eastmoney.com/',
    guba_api: 'http://gbapi.em/',
    gubawebapi: 'http://gubawebapi.eastmoney.com/',
    nuexd: 'http://nuexd.eastmoney.com/',
    datainterface: 'http://datainterface.eastmoney.com/',
    searchapi: 'https://searchapi.eastmoney.com/',
    fundmobapitest: 'http://fundmobapitest.eastmoney.com/',
    datainterface3: 'http://datainterface3.eastmoney.com/',
    option: 'http://futsse.eastmoney.com/' //期权接口
  },
  getEnvParam: function (name) {
    if (this[process.env.NODE_ENV]) {
      return this[process.env.NODE_ENV][name]
    }
    return this.production[name]
  }
}


