/**
 * 指数页面JS
 */

let quote_phf = require('../src/modules/old_zs/quote_phf');
let HistoryViews = require('../src/modules/old_zs/hisacc');

import gotowap from "../src/modules/gotowap";
declare var kLine:any
declare var newmarket:string
gotowap(kLine.stockCode, newmarket)

var oMarquee = document.getElementById("zhrool");
var iLineHeight = 28;var iLineCount = 1;var iScrollAmount = 1;

setTimeout(function () {

  quote_phf.getIndexQuote(20);

  var arg = { def: "", set: "", lns: 0 };
  var HV = new HistoryViews("historyest", arg);


}, 500); 


/**
 * Modified by zxw on 19-6-6.
 */
window['chart'] = function (opt) {

    var max = Math.abs(opt.data[0].f62) > Math.abs(opt.data[opt.many - 1].f62) ? Math.abs(opt.data[0].f62) : Math.abs(opt.data[opt.many - 1].f62)
    var _w = 15;
    var W = 26;  //减少了两根柱体后+1
    var MM = 80;

    var htm = ''
    for (var i in opt.data) {
        var arrow = opt.data[i].f62 > 0 ? 'up' : 'down'
        var title = (opt.data[i].f62 > 0 ? '主力净流入' : '主力净流出') + '(' + opt.data[i].f14 + '):' + (opt.data[i].f62 / Math.pow(10, 8)).toFixed(2) + "亿元"
        var height = (opt.data[0].f62 == '-' ? 0 : (parseFloat((Math.abs(opt.data[i].f62) / max).toString()) * MM)) + 'px'
        var left = ((1000 - (opt.many - 1) * W - _w) / 2) + parseInt(i) * W + "px"
        var value = opt.data[i].f62=='-'?'-':(Math.abs(opt.data[i].f62) / Math.pow(10, 8)).toFixed(2)
        var bkname = opt.data[i].f14
        var bkcode = opt.data[i].f12.slice(3)
        htm += '<div class="' + arrow + '" title="' + title + '" style="height:' + height + '; left: ' + left + '"><span>' + value + '</span><div class="i"><a target="_blank" href="http://data.eastmoney.com/bkzj/'+bkcode+'.html">' + bkname+'</a></div></div>'
    }
    htm += opt.appendHTML
    $("#hqzschart .chart").html(htm) 
}

require('../src/modules/old_zs/quote_min')
require('../src/modules/old_zs/fucs_min')
require('../src/modules/old_zs/data_min')
require('../src/modules/old_zs/emchart_min')