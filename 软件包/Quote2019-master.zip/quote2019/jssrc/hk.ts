/**
 * 港股行情
 */

import gotowap from "../src/modules/gotowap";
gotowap(stockcode, MktNum)

var page = require("../src/modules/old_hk/em.hkstocks.l2");
var a = require("../src/modules/old_hk/agiotage_tasks");
require('../src/modules/old_hk/historyviews')

declare var stockcode: string
declare var MktNum:string
declare var suggest2017:any

new page(stockcode).pageInit();
try {
    new suggest2017({
        inputid: "StockCode",
        offset: { left: -91, top: 5 },
        shownewtips: true,
        newtipsoffset: { top: -3, left: 0 }
    });


    // new addmystock({
    //     code: stockcode,
    //     market: MktNum
    // });

} catch (e) {
    console.error(e);
}

var qphf = require('../src/modules/old_hk/qphf')
setTimeout(function () {
    qphf.getIndexQuote(20);
}, 500);
