/**
 * 外汇 人民币汇率中间价
 */

import gotowap from "../src/modules/gotowap";
declare var stockcode:string
declare var newmarket:string
gotowap(stockcode, newmarket)

require('../src/modules/old_cnyrate/main')