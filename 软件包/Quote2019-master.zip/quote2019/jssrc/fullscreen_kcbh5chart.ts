/**
 * 全屏页面 科创板-kcbh5chart JS
 */

require('../src/modules/old_fullscreen/kcbh5chart')