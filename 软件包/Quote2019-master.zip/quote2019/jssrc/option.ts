/**
 * 期货 主JS
 */

require('../src/modules/old_option/stock')
