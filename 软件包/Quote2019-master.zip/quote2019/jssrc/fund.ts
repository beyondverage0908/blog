/**
 * 基金js
 */

import gotowap from "../src/modules/gotowap";
declare var stockEnity:any
gotowap(stockEnity.stockCode, stockEnity.MktNum)

require('../src/modules/old_fund/fundstock')