/**
 * 全屏页面-full
 */

var resize = require("../src/modules/old_fullscreen/common/resize");
var hkscripts = require('../src/modules/old_fullscreen/hk')
var aindex = require('../src/modules/old_fullscreen/aindex')
var bk = require('../src/modules/old_fullscreen/bk')
var us = require('../src/modules/old_fullscreen/us')

resize(); //后期改过来
// 用于加载不同的js
; (function () {

    var str = location.search.substr(1);
    var arr = str.split("&");

    var obj = {
      mcid: '',
      market: '',
      code: ''
    };
    for (var i = 0, len = arr.length; i < len; i++) {
        var ar = arr[i].split("=");
        obj[ar[0]] = ar[1];
    }

    if (obj.mcid) {
        var temp = obj.mcid.split(".");
        obj.market = temp[0];
        obj.code = temp[1];
    }


    var market = obj.market;
    var js = "";

    switch (market) {
        case "1":
        case "0":
            js = "aindex";
            aindex()
            break;
        case "90":
            js = "bk";
            bk()
            break;
        case "116":
            js = "hk";
            hkscripts()
            break;
        case "105":
        case "106":
        case "107":
            js = "us";
            us()
            break;
    }

    $("body").addClass('body_' + js)

    // if (location.href.indexOf("http://127") >= 0) {
    //     $.getScript("../dist/" + js + ".js");
    // } else if(location.href.indexOf("hqtest") > 0 || location.href.indexOf("quotationtest")>0 ) {
    //     $.getScript("http://hqtest.eastmoney.com/web/Content/js/static/dist/" + js + ".js")       
    // } else if(location.href.indexOf("quote") > 0 ) {
        // $.getScript("http://hqres.eastmoney.com/EMQuote_Basic/2018/js/dist/" + js + ".js")    //上线前确认下地址
    // }
    
   //$.getScript("../newstatic/js/fullscreen_full_hk.js") 


})();