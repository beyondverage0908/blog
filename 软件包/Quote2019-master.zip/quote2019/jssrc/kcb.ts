/**
 * 科创板主JS
 */

import gotowap from "../src/modules/gotowap";

declare var stockEnity:any

gotowap(stockEnity.Code, stockEnity.MktNum)