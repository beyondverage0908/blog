/**
 * 全屏页面-h5chart JS
 */

require('../src/modules/old_fullscreen/h5chart')