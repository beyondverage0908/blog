declare var emchartPiechartNew:any
declare var StockMarket_10:string
declare var StockCode:string
declare var emchartLinechartNew:any
declare var stockEnity:any

import gotowap from "../src/modules/gotowap";
declare var stockEnity:any
gotowap(stockEnity.stockCode, stockEnity.MktNum)

if (document.createElement('canvas').getContext != undefined) {
  // 资金流饼图初始化
  var pieChart = new emchartPiechartNew({
      boxid: 'pe_zjl_chart',
      width: 325,
      height: 250,
      radius: 80,
      secid: stockEnity.fullcode 
  }).init();

  //资金流实时图

  var kline = new emchartLinechartNew({
      boxid: 'pq_zjl_chart',
      width: 620,
      height: 240,
      panhou: false,
      sceid: stockEnity.fullcode,
      showdanwei: false
  })

  /**
   * 盘后资金流
   */
  var panhou = new emchartLinechartNew({
      boxid: 'ph_zjl_chart',
      width: 620,
      height: 240,
      panhou: true,
      sceid: stockEnity.fullcode,
      showdanwei: false
  })  
}
else{
  // $('#zjlbchart').hide()
  // $('#zjlsschart').hide()
  // $('#zjlphchart').hide()
}


require('../src/modules/old_b/index')