/**
 * 外汇主JS
 */

import gotowap from "../src/modules/gotowap";
declare var kLine:any
declare var newmarket:string
gotowap(kLine.stockCode, newmarket)

require('../src/modules/old_forex/main')